"""
utils/procesador_senal.py
-------------------------
Pipeline principal que integra:
- datos históricos (obtener_datos_con_fallback)
- indicadores técnicos (agregar_indicadores_tecnicos)
- sentimiento (SentimentAnalyzer)
- modelo IA (predecir_senal)
- guardado en DB y notificación por Telegram

Exporta:
- procesar_senal(activo, usuario, usar_avanzado, umbral_emitir, enviar_telegram_flag)
- _estrategia_agresiva(df)  (mantengo la versión simple que ya tenías)
"""

import pandas as pd
from datetime import datetime, timedelta
import numpy as np

from utils.data_fetcher import obtener_datos_con_fallback as obtener_datos_historicos
from utils.indicadores_tecnicos import agregar_indicadores_tecnicos, tendencia_mercado
from utils.sentiment_analyzer import SentimentAnalyzer
from utils.db_handler import guardar_en_base_datos
from utils.telegram_client import send_telegram_alert
from utils.modelo import predecir_senal
from utils.logger import log_error, log_warning, log_info

def _estrategia_agresiva(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in ["open","high","low","close","volume"]:
        if col not in df.columns:
            df[col] = np.nan
    try:
        df["ma_fast"] = df["close"].rolling(window=5, min_periods=1).mean()
        df["ma_slow"] = df["close"].rolling(window=15, min_periods=1).mean()
        df["long_signal"] = df["ma_fast"] > df["ma_slow"]
    except Exception:
        df["long_signal"] = False
    try:
        df["soporte"] = df["low"].rolling(window=20, min_periods=1).min()
        df["resistencia"] = df["high"].rolling(window=20, min_periods=1).max()
    except Exception:
        df["soporte"] = np.nan
        df["resistencia"] = np.nan
    try:
        delta = df["close"].diff()
        gain = delta.clip(lower=0).rolling(window=14, min_periods=1).mean()
        loss = -delta.clip(upper=0).rolling(window=14, min_periods=1).mean()
        rs = gain / (loss + 1e-9)
        df["rsi"] = 100 - (100 / (1 + rs))
        df["ema12"] = df["close"].ewm(span=12, adjust=False).mean()
        df["ema26"] = df["close"].ewm(span=26, adjust=False).mean()
        df["macd"] = df["ema12"] - df["ema26"]
        df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
    except Exception:
        df["rsi"] = np.nan
        df["macd"] = np.nan
        df["macd_signal"] = np.nan
    return df

def procesar_senal(
    activo: str,
    usuario: str = "desconocido",
    usar_avanzado: bool = True,
    umbral_emitir: float = 0.75,
    enviar_telegram_flag: bool = True
):
    try:
        df = obtener_datos_historicos(activo, interval="1h", mercado="spot", min_rows=200)
        if df is None or df.empty:
            return {"accion_ia": "hold", "precision": 0.0}, "sin_datos", [], None, 0

        df_ind = agregar_indicadores_tecnicos(df)
        tendencia = tendencia_mercado(df_ind)

        rsi = df_ind["rsi"].iloc[-1] if "rsi" in df_ind else None
        macd = df_ind["macd"].iloc[-1] if "macd" in df_ind else None
        macd_signal = df_ind["macd_signal"].iloc[-1] if "macd_signal" in df_ind else None
        soporte = df_ind["low"].tail(20).min() if not df_ind.empty else None
        resistencia = df_ind["high"].tail(20).max() if not df_ind.empty else None
        volumen_fuerte = (df_ind["volume"].iloc[-1] > df_ind["volume"].mean() * 1.5) if "volume" in df_ind else False

        accion, precision, hora_iso, duracion, pred_precios = predecir_senal(df_ind, activo=activo, pasos=20, futuros=4, modo_agresivo=not usar_avanzado)
        accion_ia = accion.lower() if accion else "buy"  # ✅ default BUY
        traducciones = {"buy": "Compra", "sell": "Venta"}
        accion_ia_txt = traducciones.get(accion_ia, "Compra")

        sa = SentimentAnalyzer()
        sentimiento = sa.get_market_sentiment(activo)

        conclusion = f"IA sugiere **{accion_ia.upper()}** con confianza {confianza*100:.2f}%."
        conclusion += f"\n📊 Tendencia: {tendencia}"
        conclusion += f"\n📰 Sentimiento mercado: {sentimiento}"
        if volumen_fuerte:
            conclusion += " (volumen fuerte detectado)"

        hora_entrada = (datetime.strptime(hora_iso, "%Y-%m-%dT%H:%M:%S") if hora_iso else datetime.now() + timedelta(minutes=5))

        data_db = {
            "fecha": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "activo": activo,
            "mercado": "binance",
            "precision": confianza,
            "ia_prediccion": accion_ia,
            "conclusion": conclusion,
            "precio_actual": float(df_ind["close"].iloc[-1]),
            "soporte": soporte,
            "resistencia": resistencia,
            "rsi": rsi,
            "macd_signal": macd_signal,
            "tendencia": tendencia,
            "volumen_fuerte": volumen_fuerte,
            "sl": soporte * 0.98 if soporte else None,
            "tp1": resistencia * 0.5 if resistencia else None,
            "tp2": resistencia * 0.75 if resistencia else None,
            "tp3": resistencia if resistencia else None,
            "tp4": resistencia * 1.1 if resistencia else None,
        }
        try:
            guardar_en_base_datos(data_db)
        except Exception as e:
            log_warning(f"Guardar DB falló: {e}", archivo="procesador_senal.py", funcion="procesar_senal")

        if enviar_telegram_flag:
            try:
                mensaje = (
                    f"📊 *Nueva señal detectada*\n"
                    f"📈 Activo: {activo}\n"
                    f"🤖 Acción IA: *{accion_ia.upper()}*\n"
                    f"🎯 Confianza: {confianza*100:.2f}%\n\n"
                )
                mensaje += f"   • RSI: {rsi:.2f}\n" if rsi is not None else "   • RSI: -\n"
                mensaje += f"   • MACD: {macd:.4f}\n" if macd is not None else "   • MACD: -\n"
                mensaje += f"   • Señal MACD: {macd_signal:.4f}\n" if macd_signal is not None else "   • Señal MACD: -\n"
                mensaje += f"   • Tendencia: {tendencia}\n"
                mensaje += f"   • Soporte: {soporte if soporte else '-'}\n"
                mensaje += f"   • Resistencia: {resistencia if resistencia else '-'}\n"
                mensaje += f"⏰ Hora estimada entrada: {hora_entrada.strftime('%H:%M:%S')}\n"
                mensaje += f"🕒 Duración estimada: {duracion} min"
                send_telegram_alert(mensaje)
            except Exception as e:
                log_warning(f"Enviar Telegram falló: {e}", archivo="procesador_senal.py", funcion="procesar_senal")

        resultado = {
            "accion_ia": accion_ia,
            "precision": confianza,
            "df_velas": df_ind,
            "rsi": rsi,
            "macd": macd,
            "macd_signal": macd_signal,
            "tendencia": tendencia,
            "soporte": soporte,
            "resistencia": resistencia,
            "volumen_fuerte": volumen_fuerte,
        }
        return resultado, conclusion, pred_precios, hora_entrada, duracion

    except Exception as e:
        log_error(e, archivo="procesador_senal.py", funcion="procesar_senal")
        return {"accion_ia": "hold", "precision": 0.0}, "error", [], None, 0
