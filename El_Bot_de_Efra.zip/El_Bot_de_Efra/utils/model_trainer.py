# ==========================================================
# utils/model_trainer.py
# ==========================================================
# Entrenador de modelos LSTM y auxiliares de preprocesamiento
# para trading. Incluye escalado persistente, manejo robusto
# de errores y compatibilidad multi-activos.
# ==========================================================

import os
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

from sklearn.preprocessing import MinMaxScaler
import joblib

from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras import Input

from utils.logger import log_error, log_info, log_warning

# ------------------------------
# Configuración global
# ------------------------------
DATA_DIR = Path("data_historica")
MODELOS_DIR = Path("modelos_entrenados")
SCALERS_DIR = DATA_DIR / "scalers"

MODELOS_DIR.mkdir(parents=True, exist_ok=True)
SCALERS_DIR.mkdir(parents=True, exist_ok=True)

DATE_FMT = "%Y-%m-%d %H:%M:%S"
DATE_FMT_ISO = "%Y-%m-%dT%H:%M:%S"

# ------------------------------
# Helpers para normalizar activos
# ------------------------------
def _norm_activo(activo: str) -> str:
    """Normaliza el símbolo del activo para consistencia en guardado."""
    if not activo or not isinstance(activo, str):
        raise ValueError("El parámetro 'activo' es obligatorio y debe ser str.")
    return activo.strip().upper()

def _scaler_path(activo: str) -> str:
    sym = _norm_activo(activo) if activo else "GEN"
    return str(SCALERS_DIR / f"{sym}_scaler.pkl")

def guardar_scaler(activo, scaler):
    """Guarda el scaler asociado a un activo."""
    try:
        joblib.dump(scaler, _scaler_path(activo))
        return True
    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="guardar_scaler")
        return False

def cargar_scaler(activo):
    """Carga el scaler asociado a un activo si existe."""
    try:
        path = _scaler_path(activo)
        if os.path.exists(path):
            return joblib.load(path)
    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="cargar_scaler")
    return None

# ==========================================================
# 🧠 Preparación de datos LSTM
# ==========================================================
def preparar_datos_lstm(df, pasos=20, activo=None):
    """
    Prepara secuencias para entrenamiento/predicción LSTM.
    
    Retorna:
        - X: shape (muestras, pasos, 1)
        - y: shape (muestras, 1)
        - scaler: MinMaxScaler entrenado
    
    Si no hay suficientes datos, retorna arrays vacíos y scaler=None.
    """
    try:
        if df is None or df.empty:
            log_warning("DataFrame vacío en preparar_datos_lstm",
                        archivo="model_trainer.py", funcion="preparar_datos_lstm")
            return np.array([]), np.array([]), None

        if "close" not in df.columns:
            log_error("Falta columna 'close' en DataFrame",
                      archivo="model_trainer.py", funcion="preparar_datos_lstm")
            return np.array([]), np.array([]), None

        df = df.dropna(subset=["close"]).copy()

        if len(df) < pasos + 1:
            log_warning(f"Datos insuficientes: {len(df)} filas (mínimo {pasos+1})",
                        archivo="model_trainer.py", funcion="preparar_datos_lstm")
            return np.array([]), np.array([]), None

        data = df[["close"]].values.astype(float)
        scaler = MinMaxScaler()
        scaled = scaler.fit_transform(data)

        X, y = [], []
        for i in range(len(scaled) - pasos):
            seq_x = scaled[i : i + pasos]
            seq_y = scaled[i + pasos]
            if seq_x.shape[0] == pasos:
                X.append(seq_x)
                y.append(seq_y)

        if not X or not y:
            log_warning("No se pudieron generar secuencias LSTM",
                        archivo="model_trainer.py", funcion="preparar_datos_lstm")
            return np.array([]), np.array([]), None

        X, y = np.array(X), np.array(y)
        if y.ndim == 1:
            y = y.reshape(-1, 1)
        if X.ndim == 2:
            X = X.reshape((X.shape[0], X.shape[1], 1))

        return X, y, scaler

    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="preparar_datos_lstm")
        return np.array([]), np.array([]), None

# ==========================================================
# 🧠 Entrenamiento y guardado de modelo LSTM
# ==========================================================
def entrenar_y_guardar_modelo(df, pasos=20, futuros=5, activo=None,
                              epochs=20, batch_size=32):
    """
    Entrena un modelo LSTM desde cero y lo guarda en /modelos_entrenados.
    """
    try:
        if df is None or df.empty:
            log_error("DataFrame vacío en entrenamiento",
                      archivo="model_trainer.py", funcion="entrenar_y_guardar_modelo")
            return None, None

        if "close" not in df.columns:
            log_error("Falta columna 'close' en DataFrame",
                      archivo="model_trainer.py", funcion="entrenar_y_guardar_modelo")
            return None, None

        X, y, scaler = preparar_datos_lstm(df, pasos=pasos, activo=activo)
        if X.size == 0 or y.size == 0 or scaler is None:
            log_error("No se pudo preparar datos LSTM (arrays vacíos)",
                      archivo="model_trainer.py", funcion="entrenar_y_guardar_modelo")
            return None, None

        if X.ndim == 2:
            X = X.reshape((X.shape[0], X.shape[1], 1))
        if y.ndim == 1:
            y = y.reshape(-1, 1)

        model = Sequential([
            Input(shape=(pasos, 1)),
            LSTM(64, return_sequences=True),
            Dropout(0.2),
            LSTM(32),
            Dropout(0.2),
            Dense(1, activation="linear")
        ])
        model.compile(optimizer="adam", loss="mse")
        model.fit(X, y, epochs=epochs, batch_size=batch_size, verbose=0)

        sym = _norm_activo(activo) if activo else "GEN"
        model_path = MODELOS_DIR / f"{sym}_lstm.keras"
        try:
            model.save(model_path, overwrite=True)
            guardar_scaler(sym, scaler)
            log_info(f"Modelo LSTM guardado: {model_path}",
                     archivo="model_trainer.py", funcion="entrenar_y_guardar_modelo")
        except Exception as e:
            log_error(e, archivo="model_trainer.py",
                      funcion="entrenar_y_guardar_modelo_save")

        return model, scaler

    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="entrenar_y_guardar_modelo")
        return None, None

# ==========================================================
# 🔄 Compatibilidad: cargar_modelo y predecir_senal
# ==========================================================
def cargar_modelo(activo=None, pasos=20):
    """Carga un modelo entrenado desde /modelos_entrenados."""
    try:
        if not activo:
            log_error("cargar_modelo llamado sin activo",
                      archivo="model_trainer.py", funcion="cargar_modelo")
            return None

        sym = _norm_activo(activo)
        model_path_keras = MODELOS_DIR / f"{sym}_lstm.keras"
        model_path_h5 = MODELOS_DIR / f"{sym}_lstm.h5"

        if model_path_keras.exists():
            return load_model(model_path_keras, compile=False)
        elif model_path_h5.exists():
            return load_model(model_path_h5, compile=False)
        else:
            log_warning(f"No se encontró modelo para {sym}",
                        archivo="model_trainer.py", funcion="cargar_modelo")
            return None
    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="cargar_modelo")
        return None

# ==========================================================
# 🔮 Predicción de señal con LSTM + fallback agresivo
# ==========================================================
def predecir_senal(df, activo=None, pasos=5, futuros=5, modo_agresivo=True):
    """
    Predice una señal usando un modelo entrenado (si existe) o entrena uno nuevo.
    Devuelve (accion, precision, hora_entrada_iso, duracion_min, predicciones).
    """
    try:
        if not activo or df is None or df.empty:
            return "hold", 0.0, None, 0, []

        if "close" not in df.columns:
            log_error("DataFrame sin columna 'close'",
                      archivo="model_trainer.py", funcion="predecir_senal")
            return "hold", 0.0, None, 0, []

        MIN_FILAS = pasos if modo_agresivo else 200
        if len(df) < MIN_FILAS:
            log_warning(f"Datos insuficientes: requeridos ≥{MIN_FILAS}, hay {len(df)}",
                        archivo="model_trainer.py", funcion="predecir_senal")
            return "hold", 0.0, None, 0, []

        sym = _norm_activo(activo)
        model = cargar_modelo(sym, pasos=pasos)

        if model is None:
            model, scaler = entrenar_y_guardar_modelo(df, pasos=pasos,
                                                      futuros=futuros, activo=sym)
            if model is None or scaler is None:
                return "hold", 0.0, None, 0, []
        else:
            X, y, scaler = preparar_datos_lstm(df, pasos, activo=sym)
            if X.size == 0 or y.size == 0 or scaler is None:
                return "hold", 0.0, None, 0, []
            if len(X.shape) == 2:
                X = X.reshape((X.shape[0], X.shape[1], 1))
            model.compile(optimizer="adam", loss="mse")

        ultimos_vals = df[["close"]].values.astype(float)
        if len(ultimos_vals) < pasos:
            return "hold", 0.0, None, 0, []

        ultimos_pasos = scaler.transform(ultimos_vals)[-pasos:].reshape((pasos, 1))
        predicciones_scaled = []

        for _ in range(futuros):
            entrada = ultimos_pasos.reshape((1, pasos, 1))
            pred = model.predict(entrada, verbose=0)
            pred_scalar = float(pred[0, 0])
            predicciones_scaled.append(pred_scalar)
            ultimos_pasos = np.vstack([ultimos_pasos[1:], [[pred_scalar]]])

        if not predicciones_scaled:
            return "hold", 0.0, None, 0, []

        predicciones = scaler.inverse_transform(
            np.array(predicciones_scaled).reshape(-1, 1)
        ).flatten()

        if len(predicciones) < 2:
            return "hold", 0.0, None, 0, []

        tendencia = np.sign(np.diff(predicciones))
        if tendencia[0] > 0:
            accion = "buy"
        elif tendencia[0] < 0:
            accion = "sell"
        else:
            accion = "hold"

        duracion = int((tendencia == tendencia[0]).sum())
        hora_entrada_iso = datetime.now().strftime(DATE_FMT_ISO)

        return accion, 0.8, hora_entrada_iso, duracion, predicciones.tolist()

    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="predecir_senal")
        return "hold", 0.0, None, 0, []

# ==========================================================
# 🧩 Aliases de compatibilidad para app.py
# ==========================================================
def entrenar_modelo_lstm(df, activo=None, pasos=20, futuros=5, epochs=20, batch_size=32):
    """Alias legacy: usa entrenar_y_guardar_modelo bajo el nombre antiguo."""
    return entrenar_y_guardar_modelo(
        df=df,
        pasos=pasos,
        futuros=futuros,
        activo=activo,
        epochs=epochs,
        batch_size=batch_size
    )

def evaluar_modelo_lstm(df, activo=None, pasos=20, futuros=5):
    """Alias legacy: evaluación simple de modelo LSTM."""
    try:
        accion, precision, hora_iso, duracion, preds = predecir_senal(
            df, activo=activo, pasos=pasos, futuros=futuros
        )
        return dict(
            accion=accion,
            precision=precision,
            hora=hora_iso,
            duracion=duracion,
            predicciones=preds
        )
    except Exception as e:
        log_error(e, archivo="model_trainer.py", funcion="evaluar_modelo_lstm")
        return dict(accion="hold", precision=0.0, hora=None, duracion=0, predicciones=[])

# ==========================================================
# 🧩 Alias extra para compatibilidad (guardar_modelo)
# ==========================================================
from utils.entrenamiento import guardar_modelo as _guardar_modelo_real

def guardar_modelo(model, activo: str):
    """
    Alias legacy de guardar_modelo para compatibilidad con app.py.
    Redirige al guardar_modelo real en entrenamiento.py
    """
    return _guardar_modelo_real(model, activo)

