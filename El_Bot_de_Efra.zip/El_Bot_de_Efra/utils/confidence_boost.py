# ============================================================
# utils/confidence_boost.py
# ------------------------------------------------------------
# 🔹 Ajuste inteligente y responsable de confianza IA
# 🔹 Genera alerta y mensaje Telegram si supera um umbral
# 🔹 Compatible con combinar_senales() y metodologias.py
# ============================================================

import os
from datetime import datetime
from typing import Optional, Tuple

# logger (usas utils.logger en el proyecto)
from utils.logger import log_info, log_warning, log_error

# Intentar PIL solo para generar imagen; si no está, se lo salta
try:
    from PIL import Image, ImageDraw, ImageFont
    _HAS_PIL = True
except Exception:
    _HAS_PIL = False

# Intentar importar helpers de envío (opcionales)
try:
    from telegram_alertas import enviar_telegram, enviar_imagen_telegram
except Exception:
    enviar_telegram = None
    enviar_imagen_telegram = None

# ------------------------------------------------------------
# Parámetros por defecto
# ------------------------------------------------------------
DEFAULTS = {
    "boost_to": 0.93,               # objetivo máximo de confianza por defecto
    "min_high_conf_methods": 3,     # metodologías fuertes requeridas
    "method_conf_threshold": 0.80,  # umbral de confianza alta por método
    "lstm_conf_threshold": 0.78,    # confianza mínima LSTM
    "rf_score_threshold": 0.65,     # score RF (si se usa)
    "consistency_threshold": 0.70,  # coherencia promedio entre métodos
    "stability_threshold": 0.40,    # estabilidad del modelo
    "max_delta": 0.25               # incremento máximo permitido
}

# ------------------------------------------------------------
# Rutas seguras para arte/imagenes
# ------------------------------------------------------------
_ALERT_DIR = os.path.join("data", "secure", "alerts")
os.makedirs(_ALERT_DIR, exist_ok=True)


# ============================================================
# 🎟️ Generador de "ticket" visual (opcional, no crítico)
# ============================================================
def _generate_alert_image(confianza: float, resumen: str = "") -> Optional[str]:
    """
    Genera y guarda una imagen simple que muestra la nueva confianza.
    Retorna ruta del archivo o None si no pudo generarse.
    """
    try:
        if not _HAS_PIL:
            log_warning("Pillow no disponible — omitiendo generación de imagen de alerta",
                        archivo="confidence_boost.py", funcion="_generate_alert_image")
            return None

        img = Image.new("RGB", (680, 260), color=(18, 22, 28))
        draw = ImageDraw.Draw(img)

        # Buscar fuente del sistema (opcional)
        font_path = None
        for path in (
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "C:\\Windows\\Fonts\\arialbd.ttf",
            "C:\\Windows\\Fonts\\Calibri.ttf"
        ):
            if os.path.exists(path):
                font_path = path
                break

        try:
            font_big = ImageFont.truetype(font_path, 34) if font_path else None
            font_small = ImageFont.truetype(font_path, 18) if font_path else None
        except Exception:
            font_big = None
            font_small = None

        title = "🚀 ALERTA DE CONFIANZA IA"
        conf_text = f"Confianza ajustada: {confianza*100:.2f}%"
        time_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        resumo_short = (resumen or "")[:120]

        draw.text((30, 24), title, fill=(255, 255, 255), font=font_big)
        draw.text((30, 80), conf_text, fill=(0, 220, 120), font=font_big)
        draw.text((30, 140), time_text, fill=(180, 180, 180), font=font_small)
        draw.text((30, 170), resumo_short, fill=(200, 200, 200), font=font_small)

        filename = os.path.join(_ALERT_DIR, f"confianza_alert_{int(confianza*100)}_{datetime.now().strftime('%Y%m%d%H%M%S')}.png")
        img.save(filename)
        log_info(f"Imagen de alerta generada: {filename}", archivo="confidence_boost.py", funcion="_generate_alert_image")
        return filename

    except Exception as e:
        log_warning(f"Error generando ticket alerta: {e}", archivo="confidence_boost.py", funcion="_generate_alert_image")
        return None


# ============================================================
# 📩 Envío de alerta Telegram (texto + archivo opcional)
# ============================================================
def _alertar_telegram(confianza: float, resumen: str = "", filename: Optional[str] = None):
    try:
        msg = (
            f"🚨 <b>ALERTA DE CONFIANZA IA</b>\n"
            f"📈 Nueva confianza: <b>{confianza*100:.2f}%</b>\n"
            f"🧠 Refuerzo activado por consenso múltiple\n"
            f"{(resumen[:300] + ('...' if len(resumen) > 300 else ''))}\n"
            f"🕒 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )
        # Enviar texto si la función existe
        if enviar_telegram:
            try:
                enviar_telegram(msg)
                log_info("Alerta Telegram (texto) enviada", archivo="confidence_boost.py", funcion="_alertar_telegram")
            except Exception as e:
                log_warning(f"enviar_telegram falló: {e}", archivo="confidence_boost.py", funcion="_alertar_telegram")

        # Enviar imagen si existe y la función está disponible
        if filename and os.path.exists(filename) and enviar_imagen_telegram:
            try:
                enviar_imagen_telegram(filename)
                log_info("Alerta Telegram (imagen) enviada", archivo="confidence_boost.py", funcion="_alertar_telegram")
            except Exception as e:
                log_warning(f"enviar_imagen_telegram falló: {e}", archivo="confidence_boost.py", funcion="_alertar_telegram")

    except Exception as e:
        log_error(e, archivo="confidence_boost.py", funcion="_alertar_telegram")


# ============================================================
# 🔹 Función principal — boost_confidence_and_alert
# ============================================================
def boost_confidence_and_alert(
    metodologias,
    prediccion_lstm: Optional[dict] = None,
    confianza_actual: float = 0.0,
    score_methods: float = 0.0,
    rf_score: float = 0.0,
    consistencia: float = 0.0,
    error_score: float = 0.0,
    estabilidad: float = 0.0,
    resumen: str = ""
) -> Tuple[float, bool]:
    """
    Aumenta la confianza IA si hay consenso y solidez real.
    Retorna (nueva_confianza, forced_boost: bool)
    """
    try:
        boost_to = DEFAULTS["boost_to"]
        min_methods = DEFAULTS["min_high_conf_methods"]
        umbral_conf = DEFAULTS["method_conf_threshold"]
        lstm_thr = DEFAULTS["lstm_conf_threshold"]
        rf_thr = DEFAULTS["rf_score_threshold"]
        delta_max = DEFAULTS["max_delta"]

        # 1️⃣ Contar metodologías "fuertes"
        metodos_fuertes = [
            m for m in (metodologias or [])
            if isinstance(m, dict) and float(m.get("confianza", 0.0) or 0.0) >= umbral_conf
        ]
        num_fuertes = len(metodos_fuertes)

        # 2️⃣ Extraer confianza LSTM (si existe)
        lstm_conf = 0.0
        if isinstance(prediccion_lstm, dict):
            try:
                lstm_conf = float(prediccion_lstm.get("confianza", 0.0) or 0.0)
            except Exception:
                lstm_conf = 0.0

        # 3️⃣ Evaluar condiciones de refuerzo (diccionario para logs claros)
        condiciones = {
            "metodos_fuertes": num_fuertes >= min_methods,
            "lstm_ok": lstm_conf >= lstm_thr,
            "rf_ok": rf_score >= rf_thr,
            "consistencia": consistencia >= DEFAULTS["consistency_threshold"],
            "error_score": error_score >= 0.60,
            "estabilidad": estabilidad >= DEFAULTS["stability_threshold"]
        }

        # total_ok = número de condiciones verdaderas
        total_ok = sum(1 for v in condiciones.values() if bool(v))
        aplicar_boost = total_ok >= 4

        log_info(
            f"Evaluando refuerzo confianza: metodos_fuertes={num_fuertes}, lstm={lstm_conf:.2f}, "
            f"rf={rf_score:.2f}, condiciones_ok={total_ok}/6, aplicar_boost={aplicar_boost}",
            archivo="confidence_boost.py", funcion="boost_confidence_and_alert"
        )

        # 4️⃣ Aplicar incremento de confianza
        if aplicar_boost:
            incremento = min(delta_max, (boost_to - confianza_actual))
            nueva_confianza = round(max(confianza_actual, min(boost_to, confianza_actual + incremento)), 6)

            log_info(
                f"🚀 Confianza IA ajustada de {confianza_actual:.3f} → {nueva_confianza:.3f}",
                archivo="confidence_boost.py", funcion="boost_confidence_and_alert"
            )
            log_info(
                f"⚡ Refuerzo IA aplicado — {total_ok}/6 condiciones cumplidas → confianza {nueva_confianza*100:.2f}%",
                archivo="confidence_boost.py", funcion="boost_confidence_and_alert"
            )

            # Generar arte y alertar (si puede)
            try:
                filename = _generate_alert_image(nueva_confianza, resumen)
                _alertar_telegram(nueva_confianza, resumen, filename)
            except Exception as e_alerta:
                log_warning(f"Error generando/enviando alerta: {e_alerta}",
                            archivo="confidence_boost.py", funcion="boost_confidence_and_alert")

            return nueva_confianza, True

        # No aplicar boost
        log_info(f"ℹ️ Confianza sin cambio: {confianza_actual:.3f}",
                 archivo="confidence_boost.py", funcion="boost_confidence_and_alert")
        return confianza_actual, False

    except Exception as e:
        log_error(e, archivo="confidence_boost.py", funcion="boost_confidence_and_alert")
        return confianza_actual, False


# ============================================================
# 🧠 dynamic_confidence_boost — versión autoajustable (95%)
# ------------------------------------------------------------
# Extiende boost_confidence_and_alert con una lógica adaptativa:
# - Si hay 4/6 condiciones → boost normal (hasta 90%)
# - Si hay 5/6 condiciones → refuerzo fuerte (hasta 93%)
# - Si hay 6/6 condiciones → refuerzo máximo (hasta 95%)
# ============================================================
def dynamic_confidence_boost(
    metodologias,
    prediccion_lstm=None,
    confianza_actual: float = 0.0,
    score_methods: float = 0.0,
    rf_score: float = 0.0,
    consistencia: float = 0.0,
    error_score: float = 0.0,
    estabilidad: float = 0.0,
    resumen: str = ""
):
    """
    Versión tolerante: acepta prediccion_lstm opcional y confianza_actual opcional.
    Intenta realizar refuerzos progresivos: 4/6->90%, 5/6->93%, 6/6->95%.
    """
    try:
        # Importar DEFAULTS directamente del mismo módulo para evitar recursividad
        local_defaults = DEFAULTS
        min_methods = local_defaults.get("min_high_conf_methods", 3)
        umbral_conf = local_defaults.get("method_conf_threshold", 0.80)
        lstm_thr = local_defaults.get("lstm_conf_threshold", 0.78)
        rf_thr = local_defaults.get("rf_score_threshold", 0.65)

        # Calcular metodologías fuertes
        metodos_fuertes = [
            m for m in (metodologias or [])
            if isinstance(m, dict) and float(m.get("confianza", 0)) >= umbral_conf
        ]
        num_fuertes = len(metodos_fuertes)

        # LSTM safe
        lstm_conf = 0.0
        if isinstance(prediccion_lstm, dict):
            lstm_conf = float(prediccion_lstm.get("confianza", 0.0) or 0.0)

        condiciones = [
            num_fuertes >= min_methods,
            lstm_conf >= lstm_thr,
            rf_score >= rf_thr,
            consistencia >= 0.70,
            error_score >= 0.60,
            estabilidad >= 0.40
        ]
        num_cumplidas = sum(1 for c in condiciones if bool(c))

        # Nivel target según cumplimiento
        if num_cumplidas >= 4:
            if num_cumplidas == 4:
                target = 0.90
            elif num_cumplidas == 5:
                target = 0.93
            else:
                target = 0.95

            incremento = min(local_defaults.get("max_delta", 0.25), max(0.0, target - confianza_actual))
            nueva_confianza = round(min(target, confianza_actual + incremento), 6)

            # Generar alertas visuales y Telegram (tolerante)
            try:
                filename = _generate_alert_image(nueva_confianza, resumen) if " _generate_alert_image" in globals() or callable(globals().get("_generate_alert_image")) else None
            except Exception:
                filename = None
            try:
                _alertar_telegram(nueva_confianza, resumen, filename)
            except Exception:
                pass

            log_info(f"⚡ Refuerzo IA aplicado — {num_cumplidas}/6 condiciones cumplidas → confianza {nueva_confianza*100:.2f}%",
                     archivo="confidence_boost.py", funcion="dynamic_confidence_boost")
            return nueva_confianza, True

        log_info(f"ℹ️ dynamic_confidence_boost: no aplica boost ({num_cumplidas}/6)",
                 archivo="confidence_boost.py", funcion="dynamic_confidence_boost")
        return confianza_actual, False

    except Exception as e:
        log_warning(f"[dynamic_confidence_boost] error: {e}", archivo="confidence_boost.py", funcion="dynamic_confidence_boost")
        return confianza_actual, False