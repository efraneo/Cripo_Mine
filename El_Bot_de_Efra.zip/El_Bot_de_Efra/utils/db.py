# ============================================================
# 📦 utils/db.py — Gestión de datos y lectura segura de activos
# ============================================================

import os
import pandas as pd
from datetime import datetime
from utils.logger import log_info, log_warning, log_error

# intento importar logger del proyecto si existe (no obligatorio)
try:
    from utils.logger import log_info, log_warning, log_error
except Exception:
    def log_info(*args, **kwargs): pass
    def log_warning(*args, **kwargs): pass
    def log_error(*args, **kwargs): pass

# ============================================================
# 🧩 obtener_historial — Simulación segura de historial de usuario
# ============================================================
def obtener_historial(usuario: str, fecha_inicio: datetime, fecha_fin: datetime, activo: str = ""):
    """
    ⚠️ Simulación de historial de operaciones.
    En producción, reemplázala con la consulta real a tu DB.
    """
    try:
        data = [
            {"fecha": "2025-09-10", "activo": "BTCUSDT", "accion": "compra", "resultado": "ganancia"},
            {"fecha": "2025-09-11", "activo": "ETHUSDT", "accion": "venta", "resultado": "perdida"},
        ]
        df = pd.DataFrame(data)
        df["fecha"] = pd.to_datetime(df["fecha"])

        # 🔍 Filtrado por rango de fechas y activo
        mask = (df["fecha"] >= pd.to_datetime(fecha_inicio)) & (df["fecha"] <= pd.to_datetime(fecha_fin))
        if activo:
            mask &= df["activo"] == activo

        return df[mask]

    except Exception as e:
        log_error(e, archivo="db.py", funcion="obtener_historial")
        return pd.DataFrame(columns=["fecha", "activo", "accion", "resultado"])


# ============================================================
# 📊 obtener_activos — Lista general de activos
# ============================================================
def obtener_activos():
    """
    🔹 Intenta leer activos desde base de datos simulada o archivo CSV.
    Retorna siempre una lista válida (sin romper el flujo).
    """
    try:
        # 1️⃣ Simulación de lista de activos (puedes conectar DB real aquí)
        activos = ["BTCUSDT", "ETHUSDT", "BNBUSDT", "ADAUSDT"]

        # 2️⃣ Si hay CSV de respaldo, usarlo
        if os.path.exists("activos.csv"):
            df = pd.read_csv("activos.csv")
            if "simbolo" in df.columns:
                activos = df["simbolo"].dropna().unique().tolist()

        # Validación final
        if not activos:
            activos = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

        return activos

    except Exception as e:
        log_warning(f"⚠️ obtener_activos falló: {e}", archivo="db.py", funcion="obtener_activos")
        return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]


# ============================================================
# 🧠 leer_activos_por_categoria — Bloque robusto y flexible
# ============================================================
def leer_activos_por_categoria(*args, categoria: str = "Criptos", incluir_todos: bool = False, como_tuplas: bool = False):
    """
    Función robusta y retrocompatible para devolver activos por categoría.

    Accepta:
        - llamadas antiguas con 1 argumento posicional (ej: leer_activos_por_categoria("Criptos"))
        - llamadas modernas con named args.

    Retorna:
        - Si como_tuplas True -> list of (categoria, [simbolos])
        - Si incluir_todos True -> flat list de simbolos (sin duplicados)
        - Si categoria especificada -> list de simbolos (vacío si no existe)
        - Si no hay datos -> fallback con lista mínima
    """
    try:
        # si alguien pasó un arg posicional (compatibilidad retro)
        if args:
            try:
                # si primer arg es str, lo tratamos como categoria
                if isinstance(args[0], str) and args[0].strip():
                    categoria = args[0]
            except Exception:
                pass

        # 1) intentar función de DB (si existe en otro módulo)
        try:
            # si tienes una función 'obtener_activos_por_categoria' en otro módulo, la usamos
            from utils.db_helpers import obtener_activos_por_categoria as _db_obtener_activos  # nombre ejemplo
            try:
                out = _db_obtener_activos()
                if out:
                    # si devuelve dict {cat: [simbolos]}
                    if isinstance(out, dict):
                        if como_tuplas:
                            return list(out.items())
                        if incluir_todos:
                            todos = []
                            for lst in out.values():
                                todos.extend(lst or [])
                            return sorted(set(todos))
                        return out.get(categoria, [])
            except Exception:
                pass
        except Exception:
            # no existe helper externo, seguimos con csv/fallback
            pass

        # 2) leer activos.csv (ubicado en root del proyecto)
        csv_path = os.path.join(os.getcwd(), "activos.csv")
        if os.path.exists(csv_path):
            try:
                df = pd.read_csv(csv_path)
                # normalizar nombres de columnas
                cols = [c.lower() for c in df.columns]
                df.columns = cols

                if "categoria" in cols and "simbolo" in cols:
                    # agrupar por categoria
                    grupos = {}
                    for cat, sub in df.groupby("categoria"):
                        simul = sub["simbolo"].dropna().astype(str).str.strip().tolist()
                        grupos[cat] = simul
                    if como_tuplas:
                        return list(grupos.items())
                    if incluir_todos:
                        todos = []
                        for lst in grupos.values():
                            todos.extend(lst)
                        return sorted(set(todos))
                    # buscar categoría solicitada (case-insensitive)
                    for k, v in grupos.items():
                        if k.lower() == str(categoria).lower():
                            return v
                    # si no coincide, devolver keys disponibles
                    log_warning(f"leer_activos_por_categoria: categoria '{categoria}' no encontrada. Devolviendo categorias disponibles.",
                                archivo="db.py", funcion="leer_activos_por_categoria")
                    return grupos
                elif "simbolo" in cols:
                    # CSV sin categoria: devolver lista simple
                    lista = df["simbolo"].dropna().astype(str).str.strip().tolist()
                    if incluir_todos or not categoria:
                        return sorted(set(lista))
                    return lista
                else:
                    log_warning("leer_activos_por_categoria: activos.csv no contiene columnas 'categoria' ni 'simbolo'.", archivo="db.py", funcion="leer_activos_por_categoria")
            except Exception as e:
                log_warning(f"leer_activos_por_categoria: fallo leyendo activos.csv -> {e}", archivo="db.py", funcion="leer_activos_por_categoria")

        # 3) fallback seguro
        fallback = {
            "Criptos": ["BTCUSDT", "ETHUSDT", "BNBUSDT"],
            "Acciones": ["AAPL", "TSLA", "MSFT"]
        }
        if como_tuplas:
            return list(fallback.items())
        if incluir_todos:
            todos = []
            for lst in fallback.values():
                todos.extend(lst)
            return sorted(set(todos))
        # si solicitan categoría específica, respetarla (case-insensitive)
        for k, v in fallback.items():
            if k.lower() == str(categoria).lower():
                return v
        return fallback  # dict por si el caller espera estructura completa

    except Exception as e:
        log_error(f"leer_activos_por_categoria fallo inesperado: {e}", archivo="db.py", funcion="leer_activos_por_categoria")
        # devolver estructura segura
        return {"Criptos": ["BTCUSDT", "ETHUSDT", "BNBUSDT"]} if not como_tuplas else [("Criptos", ["BTCUSDT", "ETHUSDT", "BNBUSDT"])]

# ============================================================
# 🧱 obtener_activos_por_categoria (simulada)
# ============================================================
def obtener_activos_por_categoria():
    """
    🔹 Simulación de estructura de categorías desde DB real.
    En producción, reemplázala por una consulta SQL.
    """
    try:
        categorias = {
            "Top": ["BTCUSDT", "ETHUSDT", "BNBUSDT"],
            "Altcoins": ["ADAUSDT", "XRPUSDT", "SOLUSDT"],
        }
        return categorias
    except Exception as e:
        log_error(e, archivo="db.py", funcion="obtener_activos_por_categoria")
        return {}
