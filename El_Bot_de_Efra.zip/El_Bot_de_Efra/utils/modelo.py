# ==========================================================
# utils/modelo.py — Versión 2025 Pro (Confianza IA 80%+)
# Ensemble híbrido calibrado: RF + XGBoost + LSTM
# ==========================================================
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
import joblib
import logging
import warnings
warnings.filterwarnings("ignore")
from typing import Tuple, List, Optional
from utils.logger import log_info, log_warning, log_error
import os
import pickle
from sklearn.preprocessing import StandardScaler
from typing import Any

# ML libs
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.metrics import mean_squared_error, accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import TimeSeriesSplit
from sklearn.calibration import CalibratedClassifierCV

# XGBoost (nuevo ensemble)
try:
    from xgboost import XGBClassifier
    XGB_AVAILABLE = True
except Exception:
    XGB_AVAILABLE = False

# TF / Keras
import os
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"

import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization, Bidirectional
from tensorflow.keras import Input
from tensorflow.keras.callbacks import EarlyStopping

# Indicators (ta-lib)
try:
    import ta
    TA_AVAILABLE = True
except Exception:
    TA_AVAILABLE = False

# Logging fallback
try:
    from utils.logger import log_error, log_info, log_warning
except Exception:
    log = logging.getLogger("utils.modelo")
    logging.basicConfig(format="%(asctime)s | %(levelname)s | %(message)s")
    def log_info(msg, archivo=None, funcion=None): log.info(f"{archivo or ''} {funcion or ''} - {msg}")
    def log_warning(msg, archivo=None, funcion=None): log.warning(f"{archivo or ''} {funcion or ''} - {msg}")
    def log_error(msg, archivo=None, funcion=None): log.exception(f"{archivo or ''} {funcion or ''} - {msg}")


# ==========================================================
# 🧩 BLOQUE — Guardar y cargar Scaler de modelos ML
# ==========================================================

MODELS_DIR = Path("models")
SCALERS_DIR = MODELS_DIR / "scalers"
MODELS_DIR.mkdir(parents=True, exist_ok=True)
SCALERS_DIR.mkdir(parents=True, exist_ok=True)


def guardar_scaler(symbol: str, scaler: Any, prefix: str = "std"):
    """
    Guarda un scaler (ej. StandardScaler) en disk con pickle.
    Ruta: models/scalers/{symbol}_{prefix}_scaler.pkl
    """
    try:
        fname = SCALERS_DIR / f"{symbol}_{prefix}_scaler.pkl"
        with open(fname, "wb") as f:
            pickle.dump(scaler, f)
        log_info(f"guardar_scaler: scaler guardado en {fname}", archivo="modelo.py", funcion="guardar_scaler")
        return str(fname)
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="guardar_scaler")
        return None


def cargar_scaler(symbol: str, prefix: str = "std"):
    """
    Carga un scaler desde disk. Retorna None si no existe.
    """
    try:
        fname = SCALERS_DIR / f"{symbol}_{prefix}_scaler.pkl"
        if not fname.exists():
            log_warning(f"cargar_scaler: no existe {fname}", archivo="modelo.py", funcion="cargar_scaler")
            return None
        with open(fname, "rb") as f:
            scaler = pickle.load(f)
        log_info(f"cargar_scaler: scaler cargado desde {fname}", archivo="modelo.py", funcion="cargar_scaler")
        return scaler
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="cargar_scaler")
        return None


def guardar_model(symbol: str, model: Any, prefix: str = "ensemble"):
    """
    Guarda un modelo en models/{symbol}_{prefix}.pkl
    """
    try:
        fname = MODELS_DIR / f"{symbol}_{prefix}.pkl"
        with open(fname, "wb") as f:
            pickle.dump(model, f)
        log_info(f"guardar_model: modelo guardado en {fname}", archivo="modelo.py", funcion="guardar_model")
        return str(fname)
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="guardar_model")
        return None


def cargar_model(symbol: str, prefix: str = "ensemble"):
    """
    Carga un modelo guardado; devuelve None si no existe o falla.
    """
    try:
        fname = MODELS_DIR / f"{symbol}_{prefix}.pkl"
        if not fname.exists():
            log_warning(f"cargar_model: no existe {fname}", archivo="modelo.py", funcion="cargar_model")
            return None
        with open(fname, "rb") as f:
            model = pickle.load(f)
        log_info(f"cargar_model: modelo cargado desde {fname}", archivo="modelo.py", funcion="cargar_model")
        return model
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="cargar_model")
        return None

# ==========================================================
# 🧩 Compatibilidad retro: agregar_indicadores_tecnicos
# ==========================================================
def agregar_indicadores_tecnicos(df: pd.DataFrame) -> pd.DataFrame:
    """
    Versión compatible con agregar_indicadores_avanzados (si existe).
    Si no, agrega indicadores básicos RSI, MACD, EMA y ATR.
    """
    try:
        if "agregar_indicadores_avanzados" in globals():
            return agregar_indicadores_avanzados(df)

        import pandas_ta as ta
        dfc = df.copy()
        if "close" in dfc.columns:
            dfc["rsi"] = ta.rsi(dfc["close"], length=14)
            dfc["ema_fast"] = ta.ema(dfc["close"], length=12)
            dfc["ema_slow"] = ta.ema(dfc["close"], length=26)
            dfc["macd"] = dfc["ema_fast"] - dfc["ema_slow"]
        if {"high", "low", "close"}.issubset(dfc.columns):
            dfc["atr"] = ta.atr(dfc["high"], dfc["low"], dfc["close"], length=14)
        return dfc.fillna(method="bfill").fillna(method="ffill")

    except Exception as e:
        log_warning(f"agregar_indicadores_tecnicos falló: {e}", archivo="modelo.py", funcion="agregar_indicadores_tecnicos")
        return df

# ==========================================================
# 🔧 Función auxiliar: normalizar nombre de activo
# ==========================================================
def _norm_activo(activo: str) -> str:
    """
    Normaliza el nombre del activo (ej: btc-usdt → BTCUSDT)
    """
    if not activo:
        return "BTCUSDT"
    return str(activo).replace("-", "").replace("_", "").upper()


# Paths
DATA_DIR = Path("data_historica")
MODELOS_DIR = Path("modelos_entrenados")
SCALERS_DIR = DATA_DIR / "scalers"
RF_DIR = MODELOS_DIR / "rf_models"
LSTM_DIR = MODELOS_DIR / "lstm_models"
for d in [MODELOS_DIR, SCALERS_DIR, RF_DIR, LSTM_DIR]:
    d.mkdir(parents=True, exist_ok=True)

DATE_FMT_ISO = "%Y-%m-%dT%H:%M:%S"


# ==========================================================
# PARTE ADICIONAL — funciones avanzadas: features, ensemble calibrado,
# predicción con confianza mejorada y backtest simple.
# Pegar esta sección AL FINAL de tu utils/modelo.py (no borres nada)
# ==========================================================

import math
from sklearn.metrics import precision_score, recall_score
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV

# -------------------------
# Indicadores avanzados (no reemplaza, añade)
# -------------------------
def agregar_indicadores_avanzados(df: pd.DataFrame) -> pd.DataFrame:
    """
    Añade indicadores avanzados sin modificar las funciones existentes:
    - EMA corto/largo, ROC, OBV, Bollinger bands, ATR proxy
    - Normaliza columnas de tiempo si existen datetime index
    Devuelve copia.
    """
    try:
        df = df.copy()
        if "close" not in df.columns:
            return df

        # EMA
        df["ema_8"] = df["close"].ewm(span=8, adjust=False).mean()
        df["ema_21"] = df["close"].ewm(span=21, adjust=False).mean()

        # Rate of Change (percent)
        df["roc_5"] = df["close"].pct_change(5).fillna(0.0)

        # OBV (On-Balance Volume) simple
        df["obv"] = (np.sign(df["close"].diff()).fillna(0) * df.get("volume", 0)).cumsum()

        # Bollinger Bands
        mb = df["close"].rolling(20, min_periods=1).mean()
        msd = df["close"].rolling(20, min_periods=1).std()
        df["bb_upper"] = mb + 2 * msd
        df["bb_lower"] = mb - 2 * msd
        df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / (mb + 1e-9)

        # ATR proxy: use high-low vs previous close
        if "high" in df.columns and "low" in df.columns:
            tr1 = (df["high"] - df["low"]).abs()
            tr2 = (df["high"] - df["close"].shift()).abs()
            tr3 = (df["low"] - df["close"].shift()).abs()
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            df["atr_14"] = tr.rolling(14, min_periods=1).mean().fillna(0.0)
        else:
            df["atr_14"] = df["close"].diff().abs().rolling(14, min_periods=1).mean().fillna(0.0)

        # Time features (if index is datetime-like)
        if isinstance(df.index, pd.DatetimeIndex):
            df["hour"] = df.index.hour
            df["dayofweek"] = df.index.dayofweek
        else:
            df["hour"] = 0
            df["dayofweek"] = 0

        # Fill any remaining NAs
        df.fillna(method="ffill", inplace=True)
        df.fillna(method="bfill", inplace=True)
        df.fillna(0.0, inplace=True)

        return df
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="agregar_indicadores_avanzados")
        return df


# -------------------------
# Entrenamiento ensemble calibrado (RF + XGB opcional) + LSTM
# -------------------------
def entrenar_ensemble_calibrado(df: pd.DataFrame, pasos=20, futuros=1, activo=None,
                                rf_estimators=200, xgb_estimators=100,
                                lstm_epochs=40, lstm_batch=32, calibrar=True):
    """
    Pipeline completo:
      - Genera features tabulares y secuencias LSTM
      - Entrena RandomForest (+ XGBoost si disponible)
      - Calibra probabilidades (Platt scaling)
      - Entrena LSTM multifeature
      - Guarda modelos y scalers
      - Retorna resumen y métricas de validación (TimeSeriesSplit)
    """
    try:
        sym = _norm_activo(activo)
        dfc = df.copy()

        # enrich features
        dfc = agregar_indicadores_tecnicos(dfc)
        dfc = agregar_indicadores_avanzados(dfc)

        # tabular features & labels
        X_tab, y_tab = crear_features_tabulares(dfc, pasos=pasos, future_horizon=futuros)
        if X_tab.shape[0] < 10:
            log_warning("Datos insuficientes para entrenar en entrenar_ensemble_calibrado", archivo="modelo.py", funcion="entrenar_ensemble_calibrado")

        #Añadi las dos lineas siguientes para convertir x_tab en ndarray
        if isinstance(X_tab, np.ndarray):
            import pandas as pd
            X_tab = pd.DataFrame(X_tab)
        X_tab_num = X_tab.select_dtypes(include=[np.number]).fillna(0.0)

        # scale tabular
        std_scaler = StandardScaler()
        X_tab_scaled = std_scaler.fit_transform(X_tab)
        guardar_scaler(sym, std_scaler, prefix="std")

        # base estimators
        rf = RandomForestClassifier(n_estimators=rf_estimators, n_jobs=-1, random_state=42)
        estimators = [("rf", rf)]
        if XGB_AVAILABLE:
            xgb = XGBClassifier(n_estimators=xgb_estimators, use_label_encoder=False, eval_metric="logloss", verbosity=0)
            estimators.append(("xgb", xgb))

        # stacking (meta = logistic)
        stack = StackingClassifier(estimators=estimators, final_estimator=LogisticRegression(), n_jobs=-1, passthrough=False)
        # time series CV to evaluate
        tscv = TimeSeriesSplit(n_splits=min(4, max(2, X_tab_scaled.shape[0] // 50)))
        accs, f1s = [], []
        fold = 0
        for train_idx, test_idx in tscv.split(X_tab_scaled):
            fold += 1
            Xtr, Xte = X_tab_scaled[train_idx], X_tab_scaled[test_idx]
            ytr, yte = y_tab.values[train_idx], y_tab.values[test_idx]
            try:
                stack.fit(Xtr, ytr)
                ypred = stack.predict(Xte)
                accs.append(accuracy_score(yte, ypred))
                f1s.append(f1_score(yte, ypred, zero_division=0))
            except Exception as e:
                log_warning(f"Fold {fold} fallo: {e}", archivo="modelo.py", funcion="entrenar_ensemble_calibrado")

        # Fit on full data
        stack.fit(X_tab_scaled, y_tab.values)

        # Calibrate probabilities
        if calibrar:
            try:
                cal = CalibratedClassifierCV(stack, cv='prefit', method='sigmoid')
                cal.fit(X_tab_scaled, y_tab.values)
                clf_final = cal
            except Exception as e:
                log_warning(f"Calibración falló: {e}. Usando stack sin calibrar.", archivo="modelo.py", funcion="entrenar_ensemble_calibrado")
                clf_final = stack
        else:
            clf_final = stack

        # save RF/XGB/stack
        joblib.dump(clf_final, _rf_model_path(sym))

        # LSTM multifeature
        features = ["close", "rsi_14", "macd", "vol_20", "ema_8", "ema_21", "roc_5", "obv", "atr_14"]
        X_lstm, y_lstm, scaler_lstm, used_feats = _preparar_datos_lstm_multifeature(dfc, pasos=pasos, activo=sym, features=features)
        lstm_model = None
        lstm_mse = None
        if X_lstm.size > 0:
            # architecture (bidirectional option)
            lstm_model = Sequential([
                Input(shape=(X_lstm.shape[1], X_lstm.shape[2])),
                Bidirectional(LSTM(128, return_sequences=True)),
                BatchNormalization(),
                Dropout(0.25),
                LSTM(64),
                BatchNormalization(),
                Dropout(0.25),
                Dense(32, activation="relu"),
                Dense(1, activation="linear")
            ])
            lstm_model.compile(optimizer="adam", loss="mse")
            es = EarlyStopping(monitor="loss", patience=5, restore_best_weights=True)
            lstm_model.fit(X_lstm, y_lstm, epochs=lstm_epochs, batch_size=lstm_batch, verbose=0, callbacks=[es])
            lstm_model.save(_lstm_model_path(sym), overwrite=True)
            guardar_scaler(sym, scaler_lstm, prefix="minmax")
            try:
                preds_train = lstm_model.predict(X_lstm, verbose=0)
                lstm_mse = float(mean_squared_error(y_lstm, preds_train))
            except Exception:
                lstm_mse = None

        resumen = {
            "activo": sym,
            "stack_acc_mean": float(np.mean(accs)) if accs else None,
            "stack_f1_mean": float(np.mean(f1s)) if f1s else None,
            "lstm_mse": lstm_mse,
            "model_stack_path": _rf_model_path(sym),
            "model_lstm_path": _lstm_model_path(sym),
            "n_samples_tab": int(X_tab_scaled.shape[0]) if X_tab_scaled is not None else 0
        }
        log_info(f"entrenar_ensemble_calibrado -> resumen: {resumen}", archivo="modelo.py", funcion="entrenar_ensemble_calibrado")
        return resumen

    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="entrenar_ensemble_calibrado")
        return None


# -------------------------
# Predicción usando ensemble calibrado (nuevo nombre para no romper compat)
# -------------------------
def predecir_senal_ensemble(df: pd.DataFrame, activo: str = None, pasos=20, futuros=3, modo_agresivo=True, minutos=None):
    """
    Versión mejorada de predecir_senal que:
     - carga ensemble calibrado y LSTM
     - predice precios futuros con LSTM y prob subida con el ensemble calibrado
     - calcula confianza combinada y devuelve acción y predicciones
    """
    try:
        if minutos is not None:
            pasos = minutos

        if df is None or df.empty or "close" not in df.columns or activo is None:
            return "hold", 0.0, None, 0, []

        sym = _norm_activo(activo)
        ensemble = cargar_ensemble(sym)
        rf = ensemble.get("rf")
        lstm = ensemble.get("lstm")
        std_scaler = ensemble.get("std_scaler")
        minmax_scaler = ensemble.get("minmax_scaler")

        # fallback: si no hay modelos entrenar rápido
        if rf is None or lstm is None:
            log_info(f"Modelos faltantes para {sym}, entrenando rápido como fallback.", archivo="modelo.py", funcion="predecir_senal_ensemble")
            entrenar_ensemble_calibrado(df, pasos=pasos, futuros=futuros, activo=sym, lstm_epochs=10, lstm_batch=32, rf_estimators=50, xgb_estimators=50, calibrar=True)
            ensemble = cargar_ensemble(sym)
            rf = ensemble.get("rf")
            lstm = ensemble.get("lstm")
            std_scaler = ensemble.get("std_scaler")
            minmax_scaler = ensemble.get("minmax_scaler")
            if rf is None and lstm is None:
                return entrenar_y_predecir(df)

        # prepare features for LSTM
        dfc = agregar_indicadores_tecnicos(df.copy())
        dfc = agregar_indicadores_avanzados(dfc)
        if minmax_scaler is None:
            minmax_scaler = MinMaxScaler().fit(dfc[["close"]].values)

        # infer features used by scaler if possible
        if hasattr(minmax_scaler, "n_features_in_"):
            n_f = int(minmax_scaler.n_features_in_)
            cand = ["close", "rsi_14", "macd", "vol_20", "ema_8", "ema_21", "roc_5", "obv", "atr_14"]
            features_for_lstm = [c for c in cand if c in dfc.columns][:n_f]
            if len(features_for_lstm) < n_f:
                features_for_lstm += ["close"] * (n_f - len(features_for_lstm))
        else:
            features_for_lstm = ["close"]

        data_for_lstm = dfc[features_for_lstm].astype(float).values
        scaled_all = minmax_scaler.transform(data_for_lstm)
        if scaled_all.shape[0] < pasos:
            return "hold", 0.0, None, 0, []

        window = scaled_all[-pasos:].copy()
        preds_scaled = []
        for _ in range(futuros):
            p = lstm.predict(window.reshape(1, pasos, scaled_all.shape[1]), verbose=0)
            p_val = float(p[0, 0])
            preds_scaled.append(p_val)
            last_row = window[-1].copy()
            last_row[0] = p_val
            window = np.vstack([window[1:], last_row])

        # inverse transform predicted rows into price predictions
        inv_arr = []
        last_obs_scaled = scaled_all[-1]
        for s in preds_scaled:
            row = last_obs_scaled.copy()
            row[0] = s
            inv_arr.append(row)
        inv_arr = np.array(inv_arr)
        preds = minmax_scaler.inverse_transform(inv_arr)[:, 0].flatten()

        # tabular features for RF (use latest X_tab)
        X_tab, y_tab = crear_features_tabulares(dfc, pasos=pasos, future_horizon=1)
        X_tab_num = X_tab.select_dtypes(include=[np.number]).fillna(0.0)
        if std_scaler is not None and hasattr(std_scaler, "transform") and rf is not None:
            try:
                X_tab_scaled = std_scaler.transform(X_tab_num.values)
                last_row = X_tab_scaled[-1].reshape(1, -1)
                # predict_proba may be available
                if hasattr(rf, "predict_proba"):
                    proba = rf.predict_proba(last_row)[0]
                    prob_up = float(proba[1]) if proba.shape[0] > 1 else float(proba[0])
                else:
                    prob_up = float(rf.predict(last_row)[0])
            except Exception:
                prob_up = 0.5
        else:
            prob_up = 0.5

        # signal from price diffs
        diffs = np.diff(preds)
        if len(diffs) == 0:
            return "hold", 0.0, None, 0, preds.tolist()
        sign_mean = np.sign(np.mean(diffs))
        accion = "buy" if sign_mean > 0 else ("sell" if sign_mean < 0 else "hold")
        duracion = int((np.sign(diffs) == sign_mean).sum()) if sign_mean != 0 else 0

        # components for confidence
        consistencia = float((np.sign(diffs) == sign_mean).mean()) if sign_mean != 0 else 0.0
        returns = np.diff(dfc["close"].values) / (dfc["close"].values[:-1] + 1e-12)
        volatilidad = float(np.nanstd(returns[-50:]) + 1e-9)
        estabilidad = 1.0 / (1.0 + volatilidad * 100)

        # mse recent
        try:
            X_lstm_all, y_lstm_all, _, _ = _preparar_datos_lstm_multifeature(dfc, pasos=pasos, activo=sym, features=features_for_lstm)
            if X_lstm_all.size > 0:
                ypred_recent = lstm.predict(X_lstm_all[-min(10, len(X_lstm_all)):], verbose=0)
                mse_recent = mean_squared_error(y_lstm_all[-len(ypred_recent):], ypred_recent)
                error_score = 1.0 / (1.0 + mse_recent)
            else:
                error_score = 0.5
        except Exception:
            error_score = 0.5

        rf_score = prob_up  # [0..1]

        # weighted combine
        w_cons, w_est, w_err, w_rf = 0.45, 0.15, 0.20, 0.20
        confianza = (w_cons * consistencia) + (w_est * estabilidad) + (w_err * error_score) + (w_rf * rf_score)

        # bonus for strong alignment
        if consistencia > 0.75 and rf_score > 0.75 and error_score > 0.6 and estabilidad > 0.6:
            confianza = min(1.0, confianza + 0.12)

        confianza = float(np.clip(confianza, 0.0, 1.0))
        hora_iso = datetime.now().strftime(DATE_FMT_ISO)

        return accion, confianza, hora_iso, duracion, preds.tolist()

    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="predecir_senal_ensemble")
        try:
            return entrenar_y_predecir(df)
        except Exception:
            return "hold", 0.0, None, 0, []

# ==========================================================
# 📊 Backtest simple del ensemble (robusto y tolerante a errores)
# ==========================================================
def backtest_ensemble(
    df: pd.DataFrame,
    activo: str,
    pasos: int = 20,
    futuros: int = 1,
    umbral_conf: float = 0.6,
    capital_inicial: float = 1000.0,
    fee_pct: float = 0.001
):
    """
    Backtest sencillo de señales del ensemble:
      - Recorre histórico con ventana deslizante.
      - Simula entrada/salida de posiciones.
      - Retorna df_operaciones y métricas básicas.
    Totalmente tolerante a errores y datos faltantes.
    """
    try:
        if df is None or df.empty or "close" not in df.columns:
            raise ValueError("DataFrame inválido o sin columna 'close'")

        dfc = df.copy().reset_index(drop=True)
        n = len(dfc)
        trades = []
        capital = float(capital_inicial)
        pos_size = 0.01  # 1% del capital por trade

        for i in range(pasos, n - futuros):
            window_df = dfc.iloc[:i].copy()
            if len(window_df) < pasos:
                continue

            # --- Predicción robusta ---
            try:
                result = predecir_senal_ensemble(window_df, activo=activo, pasos=pasos, futuros=futuros)
                if not result or len(result) < 5:
                    continue
                accion, confianza, hora, dur, preds = result
            except Exception as e_pred:
                log_warning(f"Predicción falló en {activo}: {e_pred}", archivo="modelo.py", funcion="backtest_ensemble")
                continue

            # --- Normalización de confianza ---
            try:
                confianza = float(confianza)
            except Exception:
                confianza = 0.0

            if accion == "hold" or confianza < float(umbral_conf):
                continue

            # --- Simulación de trade ---
            entry_price = float(dfc.loc[i, "close"])
            exit_idx = i + futuros
            if exit_idx >= n:
                break

            exit_price = float(dfc.loc[exit_idx, "close"])
            direction = 1 if accion.lower() == "buy" else -1

            position_value = capital * pos_size
            qty = position_value / max(entry_price, 1e-8)
            fee_entry = position_value * fee_pct
            pnl = ((exit_price - entry_price) / entry_price) * direction * position_value - fee_entry
            capital += pnl

            trades.append({
                "idx_entry": i,
                "idx_exit": exit_idx,
                "entry_price": entry_price,
                "exit_price": exit_price,
                "accion": accion,
                "confianza": confianza,
                "pnl": pnl,
                "capital": capital
            })

        df_trades = pd.DataFrame(trades)
        if df_trades.empty:
            return df_trades, {"total_trades": 0, "ganancia_total": 0.0, "precision": None, "recall": None, "f1": None}

        # --- Métricas ---
        try:
            metricas = calcular_metricas_basicas(df_trades.rename(columns={"pnl": "pnl"}))
        except Exception as e_m:
            log_warning(f"Error en calcular_metricas_basicas: {e_m}", archivo="modelo.py", funcion="backtest_ensemble")
            metricas = {}

        # --- Métricas de clasificación ---
        try:
            from sklearn.metrics import precision_score, recall_score, f1_score

            y_true, y_pred = [], []
            for _, r in df_trades.iterrows():
                future_move = 1 if r["exit_price"] > r["entry_price"] else 0
                y_true.append(future_move)
                y_pred.append(1 if r["accion"].lower() == "buy" else 0)

            metricas["precision"] = float(precision_score(y_true, y_pred, zero_division=0))
            metricas["recall"] = float(recall_score(y_true, y_pred, zero_division=0))
            metricas["f1"] = float(f1_score(y_true, y_pred, zero_division=0))
        except Exception as e_cls:
            log_warning(f"No se pudieron calcular métricas de clasificación: {e_cls}", archivo="modelo.py", funcion="backtest_ensemble")
            metricas["precision"] = metricas["recall"] = metricas["f1"] = None

        metricas["total_trades"] = len(df_trades)
        metricas["ganancia_total"] = float(df_trades["pnl"].sum())
        metricas["capital_final"] = capital

        return df_trades, metricas

    except Exception as e:
        log_error(f"Error general en backtest_ensemble: {e}", archivo="modelo.py", funcion="backtest_ensemble")
        return pd.DataFrame(), {}


# -------------------------
# Helpers de evaluación (exportables)
# -------------------------
def evaluar_predicciones(y_true, y_pred):
    """
    Calcula precision/recall/f1/winrate simple.
    y_true/y_pred are binary arrays (1 up, 0 down)
    """
    try:
        y_true = np.array(y_true)
        y_pred = np.array(y_pred)
        if len(y_true) == 0:
            return {}
        prec = precision_score(y_true, y_pred, zero_division=0)
        rec = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        winrate = (np.sum((y_pred==1) & (y_true==1)) + 0.0) / max(1, len(y_true))
        return {"precision": float(prec), "recall": float(rec), "f1": float(f1), "winrate": float(winrate)}
    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="evaluar_predicciones")
        return {}

# -------------------------
# Métricas básicas para backtesting
# -------------------------
def calcular_metricas_basicas(df_trades: pd.DataFrame) -> dict:
    """
    Calcula métricas simples de rendimiento sobre un DataFrame de operaciones.
    Espera columnas: 'pnl' y 'capital' opcional.
    """
    try:
        if df_trades is None or df_trades.empty:
            return {
                "ganancia_total": 0.0,
                "winrate": 0.0,
                "trades": 0,
                "pnl_pct": 0.0
            }

        total_trades = len(df_trades)
        ganancia_total = float(df_trades["pnl"].sum())
        ganancia_prom = float(df_trades["pnl"].mean()) if total_trades > 0 else 0.0
        ganadores = df_trades[df_trades["pnl"] > 0].shape[0]
        winrate = float(ganadores / total_trades * 100.0) if total_trades > 0 else 0.0

        capital_final = float(df_trades["capital"].iloc[-1]) if "capital" in df_trades.columns and not df_trades.empty else 0.0
        capital_inicial = float(df_trades["capital"].iloc[0]) if "capital" in df_trades.columns and not df_trades.empty else 1.0
        pnl_pct = (capital_final - capital_inicial) / capital_inicial * 100.0 if capital_inicial > 0 else 0.0

        return {
            "ganancia_total": ganancia_total,
            "ganancia_prom": ganancia_prom,
            "winrate": winrate,
            "pnl_pct": pnl_pct,
            "trades": total_trades
        }

    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="calcular_metricas_basicas")
        return {
            "ganancia_total": 0.0,
            "winrate": 0.0,
            "trades": 0,
            "pnl_pct": 0.0
        }

# ==========================================================
# Compatibilidad retro: alias de entrenar_y_predecir
# ==========================================================
def entrenar_y_predecir(df, activo=None):
    """
    Función de compatibilidad que llama internamente a predecir_senal_ensemble().
    Se mantiene para no romper imports antiguos.
    """
    try:
        accion, confianza, hora_iso, duracion, preds = predecir_senal_ensemble(df, activo=activo)
        return {
            "accion": accion,
            "confianza": confianza,
            "hora": hora_iso,
            "duracion": duracion,
            "preds": preds
        }
    except Exception as e:
        log_warning(f"Fallback entrenar_y_predecir: {e}", archivo="modelo.py", funcion="entrenar_y_predecir")
        return {"accion": "hold", "confianza": 0.0, "hora": None, "duracion": 0, "preds": []}


# ==========================================================
# 📊 Lectura dinámica de activos desde activos.csv (robusto)
# ==========================================================
import csv
import os
from utils.logger import log_warning, log_info

# ============================================================
# ✅ FUNCION ROBUSTA leer_activos_por_categoria
# ============================================================
def leer_activos_por_categoria():
    """
    Lee los activos categorizados desde la base de datos o archivo.
    Retorna siempre una tupla (categorias_dict, total_activos)
    aunque haya fallos.
    """
    import os, pandas as pd
    from utils.logger import log_warning, log_error

    try:
        # 1️⃣ Prioridad: base de datos
        from utils.db import obtener_activos_por_categoria
        categorias = obtener_activos_por_categoria()
        if categorias and isinstance(categorias, dict) and len(categorias) > 0:
            return categorias, sum(len(v) for v in categorias.values())

        # 2️⃣ Fallback: archivo CSV
        if os.path.exists("activos.csv"):
            df = pd.read_csv("activos.csv")
            if "categoria" in df.columns and "simbolo" in df.columns:
                categorias = {}
                for cat, sub_df in df.groupby("categoria"):
                    categorias[cat] = sub_df["simbolo"].dropna().tolist()
                return categorias, len(df)
            else:
                log_warning("⚠️ activos.csv no tiene columnas esperadas (categoria, simbolo).",
                            archivo="db.py", funcion="leer_activos_por_categoria")
                return {"Sin categoría": df["simbolo"].dropna().tolist()}, len(df)

        # 3️⃣ Fallback total: lista mínima por defecto
        log_warning("⚠️ No se encontró BD ni activos.csv, usando lista básica.",
                    archivo="db.py", funcion="leer_activos_por_categoria")
        return {"General": ["BTCUSDT", "ETHUSDT", "BNBUSDT"]}, 3

    except Exception as e:
        log_warning(f"⚠️ leer_activos_por_categoria falló: {e}",
                    archivo="db.py", funcion="leer_activos_por_categoria")
        # ✅ Devuelve estructura vacía pero válida (evita unpack error)
        return {"General": ["BTCUSDT", "ETHUSDT", "BNBUSDT"]}, 3

# ==========================================================
# 🧩 Cargar ensemble entrenado (RF/XGB/LSTM + scalers)
# ==========================================================
import joblib

def cargar_ensemble(simbolo: str):
    """
    Carga los modelos entrenados (RF/XGB/LSTM) y scalers asociados.
    Retorna dict con claves: rf, lstm, std_scaler, minmax_scaler
    """
    try:
        sym = simbolo.upper().replace("/", "")
        base = Path("modelos_entrenados")
        rf_path = base / "rf_models" / f"{sym}_rf.pkl"
        lstm_path = base / "lstm_models" / f"{sym}_lstm.keras"
        std_scaler_path = Path("data_historica/scalers") / f"{sym}_std.pkl"
        minmax_scaler_path = Path("data_historica/scalers") / f"{sym}_minmax.pkl"

        rf = joblib.load(rf_path) if rf_path.exists() else None
        lstm = load_model(lstm_path) if lstm_path.exists() else None
        std_scaler = joblib.load(std_scaler_path) if std_scaler_path.exists() else None
        minmax_scaler = joblib.load(minmax_scaler_path) if minmax_scaler_path.exists() else None

        return {"rf": rf, "lstm": lstm, "std_scaler": std_scaler, "minmax_scaler": minmax_scaler}
    except Exception as e:
        from utils.logger import log_error
        log_error(f"cargar_ensemble falló: {e}", archivo="modelo.py", funcion="cargar_ensemble")
        return {"rf": None, "lstm": None, "std_scaler": None, "minmax_scaler": None}

def crear_features_tabulares(df, pasos=20, future_horizon=1):
    """
    Fallback: genera características simples de precios y retornos
    para el entrenamiento rápido de ensemble.
    """
    import numpy as np
    dfc = df.copy()
    if "close" not in dfc.columns:
        return np.empty((0, 5)), np.empty((0,))
    dfc["retorno"] = dfc["close"].pct_change().fillna(0)
    X = []
    y = []
    for i in range(pasos, len(dfc) - future_horizon):
        features = dfc["retorno"].iloc[i-pasos:i].values
        X.append(features)
        y.append(1 if dfc["close"].iloc[i+future_horizon] > dfc["close"].iloc[i] else 0)
    return np.array(X), np.array(y)


# ---------------------------
# 🧭 agregar_indicadores_tecnicos
# ---------------------------
def agregar_indicadores_tecnicos(df: pd.DataFrame) -> pd.DataFrame:
    """
    Añade indicadores técnicos básicos al dataframe:
      - SMA_5, SMA_10
      - EMA_12, EMA_26, MACD, MACD_signal
      - RSI_14
      - ATR_14
    Garantiza que devuelva un DataFrame con índice datetime y columnas numéricas.
    """
    try:
        if df is None or df.empty:
            return df.copy() if df is not None else pd.DataFrame()

        dfc = df.copy()
        # Asegurar columnas esperadas
        for col in ["open", "high", "low", "close", "volume"]:
            if col not in dfc.columns:
                dfc[col] = np.nan

        # Asegurar índice datetime
        if not isinstance(dfc.index, pd.DatetimeIndex):
            try:
                dfc.index = pd.to_datetime(dfc.index)
            except Exception:
                pass

        # SMA
        dfc["SMA_5"] = dfc["close"].rolling(window=5, min_periods=1).mean()
        dfc["SMA_10"] = dfc["close"].rolling(window=10, min_periods=1).mean()

        # EMA
        dfc["EMA_12"] = dfc["close"].ewm(span=12, adjust=False).mean()
        dfc["EMA_26"] = dfc["close"].ewm(span=26, adjust=False).mean()
        dfc["MACD"] = dfc["EMA_12"] - dfc["EMA_26"]
        dfc["MACD_signal"] = dfc["MACD"].ewm(span=9, adjust=False).mean()

        # RSI (14)
        delta = dfc["close"].diff(1)
        up = delta.clip(lower=0)
        down = -1 * delta.clip(upper=0)
        ma_up = up.rolling(14, min_periods=1).mean()
        ma_down = down.rolling(14, min_periods=1).mean()
        rs = ma_up / (ma_down + 1e-12)
        dfc["RSI_14"] = 100 - (100 / (1 + rs))

        # ATR (14)
        high_low = dfc["high"] - dfc["low"]
        high_close = (dfc["high"] - dfc["close"].shift()).abs()
        low_close = (dfc["low"] - dfc["close"].shift()).abs()
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        dfc["ATR_14"] = tr.rolling(14, min_periods=1).mean()

        # Fill tiny gaps to avoid None types
        numeric_cols = dfc.select_dtypes(include=[np.number]).columns.tolist()
        dfc[numeric_cols] = dfc[numeric_cols].fillna(method="ffill").fillna(method="bfill").fillna(0.0)

        return dfc

    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="agregar_indicadores_tecnicos")
        return df.copy() if isinstance(df, pd.DataFrame) else pd.DataFrame()


# ---------------------------
# 🧾 crear_features_tabulares
# ---------------------------
def crear_features_tabulares(df: pd.DataFrame, pasos: int = 20, future_horizon: int = 1) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Genera X (DataFrame) e y (Series) para modelos tabulares.
    - df: DataFrame con columnas: open, high, low, close, volume y/o indicadores.
    - pasos: ventana histórica usada para construir features.
    - future_horizon: horizonte en barras futuras para la etiqueta.

    Devuelve:
      X: pd.DataFrame (filas = muestras, columnas = features)
      y: pd.Series (0/1, 1 = precio sube al future_horizon)
    """
    try:
        if df is None or df.empty:
            return pd.DataFrame(), pd.Series(dtype=int)

        d = df.copy()
        # Asegurar índice datetime
        if not isinstance(d.index, pd.DatetimeIndex):
            try:
                d.index = pd.to_datetime(d.index)
            except Exception:
                pass

        # Asegurar indicadores mínimos
        d = agregar_indicadores_tecnicos(d)

        X_rows = []
        y_rows = []
        idx_rows = []

        n = len(d)
        for end in range(pasos, n - future_horizon):
            start = end - pasos
            window = d.iloc[start:end]

            # Feature set: estadísticas de la ventana + últimos valores de indicadores
            feats = {}

            # Precios básicos
            feats["close_last"] = float(window["close"].iloc[-1])
            feats["close_mean"] = float(window["close"].mean())
            feats["close_std"] = float(window["close"].std() if window["close"].std() == window["close"].std() else 0.0)
            feats["return_1"] = float(window["close"].pct_change().iloc[-1] if pasos > 1 else 0.0)
            feats["max_high"] = float(window["high"].max())
            feats["min_low"] = float(window["low"].min())
            feats["vol_mean"] = float(window["volume"].mean() if "volume" in window.columns else 0.0)
            # slope-ish: (last - first) / first
            first = window["close"].iloc[0] if window["close"].iloc[0] != 0 else 1e-12
            feats["trend_pct"] = float((window["close"].iloc[-1] - window["close"].iloc[0]) / first)

            # indicadores recientes (última fila del window)
            last = window.iloc[-1]
            for c in ["SMA_5", "SMA_10", "EMA_12", "EMA_26", "MACD", "MACD_signal", "RSI_14", "ATR_14"]:
                feats[c] = float(last.get(c, 0.0) if pd.notna(last.get(c, 0.0)) else 0.0)

            # Ratios y diferencias entre indicadores
            feats["macd_minus_signal"] = feats.get("MACD", 0.0) - feats.get("MACD_signal", 0.0)
            feats["sma5_minus_close"] = feats.get("SMA_5", 0.0) - feats.get("close_last", 0.0)

            X_rows.append(feats)

            # Etiqueta: si el close en future_horizon es mayor al close actual -> 1
            future_close = d["close"].iloc[end + future_horizon]
            y = 1 if future_close > feats["close_last"] else 0
            y_rows.append(y)
            idx_rows.append(d.index[end])  # marca temporal del sample

        if not X_rows:
            return pd.DataFrame(), pd.Series(dtype=int)

        X = pd.DataFrame(X_rows, index=idx_rows)
        y = pd.Series(y_rows, index=idx_rows, name="target")

        # Limpiar NaNs y asegurar tipos numéricos
        X = X.select_dtypes(include=[np.number])
        X = X.fillna(0.0)

        return X, y

    except Exception as e:
        log_error(e, archivo="modelo.py", funcion="crear_features_tabulares")
        return pd.DataFrame(), pd.Series(dtype=int)


# utils/modelo.py (añadir)

import time

def entrenar_ensemble_calibrado_safe(sym: str, df: pd.DataFrame, pasos: int = 20, futuros: int = 1, max_attempts: int = 3, backoff: float = 2.0):
    """
    Wrapper seguro alrededor de entrenar_ensemble_calibrado para:
      - limitar reintentos
      - evitar loop infinito desde predecir_senal_ensemble
      - loguear claramente y devolver None en fallos
    """
    from utils.logger import log_info, log_warning, log_error

    attempt = 0
    last_exc = None
    while attempt < max_attempts:
        try:
            attempt += 1
            log_info(f"entrenar_ensemble_calibrado_safe: attempt {attempt} para {sym}", archivo="modelo.py", funcion="entrenar_ensemble_calibrado_safe")
            # Llamamos a la implementación real (esperamos que exista en tu módulo)
            from utils.modelo import entrenar_ensemble_calibrado  # intenta resolver la función real
            res = entrenar_ensemble_calibrado(df.copy(), activo=sym, pasos=pasos, futuros=futuros)
            return res
        except Exception as e:
            last_exc = e
            log_warning(f"entrenar_ensemble: intento {attempt} falló para {sym}: {e}", archivo="modelo.py", funcion="entrenar_ensemble_calibrado_safe")
            time.sleep(backoff * attempt)
            continue

    log_error(f"entrenar_ensemble_calibrado_safe: falló tras {max_attempts} intentos para {sym}: {last_exc}", archivo="modelo.py", funcion="entrenar_ensemble_calibrado_safe")
    return None

