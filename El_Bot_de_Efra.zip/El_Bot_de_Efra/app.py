# ============================================================
# 🧩 BLOQUE 1 — IMPORTS, CONFIGURACIÓN INICIAL Y LOGGER GLOBAL
# ============================================================

import os
import sys
import time
import json
import base64
import hashlib
import random
import logging
import traceback
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any

import pandas as pd
import numpy as np
import streamlit as st

# TensorFlow - Configuración segura para evitar warnings excesivos
import tensorflow as tf
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)

# Establecer ruta base del proyecto
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
SECURE_DIR = DATA_DIR / "secure"
SECURE_DIR.mkdir(parents=True, exist_ok=True)

# Configuración básica de logging global
LOG_PATH = SECURE_DIR / "bot.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | [%(name)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("BotDeEfra")

# Helpers de logging uniformes
def log_info(msg: str, archivo="app.py", funcion=""):
    logger.info(f"ℹ️ {archivo}.{funcion} -> {msg}")

def log_warning(msg: str, archivo="app.py", funcion=""):
    logger.warning(f"⚠️ {archivo}.{funcion} -> {msg}")

def log_error(err: Exception, archivo="app.py", funcion=""):
    logger.error(f"❌ {archivo}.{funcion} -> {err}")
    traceback.print_exc()

# Variables globales de control
VERSION_BOT = "3.0-secure"
APP_NAME = "🤖 BotDeEfra — Sistema IA de Trading Seguro"
ALLOW_SESSION_RESTORE = False  # seguridad: no restaurar sesiones automáticamente
MAX_SESSION_MINUTES = 60

# Crear carpeta data/secure si no existe
DATA_DIR.mkdir(exist_ok=True)
SECURE_DIR.mkdir(exist_ok=True)

# Mostrar encabezado de versión en consola
log_info(f"{APP_NAME} inicializado — versión {VERSION_BOT}", archivo="app.py", funcion="startup")

# ============================================================
# 🔚 FIN BLOQUE 1
# ============================================================

# ============================================================
# 🧩 BLOQUE 2 — CARGA DE ENTORNO, CLAVES AES Y SEGURIDAD INICIAL
# ============================================================

from cryptography.fernet import Fernet
from utils.security import load_master_key, cifrar, descifrar, ensure_master_key_loaded
from utils.logger import log_info, log_warning, log_error

# Rutas seguras
CLAVE_AES_PATH = SECURE_DIR / "clave_aes.key"

# ============================================================
# 🔑 Carga o creación de clave AES maestra local
# ============================================================
try:
    MASTER_KEY = load_master_key(str(CLAVE_AES_PATH))
    if MASTER_KEY:
        os.environ["DB_MASTER_KEY"] = base64.b64encode(MASTER_KEY).decode("utf-8")
        log_info("🔐 Clave maestra AES cargada correctamente.", archivo="app.py", funcion="bloque_2_startup")
    else:
        raise ValueError("No se pudo cargar la clave AES maestra.")
except Exception as e:
    log_error(e, archivo="app.py", funcion="bloque_2_startup")
    MASTER_KEY = Fernet.generate_key()
    with open(CLAVE_AES_PATH, "wb") as f:
        f.write(MASTER_KEY)
    os.environ["DB_MASTER_KEY"] = base64.b64encode(MASTER_KEY).decode("utf-8")
    log_warning("⚠️ Se generó una nueva clave AES maestra de emergencia.", archivo="app.py", funcion="bloque_2_startup")

# ============================================================
# 🧭 Variables globales seguras y control de sesión
# ============================================================
SESSION_FILE = SECURE_DIR / "session_state.json"
BINANCE_CACHE = SECURE_DIR / "binance_cache.json"

# Control de sesiones activas
def _limpiar_cache_sesion():
    """🧹 Limpia el archivo de cache de sesión (al cerrar o reiniciar sesión)."""
    try:
        if SESSION_FILE.exists():
            SESSION_FILE.unlink()
            log_info("🧹 Cache de sesión eliminada correctamente.", archivo="app.py", funcion="_limpiar_cache_sesion")
    except Exception as e:
        log_warning(f"No se pudo limpiar la cache de sesión: {e}", archivo="app.py", funcion="_limpiar_cache_sesion")


def _guardar_cache_sesion():
    """💾 Guarda datos críticos de la sesión para restauración manual (si se activa)."""
    try:
        if st.session_state.get("usuario"):
            data = {
                "usuario": st.session_state.get("usuario"),
                "rol": st.session_state.get("rol"),
                "fecha": datetime.now().isoformat(),
                "dry_run": st.session_state.get("dry_run", True)
            }
            with open(SESSION_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            log_info("💾 Cache de sesión guardada correctamente.", archivo="app.py", funcion="_guardar_cache_sesion")
    except Exception as e:
        log_warning(f"No se pudo guardar cache de sesión: {e}", archivo="app.py", funcion="_guardar_cache_sesion")


def _restaurar_cache_sesion():
    """♻️ Intenta restaurar una sesión previa (solo si ALLOW_SESSION_RESTORE=True)."""
    try:
        if not ALLOW_SESSION_RESTORE or not SESSION_FILE.exists():
            log_info("Auto-restore de sesión desactivado. Set ALLOW_SESSION_RESTORE=1 para habilitar.", archivo="app.py", funcion="_restaurar_cache_sesion")
            return False

        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not data.get("usuario"):
            return False

        st.session_state.update(data)
        log_info(f"🔁 Sesión restaurada para {data['usuario']}", archivo="app.py", funcion="_restaurar_cache_sesion")
        return True
    except Exception as e:
        log_warning(f"Error restaurando sesión: {e}", archivo="app.py", funcion="_restaurar_cache_sesion")
        return False

# ============================================================
# 🔚 FIN BLOQUE 2
# ============================================================

# ============================================================
# BLOQUE 3 — IMPORTS GLOBALES Y CONSTANTES
# ============================================================
import os
import json
import base64
import hashlib
import hmac
from pathlib import Path
from datetime import datetime, timedelta
from typing import Optional
import sqlite3
import logging

# Streamlit
try:
    import streamlit as st
except Exception:
    st = None  # Permite importar el archivo fuera de Streamlit para análisis unitario

# Dependencias opcionales (se intentan más abajo con try/except)
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
except Exception:
    AES = None

# Rutas y archivos locales
SESSION_FILE = Path(".session_cache.json")
SESSION_CACHE_FILE = SESSION_FILE  # alias
SESSION_HASH_FILE = Path(".session_cache.hash")
SESSION_ROTATION_FILE = Path(".session_rotation.json")
AUDITORIA_DB = Path("data/secure/auditoria_sesiones.db")
RESET_TOKEN_FILE = Path("reset_tokens.json")
BINANCE_MONITOR_DB = Path("data/secure/binance_monitor.db")

# Defaults
SESSION_EXPIRATION_DAYS = 7
SESSION_CACHE_MAX_AGE_HOURS = 48
AUDIT_RETENTION_DAYS = 90

# Seguridad / rotación parámetros por defecto
# FIN BLOQUE 3

# ============================================================
# BLOQUE 4 — LOGGER (WRAPPER)
# ============================================================
# Intenta usar tu logger central (utils.logger), si no, define un fallback simple.
try:
    from utils.logger import log_info, log_warning, log_error
except Exception:
    # Fallback mínimo para no romper en entornos de desarrollo
    def _fmt(msg: str) -> str:
        return f"{datetime.utcnow().isoformat()} - {msg}"

    def log_info(msg: str, **kwargs):
        print("[INFO]", _fmt(msg))

    def log_warning(msg: str, **kwargs):
        print("[WARN]", _fmt(msg))

    def log_error(msg: str, **kwargs):
        print("[ERROR]", _fmt(str(msg)))
# FIN BLOQUE 4

# ============================================================
# BLOQUE 5 — PERSISTENCIA DE SESIÓN, CIFRADO Y HASH (ANTIRREINICIO)
# ============================================================
import os
import json
import base64

# Utilidad para obtener clave de cifrado
def _get_aes_key_from_master(master_key: str) -> bytes:
    """Deriva AES-256 key desde master_key usando SHA256 (fallback)."""
    if not master_key:
        master_key = "efra_local_default_key"
    return hashlib.sha256(master_key.encode("utf-8")).digest()

# Intentar integrar con utils.security.load_master_key (Fernet)
def _get_master_key_bytes() -> bytes:
    """
    Intenta leer la clave maestra desde utils.security.load_master_key (Fernet).
    Si no está disponible, deriva una key desde la variable de entorno DB_MASTER_KEY.
    """
    try:
        from utils.security import load_master_key
        k = load_master_key()
        if isinstance(k, bytes):
            return k
        # si viene en str, devolver bytes
        if isinstance(k, str):
            return k.encode("utf-8")
    except Exception:
        pass
    # fallback: usar env var DB_MASTER_KEY o derivado sha256
    env = os.getenv("DB_MASTER_KEY", "")
    if env:
        try:
            return base64.b64decode(env)
        except Exception:
            return env.encode("utf-8")
    return hashlib.sha256(b"efra_default_master").digest()

# AES helpers (usando Crypto.Cipher si está disponible) — si no, usamos Fernet a través de utils.security.cifrar/descifrar
def _aes_encrypt(plain_text: str, key_bytes: bytes) -> str:
    try:
        if not plain_text:
            return ""
        # Si Crypto.Cipher AES está disponible, usar AES-CBC con IV
        if AES:
            from Crypto.Random import get_random_bytes
            iv = get_random_bytes(16)
            cipher = AES.new(key_bytes[:32], AES.MODE_CBC, iv)
            ct = cipher.encrypt(pad(plain_text.encode("utf-8"), AES.block_size))
            return base64.b64encode(iv + ct).decode("utf-8")
        # Fallback: usar utils.security.cifrar (Fernet)
        from utils.security import cifrar
        return cifrar(plain_text)
    except Exception as e:
        log_warning(f"_aes_encrypt error: {e}", archivo="app.py", funcion="_aes_encrypt")
        return ""

def _aes_decrypt(cipher_text_b64: str, key_bytes: bytes) -> str:
    try:
        if not cipher_text_b64:
            return ""
        if AES:
            raw = base64.b64decode(cipher_text_b64)
            iv = raw[:16]
            ct = raw[16:]
            cipher = AES.new(key_bytes[:32], AES.MODE_CBC, iv)
            pt = unpad(cipher.decrypt(ct), AES.block_size)
            return pt.decode("utf-8")
        from utils.security import descifrar
        return descifrar(cipher_text_b64)
    except Exception as e:
        # Puede ser texto plano o un token Fernet; log y devolver cadena vacía para seguridad
        log_warning(f"_aes_decrypt failed: {e}", archivo="app.py", funcion="_aes_decrypt")
        return ""

# Guardar sesión (simple, sin cifrar sensible)
def _guardar_session_state():
    try:
        data = {
            "usuario": st.session_state.get("usuario"),
            "nombre": st.session_state.get("nombre"),
            "rol": st.session_state.get("rol"),
            "dry_run": st.session_state.get("dry_run", True),
            "binance_api_key": st.session_state.get("binance_api_key"),
            "binance_api_secret": st.session_state.get("binance_api_secret"),
            "modo_demo": st.session_state.get("modo_demo"),
            "permisos": st.session_state.get("permisos", {}),
        }
        with open(SESSION_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as e:
        log_warning(f"No se pudo guardar el estado de sesión: {e}", archivo="app.py", funcion="_guardar_session_state")

def _cargar_session_state():
    try:
        if not SESSION_FILE.exists():
            return False
        with open(SESSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("usuario"):
            for k, v in data.items():
                if k not in st.session_state:
                    st.session_state[k] = v
            log_info(f"🔁 Sesión restaurada para {data.get('usuario')}", archivo="app.py", funcion="_cargar_session_state")
            return True
        return False
    except Exception as e:
        log_warning(f"No se pudo restaurar el estado de sesión: {e}", archivo="app.py", funcion="_cargar_session_state")
        return False

# Versión segura (cifrada) — guarda y carga cifrando claves sensibles
def _guardar_sesion_segura():
    try:
        if not st or not st.session_state.get("usuario"):
            return
        data = dict(st.session_state)
        master_bytes = _get_master_key_bytes()
        for campo in ["binance_api_key", "binance_api_secret"]:
            valor = data.get(campo)
            if valor:
                try:
                    data[campo] = _aes_encrypt(valor, master_bytes)
                except Exception as e:
                    log_warning(f"No se pudo cifrar campo {campo}: {e}", archivo="app.py", funcion="_guardar_sesion_segura")
        with open(SESSION_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
        # guardar hash de integridad
        try:
            h = hmac.new(master_bytes[:32], json.dumps(data, sort_keys=True).encode("utf-8"), hashlib.sha256).hexdigest()
            with open(SESSION_HASH_FILE, "w", encoding="utf-8") as f:
                f.write(h)
        except Exception:
            pass
        log_info("💾 Sesión cifrada guardada correctamente.", archivo="app.py", funcion="_guardar_sesion_segura")
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_guardar_sesion_segura")

def _cargar_sesion_segura():
    try:
        if not SESSION_CACHE_FILE.exists():
            return False
        with open(SESSION_CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # verificar hash si existe
        master_bytes = _get_master_key_bytes()
        try:
            if SESSION_HASH_FILE.exists():
                with open(SESSION_HASH_FILE, "r", encoding="utf-8") as hf:
                    guardado = hf.read().strip()
                actual = hmac.new(master_bytes[:32], json.dumps(data, sort_keys=True).encode("utf-8"), hashlib.sha256).hexdigest()
                if not hmac.compare_digest(guardado, actual):
                    st.warning("⚠️ Archivo de sesión modificado o corrupto. Se limpiará por seguridad.")
                    _limpiar_cache_sesion()
                    return False
        except Exception:
            pass
        for campo in ["binance_api_key", "binance_api_secret"]:
            valor = data.get(campo)
            if valor and isinstance(valor, str):
                try:
                    data[campo] = _aes_decrypt(valor, master_bytes)
                except Exception:
                    pass
        for k, v in data.items():
            st.session_state[k] = v
        log_info("🔐 Sesión descifrada restaurada correctamente.", archivo="app.py", funcion="_cargar_sesion_segura")
        return True
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_cargar_sesion_segura")
        return False

def _limpiar_cache_sesion():
    try:
        if SESSION_CACHE_FILE.exists():
            SESSION_CACHE_FILE.unlink()
        if SESSION_HASH_FILE.exists():
            SESSION_HASH_FILE.unlink()
    except Exception as e:
        log_warning(f"No se pudo eliminar SESSION_FILE/HASH: {e}", archivo="app.py", funcion="_limpiar_cache_sesion")

# Rotación de clave (metadatos en archivo .session_rotation.json)
def _load_rotation_metadata():
    try:
        if SESSION_ROTATION_FILE.exists():
            with open(SESSION_ROTATION_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        log_warning(f"No se pudo leer rotation metadata: {e}", archivo="app.py", funcion="_load_rotation_metadata")
    return {}

def _save_rotation_metadata(meta: dict):
    try:
        with open(SESSION_ROTATION_FILE, "w", encoding="utf-8") as f:
            json.dump(meta, f)
    except Exception as e:
        log_warning(f"No se pudo guardar rotation metadata: {e}", archivo="app.py", funcion="_save_rotation_metadata")

def _debe_rotar_clave() -> bool:
    try:
        meta = _load_rotation_metadata()
        ultima = meta.get("ultima_rotacion")
        if not ultima:
            return True
        fecha = datetime.fromisoformat(ultima)
        return datetime.utcnow() - fecha > timedelta(days=SESSION_EXPIRATION_DAYS)
    except Exception:
        return True

def _rotar_clave_aes():
    try:
        master = os.getenv("DB_MASTER_KEY", "efra_default_master")
        nuevo_nonce = base64.b64encode(os.urandom(16)).decode("utf-8")
        nueva_key = _get_aes_key_from_master(master + nuevo_nonce)
        meta = {"ultima_rotacion": datetime.utcnow().isoformat(), "nonce": nuevo_nonce}
        _save_rotation_metadata(meta)
        log_info("🔄 Clave AES rotada exitosamente.", archivo="app.py", funcion="_rotar_clave_aes")
        return nueva_key
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_rotar_clave_aes")
        return _get_aes_key_from_master(os.getenv("DB_MASTER_KEY", "efra_default_master"))

def _get_current_aes_key():
    try:
        if _debe_rotar_clave():
            return _rotar_clave_aes()
        meta = _load_rotation_metadata()
        master = os.getenv("DB_MASTER_KEY", "efra_default_master")
        nonce = meta.get("nonce", "")
        return _get_aes_key_from_master(master + nonce)
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_get_current_aes_key")
        return _get_aes_key_from_master(os.getenv("DB_MASTER_KEY", "efra_default_master"))

# Limpieza de sesiones antiguas
def _limpiar_sesiones_antiguas():
    try:
        if not SESSION_CACHE_FILE.exists():
            return
        mod_time = datetime.utcfromtimestamp(SESSION_CACHE_FILE.stat().st_mtime)
        if datetime.utcnow() - mod_time > timedelta(hours=SESSION_CACHE_MAX_AGE_HOURS):
            log_warning("🧹 Sesión expirada detectada, limpiando archivos locales.", archivo="app.py", funcion="_limpiar_sesiones_antiguas")
            _limpiar_cache_sesion()
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_limpiar_sesiones_antiguas")

# Auto-inicio: intentar cargar sesión segura si ALLOW_SESSION_RESTORE=1
try:
    if os.getenv("ALLOW_SESSION_RESTORE", "0") == "1":
        _cargar_sesion_segura()
    else:
        log_info("Auto-restore de sesión desactivado. Set ALLOW_SESSION_RESTORE=1 para habilitar.", archivo="app.py", funcion="inicio")
except Exception:
    pass

# Guardar seguro al exit (si se ejecuta en entorno que lo respeta)
try:
    import atexit
    atexit.register(_guardar_sesion_segura)
except Exception:
    pass

# FIN BLOQUE 5

# ============================================================
# BLOQUE 6 — LOGIN / AUTENTICACIÓN (HELPERS) + IP APPROVAL
# ============================================================
import secrets
import string

# Intentar importar helpers reales de tu proyecto
try:
    from utils.auth import (
        actualizar_clave, get_user, login_usuario,
        request_ip_access, list_pending_ip_requests,
        approve_ip_request, deny_ip_request, _get_client_ip,
        _get_connection, registrar_sesion, cerrar_sesion
    )
except Exception:
    # Definiciones fallback que no rompen la carga del archivo. En producción use utils.auth real.
    def actualizar_clave(usuario, nueva):
        log_warning("fallback actualizar_clave invoked", archivo="app.py", funcion="actualizar_clave")
        return True

    def get_user(usuario):
        return {"usuario": usuario, "nombre": usuario, "correo": None}

    def login_usuario(u, p, ip_actual=None):
        # login dummy: acepta usuario 'admin' con cualquier clave; otras cuentas permitidas si p == 'demo'
        if not u:
            return {"error": "usuario_no_existe"}
        if u == "admin":
            return {"usuario": "admin", "es_admin": True, "ip_ok": True}
        if p == "demo":
            return {"usuario": u, "es_admin": False, "ip_ok": True}
        return {"error": "clave_incorrecta"}

    def request_ip_access(usuario, ip):
        log_info(f"Solicitud IP para {usuario} registrada: {ip}")
        return True

    def list_pending_ip_requests():
        return []

    def approve_ip_request(rid):
        return True

    def deny_ip_request(rid):
        return True

    def _get_client_ip():
        return "0.0.0.0"

    def _get_connection():
        return sqlite3.connect(":memory:")

    def registrar_sesion(usuario):
        log_info(f"registrar_sesion fallback: {usuario}")

    def cerrar_sesion(usuario):
        # retorna dur_seg, acum_seg, falt_seg
        return 0, 0, 7200

# Funciones de notificación (intentos flexibles)
try:
    from utils.telegram_bot import enviar_mensaje_admin as enviar_telegram_admin
except Exception:
    enviar_telegram_admin = None

def enviar_telegram(msg: str):
    try:
        # tratar de usar enviar_mensaje_admin si existe
        if enviar_telegram_admin:
            enviar_telegram_admin(msg)
            return True
        # fallback a utils.telegram_bot.enviar_mensaje (si existe)
        try:
            from utils.telegram_bot import enviar_mensaje
            enviar_mensaje(msg)
            return True
        except Exception:
            log_info("No hay canal Telegram configurado.")
            return False
    except Exception as e:
        log_warning(f"enviar_telegram fallo: {e}", archivo="app.py", funcion="enviar_telegram")
        return False

# FIN BLOQUE 6

# ============================================================
# BLOQUE 7 — UTILIDADES DE TOKEN PARA RECUPERACIÓN DE CLAVE
# ============================================================
import string
import secrets

def _load_reset_tokens():
    try:
        if not RESET_TOKEN_FILE.exists():
            return {}
        with open(RESET_TOKEN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log_warning(f"No se pudo leer reset tokens: {e}", archivo="app.py", funcion="_load_reset_tokens")
        return {}

def _save_reset_tokens(data: dict):
    try:
        with open(RESET_TOKEN_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as e:
        log_warning(f"No se pudo guardar reset tokens: {e}", archivo="app.py", funcion="_save_reset_tokens")

def _generar_token(length: int = 6) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def _guardar_token(usuario: str, correo: str, token: str, minutos: int = 15):
    try:
        tokens = _load_reset_tokens()
        vencimiento = (datetime.utcnow() + timedelta(minutes=minutos)).timestamp()
        tokens[usuario] = {"token": token, "correo": correo, "expires": vencimiento}
        _save_reset_tokens(tokens)
        log_info(f"Token guardado para {usuario}", archivo="app.py", funcion="_guardar_token")
        return True
    except Exception as e:
        log_warning(f"No se pudo guardar token: {e}", archivo="app.py", funcion="_guardar_token")
        return False

def _validar_token(usuario: str, token: str):
    tokens = _load_reset_tokens()
    data = tokens.get(usuario)
    if not data:
        return False, "token_no_generado"
    if data.get("token") != token:
        return False, "token_incorrecto"
    if datetime.utcnow().timestamp() > float(data.get("expires", 0)):
        return False, "token_expirado"
    return True, "ok"

def _borrar_token(usuario: str):
    try:
        tokens = _load_reset_tokens()
        if usuario in tokens:
            tokens.pop(usuario, None)
            _save_reset_tokens(tokens)
            log_info(f"Token borrado para {usuario}", archivo="app.py", funcion="_borrar_token")
    except Exception as e:
        log_warning(f"No se pudo borrar token: {e}", archivo="app.py", funcion="_borrar_token")

# FIN BLOQUE 7

# ============================================================
# BLOQUE 8 — OBTENER SALDO DE BINANCE (ROBUSTO)
# ============================================================
from typing import Optional

def obtener_saldo_usuario(usuario: str, asset: str = "USDT") -> Optional[float]:
    """
    Consulta el saldo de un usuario en Binance.
    Retorna float o None.
    Respeta modo DEMO y gestiona errores.
    """
    try:
        datos = get_user(usuario)
        if not datos:
            log_warning(f"Usuario no encontrado: {usuario}", archivo="app.py", funcion="obtener_saldo_usuario")
            registrar_auditoria("saldo_error", detalle=f"Usuario no encontrado ({usuario})", usuario=usuario)
            return None

        # Modo demo
        if st and st.session_state.get("dry_run", True):
            registrar_auditoria("saldo_demo", detalle=f"Saldo simulado consultado ({asset})", usuario=usuario)
            return 100.0

        api_key = (datos.get("clave1_binance") or "").strip()
        api_secret = (datos.get("clave2_binance") or "").strip()
        if not api_key or not api_secret:
            log_warning(f"Usuario {usuario} sin claves Binance.", archivo="app.py", funcion="obtener_saldo_usuario")
            registrar_auditoria("saldo_sin_claves", detalle="Claves Binance ausentes", usuario=usuario)
            return None

        try:
            from utils.trading import TradingExecutor
            exec_user = TradingExecutor(api_key=api_key, api_secret=api_secret, dry_run=False)
        except Exception as e_init:
            log_error(e_init, archivo="app.py", funcion="obtener_saldo_usuario_init")
            registrar_auditoria("saldo_error_init", detalle=str(e_init), usuario=usuario)
            return None

        try:
            bal = exec_user.get_balance(asset)
        except Exception as e_bal:
            log_error(e_bal, archivo="app.py", funcion="obtener_saldo_usuario_balance")
            registrar_auditoria("saldo_error_binance", detalle=str(e_bal), usuario=usuario)
            return None

        if bal is None:
            registrar_auditoria("saldo_none", detalle=f"Saldo None recibido ({asset})", usuario=usuario)
            return None

        # Normalizar
        try:
            if isinstance(bal, dict):
                if "free" in bal:
                    val = float(bal.get("free", 0))
                elif "total" in bal:
                    val = float(bal.get("total", 0))
                else:
                    return None
            elif isinstance(bal, (str, float, int)):
                val = float(str(bal).replace(",", "."))
            else:
                return None
            registrar_auditoria("saldo_ok", detalle=f"Saldo {asset}: {val:.4f}", usuario=usuario)
            return val
        except Exception as e_cast:
            log_error(e_cast, archivo="app.py", funcion="obtener_saldo_usuario_cast")
            registrar_auditoria("saldo_error_parseo", detalle=str(e_cast), usuario=usuario)
            return None

    except Exception as e:
        log_error(e, archivo="app.py", funcion="obtener_saldo_usuario")
        return None

# FIN BLOQUE 8

# ============================================================
# BLOQUE 9 — CAPTURA DE FIRMA (UI)
# ============================================================
import base64

def captura_firma_ui(usuario: str):
    """
    Renderiza canvas para firma y guarda en la BD (columna firma_tratamiento_datos).
    Requiere streamlit_drawable_canvas instalado en el entorno.
    """
    try:
        st.markdown("### ✍️ Firma de autorización de tratamiento de datos")
        st.caption("Por favor firme en el recuadro para autorizar el uso de sus datos.")

        try:
            from streamlit_drawable_canvas import st_canvas
        except Exception:
            st.error("streamlit_drawable_canvas no está disponible.")
            return

        canvas_result = st_canvas(
            fill_color="rgba(255, 255, 255, 0)",
            stroke_width=2,
            stroke_color="black",
            background_color="white",
            height=200,
            width=400,
            drawing_mode="freedraw",
            key=f"canvas_firma_{usuario}"
        )

        if st.button("Guardar firma", key=f"ui_btn_guardar_firma_{usuario}"):
            if canvas_result and getattr(canvas_result, "image_data", None) is not None:
                try:
                    import cv2
                    import numpy as np
                    img = (canvas_result.image_data * 255).astype(np.uint8)
                    _, buf = cv2.imencode(".png", cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA))
                    firma_b64 = base64.b64encode(buf).decode("utf-8")
                    conn = _get_connection()
                    cur = conn.cursor()
                    # Asegurar columna
                    cur.execute("PRAGMA table_info(usuarios)")
                    cols = [r[1] for r in cur.fetchall()]
                    if "firma_tratamiento_datos" not in cols:
                        cur.execute("ALTER TABLE usuarios ADD COLUMN firma_tratamiento_datos TEXT")
                    cur.execute("UPDATE usuarios SET firma_tratamiento_datos = ? WHERE usuario = ?", (firma_b64, usuario))
                    conn.commit()
                    conn.close()
                    st.success("✅ Firma guardada con éxito")
                    registrar_auditoria("firma_guardada", detalle=f"Firma guardada para {usuario}", usuario=usuario)
                except Exception as e:
                    log_error(e, archivo="app.py", funcion="captura_firma_ui")
                    st.error("❌ No se pudo guardar la firma.")
            else:
                st.warning("⚠️ No se detectó firma, intente de nuevo.")
    except Exception as e:
        log_error(e, archivo="app.py", funcion="captura_firma_ui")
        try:
            st.error("Error en captura de firma.")
        except Exception:
            pass

# FIN BLOQUE 9

# ============================================================
# BLOQUE 10 — TIEMPO DE SESIÓN RESTANTE (UI)
# ============================================================
def mostrar_tiempo_restante(usuario: str, max_diario_seg: int = 7200):
    """
    Muestra en UI cuánto tiempo le queda al usuario hoy.
    Lee la columna duracion_acumulada_seg de la tabla usuarios.
    """
    try:
        conn = _get_connection()
        cur = conn.cursor()
        cur.execute("SELECT duracion_acumulada_seg FROM usuarios WHERE usuario = ?", (usuario,))
        row = cur.fetchone()
        conn.close()
        usado = int(row[0] or 0) if row else 0
        restante = max(0, max_diario_seg - usado)
        mins, segs = divmod(restante, 60)
        if st:
            st.info(f"⏳ Tiempo restante hoy: {mins} min {segs} seg")
        return restante
    except Exception as e:
        log_error(e, archivo="app.py", funcion="mostrar_tiempo_restante")
        if st:
            st.warning("⚠️ No se pudo calcular el tiempo restante.")
        return 0

# FIN BLOQUE 10


# ======================================================
# 🧩 BLOQUE 11 — LOGIN UI (ROBUSTECIDO Y CORREGIDO)
# ======================================================

def login_ui():
    """
    🔐 Interfaz de autenticación principal del Bot de Efra.
    Fortificada y corregida:
      - Keys únicas para widgets
      - No renderiza panel del bot antes del login
      - Inicializa clave AES de forma defensiva
      - Auditoría en acciones importantes
      - Descifra claves Binance si existen
      - Confirmación de fuente de activos antes de obtener tickers
      - Crea/asegura TradingExecutor solo cuando se necesita (al confirmar fuente o iniciar análisis)
    """
    try:
        # =====================================================
        # 0️⃣ — Inicialización segura de la clave maestra
        # =====================================================
        try:
            # Si tienes load_master_key en otro bloque, úsalo; sino, esto no rompe.
            from app import load_master_key  # puede lanzar si se reorganizó el archivo
            MASTER_KEY = load_master_key()
            if MASTER_KEY:
                os.environ["DB_MASTER_KEY"] = base64.b64encode(MASTER_KEY).decode("utf-8")
        except Exception as e_key:
            log_warning(f"Fallo al inicializar clave maestra: {e_key}", archivo="app.py", funcion="login_ui")
            # fallback no rompedor
            try:
                os.environ["DB_MASTER_KEY"] = base64.b64encode(hashlib.sha256(b"efra_default_master").digest()).decode()
            except Exception:
                pass

        client_ip = _get_client_ip()

        # =====================================================
        # 🧭 INTERFAZ SIDEBAR — LOGIN O PANEL
        # =====================================================
        with st.sidebar:
            # =====================================================
            # 🟡 1️⃣ — LOGIN (cuando no hay usuario autenticado)
            # =====================================================
            if not st.session_state.get("usuario"):
                st.markdown("## 🔑 Inicio de sesión")

                usuario_input = st.text_input("👤 Usuario", key="ui_usuario_login")
                clave_input = st.text_input("🔒 Contraseña", type="password", key="ui_clave_login")

                # ⚙️ Selección del modo de operación (DEMO / REAL)
                modo = st.radio(
                    "⚙️ Modo de operación",
                    ["DEMO", "REAL"],
                    index=0,
                    horizontal=True,
                    key="ui_modo_login"
                )
                # Guardar preferencia inmediata pero no inicializar executor aún
                st.session_state["dry_run"] = (modo == "DEMO")

                # Botón ingresar (acción explícita)
                if st.button("Ingresar", key="ui_btn_ingresar"):
                    try:
                        auth = login_usuario(usuario_input, clave_input, ip_actual=client_ip)
                        if not auth or "error" in auth:
                            err = auth.get("error") if auth else "error_desconocido"
                            errores = {
                                "usuario_no_existe": "❌ El usuario no existe.",
                                "usuario_inhabilitado": "⚠️ Usuario inhabilitado.",
                                "clave_incorrecta": "❌ Clave incorrecta.",
                                "ip_no_detectada": "⚠️ No se pudo detectar tu IP.",
                                "ip_no_autorizada": f"⚠️ Tu IP ({client_ip}) no está autorizada.",
                                "ip_pendiente_autorizacion": "⚠️ IP pendiente de autorización.",
                                "tiempo_excedido": "⏳ Tiempo diario excedido."
                            }
                            st.error(errores.get(err, "⚠️ Error interno al iniciar sesión."))
                            registrar_auditoria("login_fallido", detalle=f"Usuario {usuario_input} ({err})", ip=client_ip)
                        else:
                            # Login ok → preparar datos de usuario y persistir en session_state
                            datos_user = get_user(auth["usuario"])
                            nombre_real = datos_user.get("nombre", auth["usuario"]) if datos_user else auth["usuario"]

                            api_key, api_secret = None, None
                            try:
                                from utils.security import descifrar
                                if datos_user:
                                    if datos_user.get("clave1_binance"):
                                        api_key = descifrar(datos_user["clave1_binance"])
                                    if datos_user.get("clave2_binance"):
                                        api_secret = descifrar(datos_user["clave2_binance"])
                            except Exception as e_dec:
                                log_warning(f"Descifrado fallido: {e_dec}", archivo="app.py", funcion="login_ui_descifrar")
                                api_key, api_secret = None, None

                            st.session_state["binance_api_key"] = api_key
                            st.session_state["binance_api_secret"] = api_secret

                            # ADMIN
                            if auth.get("es_admin"):
                                st.session_state.update({
                                    "usuario": auth["usuario"],
                                    "nombre": nombre_real,
                                    "rol": "admin",
                                    "permisos": obtener_permisos(auth["usuario"]),
                                    "modo_demo": modo,
                                    "dry_run": (modo == "DEMO")
                                })
                                try:
                                    enviar_telegram(f"✅ Nuevo inicio de sesión\n👤 <b>{nombre_real}</b> (admin)\n🌐 IP: {client_ip}")
                                except Exception as e:
                                    log_warning(f"Enviar telegram admin fallo: {e}", archivo="app.py", funcion="login_telegram")
                                try:
                                    registrar_auditoria("login_exitoso", detalle=f"Admin {nombre_real} inició sesión.", usuario=auth["usuario"], ip=client_ip)
                                except Exception:
                                    pass
                                # recargar para que app muestre panel autenticado
                                try:
                                    st.rerun()
                                except Exception:
                                    safe_rerun()

                            # USUARIO normal con IP ok
                            elif auth.get("ip_ok"):
                                st.session_state.update({
                                    "usuario": auth["usuario"],
                                    "nombre": nombre_real,
                                    "rol": "user",
                                    "permisos": obtener_permisos(auth["usuario"]),
                                    "modo_demo": modo,
                                    "dry_run": (modo == "DEMO")
                                })
                                if datos_user and not datos_user.get("firma_tratamiento_datos"):
                                    st.session_state["requiere_firma"] = True
                                else:
                                    st.session_state["requiere_firma"] = False
                                try:
                                    registrar_auditoria("login_exitoso", detalle=f"Usuario {nombre_real} inició sesión.", usuario=auth["usuario"], ip=client_ip)
                                except Exception:
                                    pass
                                try:
                                    enviar_telegram(f"✅ Nuevo inicio de sesión\n👤 <b>{nombre_real}</b>\n🌐 IP: {client_ip}")
                                except Exception as e:
                                    log_warning(f"Enviar telegram usuario fallo: {e}", archivo="app.py", funcion="login_telegram")
                                try:
                                    st.rerun()
                                except Exception:
                                    safe_rerun()

                            # IP no autorizada
                            else:
                                st.warning("⚠️ Tu IP no está autorizada para este usuario.")
                                registrar_auditoria("login_ip_no_autorizada", detalle=f"Login intento IP no autorizada ({client_ip})", usuario=usuario_input, ip=client_ip)
                                if st.button("Solicitar autorización de esta IP", key="ui_btn_request_ip"):
                                    try:
                                        ok = request_ip_access(usuario_input, client_ip)
                                        if ok:
                                            st.success("✅ Petición enviada al administrador.")
                                            registrar_auditoria("request_ip_access", detalle=f"Solicitud IP {client_ip} para {usuario_input}", usuario=usuario_input, ip=client_ip)
                                        else:
                                            st.error("❌ No se pudo registrar la petición.")
                                    except Exception as e:
                                        log_error(e, archivo="app.py", funcion="request_ip_access_ui")
                                        st.error("❌ Error registrando petición de IP.")


                # Recuperación de clave: flujo simple (inicio → solicitar → cambiar)
                st.markdown("---")
                st.markdown("### 🔐 ¿Olvidaste tu clave?")
                if "recuperar_estado" not in st.session_state:
                    st.session_state["recuperar_estado"] = "inicio"
                    st.session_state["usuario_recuperacion"] = None
                    st.session_state["token_recuperacion"] = None

                estado = st.session_state["recuperar_estado"]
                if estado == "inicio":
                    if st.button("¿Olvidaste tu clave?", key="ui_btn_olvide"):
                        st.session_state["recuperar_estado"] = "solicitar"
                        st.rerun()
                    # detener render del panel de autenticación para no mezclar lógica
                    return

                elif estado == "solicitar":
                    usuario_req = st.text_input("👤 Ingresa tu usuario", key="ui_usuario_recuperar")
                    if st.button("📨 Enviar token", key="ui_btn_enviar_token"):
                        try:
                            datos = get_user(usuario_req)
                            if datos and datos.get("correo"):
                                token = _generar_token()
                                _guardar_token(usuario_req, datos["correo"], token)
                                cuerpo = (
                                    f"Hola {usuario_req},\n\n"
                                    "Tu token temporal es: "
                                    f"{token}\n\n"
                                    "Expira en 15 minutos.\nEl Bot de Efra 🚀"
                                )
                                if enviar_email(datos["correo"], "🔐 Recuperación de clave", cuerpo):
                                    st.success("✅ Token enviado a tu correo.")
                                    st.session_state["recuperar_estado"] = "cambiar"
                                    registrar_auditoria("token_enviado", detalle=f"Token enviado a {usuario_req}", usuario=usuario_req, ip=client_ip)
                                else:
                                    st.error("❌ No se pudo enviar el token.")
                            else:
                                st.error("❌ Usuario no encontrado o sin correo registrado.")
                        except Exception as e:
                            log_error(e, archivo="app.py", funcion="recuperar_clave")
                            st.error("❌ Error al procesar la solicitud.")
                    return

                elif estado == "cambiar":
                    token_input = st.text_input("🔑 Token recibido", key="ui_token_recuperar")
                    nueva_clave = st.text_input("🆕 Nueva clave", type="password", key="ui_nueva_clave")
                    confirmar_clave = st.text_input("🔄 Confirmar clave", type="password", key="ui_confirmar_clave")

                    if st.button("✅ Cambiar clave", key="ui_btn_cambiar_clave"):
                        try:
                            valido, msg = _validar_token(st.session_state.get("usuario_recuperacion", ""), token_input)
                            if not valido:
                                st.error(f"❌ Token inválido: {msg}")
                                registrar_auditoria("token_invalido", detalle=f"Token inválido para {st.session_state.get('usuario_recuperacion')}", usuario=st.session_state.get('usuario_recuperacion'), ip=client_ip)
                            elif nueva_clave != confirmar_clave:
                                st.error("❌ Las claves no coinciden.")
                            elif len(nueva_clave) < 4:
                                st.warning("⚠️ Clave demasiado corta.")
                            else:
                                if actualizar_clave(st.session_state.get("usuario_recuperacion", ""), nueva_clave):
                                    st.success("✅ Clave cambiada correctamente.")
                                    registrar_auditoria("clave_cambiada", detalle=f"Clave cambiada para {st.session_state.get('usuario_recuperacion')}", usuario=st.session_state.get('usuario_recuperacion'), ip=client_ip)
                                    st.session_state["recuperar_estado"] = "inicio"
                                    st.rerun()
                                else:
                                    st.error("❌ Error al actualizar la clave.")
                        except Exception as e:
                            log_error(e, archivo="app.py", funcion="cambiar_clave")
                            st.error("❌ Error al cambiar la clave.")
                    return

            # =====================================================
            # 🟢 2️⃣ — PANEL DE USUARIO AUTENTICADO
            # =====================================================
            else:
                # Mostrar datos del usuario autenticado
                nombre = st.session_state.get("nombre", st.session_state.get("usuario"))
                rol = st.session_state.get("rol", "user")
                rol_str = "👑 Administrador" if rol == "admin" else "🙋 Usuario"

                st.markdown(f"### 👤 {nombre}")
                st.caption(rol_str)
                st.caption(f"🛠️ Modo actual: {'REAL' if not st.session_state.get('dry_run', True) else 'DEMO'}")

                # Firma pendiente
                if st.session_state.get("requiere_firma"):
                    st.warning("⚠️ Debes registrar tu firma antes de continuar.")
                    captura_firma_ui(st.session_state.get("usuario"))
                    datos_user = get_user(st.session_state.get("usuario"))
                    if datos_user and datos_user.get("firma_tratamiento_datos"):
                        st.success("✅ Firma registrada. Ya puedes usar el bot.")
                        st.session_state["requiere_firma"] = False
                        st.rerun()
                    # detener render hasta que firme
                    return

                # Mostrar tiempo restante (solo usuarios)
                if rol != "admin":
                    try:
                        mostrar_tiempo_restante(st.session_state.get("usuario"))
                    except Exception as e:
                        log_warning(f"mostrar_tiempo_restante fallo: {e}", archivo="app.py", funcion="login_ui")

                # =====================================================
                # 🌐 Fuente de activos (persistente hasta confirmar)
                # =====================================================
                if "fuente_activos" not in st.session_state:
                    fuente = st.radio(
                        "📦 Fuente de Activos",
                        ["Base de Datos", "Binance"],
                        horizontal=True,
                        key="ui_fuente_activos"
                    )
                    if st.button("Confirmar Fuente", key="ui_btn_confirmar_fuente"):
                        st.session_state["fuente_activos"] = fuente
                        registrar_auditoria("fuente_activos_confirmada", detalle=f"Fuente seleccionada: {fuente}", usuario=st.session_state.get("usuario"), ip=client_ip)
                        # Solo crear executor si escogió BINANCE y está en modo REAL
                        try:
                            if fuente == "Binance" and not st.session_state.get("dry_run", True):
                                ensure_trading_executor(api_key=st.session_state.get("binance_api_key"), api_secret=st.session_state.get("binance_api_secret"))
                        except Exception as e:
                            log_warning(f"No se pudo inicializar trading executor al confirmar fuente: {e}", archivo="app.py", funcion="login_ui_confirmar_fuente")
                        try:
                            st.rerun()
                        except Exception:
                            safe_rerun()
                    # detener hasta confirmar
                    return

                # =====================================================
                # 📊 Selección de activo (ya hay fuente confirmada)
                # =====================================================
                activos = ["BTCUSDT", "BNBUSDT", "ETHUSDT"]
                try:
                    if st.session_state.get("fuente_activos") == "Base de Datos":
                        from utils.db import obtener_activos
                        activos = obtener_activos() or activos
                        if not activos and os.path.exists("activos.csv"):
                            import pandas as pd
                            df_act = pd.read_csv("activos.csv")
                            activos = df_act["simbolo"].dropna().unique().tolist() if "simbolo" in df_act.columns else activos
                    else:
                        # Fuente Binance: solo intentar obtener tickers si el executor/cliente existe
                        te = st.session_state.get("trading_executor") or (trading_executor if "trading_executor" in globals() else None)
                        client = getattr(te, "client", None) if te else None
                        if client:
                            try:
                                tickers = client.get_all_tickers()
                                activos = sorted([t["symbol"] for t in tickers if t.get("symbol", "").endswith("USDT")])
                                if not activos:
                                    log_warning("obtener_tickers: Binance devolvió lista vacía, usando fallback", archivo="app.py", funcion="login_ui")
                                    activos = ["BTCUSDT", "BNBUSDT", "ETHUSDT"]
                            except Exception as e:
                                log_warning(f"Error consultando tickers Binance: {e}", archivo="app.py", funcion="login_ui")
                                activos = ["BTCUSDT", "BNBUSDT", "ETHUSDT"]
                except Exception as e:
                    log_error(e, archivo="app.py", funcion="login_ui_cargar_activos")
                    activos = ["BTCUSDT", "BNBUSDT", "ETHUSDT"]

                activo = st.selectbox("📌 Selecciona activo", activos, key="ui_activo")

                # =====================================================
                # ⚙️ Configuración análisis
                # =====================================================
                stop_loss_pct = st.number_input(
                    "📉 Stop Loss (%)", min_value=0.5, max_value=10.0,
                    value=st.session_state.get("stop_loss_pct", 2.0),
                    step=0.5,
                    key="ui_stop_loss"
                )

                st.session_state.update({
                    "activo": activo,
                    "stop_loss_pct": stop_loss_pct
                })

                # =====================================================
                # 🚀 Botones de análisis
                # =====================================================
                if not st.session_state.get("analisis_activo", False):
                    if st.button("🚀 Iniciar análisis", key="ui_btn_iniciar_analisis"):
                        try:
                            if st.session_state.get("fuente_activos") == "Binance" and not st.session_state.get("dry_run", True):
                                ensure_trading_executor(api_key=st.session_state.get("binance_api_key"), api_secret=st.session_state.get("binance_api_secret"))
                        except Exception as e:
                            log_warning(f"Fallo al preparar executor antes de iniciar análisis: {e}", archivo="app.py", funcion="login_ui_iniciar_analisis")

                        st.session_state["analisis_activo"] = True
                        st.session_state["analisis_pendiente"] = {
                            "activo": activo,
                            "usar_avanzado": True,
                            "usar_agresivo": False,
                            "umbral_confianza": 70.0
                        }
                        registrar_auditoria("analisis_iniciado", detalle=f"Analisis iniciado para {activo}", usuario=st.session_state.get("usuario"), ip=client_ip)
                        try:
                            st.rerun()
                        except Exception:
                            safe_rerun()
                else:
                    if st.button("⛔ Finalizar análisis", key="ui_btn_finalizar_analisis"):
                        st.session_state["analisis_activo"] = False
                        st.session_state["analisis_pendiente"] = None
                        registrar_auditoria("analisis_finalizado", detalle=f"Analisis finalizado para {st.session_state.get('activo')}", usuario=st.session_state.get("usuario"), ip=client_ip)
                        try:
                            st.rerun()
                        except Exception:
                            safe_rerun()

                # =====================================================
                # 🔒 Cierre de sesión
                # =====================================================
                st.markdown("---")
                if st.button("Cerrar sesión", key="ui_btn_cerrar_sesion"):
                    try:
                        nombre = st.session_state.get("nombre", "Usuario")
                        usuario = st.session_state.get("usuario", "desconocido")
                        try:
                            dur_seg, acum_seg, falt_seg = cerrar_sesion(usuario)
                        except Exception as e:
                            log_warning(f"cerrar_sesion fallo: {e}", archivo="app.py", funcion="cerrar_sesion")
                            dur_seg, acum_seg, falt_seg = 0, 0, 7200

                        try:
                            enviar_telegram(
                                f"👋 Hasta pronto <b>{nombre}</b>.\n"
                                f"🔒 Sesión cerrada.\n"
                                f"🕓 Esta sesión: {dur_seg//60} min\n"
                                f"🧮 Total: {acum_seg//60} min\n"
                                f"⏰ Quedan: {falt_seg//3600}h {(falt_seg%3600)//60}m"
                            )
                        except Exception as e:
                            log_warning(f"Enviar telegram cierre sesion fallo: {e}", archivo="app.py", funcion="cerrar_sesion_telegram")

                        st.session_state.clear()
                        st.session_state["dry_run"] = True
                        _limpiar_cache_sesion()
                        registrar_auditoria("logout", detalle=f"{usuario} cerró sesión", usuario=usuario, ip=client_ip)
                        try:
                            st.rerun()
                        except Exception:
                            safe_rerun()
                    except Exception as e:
                        log_error(e, archivo="app.py", funcion="cerrar_sesion_ui")
                        st.sidebar.error("⚠️ No se pudo cerrar sesión.")

    except Exception as e:
        log_error(e, archivo="app.py", funcion="login_ui_general")
        # Evitar mostrar panel principal si falla; solo notificar
        try:
            st.sidebar.error("❌ Error general en la interfaz de login. Revisa logs.")
        except Exception:
            pass

# ============================
# FIN BLOQUE 11
# ============================

# ============================================================
# 🧩 BLOQUE 12 — POST LOGIN (GESTIÓN DE SESIONES Y PANEL PRINCIPAL)
# ============================================================
import pandas as pd
import time

def gestionar_sesiones_activas():
    """
    🧠 Controla sesiones activas y auditorías.
    Limpia sesiones expiradas, muestra panel principal y datos de usuario.
    No se ejecuta antes del login.
    """
    try:
        # 🕓 Limpieza de sesiones antiguas
        try:
            _limpiar_sesiones_antiguas()
        except Exception as e:
            log_warning(f"Error limpiando sesiones antiguas: {e}", archivo="app.py", funcion="gestionar_sesiones_activas")

        # ⚙️ Si no hay usuario logueado, detener ejecución
        if not st.session_state.get("usuario"):
            return

        usuario = st.session_state["usuario"]
        rol = st.session_state.get("rol", "user")

        # =====================================================
        # 🧾 Auditoría resumida de la sesión actual
        # =====================================================
        try:
            auditorias = obtener_auditorias_recientes(usuario)
            if auditorias is not None and not auditorias.empty:
                with st.expander("🧾 Auditoría reciente", expanded=False):
                    st.dataframe(auditorias.tail(10), use_container_width=True)
        except Exception as e:
            log_warning(f"No se pudo mostrar auditorías: {e}", archivo="app.py", funcion="gestionar_sesiones_activas")

        # =====================================================
        # 💬 Mensajes del sistema
        # =====================================================
        try:
            mensajes = obtener_mensajes_sistema()
            if mensajes:
                with st.expander("💬 Mensajes del sistema", expanded=False):
                    for msg in mensajes[-5:]:
                        st.info(msg)
        except Exception as e:
            log_warning(f"No se pudieron cargar mensajes: {e}", archivo="app.py", funcion="gestionar_sesiones_activas")

        # =====================================================
        # ⏱️ Tiempo restante de sesión (solo usuario)
        # =====================================================
        if rol != "admin":
            try:
                mostrar_tiempo_restante(usuario)
            except Exception as e:
                log_warning(f"mostrar_tiempo_restante fallo: {e}", archivo="app.py", funcion="gestionar_sesiones_activas")

        # =====================================================
        # 💰 Balance estimado (modo demo o real)
        # =====================================================
        try:
            panel_balance_usuario()
        except Exception as e:
            log_warning(f"No se pudo mostrar balance: {e}", archivo="app.py", funcion="gestionar_sesiones_activas")

    except Exception as e:
        log_error(e, archivo="app.py", funcion="gestionar_sesiones_activas")
        st.error("⚠️ Error general al gestionar sesiones activas.")

# ======================================================
# 🧩 BLOQUE 12 — UTILIDADES DE SOPORTE PARA BLOQUE 12
# ======================================================

def obtener_auditorias_recientes(usuario: str, limite: int = 10):
    """📜 Obtiene las últimas acciones registradas del usuario."""
    try:
        df = pd.read_csv("data/auditoria_sesiones.csv")
        df = df[df["usuario"] == usuario].tail(limite)
        return df
    except Exception:
        return None

def obtener_mensajes_sistema():
    """💬 Carga mensajes o alertas del sistema."""
    try:
        path = "data/mensajes_sistema.txt"
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return [line.strip() for line in f.readlines() if line.strip()]
        return []
    except Exception:
        return []

def check_session():
    """
    🚨 Verifica si existe una sesión válida y autenticada.
    Si no la hay, corta la ejecución y exige login.
    """
    try:
        if not st.session_state.get("usuario"):
            st.warning("⚠️ Debes iniciar sesión para acceder al bot.")
            st.stop()

        usuario = st.session_state.get("usuario", "desconocido")
        registrar_auditoria("sesion_validada", detalle=f"Sesión activa validada para {usuario}", usuario=usuario)
        log_info(f"✅ Sesión válida para {usuario}", archivo="app.py", funcion="check_session")

    except Exception as e:
        log_error(e, archivo="app.py", funcion="check_session")
        st.error("❌ Error validando la sesión actual.")
# FIN BLOQUE 12

# ============================================================
# 🧩 BLOQUE 13 — TABS INTELIGENTES Y MONITOREO DE INTEGRIDAD
# ============================================================

def construir_tabs():
    """
    🧭 Construye pestañas según permisos y rol del usuario.
    - Valida sesión activa
    - Registra auditoría
    """
    check_session()
    permisos = st.session_state.get("permisos", {}) or {}
    rol = st.session_state.get("rol", "user").lower()
    es_admin = rol == "admin" or permisos.get("es_admin", False)

    # ------------------------------------------------------------
    # 🧱 Construcción dinámica
    # ------------------------------------------------------------
    if es_admin:
        tabs_nombres = ["📊 Analizar", "🧠 Entrenar", "📜 Historial", "📈 Backtesting", "🏆 Ranking", "⚙️ Configuración"]
    else:
        tabs_nombres = ["📊 Analizar", "🧠 Entrenar", "📜 Historial"]
        if permisos.get("ver_backtesting", False):
            tabs_nombres.append("📈 Backtesting")
        if permisos.get("ver_senales", False):
            tabs_nombres.append("🏆 Ranking")

    tabs = st.tabs(tabs_nombres)
    idx = {name: i for i, name in enumerate(tabs_nombres)}

    # 🧾 Auditoría: qué pestañas se generaron
    try:
        usuario = st.session_state.get("usuario", "desconocido")
        registrar_auditoria("tabs_construidas", detalle=f"{usuario} → {', '.join(tabs_nombres)}", usuario=usuario)
    except Exception:
        pass

    return tabs, idx

# Parámetros de monitoreo
MONITOR_WINDOW_MINUTES = 10
ALERT_THRESHOLD = 5
ALERT_RATE_LIMIT_PER_HOUR = 3

def monitor_integridad_binance(symbol: str = None,
                               minutes_window: int = MONITOR_WINDOW_MINUTES,
                               threshold: int = ALERT_THRESHOLD,
                               dry_run_report: bool = False) -> dict:
    """
    📡 Analiza errores recientes y envía alertas a admin si aplica.
    """
    try:
        cnt = _count_errors_window(minutes_window, symbol=symbol)
        summary = {"symbol": symbol, "window_min": minutes_window, "count": cnt, "threshold": threshold,
                   "to_alert": False, "alerted": False, "message": ""}
        if cnt < threshold:
            summary["message"] = f"No hay suficientes errores recientes ({cnt} < {threshold})"
            return summary

        alerta_text = (f"🚨 *Monitor Binance*\n"
                       f"Símbolo: {symbol or 'GLOBAL'}\n"
                       f"Errores: {cnt} / {threshold}")
        registrar_auditoria("alerta_binance", detalle=alerta_text)

        if dry_run_report:
            summary["to_alert"] = True
            summary["message"] = alerta_text
            return summary

        enviar_telegram(alerta_text)
        summary["alerted"] = True
        summary["message"] = "Alerta enviada al admin."
        return summary
    except Exception as e:
        log_error(e, archivo="app.py", funcion="monitor_integridad_binance")
        return {"error": str(e)}
# FIN BLOQUE 13

# ============================================================
# 🧩 BLOQUE 14A — TABS: ANALIZAR (Binance live, señales RSI/MACD, TP1-4, gráfico + telegram)
# ============================================================
import io
import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime, timedelta

def _calc_rsi(closes: np.ndarray, period: int = 14) -> np.ndarray:
    """Calcula RSI clásico (vectorizado). Devuelve array same-length (primeros valores NaN)."""
    try:
        deltas = np.diff(closes)
        seed = deltas[:period]
        up = seed[seed >= 0].sum() / period
        down = -seed[seed < 0].sum() / period
        rs = up / down if down != 0 else np.inf
        rsi = np.full_like(closes, fill_value=np.nan, dtype=float)
        rsi[period] = 100. - 100. / (1. + rs)

        up_ewma = np.zeros_like(deltas)
        down_ewma = np.zeros_like(deltas)
        up_ewma[:period] = seed.clip(min=0) / period
        down_ewma[:period] = -seed.clip(max=0) / period

        for i in range(period, len(deltas)):
            up_val = max(deltas[i], 0)
            down_val = -min(deltas[i], 0)
            up_ewma[i] = (up_ewma[i-1] * (period - 1) + up_val) / period
            down_ewma[i] = (down_ewma[i-1] * (period - 1) + down_val) / period

        rs_series = np.divide(up_ewma, down_ewma, out=np.full_like(up_ewma, np.inf), where=down_ewma!=0)
        rsi[period+1:] = 100. - 100. / (1. + rs_series[period:])
        return rsi
    except Exception:
        # fallback simple
        return np.full_like(closes, np.nan, dtype=float)

def _calc_macd(closes: np.ndarray, fast: int = 12, slow: int = 26, signal: int = 9):
    """Calcula MACD (MACD line, signal line, histogram)."""
    try:
        def ema(values, span):
            alpha = 2.0 / (span + 1)
            out = np.empty_like(values)
            out[0] = values[0]
            for i in range(1, len(values)):
                out[i] = alpha * values[i] + (1 - alpha) * out[i-1]
            return out

        fast_ema = ema(closes, fast)
        slow_ema = ema(closes, slow)
        macd_line = fast_ema - slow_ema
        signal_line = ema(macd_line, signal)
        hist = macd_line - signal_line
        return macd_line, signal_line, hist
    except Exception:
        return np.full_like(closes, np.nan), np.full_like(closes, np.nan), np.full_like(closes, np.nan)

def _compute_tp_levels(last_close: float, highs: np.ndarray, lows: np.ndarray):
    """
    Genera 4 niveles de TakeProfit basados en volatilidad reciente.
    - Usa rango medio verdadero aproximado (simple high-low)
    - TP1..TP4 = last_close + k * atr_est (k incrementa)
    """
    try:
        recent_range = np.mean(highs - lows) if len(highs) > 0 else (last_close * 0.01)
        atr_est = recent_range
        tp1 = last_close + 0.5 * atr_est
        tp2 = last_close + 1.0 * atr_est
        tp3 = last_close + 1.5 * atr_est
        tp4 = last_close + 2.0 * atr_est
        return [tp1, tp2, tp3, tp4]
    except Exception:
        return [last_close * (1 + x/100) for x in (0.5, 1, 1.5, 2)]

def _calc_confidence(rsi_latest: float, macd_hist_latest: float) -> float:
    """
    Score heurístico de confianza [0..100].
    - RSI en zona extrema (<=25 o >=75) añade confianza
    - MACD histogram grande (en valor absoluto) añade confianza
    """
    try:
        score = 50.0
        # RSI contribuye hasta +/-25 puntos
        if not math.isnan(rsi_latest):
            if rsi_latest < 30:
                score += (30 - rsi_latest) * 0.6  # sobreventa -> compra (más confianza)
            elif rsi_latest > 70:
                score += (rsi_latest - 70) * 0.6  # sobrecompra -> venta (más confianza)

        # MACD histogram contribuye (normalizar por abs)
        mh = abs(macd_hist_latest or 0.0)
        score += min(30.0, mh * 10.0)  # escala heurística

        # clamp
        if score > 100:
            score = 100.0
        if score < 0:
            score = 0.0
        return round(float(score), 2)
    except Exception:
        return 0.0

def _plot_analysis(dates, closes, rsi, macd_hist, signals: dict, asset: str):
    """Grafica cierre, RSI (subplot), MACD hist (subplot) y marca señales TP / entrada."""
    try:
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 8), sharex=True, gridspec_kw={'height_ratios':[3,1,1]})
        # cierre
        ax1.plot(dates, closes, label=f"{asset} Close", linewidth=1.5)
        ax1.scatter([signals.get("time")], [signals.get("price")] , color='green' if signals.get("action") == "BUY" else 'red', s=80, label=signals.get("action"))
        for i, tp in enumerate(signals.get("tps", []) or []):
            ax1.hlines(tp, dates[0], dates[-1], linestyles="--", linewidth=0.7, label=f"TP{i+1}")
        ax1.set_title(f"{asset} - Close + Señales")
        ax1.legend(loc="upper left", fontsize="small")

        # RSI
        ax2.plot(dates, rsi, label="RSI", linewidth=1)
        ax2.axhline(70, color='red', linestyle='--', linewidth=0.6)
        ax2.axhline(30, color='green', linestyle='--', linewidth=0.6)
        ax2.set_ylabel("RSI")

        # MACD hist
        ax3.bar(dates, macd_hist, width=0.0008)
        ax3.set_ylabel("MACD hist")

        # format x
        ax3.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
        fig.autofmt_xdate()
        fig.tight_layout()
        return fig
    except Exception:
        return None

def _safe_send_telegram_with_image(mensaje: str, fig, fallback_text: str = ""):
    """
    Intenta enviar imagen + texto al admin.
    Usa `enviar_mensaje_admin(mensaje, parse_mode='Markdown')` si existe, tratando de adjuntar la imagen.
    Si no soporta adjunto, envía texto simple.
    """
    try:
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=150, bbox_inches='tight')
        buf.seek(0)
        # primero intentar función admin (más completa)
        try:
            from utils.telegram_bot import enviar_mensaje_admin
            # si enviar_mensaje_admin acepta 'file' arg, intentamos pasarlo (try/except)
            try:
                enviar_mensaje_admin(mensaje, parse_mode="Markdown", file=buf)
                return True
            except TypeError:
                # no acepta file -> enviar texto y luego imagen con otro helper
                enviar_mensaje_admin(mensaje, parse_mode="Markdown")
                try:
                    # fallback to enviar_telegram with file if exists
                    from utils.telegram_bot import enviar_telegram
                    enviar_telegram(mensaje)
                except Exception:
                    pass
                return True
        except Exception:
            # fallback general
            try:
                from utils.telegram_bot import enviar_telegram
                enviar_telegram(mensaje)
            except Exception:
                # no telegram available
                log_warning("No se pudo enviar Telegram (funciones no disponibles).", archivo="app.py", funcion="_safe_send_telegram_with_image")
            return False
    except Exception as e:
        log_error(e, archivo="app.py", funcion="_safe_send_telegram_with_image")
        return False

# ===========================
# UI: pestaña "Analizar"
# ===========================
def tab_analizar_ui(tab_container):
    """
    Renderiza la UI del tab 'Analizar'. `tab_container` es el context manager de Streamlit.tab().
    """
    try:
        with tab_container:
            st.header("📊 Analizar — Señales y Predicción IA")
            st.caption("Lectura directa desde Binance (si estás en MODO REAL y confirmaste fuente).")

            # controles (intervalo, lookback)
            col1, col2, col3 = st.columns([1,1,1])
            intervalo = col1.selectbox("Intervalo", ["1m", "3m", "5m", "15m", "1h"], index=2, key="ui_analizar_intervalo")
            lookback = col2.number_input("Velas (lookback)", min_value=20, max_value=1000, value=200, step=20, key="ui_analizar_lookback")
            asset_filter = col3.text_input("Filtro símbolo (ej: BTC)", value="", key="ui_analizar_filter")

            # Obtener lista de activos desde Binance (si hay executor/client) — solo cuando el usuario pulse 'Refrescar activos'
            if st.button("🔁 Refrescar activos desde Binance", key="ui_btn_refresh_activos"):
                activos = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
                try:
                    te = st.session_state.get("trading_executor") or (trading_executor if "trading_executor" in globals() else None)
                    client = getattr(te, "client", None) if te else None
                    if client:
                        tickers = client.get_all_tickers()
                        activos = sorted([t["symbol"] for t in tickers if t["symbol"].endswith("USDT")])
                        if asset_filter:
                            activos = [a for a in activos if asset_filter.lower() in a.lower()]
                except Exception as e:
                    log_warning(f"Fallo al cargar tickers Binance: {e}", archivo="app.py", funcion="tab_analizar_ui")
                    activos = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
                st.session_state["activos_analizar"] = activos

            activos = st.session_state.get("activos_analizar", ["BTCUSDT", "ETHUSDT", "BNBUSDT"])
            activo = st.selectbox("📌 Activo a analizar", activos, index=0 if activos else 0, key="ui_analizar_activo")

            # botón de análisis
            if st.button("🚀 Analizar activo seleccionado", key="ui_btn_analizar_ejecutar"):
                st.info(f"Iniciando análisis para {activo} — intervalo {intervalo} — {lookback} velas")
                registrar_auditoria("analisis_ui_iniciado", detalle=f"{activo} {intervalo} lookback={lookback}", usuario=st.session_state.get("usuario"), ip=st.session_state.get("ip_usuario"))

                # obtener datos OHLC desde TradingExecutor o client
                try:
                    te = st.session_state.get("trading_executor") or (trading_executor if "trading_executor" in globals() else None)
                    client = getattr(te, "client", None) if te else None

                    klines = None
                    if te and hasattr(te, "get_klines"):
                        klines = te.get_klines(symbol=activo, interval=intervalo, limit=lookback)
                    elif client and hasattr(client, "get_klines"):
                        klines = client.get_klines(symbol=activo, interval=intervalo, limit=lookback)
                    else:
                        raise RuntimeError("No Binance client disponible (asegura executor en modo REAL).")

                    # Normalizar klines: esperamos lista de listas (open_time, open, high, low, close, ...)
                    times = []
                    opens, highs, lows, closes, vols = [], [], [], [], []
                    for k in klines:
                        # algunos clientes devuelven dicts o tuples - controlar
                        try:
                            t = int(k[0]) if isinstance(k, (list, tuple)) else int(k["open_time"])
                            dt = datetime.utcfromtimestamp(t/1000) if t > 1e10 else datetime.utcfromtimestamp(t)
                            times.append(dt)
                            opens.append(float(k[1]))
                            highs.append(float(k[2]))
                            lows.append(float(k[3]))
                            closes.append(float(k[4]))
                            vols.append(float(k[5]) if len(k) > 5 else 0.0)
                        except Exception:
                            # intentar otras formas
                            continue

                    if len(closes) < 20:
                        st.warning("No se obtuvieron suficientes velas para el análisis.")
                        registrar_auditoria("analisis_fallo_klines", detalle=f"Pocas velas obtenidas ({len(closes)})", usuario=st.session_state.get("usuario"))
                        return

                    closes_arr = np.array(closes)
                    highs_arr = np.array(highs)
                    lows_arr = np.array(lows)

                    # calcular RSI y MACD
                    rsi_series = _calc_rsi(closes_arr, period=14)
                    macd_line, signal_line, macd_hist = _calc_macd(closes_arr)
                    rsi_latest = float(rsi_series[-1]) if not math.isnan(rsi_series[-1]) else float('nan')
                    macd_hist_latest = float(macd_hist[-1])

                    # calcular tps
                    last_close = float(closes_arr[-1])
                    tps = _compute_tp_levels(last_close, highs_arr[-20:], lows_arr[-20:])

                    # heurística simple de acción
                    action = "HOLD"
                    rationale = []
                    if rsi_latest < 30 and macd_hist_latest > 0:
                        action = "BUY"
                        rationale.append("RSI sobreventa + MACD positivo")
                    elif rsi_latest > 70 and macd_hist_latest < 0:
                        action = "SELL"
                        rationale.append("RSI sobrecompra + MACD negativo")
                    else:
                        if macd_hist_latest > 0 and rsi_latest < 60:
                            action = "BUY"
                            rationale.append("MACD positivo y RSI no extremo")
                        elif macd_hist_latest < 0 and rsi_latest > 40:
                            action = "SELL"
                            rationale.append("MACD negativo y RSI no extremo")
                        else:
                            rationale.append("Condiciones neutras")

                    # calcular confianza heurística
                    confianza = _calc_confidence(rsi_latest, macd_hist_latest)

                    # limitar ventana de inversión (no mayor a 5 minutos)
                    hora_recomendada = times[-1] + timedelta(minutes=1)
                    hora_recomendada = hora_recomendada.replace(second=0, microsecond=0)

                    # Si confidence < 90 marcar advertencia (pero aún mostrar resultados)
                    st.markdown("### ✅ Resultados del Análisis")
                    colA, colB = st.columns(2)
                    with colA:
                        st.metric("Acción sugerida", action)
                        st.write("• Confianza:", f"{confianza}%")
                        st.write("• Hora recomendada:", hora_recomendada.strftime("%Y-%m-%d %H:%M:%S UTC"))
                        st.write("• Justificación:")
                        for r in rationale:
                            st.write(f"  - {r}")
                    with colB:
                        st.write("Último precio:", f"{last_close:.6f}")
                        st.write("TP1..TP4:")
                        for i, tp in enumerate(tps, start=1):
                            st.write(f"• TP{i}: {tp:.6f}")

                    # tabla resumen señales
                    df_sign = {
                        "fecha": [times[-1].strftime("%Y-%m-%d %H:%M:%S")],
                        "activo": [activo],
                        "precio": [last_close],
                        "rsi": [round(rsi_latest, 2) if not math.isnan(rsi_latest) else None],
                        "macd_hist": [round(macd_hist_latest, 6)],
                        "accion": [action],
                        "confianza": [confianza]
                    }
                    try:
                        import pandas as _pd
                        st.dataframe(_pd.DataFrame(df_sign), use_container_width=True)
                    except Exception:
                        pass

                    # graficar
                    fig = _plot_analysis(times, closes_arr, rsi_series, macd_hist, {"action": action, "price": last_close, "tps": tps, "time": times[-1]}, activo)
                    if fig:
                        st.pyplot(fig)
                    else:
                        st.info("No fue posible generar gráfico.")

                    # enviar resumen por telegram (intento)
                    mensaje = (
                        f"🤖 *Analisis automático* — {activo}\n"
                        f"Acción sugerida: *{action}*\n"
                        f"Confianza: *{confianza}%*\n"
                        f"Precio: {last_close:.6f}\n"
                        f"TP1..TP4: {', '.join([f'{x:.6f}' for x in tps])}\n"
                        f"Hora recomendada: {hora_recomendada.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n"
                        f"Justificación: {'; '.join(rationale)}"
                    )
                    try:
                        _safe_send_telegram_with_image(mensaje, fig)
                    except Exception:
                        log_warning("No se pudo enviar notificación por Telegram (intento fallido).", archivo="app.py", funcion="tab_analizar_ui_telegram")

                    # registrar auditoría del resultado
                    registrar_auditoria("analisis_ejecutado", detalle=f"{activo} action={action} conf={confianza}", usuario=st.session_state.get("usuario"), ip=st.session_state.get("ip_usuario"))
                except Exception as e:
                    log_error(e, archivo="app.py", funcion="tab_analizar_ui_run")
                    st.error(f"Error ejecutando análisis: {e}")
                    registrar_auditoria("analisis_error", detalle=str(e), usuario=st.session_state.get("usuario"))
    except Exception as e:
        log_error(e, archivo="app.py", funcion="tab_analizar_ui")
        st.error("Error mostrando pestaña Analizar.")
# ===========================
# FIN BLOQUE 14A
# ===========================

