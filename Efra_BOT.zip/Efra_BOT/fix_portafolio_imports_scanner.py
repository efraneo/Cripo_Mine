# fix_portafolio_imports_scanner.py
# ============================================================
# SCANNER PROFESIONAL — DETECTAR IMPORTS core.portafolio
# ============================================================

import os
import sys

TARGET = "core.portfolio"
ROOT_DIR = os.getcwd()

EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "env",
    "site-packages",
    ".mypy_cache",
    ".streamlit"
}

VALID_EXTENSIONS = {".py"}


def should_skip_dir(dirname):
    return dirname.lower() in EXCLUDE_DIRS


def scan_file(filepath):

    matches = []

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:

            for line_number, line in enumerate(f, start=1):

                if TARGET in line:

                    matches.append({
                        "file": filepath,
                        "line_number": line_number,
                        "line": line.strip()
                    })

    except Exception as e:
        print(f"Error leyendo archivo: {filepath} | {e}")

    return matches


def scan_project(root_dir):

    all_matches = []

    for root, dirs, files in os.walk(root_dir):

        # Filtrar directorios excluidos
        dirs[:] = [d for d in dirs if not should_skip_dir(d)]

        for file in files:

            ext = os.path.splitext(file)[1]

            if ext not in VALID_EXTENSIONS:
                continue

            filepath = os.path.join(root, file)

            matches = scan_file(filepath)

            if matches:
                all_matches.extend(matches)

    return all_matches


def print_report(matches):

    print("\n" + "=" * 60)
    print("SCAN REPORT — core.portafolio")
    print("=" * 60)

    if not matches:
        print("No se encontraron referencias.")
        return

    for match in matches:

        print(f"\nArchivo : {match['file']}")
        print(f"Línea   : {match['line_number']}")
        print(f"Código  : {match['line']}")

    print("\n" + "=" * 60)
    print(f"TOTAL ENCONTRADOS: {len(matches)}")
    print("=" * 60)


def main():

    print("Escaneando proyecto...")
    print(f"Directorio raíz: {ROOT_DIR}")

    matches = scan_project(ROOT_DIR)

    print_report(matches)


if __name__ == "__main__":
    main()