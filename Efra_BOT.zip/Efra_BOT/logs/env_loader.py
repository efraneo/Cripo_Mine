[2025-12-02 23:51:44] ❌ Error en env_loader.py::load_all_envs -> name 'st' is not defined
