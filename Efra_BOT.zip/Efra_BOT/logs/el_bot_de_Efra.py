[2025-11-15 23:49:23] ❌ Error en el_bot_de_Efra.py::login_btn -> module 'streamlit' has no attribute 'experimental_rerun'
[2025-11-15 23:53:12] ❌ Error en el_bot_de_Efra.py::import_trading_engine -> cannot import name 'ia_predictor' from 'backend.ia_predictor' (C:\software_phyton\Efra_BOT\backend\ia_predictor.py)
[2025-11-15 23:53:13] ❌ Error en el_bot_de_Efra.py::analizar_btn -> cannot import name 'ia_predictor' from 'backend.ia_predictor' (C:\software_phyton\Efra_BOT\backend\ia_predictor.py)
[2025-11-16 16:48:53] ❌ Error en el_bot_de_Efra.py::import_trading_engine -> cannot import name 'calcular_indicadores' from 'backend.trading_engine' (C:\software_phyton\Efra_BOT\backend\trading_engine.py)
[2025-11-16 16:48:53] ❌ Error en el_bot_de_Efra.py::analizar_btn -> cannot import name 'calcular_indicadores' from 'backend.trading_engine' (C:\software_phyton\Efra_BOT\backend\trading_engine.py)
[2025-11-17 10:05:16] ❌ Error en el_bot_de_Efra.py::obtener_datos_ohlcv -> Cannot cast DatetimeArray to dtype float64
[2025-11-17 10:15:01] ❌ Error en el_bot_de_Efra.py::analizar_btn -> procesar_senal_compuesta() missing 1 required positional argument: 'señales'
[2025-11-20 19:31:36] ❌ Error en el_bot_de_Efra.py::ejecutar_compound_order -> name 'ejecutar_compound_order' is not defined
[2025-11-20 23:03:44] ❌ Error en el_bot_de_Efra.py::ejecutar_compound_order -> name 'ejecutar_compound_order' is not defined
[2025-11-20 23:50:40] ❌ Error en el_bot_de_Efra.py::ejecutar_compound_order -> name 'ejecutar_compound_order' is not defined
[2025-11-23 00:31:13] ❌ Error en el_bot_de_Efra.py::ejecutar_compound_order -> name 'ejecutar_compound_order' is not defined
