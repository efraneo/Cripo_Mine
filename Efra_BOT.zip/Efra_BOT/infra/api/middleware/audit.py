import time
import logging

log = logging.getLogger("api_audit")

async def audit_middleware(request, call_next):
    start = time.time()
    response = await call_next(request)
    elapsed = (time.time() - start) * 1000

    log.info(
        f"{request.method} {request.url.path} "
        f"status={response.status_code} "
        f"time_ms={elapsed:.2f}"
    )

    return response
