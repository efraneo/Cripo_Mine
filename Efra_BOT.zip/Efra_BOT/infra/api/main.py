from fastapi import FastAPI
from infra.api.routes import ia, sessions, risk, health
from infra.api.middleware.audit import audit_middleware

app = FastAPI(
    title="EFRA Trading Intelligence API",
    version="6.0",
    description="Institutional-grade trading decision engine"
)

app.middleware("http")(audit_middleware)

app.include_router(health.router, prefix="/health")
app.include_router(ia.router, prefix="/ia")
app.include_router(sessions.router, prefix="/sessions")
app.include_router(risk.router, prefix="/risk")
