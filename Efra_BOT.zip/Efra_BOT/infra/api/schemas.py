from pydantic import BaseModel
from typing import Dict, List, Any

class IADecisionRequest(BaseModel):
    symbol: str
    data_by_tf: Dict[str, Any]

class IADecisionResponse(BaseModel):
    symbol: str
    direction: str
    confidence: float
    actionable: bool
    entry_timing: Dict[str, Any]
    reasons: List[Dict[str, str]]
    trader_explanation: str
