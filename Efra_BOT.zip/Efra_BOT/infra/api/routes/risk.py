from fastapi import APIRouter
from core.session_performance.session_tracker import get_session_stats
from core.risk.capital_preservation import capital_preservation_gate

router = APIRouter()

@router.get("/gate")
def risk_gate():
    stats = get_session_stats()
    return capital_preservation_gate(stats)
