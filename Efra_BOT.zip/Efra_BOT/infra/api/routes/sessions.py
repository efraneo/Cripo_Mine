from fastapi import APIRouter
from core.session_performance.session_tracker import get_session_stats

router = APIRouter()

@router.get("/stats")
def session_stats():
    return get_session_stats()
