from fastapi import APIRouter

router = APIRouter()


@router.get("/")
def healthcheck():
    return {
        "status": "ok",
        "service": "EFRA Trading Intelligence API",
    }
