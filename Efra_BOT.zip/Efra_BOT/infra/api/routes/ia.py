from fastapi import APIRouter, HTTPException
from infra.api.schemas import IADecisionRequest, IADecisionResponse
from core.ia_pro_orchestrator import compute_ia_pro_decision

router = APIRouter()

@router.post("/decision", response_model=IADecisionResponse)
def ia_decision(req: IADecisionRequest):

    try:
        ia = compute_ia_pro_decision(
            data_by_tf=req.data_by_tf,
            symbol=req.symbol
        )

        return {
            "symbol": req.symbol,
            "direction": ia["direction"],
            "confidence": ia["confidence"],
            "actionable": ia.get("actionable", True),
            "entry_timing": ia["entry_timing"],
            "reasons": ia["reasons"],
            "trader_explanation": ia["trader_explanation"]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
