# risk_manager.py
"""
RiskManager PRO
 - max_risk_pct: fraction of capital to risk per trade (e.g., 0.02)
 - position_size_from_risk: computes units to buy from USD risk and stop distance
 - compute_atr: requires klines from binance_client.get_klines (array like Binance)
 - trailing_stop_price: compute trailing stop given entry and pct
"""
from typing import List
import numpy as np
import math

class RiskManager:
    def __init__(self, max_risk_pct: float = 0.02):
        if not (0.0 < max_risk_pct < 1.0):
            raise ValueError("max_risk_pct must be between 0 and 1")
        self.max_risk_pct = max_risk_pct

    def risk_usd_from_capital(self, capital_usd: float) -> float:
        return capital_usd * self.max_risk_pct

    def position_size_from_risk(self, capital_usd: float, entry_price: float, stop_price: float) -> float:
        """
        Returns units to buy so that (entry - stop) * units = risk_usd
        Rounded to 8 decimals (exchange will do final step rounding).
        """
        risk_per_trade_usd = self.risk_usd_from_capital(capital_usd)
        risk_per_unit = abs(entry_price - stop_price)
        if risk_per_unit <= 0:
            raise ValueError("stop_price must be different from entry_price")
        units = risk_per_trade_usd / risk_per_unit
        return round(units, 8)

    def compute_atr(self, klines: List[List], period: int = 14) -> float:
        """
        klines: list of kline arrays as returned by Binance: [open_time, open, high, low, close, ...]
        Returns ATR of last period.
        """
        highs = np.array([float(k[2]) for k in klines])
        lows = np.array([float(k[3]) for k in klines])
        closes = np.array([float(k[4]) for k in klines])
        trs = []
        for i in range(1, len(closes)):
            tr = max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
            trs.append(tr)
        if len(trs) == 0:
            return float(np.mean(highs - lows))
        if len(trs) < period:
            return float(np.mean(trs))
        return float(np.mean(trs[-period:]))

    def trailing_stop_price(self, entry_price: float, pct_trail: float) -> float:
        if not (0 < pct_trail < 1):
            raise ValueError("pct_trail between 0 and 1")
        return entry_price * (1 - pct_trail)
