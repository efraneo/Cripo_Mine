import os
from pathlib import Path

def load_env_file(file_path: str):
    """
    Carga manualmente un archivo .env porque no estamos usando python-dotenv.
    Retorna un diccionario con todas las claves.
    Cada línea debe ser: CLAVE=valor
    """
    env_vars = {}

    file = Path(file_path)
    if not file.exists():
        raise FileNotFoundError(f"❌ No se encontró el archivo .env en: {file_path}")

    with open(file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            # Saltar líneas vacías o comentarios
            if not line or line.startswith("#"):
                continue

            if "=" not in line:
                continue  # ignorar líneas inválidas

            key, value = line.split("=", 1)
            env_vars[key.strip()] = value.strip()

    return env_vars


def load_binance_keys():
    """
    Carga las claves BINANCE_API_KEY y BINANCE_API_SECRET desde:
        /env/binance.env

    Retorna:
        (api_key, api_secret, modo_demo)
    """

    # ruta absoluta desde el proyecto
    base_path = Path(__file__).resolve().parent
    env_path = base_path / "env" / "binance.env"

    env = load_env_file(env_path)

    api_key = env.get("BINANCE_API_KEY")
    api_secret = env.get("BINANCE_API_SECRET")
    modo_demo = env.get("MODO_DEMO", "True").lower() in ("true", "1", "yes")

    if not api_key or not api_secret:
        raise ValueError("❌ Faltan claves en binance.env")

    return api_key, api_secret, modo_demo


def load_app_secrets():
    """
    Carga CLAVE_SECRETA y DB_MASTER_KEY desde el mismo archivo.

    Retorna:
        (CLAVE_SECRETA, DB_MASTER_KEY)
    """

    base_path = Path(__file__).resolve().parent
    env_path = base_path / "env" / "binance.env"

    env = load_env_file(env_path)

    return env.get("CLAVE_SECRETA"), env.get("DB_MASTER_KEY")
