# bbe_sync_server.py
import os
import time
import base64
import hmac
import hashlib
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import jwt
from jwt import PyJWTError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# -----------------------
# Config (usar env vars en producción)
# -----------------------
JWT_SECRET = os.getenv("JWT_SECRET", "cambia_este_jwt_secret")
JWT_ALGORITHM = "HS256"
JWT_EXP_SECONDS = int(os.getenv("JWT_EXP_SECONDS", "3600"))
_MASTER_KEY_HEX = os.getenv("MASTER_KEY_HEX", None)
if _MASTER_KEY_HEX:
    MASTER_KEY = bytes.fromhex(_MASTER_KEY_HEX)
else:
    MASTER_KEY = hashlib.sha256(b"default_master_key_dev").digest()

ADMIN_API_TOKEN = os.getenv("ADMIN_API_TOKEN", "cambia_admin_token")

BASE_DIR = Path(__file__).resolve().parent
USERS_DIR = BASE_DIR / "data" / "usuarios"
USERS_DIR.mkdir(parents=True, exist_ok=True)

CLAVES_CSV = BASE_DIR / "data" / "claves.csv"

# -----------------------
# Util helpers
# -----------------------
def derive_user_key(username: str) -> bytes:
    if not isinstance(username, bytes):
        username = username.encode("utf-8")
    return hmac.new(MASTER_KEY, username, hashlib.sha256).digest()

def aesgcm_encrypt(key: bytes, data: bytes) -> bytes:
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ct = aesgcm.encrypt(nonce, data, associated_data=None)
    return base64.b64encode(nonce + ct)

def aesgcm_decrypt(key: bytes, b64payload: bytes) -> bytes:
    payload = base64.b64decode(b64payload)
    nonce = payload[:12]
    ct = payload[12:]
    aesgcm = AESGCM(key)
    return aesgcm.decrypt(nonce, ct, associated_data=None)

def create_token(username: str, expires_in: int = JWT_EXP_SECONDS):
    now = int(time.time())
    payload = {"sub": username, "iat": now, "exp": now + int(expires_in)}
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token

def decode_token(token: str) -> Optional[dict]:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except PyJWTError:
        return None

# -----------------------
# FastAPI app
# -----------------------
app = FastAPI(title="BBE Sync Server (Efra Bot)", version="1.1")
bearer = HTTPBearer(auto_error=False)

# -----------------------
# Models
# -----------------------
class TokenRequest(BaseModel):
    usuario: str
    clave: str

# -----------------------
# Endpoints
# -----------------------
@app.post("/token")
def token(req: TokenRequest):
    import pandas as pd
    if not CLAVES_CSV.exists():
        raise HTTPException(status_code=400, detail="No hay base de usuarios en el servidor")
    df = pd.read_csv(CLAVES_CSV, dtype=str).fillna("")
    row = df[(df["usuario"].astype(str) == str(req.usuario)) | (df.get("correo","").astype(str).str.lower() == str(req.usuario).lower())]
    if row.empty or str(row["clave"].iloc[0]) != str(req.clave):
        raise HTTPException(status_code=401, detail="Credenciales inválidas")
    estado = str(row["estado"].iloc[0]).upper() if "estado" in row else "PENDIENTE"
    if estado != "APROBADO":
        raise HTTPException(status_code=403, detail=f"Usuario no aprobado: {estado}")
    token = create_token(req.usuario)
    return {"access_token": token, "token_type": "bearer", "expires_in": JWT_EXP_SECONDS}

@app.post("/sync/upload")
async def sync_upload(file: UploadFile = File(...), usuario: str = Form(...), authorization: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    # token validation
    if not authorization:
        raise HTTPException(status_code=401, detail="Token missing")
    payload = decode_token(authorization.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload["sub"] != usuario:
        raise HTTPException(status_code=403, detail="Token does not match usuario field")
    data = await file.read()
    try:
        user_key = derive_user_key(usuario)
        enc = aesgcm_encrypt(user_key, data)
        target = USERS_DIR / f"BBE_{usuario}.enc"
        with open(target, "wb") as f:
            f.write(enc)
        return {"ok": True, "path": str(target), "size": len(enc)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Encryption/save failed: {e}")

@app.get("/sync/download")
def sync_download(usuario: str, authorization: Optional[HTTPAuthorizationCredentials] = Depends(bearer)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Token missing")
    payload = decode_token(authorization.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload["sub"] != usuario:
        raise HTTPException(status_code=403, detail="Token/user mismatch")
    source = USERS_DIR / f"BBE_{usuario}.enc"
    if not source.exists():
        raise HTTPException(status_code=404, detail="No BBE stored for usuario")
    with open(source, "rb") as f:
        enc = f.read()
    return {"file_b64": enc.decode("utf-8")}

# Admin endpoint to update user status in data/claves.csv (protected by ADMIN_API_TOKEN)
@app.post("/admin/update_user_status")
def admin_update_user_status(usuario: str, estado: str, admin_token: Optional[str] = Header(None)):
    if admin_token is None or admin_token != ADMIN_API_TOKEN:
        raise HTTPException(status_code=401, detail="Missing or invalid admin token")
    import pandas as pd
    if not CLAVES_CSV.exists():
        raise HTTPException(status_code=404, detail="No claves.csv")
    df = pd.read_csv(CLAVES_CSV, dtype=str)
    if "usuario" not in df.columns:
        raise HTTPException(status_code=400, detail="Formato de claves.csv inválido")
    mask = df["usuario"].astype(str) == usuario
    if not mask.any():
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    df.loc[mask, "estado"] = estado
    df.to_csv(CLAVES_CSV, index=False)
    return {"ok": True, "usuario": usuario, "estado": estado}

@app.get("/health")
def health():
    return {"status":"ok", "time": int(time.time())}
