# repair_security_full.py

import sqlite3

DB_PATH="data/usuarios.db"

conn=sqlite3.connect(DB_PATH)
cur=conn.cursor()

print("\nVerificando tabla ip_risk...\n")

cur.execute("PRAGMA table_info(ip_risk)")
cols=[x[1] for x in cur.fetchall()]

print("Columnas actuales:")
print(cols)


required={

    "risk_score":
    "INTEGER DEFAULT 0",

    "failed_attempts":
    "INTEGER DEFAULT 0",

    "last_seen":
    "TEXT"

}


for col,dtype in required.items():

    if col not in cols:

        print(f"\nAgregando {col}...")

        cur.execute(
            f"""
            ALTER TABLE ip_risk
            ADD COLUMN {col} {dtype}
            """
        )

        print("OK")

    else:

        print(f"\n{col} ya existe")


conn.commit()
conn.close()

print("\nDB reparada completamente")
