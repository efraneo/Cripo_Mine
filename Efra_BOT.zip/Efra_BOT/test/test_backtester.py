from backend.backtester import Backtester

bt = Backtester()

df = bt.load_csv("data/example.csv")   # cambia archivo
df = bt.prepare_dataset(df)
report = bt.run(df)

print("Reporte Backtester:")
print(report)
