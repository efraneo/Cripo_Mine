import os
from dotenv import load_dotenv

load_dotenv("../env/binance.env")

key = os.getenv("BINANCE_API_KEY")
secret = os.getenv("BINANCE_API_SECRET")

print("KEY:", key, "LEN:", len(key))
print("SECRET:", secret, "LEN:", len(secret))
