# test/check_users_schema.py
"""
Verificación de esquema y datos críticos de la tabla users
Punto 4 - Auditoría de seguridad IP
"""

import sqlite3
import os
import sys

DB_PATH = os.path.join("data", "usuarios.db")

REQUIRED_COLUMNS = {
    "last_ip",
    "ip_whitelist",
    "ip_verified"
}


def main():
    if not os.path.exists(DB_PATH):
        print(f"[ERROR] Base de datos no encontrada: {DB_PATH}")
        sys.exit(1)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # ---------------------------------------------
    # Verificar columnas del schema
    # ---------------------------------------------
    cur.execute("PRAGMA table_info(users)")
    cols = {row[1] for row in cur.fetchall()}

    print("\n[INFO] Columnas detectadas en users:")
    for c in sorted(cols):
        print(f"  - {c}")

    missing = REQUIRED_COLUMNS - cols
    if missing:
        print("\n[ERROR] FALTAN columnas críticas:")
        for c in missing:
            print(f"  ❌ {c}")
        conn.close()
        sys.exit(2)

    print("\n[OK] Todas las columnas críticas existen.")

    # ---------------------------------------------
    # Mostrar estado IP por usuario
    # ---------------------------------------------
    print("\n[INFO] Estado IP por usuario:\n")

    cur.execute("""
        SELECT username, last_ip, ip_whitelist, ip_verified
        FROM users
        ORDER BY username
    """)

    rows = cur.fetchall()
    if not rows:
        print("⚠️ No hay usuarios registrados.")
    else:
        for u, last_ip, wl, verified in rows:
            print("-" * 50)
            print(f"Usuario      : {u}")
            print(f"Última IP    : {last_ip or 'N/D'}")
            print(f"Whitelist    : {wl or 'VACÍA'}")
            print(f"IP verificada: {'SÍ' if verified else 'NO'}")

    conn.close()
    print("\n[FIN] Verificación completada correctamente.")


if __name__ == "__main__":
    main()
