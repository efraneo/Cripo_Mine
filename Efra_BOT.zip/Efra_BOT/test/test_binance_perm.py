# test_binance_perm.py
import requests, time, hmac, hashlib
API_KEY = "TU_KEY"
API_SECRET = "TU_SECRET"
base = "https://api.binance.com"
path = "/api/v3/account"
ts = str(int(time.time()*1000))
params = f"timestamp={ts}"
sig = hmac.new(API_SECRET.encode(), params.encode(), hashlib.sha256).hexdigest()
r = requests.get(base+path, params={"timestamp":ts,"signature":sig}, headers={"X-MBX-APIKEY":API_KEY})
print(r.status_code, r.text)
