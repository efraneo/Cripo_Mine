from backend.backtester import Backtester
import json

# Datos ficticios de entrenamiento IA (ejemplo)
y_true = [1,0,1,1,0,1,0,0,1,1]
y_proba = [0.9,0.3,0.7,0.8,0.1,0.6,0.4,0.2,0.95,0.85]

bt = Backtester()
th = bt.calibrate_threshold(y_true, y_proba, metric="precision", target=0.75)

print("Threshold calibrado =", th)
with open("models/threshold.json") as f:
    print("Guardado en archivo:", json.load(f))
