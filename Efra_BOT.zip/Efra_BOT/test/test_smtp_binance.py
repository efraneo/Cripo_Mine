"""
Tester SMTP + Binance — Pro
Ubicación recomendada: /test/test_smtp_binance.py
"""

import os
import sys
sys.path.append("..")

print(">>\n")

print("===============")
print(" TEST COMPLETO")
print("===============")

# ============================================================
# 1) Cargar los .env EXACTAMENTE como hace el bot
# ============================================================
try:
    from backend.env_loader import load_all_envs
    load_all_envs("env", override=True)
    print("\n✔ Variables de entorno cargadas correctamente.\n")
except Exception as e:
    print("\n⚠ No se pudieron cargar los env con load_all_envs:", e)


# ============================================================
# 2) TEST SMTP — Con correo automático del usuario conectado
# ============================================================
print("============================================================")
print("🔐 TEST SMTP — Envío de correo real")
print("============================================================")

SMTP_HOST   = os.getenv("SERVIDOR_SMTP")
SMTP_PORT   = os.getenv("PUERTO_SMTP")
SMTP_USER   = os.getenv("CORREO_ORIGEN")
SMTP_PASS   = os.getenv("CLAVE_CORREO")

# ------------------------------------------------------------
# 1) Intentar leer TEST_MAIL_TO desde .env
# ------------------------------------------------------------
TEST_TO = os.getenv("TEST_MAIL_TO")

# ------------------------------------------------------------
# 2) Si no existe, intentar usar el correo del usuario conectado
# ------------------------------------------------------------
if not TEST_TO:
    try:
        from backend.users_manager import UsersManager
        um = UsersManager()
        current_user = os.getenv("TEST_USER")  # puedes poner TU usuario aquí
        if current_user:
            user_rec = um.get_user_by_username(current_user)
            if user_rec:
                TEST_TO = user_rec.get("email")
    except Exception:
        TEST_TO = None

# ------------------------------------------------------------
# 3) Fallback final: usar tu correo personal (Efra)
# ------------------------------------------------------------
if not TEST_TO:
    TEST_TO = "efraneo@gmail.com"

print(f"SMTP_SERVER   = {SMTP_HOST}")
print(f"SMTP_PORT     = {SMTP_PORT}")
print(f"SMTP_USER     = {SMTP_USER}")
print(f"SMTP_PASSWORD = {'DEFINIDO' if SMTP_PASS else 'NO DEFINIDO'}")
print(f"Correo destino = {TEST_TO}")

smtp_ok = False

if not (SMTP_HOST and SMTP_PORT and SMTP_USER and SMTP_PASS and TEST_TO):
    print("\n❌ ERROR: Falta configuración SMTP válida.\n")
else:
    try:
        from backend.mailer import send_mail
        r = send_mail(
            to=TEST_TO,
            subject="TEST SMTP — BOT EFRA",
            body="Correo enviado correctamente desde test_smtp_binance.py"
        )
        print("\nResultado envío:", r)
        smtp_ok = r.get("ok", False)
    except Exception as e:
        print("\n❌ ERROR enviando correo:", e)


# ============================================================
# 3) TEST BINANCE
# ============================================================
print("\n============================================================")
print("💰 TEST BINANCE — API Key, ping y balance")
print("============================================================")

API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_API_SECRET")
BASE_URL = os.getenv("BINANCE_BASE_URL", "https://api.binance.com")

print(f"API_KEY     = {'DEFINIDO' if API_KEY else 'NO DEFINIDO'}")
print(f"API_SECRET  = {'DEFINIDO' if API_SECRET else 'NO DEFINIDO'}")
print(f"BASE_URL    = {BASE_URL}")

if not (API_KEY and API_SECRET):
    print("\n❌ ERROR: Falta API KEY o SECRET.\n")
    binance_ok = False
else:
    try:
        from backend.binance_manager import BinanceManager
        b = BinanceManager(API_KEY, API_SECRET, base_url=BASE_URL)

        ping = b.ping()
        print("Ping:", ping)

        bal = b.get_spot_balance("USDT")
        print("Balance USDT:", bal)

        binance_ok = True
    except Exception as e:
        print("\n❌ ERROR probando Binance:", e)
        binance_ok = False


# ============================================================
# 4) RESULTADO FINAL
# ============================================================
print("\n===============")
print(" RESULTADO FINAL")
print("===============\n")

print("📧 SMTP ..................", "OK" if smtp_ok else "ERROR")
print("💰 Binance ...............", "OK" if binance_ok else "ERROR")

print("\nFIN DEL TEST.\n")
