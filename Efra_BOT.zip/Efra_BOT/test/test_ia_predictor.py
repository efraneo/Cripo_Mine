from backend.ia_predictor import IAPredictor

ia = IAPredictor()

sample = {
    "open": 100,
    "high": 102,
    "low": 99,
    "close": 101,
    "volume": 2000,
    "ma_fast": 101,
    "ma_slow": 100,
    "volatility": 0.002,
    "atr": 0.5
}

print("Probabilidad:", ia.predict_proba(sample))
print("Señal:", ia.predict_signal(sample))
