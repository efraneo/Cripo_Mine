# tests/test_audit_manager.py

import os
import shutil
import time
from backend.audit_manager import AuditManager

def setup_module(module):
    # limpiar data/ para pruebas
    if os.path.exists("data/test_audit.db"):
        os.remove("data/test_audit.db")
    if os.path.exists("data/signals_test.jsonl"):
        os.remove("data/signals_test.jsonl")
    if os.path.exists("data/executions_test.jsonl"):
        os.remove("data/executions_test.jsonl")

def test_log_signal():
    am = AuditManager(
        db_path="data/test_audit.db",
        signals_jsonl="data/signals_test.jsonl",
        exec_jsonl="data/executions_test.jsonl"
    )

    payload = {
        "symbol": "BTCUSDT",
        "interval": "1m",
        "close": 45000.5,
        "ts": time.time()
    }

    am.log_signal(payload)

    sigs = am.get_signals(limit=10)
    assert len(sigs) >= 1
    assert sigs[-1]["symbol"] == "BTCUSDT"

def test_log_execution():
    am = AuditManager(
        db_path="data/test_audit.db",
        signals_jsonl="data/signals_test.jsonl",
        exec_jsonl="data/executions_test.jsonl"
    )

    rec = {
        "symbol": "BTCUSDT",
        "side": "BUY",
        "user": "tester",
        "amount": 10.0,
        "result": {"pnl": 1.5}
    }

    am.log_execution(rec)

    ex = am.get_executions(limit=10)
    assert len(ex) >= 1
    assert ex[-1]["pnl"] == 1.5
