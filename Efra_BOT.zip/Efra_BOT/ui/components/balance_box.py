# ui/components/balance_box.py
import streamlit as st

def render_balance_box(balance):
    try:
        st.caption("💰 Balance Spot")
        st.write(f"**{balance if balance is not None else 'N/D'} USDT**")
    except Exception:
        pass
