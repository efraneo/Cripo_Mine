import plotly.graph_objects as go


def render_agent_radar(agent_votes):
    labels = []
    values = []

    for v in agent_votes or []:
        labels.append(v.get("agent", "unknown"))
        values.append(1 if v.get("vote") == "YES" else 0)

    fig = go.Figure(
        data=go.Scatterpolar(
            r=values,
            theta=labels,
            fill="toself",
        )
    )

    fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
        showlegend=False,
        height=360,
        title="Consenso de Agentes IA",
    )

    return fig
