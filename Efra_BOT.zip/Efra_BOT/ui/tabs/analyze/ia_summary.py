# ui/tabs/analyze/ia_summary.py

import streamlit as st


def render_ia_summary(ia):

    st.success("Análisis cargado")

    # ==========================================
    # DIRECCIÓN PRINCIPAL
    # ==========================================

    direction = ia.get(
        "direction",
        "UNKNOWN"
    )

    emoji = {

        "LONG":"🟢📈",
        "BUY":"🟢📈",
        "SHORT":"🔴📉",
        "SELL":"🔴📉"

    }.get(
        direction,
        "⚪"
    )

    st.markdown(
        f"### {emoji} Dirección esperada: {direction}"
    )

    confidence = ia.get(
        "confidence",
        0
    )

    st.write(
        f"Confianza IA: **{confidence:.2f}%**"
    )

    # ==========================================
    # SMART MONEY
    # ==========================================

    smc = ia.get(
        "smart_money",
        {}
    )

    st.markdown(
        "### 🏦 Smart Money"
    )

    col1, col2 = st.columns(2)

    with col1:

        st.metric(
            "Confianza SMC",
            f"{smc.get('confidence',0):.2f}%"
        )

    with col2:

        st.metric(
            "Dirección SMC",
            smc.get(
                "direction",
                "N/A"
            )
        )

    signals = smc.get(
        "signals",
        []
    )

    if signals:

        st.write(
            "Señales:",
            signals
        )

    # ==========================================
    # MICROSTRUCTURA
    # ==========================================

    st.markdown(
        "### 📡 Señales Institucionales"
    )

    micro = ia.get(
        "microstructure",
        {}
    )

    footprint = micro.get(
        "footprint",
        {}
    )

    whales = micro.get(
        "whales",
        {}
    )

    traps = micro.get(
        "traps",
        {}
    )

    clusters = micro.get(
        "clusters",
        {}
    )

    c1,c2 = st.columns(2)

    with c1:

        st.metric(
            "Footprint",
            footprint.get(
                "signal",
                "N/A"
            )
        )

        st.metric(
            "Imbalance",
            round(
                footprint.get(
                    "imbalance",
                    0
                ),
                2
            )
        )

    with c2:

        st.metric(
            "Whales",
            "ACTIVOS"
            if whales.get(
                "active",
                False
            )
            else "INACTIVOS"
        )

        st.metric(
            "Trampa",
            "DETECTADA"
            if traps.get(
                "trap",
                False
            )
            else "NO"
        )

    # ==========================================
    # RÉGIMEN Y ENSEMBLE
    # ==========================================

    st.markdown(
        "### 🤖 IA Ensemble"
    )

    ensemble = ia.get(
        "ensemble",
        {}
    )

    st.write(
        f"Régimen: **{ia.get('regime','N/A')}**"
    )

    st.write(
        f"Consenso IA: **{ensemble.get('direction','N/A')}**"
    )

    st.write(
        f"Confianza Ensemble: **{ensemble.get('confidence',0):.2f}%**"
    )

    # ==========================================
    # CLUSTERS
    # ==========================================

    dominant = clusters.get(
        "dominant",
        None
    )

    if dominant:

        st.info(
            f"💰 Liquidez dominante detectada: {dominant:,.2f}"
        )
