# ui/tabs/analyze/ohlc_loader.py

import pandas as pd


def load_ohlc(engine, symbol):

    if hasattr(engine,"get_ohlc_df_for_ui"):

        df = engine.get_ohlc_df_for_ui(
            symbol=symbol,
            timeframe="5m",
            limit=200
        )

    elif hasattr(engine,"get_klines_df"):

        df=engine.get_klines_df(
            symbol=symbol,
            interval="5m",
            limit=200
        )

    else:
        raise RuntimeError(
            "Engine no soporta OHLC"
        )

    if df is None:
        raise RuntimeError("df=None")

    if df.empty:
        raise RuntimeError("df vacío")

    df=df.copy()

    # ==================================================
    # TIEMPO
    # ==================================================

    if "time" not in df.columns:

        if "timestamp" in df.columns:

            df["time"]=pd.to_datetime(
                df["timestamp"],
                unit="ms"
            )

        elif "open_time" in df.columns:

            df["time"]=pd.to_datetime(
                df["open_time"],
                unit="ms"
            )

        else:

            raise RuntimeError(
                "Sin columna temporal"
            )

    # ==================================================
    # NUMÉRICOS
    # ==================================================

    numeric=[

        "open",
        "high",
        "low",
        "close",
        "volume"
    ]

    for c in numeric:

        if c in df.columns:

            df[c]=pd.to_numeric(
                df[c],
                errors="coerce"
            )

    df=df.dropna(
        subset=[
            "time",
            "open",
            "high",
            "low",
            "close"
        ]
    )

    df=df.sort_values(
        "time"
    )

    df=df.reset_index(
        drop=True
    )

    return df
