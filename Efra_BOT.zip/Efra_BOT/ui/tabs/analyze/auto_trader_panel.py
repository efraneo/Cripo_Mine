# tabs/analyze/auto_trader_panel.py

import streamlit as st
from ui.tabs.analyze.analyze_utils import run_async_safely


def render_auto_trader(engine, ia):

    st.markdown("## 🤖 Auto Trader Inteligente")

    auto_enabled = st.toggle(
        "Activar Auto Trader IA",
        value=st.session_state.get(
            "auto_trader_enabled",
            False
        )
    )

    st.session_state[
        "auto_trader_enabled"
    ]=auto_enabled

    if not auto_enabled:
        st.info(
            "Auto Trader desactivado"
        )
        return

    st.success(
        "🟢 Auto Trader activo"
    )

    direction=ia.get(
        "direction",
        "RANGE"
    )

    emoji={

        "LONG":"🐂",
        "SHORT":"🐻",
        "RANGE":"⚖️"

    }.get(direction,"⚪")

    st.markdown(
        f"### Estado IA: {emoji} {direction}"
    )

    if st.button(
        "⚡ Ejecutar ciclo IA"
    ):

        try:

            result=run_async_safely(
                engine.run_multi_asset_cycle()
            )

            st.session_state[
                "last_auto_exec"
            ]=result

            st.success(
                "Ciclo ejecutado"
            )

            st.json(result)

        except Exception as e:

            st.error(str(e))
