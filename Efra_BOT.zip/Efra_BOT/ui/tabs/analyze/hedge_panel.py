import streamlit as st


def render_hedge(
    engine,
    ia=None
):

    st.subheader(
        "🏦 Hedge Fund Mode"
    )

    try:

        hedge_engine = getattr(
            engine,
            "hedge_engine",
            None
        )

        if hedge_engine is None:

            st.warning(
                "Hedge Engine no inicializado"
            )

            return

        if st.button(
            "🔥 Construir Portfolio Market Neutral"
        ):

            with st.spinner(
                "Analizando mercado..."
            ):

                results = (
                    engine.scanner.scan_market()
                )

            if not results:

                st.warning(
                    "Sin oportunidades"
                )

                return

            balance = (
                engine.get_balance(
                    "USDT"
                ) or 0
            )

            portfolio = (
                hedge_engine.build_hedge_portfolio(
                    results,
                    balance
                )
            )

            if not portfolio:

                st.warning(
                    "No se encontró hedge válido"
                )

                return

            st.success(
                f"Portfolio generado ({len(portfolio)})"
            )

            for p in portfolio:

                col1,col2,col3=st.columns(3)

                col1.metric(
                    "Activo",
                    p["symbol"]
                )

                col2.metric(
                    "Lado",
                    p["side"]
                )

                col3.metric(
                    "Capital",
                    f"${p['capital']:.2f}"
                )

    except Exception as e:

        st.exception(e)
