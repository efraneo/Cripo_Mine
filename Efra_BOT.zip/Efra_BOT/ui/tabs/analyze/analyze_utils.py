# tabs/analyze/analyze_utils.py

import asyncio
import inspect


def run_async_safely(coro):

    try:

        loop=asyncio.new_event_loop()

        asyncio.set_event_loop(
            loop
        )

        return loop.run_until_complete(
            coro
        )

    finally:

        try:
            loop.close()

        except Exception:
            pass


def normalize_execution_result(
        result
):

    if inspect.iscoroutine(
        result
    ):

        return {

            "executed":False,
            "orders":[],
            "reason":"Coroutine sin await"

        }

    if result is None:

        return {

            "executed":False,
            "orders":[]
        }

    if isinstance(
        result,
        dict
    ):

        result.setdefault(
            "executed",
            False
        )

        return result

    return {

        "executed":False,
        "orders":[]
    }
