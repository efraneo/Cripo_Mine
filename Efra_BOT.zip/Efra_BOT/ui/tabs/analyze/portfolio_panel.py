# tabs/analyze/portfolio_panel.py

import streamlit as st


def render_portfolio(engine):

    st.subheader(
        "🏦 Portfolio"
    )

    try:

        if not hasattr(
            engine,
            "portfolio"
        ):

            st.warning(
                "Portfolio no disponible"
            )

            return

        if st.button(
            "🚀 Construir portfolio"
        ):

            results = (
                engine.scanner.scan_market()
            )

            if not results:

                st.warning(
                    "Sin oportunidades"
                )

                return

            balance = (
                engine.get_balance(
                    "USDT"
                )
                or 0
            )

            allocations = (
                engine.portfolio.allocate_capital(
                    results[:5],
                    balance
                )
            )

            for a in allocations:

                st.write(

                    f"{a['symbol']}"

                    f" → "

                    f"${a['capital']:.2f}"
                )

    except Exception as e:

        st.error(
            f"Portfolio error: {e}"
        )
