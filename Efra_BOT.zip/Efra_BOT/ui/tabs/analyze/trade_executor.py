# tabs/analyze/trade_executor.py

import streamlit as st

from core.execution.oms import execute_via_oms


def render_trade_button(
    symbol,
    ia,
    engine
):

    policy=ia.get(
        "execution_policy",
        {}
    )

    if not policy.get(
        "allow_trade"
    ):
        st.button(
            "🚫 Ejecutar Trade IA",
            disabled=True
        )
        return

    if st.button(
        "🚀 Ejecutar Trade IA",
        type="primary"
    ):

        result=execute_via_oms(
            symbol=symbol,
            ia=ia,
            engine=engine
        )

        if result.get(
            "status"
        )=="ERROR":

            st.error(
                result.get(
                    "reason"
                )
            )

        else:

            st.success(
                "Trade ejecutado"
            )

        st.json(result)
