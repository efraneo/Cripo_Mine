# ui/tabs/analyze/chart_renderer.py

import streamlit as st
import plotly.graph_objects as go

from plotly.subplots import make_subplots

from ui.tabs.analyze.smc_overlay import (
    add_smc_overlays
)


def render_chart(
    df,
    symbol,
    ia
):

    if df is None or df.empty:

        st.warning(
            "No hay datos OHLC"
        )
        return

    df = df.copy()

    # =====================================================
    # SUBPLOTS
    # =====================================================

    fig = make_subplots(

        rows=2,
        cols=1,

        shared_xaxes=True,

        row_heights=[
            0.75,
            0.25
        ],

        vertical_spacing=0.03
    )

    # =====================================================
    # CANDLESTICKS
    # =====================================================

    fig.add_trace(

        go.Candlestick(

            x=df["time"],

            open=df["open"],
            high=df["high"],
            low=df["low"],
            close=df["close"],

            name="Price"

        ),

        row=1,
        col=1
    )

    # =====================================================
    # EMA20
    # =====================================================

    df["ema20"] = (

        df["close"]

        .ewm(span=20)

        .mean()
    )

    fig.add_trace(

        go.Scatter(

            x=df["time"],
            y=df["ema20"],

            mode="lines",

            name="EMA20"

        ),

        row=1,
        col=1
    )

    # =====================================================
    # EMA50
    # =====================================================

    df["ema50"] = (

        df["close"]

        .ewm(span=50)

        .mean()
    )

    fig.add_trace(

        go.Scatter(

            x=df["time"],
            y=df["ema50"],

            mode="lines",

            name="EMA50"

        ),

        row=1,
        col=1
    )

    # =====================================================
    # VWAP
    # =====================================================

    try:

        typical = (

            df["high"]
            + df["low"]
            + df["close"]

        ) / 3

        vwap = (

            (typical * df["volume"]).cumsum()

            /

            df["volume"].cumsum()

        )

        fig.add_trace(

            go.Scatter(

                x=df["time"],
                y=vwap,

                mode="lines",

                name="VWAP"

            ),

            row=1,
            col=1
        )

    except Exception:
        pass

    # =====================================================
    # ENTRY
    # =====================================================

    entry = ia.get("entry_price")

    if entry:

        fig.add_hline(

            y=float(entry),

            annotation_text="ENTRY",

            row=1,
            col=1
        )

    # =====================================================
    # TP
    # =====================================================

    tp = ia.get("take_profit")

    if tp:

        fig.add_hline(

            y=float(tp),

            annotation_text="TP",

            row=1,
            col=1
        )

    # =====================================================
    # SL
    # =====================================================

    sl = ia.get("stop_loss")

    if sl:

        fig.add_hline(

            y=float(sl),

            annotation_text="SL",

            row=1,
            col=1
        )

    # =====================================================
    # SMART MONEY
    # =====================================================

    add_smc_overlays(
        fig,
        df,
        ia
    )

    # =====================================================
    # DIRECCIÓN IA
    # =====================================================

    last = df.iloc[-1]

    signal = "📈 LONG"

    if ia.get("direction") == "SHORT":

        signal = "📉 SHORT"

    fig.add_annotation(

        x=last["time"],
        y=last["close"],

        text=signal,

        showarrow=True,

        row=1,
        col=1
    )

    # =====================================================
    # VOLUMEN SEPARADO
    # =====================================================

    volume_colors = [

        "green"

        if c >= o

        else "red"

        for c, o in zip(
            df["close"],
            df["open"]
        )
    ]

    fig.add_trace(

        go.Bar(

            x=df["time"],
            y=df["volume"],

            name="Volume",

            marker_color=volume_colors

        ),

        row=2,
        col=1
    )

    # =====================================================
    # LAYOUT
    # =====================================================

    confidence = ia.get(
        "confidence",
        0
    )

    fig.update_layout(

        title=(
            f"{symbol} | "
            f"IA PRO {confidence:.2f}%"
        ),

        xaxis_rangeslider_visible=False,

        height=1000,

        legend=dict(
            orientation="h"
        )
    )

    st.plotly_chart(
        fig,
        width="stretch"
    )

    # =====================================================
    # DEBUG
    # =====================================================

    with st.expander(
        "📊 OHLC Debug"
    ):

        st.dataframe(
            df.tail(20),
            width="stretch"
        )
