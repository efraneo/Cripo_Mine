# ui/tabs/analyze/smc_overlay.py

import pandas as pd


def add_smc_overlays(
    fig,
    df,
    ia
):
    """
    Overlay institucional:
    - Liquidez
    - Order Blocks
    - FVG
    - Smart Money
    """

    try:

        if df is None or df.empty:
            return

        # =====================================================
        # SMART MONEY
        # =====================================================

        smc = ia.get(
            "smart_money",
            {}
        )

        smc_conf = smc.get(
            "confidence",
            0
        )

        fig.add_annotation(

            x=df.iloc[-10]["time"],
            y=df["high"].max(),

            text=(
                f"🏦 SMC "
                f"{smc_conf:.1f}%"
            ),

            showarrow=False
        )

        # =====================================================
        # LIQUIDEZ
        # =====================================================

        liquidity = ia.get(
            "liquidity",
            {}
        )

        liquidity_level = liquidity.get(
            "dominant_level",
            None
        )

        if liquidity_level:

            fig.add_hline(

                y=float(liquidity_level),

                annotation_text="💰 Liquidez",

                line_dash="dash"
            )

        # =====================================================
        # ORDER BLOCKS
        # =====================================================

        order_blocks = ia.get(
            "order_blocks",
            []
        )

        for ob in order_blocks[:3]:

            try:

                level = float(
                    ob.get(
                        "price",
                        0
                    )
                )

                fig.add_hline(

                    y=level,

                    annotation_text="OB",

                    line_dash="dot"
                )

            except Exception:
                pass

        # =====================================================
        # FAIR VALUE GAP
        # =====================================================

        fvgs = ia.get(
            "fvg",
            []
        )

        for gap in fvgs[:2]:

            try:

                low = float(
                    gap["low"]
                )

                high = float(
                    gap["high"]
                )

                fig.add_hrect(

                    y0=low,
                    y1=high,

                    opacity=0.15,

                    annotation_text="FVG"
                )

            except Exception:
                pass

    except Exception:
        pass