# tabs/analyze/market_context_panel.py

import streamlit as st


def render_market_context(
    ia,
    engine
):

    st.subheader(
        "🌍 Contexto Institucional"
    )

    mc=ia.get(
        "market_context",
        engine.get_market_context()
    )

    session=mc.get(
        "session",
        {}
    )

    news=mc.get(
        "news",
        {}
    )

    c1,c2=st.columns(2)

    c1.metric(
        "Sesión dominante",
        session.get(
            "active",
            "N/A"
        ),
        session.get(
            "bias",
            "NEUTRAL"
        )
    )

    c2.metric(
        "Riesgo noticias",
        news.get(
            "risk",
            "LOW"
        ),
        f"{news.get('headline_count',0)} eventos"
    )
