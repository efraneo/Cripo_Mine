import streamlit as st
import pandas as pd


def render_opportunities(engine):

    st.subheader(
        "🏆 Top oportunidades"
    )

    try:

        if (
            not hasattr(
                engine,
                "scanner"
            )
            or engine.scanner is None
        ):

            st.warning(
                "Scanner no disponible"
            )

            return

        results = engine.scanner.scan_market()

        if not results:

            st.info(
                "Sin oportunidades encontradas"
            )

            return

        df = pd.DataFrame([

            {
                "Activo":r.get(
                    "symbol",
                    "N/A"
                ),

                "Confianza":round(
                    r.get(
                        "confidence",
                        0
                    ),
                    2
                ),

                "Dirección":r.get(
                    "direction",
                    "N/A"
                )
            }

            for r in results[:10]

        ])

        st.dataframe(
            df,
            width="stretch"
        )

    except Exception as e:

        st.error(
            f"Error scanner: {e}"
        )
