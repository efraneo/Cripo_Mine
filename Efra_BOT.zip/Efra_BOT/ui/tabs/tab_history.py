import streamlit as st
import logging
import pandas as pd

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")

def render_tab_history(ctx=None):

    st.header("📜 Historial de Operaciones")
    # ============================================================
    # DEPENDENCIA ANALYSIS STATE
    # ============================================================

    if not st.session_state.get("analysis_ready"):
        st.info("Ejecute un análisis primero.")
        return

    # ----------------------------------------------
    # VALIDACIÓN DE SESIÓN (CORRECTA)
    # ----------------------------------------------
    if not st.session_state.get("session"):
        st.error("Sesión inválida.")
        return

    engine = (
        st.session_state.get("trading_engine")
        or st.session_state.get("engine")
    )

    if not engine:
        st.warning("Motor de trading no inicializado.")
        return

    if not hasattr(engine, "get_trade_history"):
        st.warning("El motor no expone historial de operaciones.")
        return

    try:
        history = engine.get_trade_history() # le quite limit=200...
    except Exception:
        app_log.exception("Error cargando historial")
        st.error("No se pudo cargar el historial.")
        return

    if not history:
        st.info("No hay operaciones registradas.")
        return

    df = pd.DataFrame(history)

    # -----------------------------
    # Normalización segura
    # -----------------------------
    for col in ("created_at", "timestamp", "executed_at"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    date_col = next(
        (c for c in ("executed_at", "created_at", "timestamp") if c in df.columns),
        None,
    )

    if date_col:
        df = df.sort_values(by=date_col, ascending=False)

    st.dataframe(
        df,
        width="stretch",
        hide_index=True,
    )

    st.caption(f"Total operaciones registradas: {len(df)}")
