import streamlit as st
import sqlite3
import pandas as pd
import logging

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")


DB_PATH = "data/usuarios.db"


def safe_read_table(conn, table_name, limit=100):
    try:
        cursor = conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name})")
        cols = [c[1] for c in cursor.fetchall()]

        if not cols:
            return pd.DataFrame()

        order_col = "timestamp" if "timestamp" in cols else cols[0]

        query = f"SELECT * FROM {table_name} ORDER BY {order_col} DESC LIMIT {limit}"
        return pd.read_sql(query, conn)

    except Exception:
        app_log.exception(f"safe_read_table {table_name}")
        return pd.DataFrame()


def render_tab_settings(ctx=None):

    # 🔐 VALIDACIÓN
    session = st.session_state.get("session")
    if not session:
        st.error("Sesión inválida.")
        return

    if not session.get("is_admin"):
        st.error("Solo administrador.")
        return

    st.header("⚙️ Configuración Avanzada")

    engine = st.session_state.get("engine")

    st.subheader("Estado del sistema")
    st.write(f"Motor activo: **{'Sí' if engine else 'No'}**")
    st.write(f"Modo trading: **{getattr(engine, 'mode', 'N/D')}**")

    if engine and st.button("♻️ Reiniciar motor"):
        try:
            engine.reset()
            st.success("Motor reiniciado")
        except Exception:
            app_log.exception("reset engine")
            st.error("Error reiniciando motor")

    if st.button("🧹 Limpiar caché UI"):
        preserved = {
            "session": st.session_state.get("session"),
            "engine": st.session_state.get("engine"),
        }
        st.session_state.clear()
        st.session_state.update(preserved)
        st.success("Caché limpiada")
        st.rerun()

    st.subheader("🔐 Panel de Seguridad")

    conn = sqlite3.connect(DB_PATH)

    try:
        st.write("Score dinámico IP")
        st.dataframe(safe_read_table(conn, "ip_risk"))

        st.write("Eventos IDS")
        st.dataframe(safe_read_table(conn, "ids_events"))

        st.subheader("🧠 Score Dinámico IP")
        st.dataframe(safe_read_table(conn, "ip_risk"))

        st.subheader("⚠ Score Riesgo por Usuario")
        st.dataframe(safe_read_table(conn, "users"))

    except Exception:
        app_log.exception("settings render")

    conn.close()