# ui/tabs/tab_users.py

import streamlit as st
import logging
import pandas as pd
import sqlite3

DB_PATH = "data/usuarios.db"

# =========================================================
# LOGGER
# =========================================================
try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")


# =========================================================
# TAB PRINCIPAL
# =========================================================
def render_tab_users(ctx=None):

    from backend.session_manager import SessionManager
    from backend.ip_manager import IPManager

    session_m = SessionManager(DB_PATH)
    ip_m = IPManager(DB_PATH)

    # ======================================================
    # VALIDACIÓN SESIÓN
    # ======================================================
    sid = st.session_state.get("session_id")
    session = session_m.get_session(sid) if sid else None

    if not session:
        st.error("Sesión inválida")
        return

    username = session.get("username")

    conn = sqlite3.connect(DB_PATH)

    user_df = pd.read_sql(
        "SELECT is_admin FROM users WHERE username=?",
        conn,
        params=(username,)
    )

    if user_df.empty or user_df["is_admin"].iloc[0] != 1:
        st.error("Solo administrador")
        conn.close()
        return

    st.header("👥 Gestión Institucional de Usuarios")

    # ======================================================
    # 1️⃣ USUARIOS
    # ======================================================
    try:
        users_df = pd.read_sql("SELECT * FROM users", conn)

        st.subheader("👤 Usuarios registrados")
        st.dataframe(users_df, width="stretch")

    except Exception:
        app_log.exception("Error cargando users")
        st.error("No se pudo cargar tabla users")
        conn.close()
        return

    # ======================================================
    # 2️⃣ SESIONES ACTIVAS
    # ======================================================
    try:
        sessions = session_m.list_active_sessions()
        df_sessions = pd.DataFrame(sessions)

        st.subheader("🟢 Sesiones activas")

        if not df_sessions.empty:
            st.dataframe(df_sessions, width="stretch")
        else:
            st.info("Sin sesiones activas")

    except Exception:
        app_log.exception("Error sesiones")

    # ======================================================
    # 3️⃣ CONTROL DE IPs (🔥 NUEVO CORE)
    # ======================================================
    try:
        ips = ip_m.get_all()
        df_ips = pd.DataFrame(ips)

        st.subheader("🌐 Control de IPs")

        if not df_ips.empty:

            # 🔥 visual mejorado
            df_ips["estado"] = df_ips["approved"].apply(
                lambda x: "✅ APROBADA" if x else "⛔ PENDIENTE"
            )

            st.dataframe(df_ips, width="stretch")

            # selector
            options = df_ips.apply(
                lambda x: f"{x['username']} | {x['ip']} | {x['estado']}",
                axis=1
            ).tolist()

            selected = st.selectbox("Seleccionar IP", options)

            selected_row = df_ips.iloc[options.index(selected)]

            col1, col2 = st.columns(2)

            # ==========================
            # APROBAR
            # ==========================
            if not selected_row["approved"]:
                with col1:
                    if st.button("✅ Aprobar IP"):

                        try:
                            ip_m.approve_ip(
                                selected_row["username"],
                                selected_row["ip"]
                            )
                            st.success("IP aprobada")
                            st.rerun()

                        except Exception as e:
                            st.error(str(e))

            # ==========================
            # INFO
            # ==========================
            with col2:
                st.info(
                    f"Usuario: {selected_row['username']}\n"
                    f"IP: {selected_row['ip']}"
                )

        else:
            st.info("Sin registros de IP")

    except Exception:
        app_log.exception("Error IPs")
        st.error("⚠️ Error cargando control de IPs")

    # ======================================================
    # 4️⃣ LOGS DE SEGURIDAD
    # ======================================================
    try:
        logs = ip_m.list_logs()
        df_logs = pd.DataFrame(logs)

        st.subheader("🚨 Eventos de seguridad")

        if not df_logs.empty:
            st.dataframe(df_logs, width="stretch")
        else:
            st.info("Sin eventos")

    except Exception:
        app_log.exception("Error logs")

    # ======================================================
    # 5️⃣ BLOQUEOS
    # ======================================================
    try:
        blocks_df = pd.read_sql("SELECT * FROM ip_blocks", conn)
        st.subheader("🚫 IPs Bloqueadas")

        if not blocks_df.empty:
            st.dataframe(blocks_df, width="stretch")
        else:
            st.info("Sin IPs bloqueadas")

    except Exception:
        pass

    # ======================================================
    # 6️⃣ EDITAR USUARIO
    # ======================================================
    st.subheader("✏ Editar Usuario")
    if not users_df.empty:
        selected_user = st.selectbox(
            "Seleccionar usuario",
            users_df["username"].dropna().tolist()
        )
        user_row = users_df[users_df["username"] == selected_user].iloc[0]
        updated_data = {}
        for col in users_df.columns:
            if col == "id":
                continue
            updated_data[col] = st.text_input(col, str(user_row[col]))
        if st.button("Guardar cambios usuario"):
            set_clause = ", ".join([f"{c}=?" for c in updated_data.keys()])
            values = list(updated_data.values())
            values.append(selected_user)
            conn.execute(
                f"UPDATE users SET {set_clause} WHERE username=?",
                values
            )
            conn.commit()
            st.success("Usuario actualizado")
            st.rerun()

    # ======================================================
    # 7️⃣ ELIMINAR USUARIO
    # ======================================================
    st.subheader("🗑 Eliminar Usuario")

    if not users_df.empty:
        del_user = st.selectbox(
            "Usuario a eliminar",
            users_df["username"].dropna().tolist()
        )
        if st.button("Eliminar definitivamente"):
            conn.execute(
                "DELETE FROM users WHERE username=?",
                (del_user,)
            )
            conn.commit()
            st.success("Usuario eliminado")
            st.rerun()
    conn.close()

    # ======================================================
    # 8️⃣ HISTORIAL INSTITUCIONAL
    # ======================================================
    st.subheader("🧠 Historial institucional")
    try:
        conn = sqlite3.connect("data/user_activity.db")
        # ==========================================
        # CREATE TABLE IF NOT EXISTS
        # ==========================================
        conn.execute("""
            CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                event TEXT,
                ip TEXT,
                created_at TIMESTAMP
                DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        df = pd.read_sql(
            """
            SELECT *
            FROM activity_logs
            ORDER BY id DESC
            LIMIT 100
            """,
            conn
        )
        conn.close()
        if not df.empty:
            st.dataframe(
                df,
                width="stretch"
            )
        else:
            st.info(
                "Sin historial institucional"
            )
    except Exception:
        app_log.exception(
            "Error cargando activity_logs"
        )
        st.error(
            "No se pudo cargar historial institucional"
        )
