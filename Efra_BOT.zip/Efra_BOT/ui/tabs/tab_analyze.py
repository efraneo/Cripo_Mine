# ui/tabs/tab_analyze.py

import streamlit as st

from ui.tabs.analyze.ohlc_loader import load_ohlc
from ui.tabs.analyze.ia_summary import render_ia_summary
from ui.tabs.analyze.trade_executor import render_trade_button
from ui.tabs.analyze.market_context_panel import render_market_context
from ui.tabs.analyze.chart_renderer import render_chart
from ui.tabs.analyze.auto_trader_panel import render_auto_trader
from ui.tabs.analyze.opportunities_panel import render_opportunities
from ui.tabs.analyze.portfolio_panel import render_portfolio
from ui.tabs.analyze.hedge_panel import render_hedge
from ui.tabs.analyze.analyze_utils import (
    run_async_safely,
    normalize_execution_result
)


def render_tab_analyze(ctx=None):

    st.header(
        "🧠 Predicción IA PRO"
    )

    # =====================================
    # VALIDACIONES
    # =====================================

    if not ctx:
        st.error("Contexto inválido")
        return

    engine = ctx.get("engine")

    if not engine:
        st.error("Engine no disponible")
        return

    symbol = st.session_state.get(
        "selected_asset"
    )

    if not symbol:
        st.warning(
            "Selecciona un activo"
        )
        return

    ia = st.session_state.get(
        "ia_decision"
    )

    if not ia:
        st.warning(
            "Sin análisis"
        )
        return

    # =====================================
    # OHLC
    # =====================================

    try:

        df_5m = load_ohlc(
            engine,
            symbol
        )

    except Exception as e:

        st.error(
            f"Error OHLC: {e}"
        )

        return

    # =====================================
    # RESUMEN IA
    # =====================================

    render_ia_summary(
        ia
    )

    # =====================================
    # BOTÓN EJECUCIÓN
    # =====================================

    render_trade_button(
        symbol,
        ia,
        engine
    )

    # =====================================
    # CONTEXTO INSTITUCIONAL
    # =====================================

    render_market_context(
        ia,
        engine
    )

    # =====================================
    # GRÁFICA
    # =====================================
    st.markdown("---")

    st.subheader(
        "📈 Gráfico Institucional"
    )

    render_chart(
        df_5m,
        symbol,
        ia
    )

    # =====================================
    # AUTO TRADER
    # =====================================

    render_auto_trader(
        engine,
        ia
    )

    # =====================================
    # OPORTUNIDADES
    # =====================================

    render_opportunities(
        engine
    )

    # =====================================
    # PORTFOLIO
    # =====================================

    render_portfolio(
        engine
    )

    # =====================================
    # HEDGE
    # =====================================

    render_hedge(
        engine
    )

