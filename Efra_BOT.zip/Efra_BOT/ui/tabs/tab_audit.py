import streamlit as st
import logging
import pandas as pd
import plotly.graph_objects as go

from backend.ip_manager import IPManager

DB_PATH = "data/usuarios.db"
ip_m = IPManager(DB_PATH)

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")


# =========================================================
# TAB AUDITORÍA INSTITUCIONAL + SEGURIDAD
# =========================================================
def render_tab_audit(ctx=None):

    st.header("🛡️ Auditoría Institucional")

    engine = ctx.get("engine") if ctx else None

    # =========================================================
    # 🔐 BLOQUE 1 — SEGURIDAD (TU SISTEMA ACTUAL)
    # =========================================================
    st.subheader("🔐 Seguridad (IPs / Accesos)")

    if not st.session_state.get("session"):
        st.error("Sesión inválida.")
        return

    try:
        records = ip_m.list_logs(
            limit=100
        )
    except Exception:
        app_log.exception(
            "Audit load failed",
            exc_info=True
        )
        records = []
    if records:
        df_sec = pd.DataFrame(
            records
        )
        if "ts" in df_sec.columns:
            df_sec["ts"] = pd.to_datetime(
                df_sec["ts"],
                errors="coerce"
            )
            df_sec = df_sec.sort_values(
                "ts",
                ascending=False
            )
        st.dataframe(
            df_sec,
            width="stretch"
        )
    else:
        st.info(
            "Sin eventos de seguridad registrados"
        )

    # =========================================================
    # 🚀 BLOQUE 2 — EJECUCIÓN (INSTITUCIONAL)
    # =========================================================
    st.subheader("📊 Auditoría de Ejecución")

    if not engine:
        st.warning("Engine no disponible")
        return

    executions = []
    if hasattr(engine.execution_engine, "analytics"):
        executions = getattr(
            engine.execution_engine.analytics,
            "executions",
            []
        )
    elif hasattr(engine.execution_engine, "executions"):
        executions = getattr(
            engine.execution_engine,
            "executions",
            []
        )

    if not executions:
        st.info("Sin ejecuciones registradas")
        return

    df = pd.DataFrame(executions)

    # =========================================================
    # NORMALIZACIÓN
    # =========================================================
    try:
        df["timestamp"] = pd.to_datetime(df.get("timestamp"), errors="coerce")
    except Exception:
        df["timestamp"] = pd.Timestamp.utcnow()

    df["slippage"] = pd.to_numeric(df.get("slippage", 0), errors="coerce")
    df["expected_slippage"] = pd.to_numeric(df.get("expected_slippage", 0), errors="coerce")
    df["latency"] = pd.to_numeric(df.get("latency", 0), errors="coerce")

    df = df.fillna(0)

    # =========================================================
    # KPIs
    # =========================================================
    st.subheader("📈 Métricas institucionales")

    avg_slippage = df["slippage"].mean()
    avg_latency = df["latency"].mean()
    slippage_diff = (df["slippage"] - df["expected_slippage"]).mean()

    execution_score = max(0, 100 - abs(avg_slippage * 10000))

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Slippage Promedio", f"{avg_slippage:.5f}")
    c2.metric("Latencia Promedio", f"{avg_latency:.4f}s")
    c3.metric("Desviación Slippage", f"{slippage_diff:.5f}")
    c4.metric("Execution Score", f"{execution_score:.2f}/100")

    # =========================================================
    # 📉 SLIPPAGE REAL VS ESPERADO
    # =========================================================
    st.subheader("📉 Slippage Real vs Esperado")

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=df["timestamp"],
        y=df["slippage"],
        name="Real",
        mode="lines+markers"
    ))

    fig.add_trace(go.Scatter(
        x=df["timestamp"],
        y=df["expected_slippage"],
        name="Esperado",
        mode="lines"
    ))

    fig.update_layout(
        template="plotly_dark",
        height=400
    )

    st.plotly_chart(fig, use_container_width=True)

    # =========================================================
    # ⏱️ LATENCIA
    # =========================================================
    st.subheader("⏱️ Latencia por orden")

    fig2 = go.Figure()

    fig2.add_bar(
        x=df["timestamp"],
        y=df["latency"],
        name="Latency"
    )

    fig2.update_layout(
        template="plotly_dark",
        height=350
    )

    st.plotly_chart(fig2, use_container_width=True)

    # =========================================================
    # 📊 DISTRIBUCIÓN SLIPPAGE
    # =========================================================
    st.subheader("📊 Distribución de Slippage")

    fig3 = go.Figure()

    fig3.add_histogram(x=df["slippage"])

    fig3.update_layout(
        template="plotly_dark",
        height=350
    )

    st.plotly_chart(fig3, width="stretch")

    # =========================================================
    # 🚨 ERRORES
    # =========================================================
    st.subheader("🚨 Errores de ejecución")

    errors = df[df.get("status") == "ERROR"]

    if not errors.empty:
        st.error(f"{len(errors)} errores detectados")
        st.dataframe(errors, use_container_width=True)
    else:
        st.success("Sin errores de ejecución")

    # =========================================================
    # 📋 LOG COMPLETO
    # =========================================================
    st.subheader("📋 Log completo de ejecuciones")

    st.dataframe(df, use_container_width=True)