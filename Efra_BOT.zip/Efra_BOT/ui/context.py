# ui/context.py
import streamlit as st
from backend.user_manager import UserManager
from backend.session_manager import SessionManager
from core.engine_utils import lazy_init_engine

DB_PATH = "data/usuarios.db"

def get_ui_context():
    if "ui_context" in st.session_state:
        return st.session_state["ui_context"]

    ctx = {
        "session_id": st.session_state.get("session_id"),
        "engine": None,
        "user": None,
        "session": None,
        "is_admin": False,
    }

    if not ctx["session_id"]:
        st.session_state["ui_context"] = ctx
        return ctx

    user_m = UserManager(DB_PATH)
    session_m = SessionManager(DB_PATH)

    sess = session_m.get_session(ctx["session_id"])
    if not sess:
        st.session_state["ui_context"] = ctx
        return ctx

    user = user_m.get_user_by_username(sess["username"])
    engine = lazy_init_engine(force=False)

    ctx.update({
        "session": sess,
        "user": user,
        "engine": engine,
        "is_admin": bool(user and user.get("is_admin")),
    })

    st.session_state["ui_context"] = ctx
    return ctx
