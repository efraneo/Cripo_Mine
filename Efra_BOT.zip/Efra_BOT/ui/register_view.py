import streamlit as st

def render_register_view():
    st.title("🆕 Registro de nuevo usuario")

    st.info("Completa todos los campos para crear tu cuenta")

    with st.form("register_form", clear_on_submit=False):
        col1, col2 = st.columns(2)

        with col1:
            full_name = st.text_input("Nombre completo")
            cedula = st.text_input("Cédula / ID")
            username = st.text_input("Usuario")
            email = st.text_input("Correo electrónico")

        with col2:
            password1 = st.text_input("Contraseña", type="password")
            password2 = st.text_input("Confirmar contraseña", type="password")
            binance_key = st.text_input("Binance API Key")
            binance_secret = st.text_input("Binance API Secret", type="password")

        submit = st.form_submit_button("✅ Crear cuenta")

    if submit:
        if not all([full_name, cedula, username, email, password1, password2]):
            st.error("Todos los campos son obligatorios")
            return

        if password1 != password2:
            st.error("Las contraseñas no coinciden")
            return

        # aquí llamas a UserManager.create_user(...)
        st.success("Cuenta creada correctamente")
        st.session_state["ui_mode"] = "LOGIN"
        st.rerun()
