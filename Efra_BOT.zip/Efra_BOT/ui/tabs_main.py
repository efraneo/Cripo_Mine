"""
Orquestador central de Tabs
Decide qué pestañas renderizar según el rol del usuario
"""

import streamlit as st
import logging

from backend.user_manager import UserManager

# -------------------------------------------------
# Tabs
# -------------------------------------------------
from ui.tabs.tab_analyze import render_tab_analyze
from ui.tabs.tab_history import render_tab_history
from ui.tabs.tab_audit import render_tab_audit
from ui.tabs.tab_users import render_tab_users
from ui.tabs.tab_settings import render_tab_settings

DB_PATH = "data/usuarios.db"
user_m = UserManager(DB_PATH)

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")


def _get_current_user():
    sid = st.session_state.get("session_id")
    if not sid:
        return None

    try:
        from backend.session_manager import SessionManager
        sess_m = SessionManager(DB_PATH)
        sess = sess_m.get_session(sid)
        if not sess:
            return None

        return user_m.get_user_by_username(sess["username"])
    except Exception:
        app_log.exception("Failed resolving current user", exc_info=True)
        return None


def _resolve_user_from_ctx(ctx):
    """
    Prioridad:
    1) ctx.session.user
    2) session_id → DB
    """
    if ctx and ctx.get("session"):
        user = ctx["session"].get("user")
        if user:
            return user

    # Fallback DB
    sid = st.session_state.get("session_id")
    if not sid:
        return None

    try:
        from backend.session_manager import SessionManager
        sess_m = SessionManager(DB_PATH)
        sess = sess_m.get_session(sid)
        if not sess:
            return None
        return user_m.get_user_by_username(sess["username"])
    except Exception:
        app_log.exception("Failed resolving user", exc_info=True)
        return None


def render_tabs(ctx):

    # -----------------------------
    # Sesión mínima requerida
    # -----------------------------
    if not st.session_state.get("session_id"):
        st.warning("Sesión no inicializada.")
        return

    user = _resolve_user_from_ctx(ctx)
    if not user:
        st.error("Usuario no válido.")
        return

    is_admin = bool(user.get("is_admin"))

    # ---------------------------------
    # HIDRATAR SESIÓN GLOBAL PARA TABS
    # ---------------------------------
    if "session" not in st.session_state:
        st.session_state["session"] = {
            "username": user["username"],
            "user": user,
            "is_admin": user.get("is_admin", False),
            "session_id": st.session_state.get("session_id"),
        }

    # -----------------------------
    # Definición de tabs
    # -----------------------------
    tab_defs = [
        ("🧠 Analizar", render_tab_analyze),
        ("📜 Historial", render_tab_history),
    ]

    # Tabs admin
    if is_admin:
        tab_defs.extend([
            ("👥 Usuarios", render_tab_users),
            ("🛡️ Auditoría", render_tab_audit),
            ("⚙️ Configuración", render_tab_settings),
        ])

    labels = [label for label, _ in tab_defs]
    renderers = [renderer for _, renderer in tab_defs]

    try:
        tabs = st.tabs(labels)
    except Exception:
        app_log.exception("Failed creating tabs UI", exc_info=True)
        st.error("Error inicializando el panel.")
        return

    # -----------------------------
    # Render seguro
    # -----------------------------
    for tab, renderer in zip(tabs, renderers):
        with tab:
            try:
                renderer(ctx)
            except Exception:
                app_log.exception(
                    f"Tab render failed: {renderer.__name__}",
                    exc_info=True
                )
                st.error("⚠️ Error cargando esta sección.")
