# ui/tabs/admin_limits.py

import streamlit as st
import json
import os
from datetime import datetime

# Backend
from backend.order_manager import OrderManager
from backend.user_manager import UserManager
from backend.log_manager import get_logger

log = get_logger("admin_limits")

LIMITS_FILE = os.path.join("data", "real_limits.jsonl")

def render_admin_limits_tab(order_manager: OrderManager, user_manager: UserManager):
    st.title("Panel Administrativo — Límites de Operación")

    st.markdown("""
    Este panel permite:
    - Establecer **límite global por operación REAL**
    - Configurar límite específico por **usuario**
    - Revisar **violaciones registradas**
    """)

    st.divider()

    # ============================================================
    #           1.  LÍMITE GLOBAL
    # ============================================================

    st.subheader("Límite global por operación (USDT)")

    current_global = order_manager.max_usdt_per_order_global
    new_global = st.number_input(
        "Nuevo límite global",
        min_value=1.0,
        max_value=100000.0,
        value=float(current_global),
        step=1.0
    )

    if st.button("Actualizar límite global"):
        try:
            order_manager.set_global_limit(new_global)
            st.success(f"Límite global actualizado a {new_global} USDT.")
        except Exception as e:
            st.error(f"Error: {e}")

    st.divider()

    # ============================================================
    #           2.  LÍMITES POR USUARIO
    # ============================================================

    st.subheader("Límites por usuario")

    # Listado de usuarios
    try:
        users = user_manager.get_all_users()
        user_list = [u.get("username") for u in users if u.get("username")]
    except Exception:
        user_list = []

    if user_list:
        selected_user = st.selectbox("Selecciona un usuario", user_list)
        current_user_limit = order_manager.max_usdt_per_order_by_user.get(selected_user)

        st.write(f"Límite actual: **{current_user_limit if current_user_limit else 'No definido'}**")

        new_user_limit = st.number_input(
            f"Límite para {selected_user} (USDT)",
            min_value=1.0,
            max_value=100000.0,
            value=float(current_user_limit) if current_user_limit else 100.0,
            step=1.0,
            key="limit_user_input"
        )

        if st.button("Asignar límite por usuario"):
            try:
                order_manager.set_user_limit(selected_user, new_user_limit)
                st.success(f"Límite actualizado: {selected_user} → {new_user_limit} USDT")
            except Exception as e:
                st.error(f"Error: {e}")
    else:
        st.warning("No hay usuarios registrados.")

    st.divider()

    # ============================================================
    #           3. AUDITORIA DE VIOLACIONES
    # ============================================================

    st.subheader("Auditoría — Intentos excedidos de límite")

    if os.path.exists(LIMITS_FILE):
        records = []
        try:
            with open(LIMITS_FILE, "r", encoding="utf-8") as f:
                for ln in f:
                    try:
                        rec = json.loads(ln)
                        records.append(rec)
                    except:
                        continue
        except Exception as e:
            st.error(f"Error leyendo archivo de auditoría: {e}")
            return

        if not records:
            st.info("Sin registros de violaciones.")
        else:
            st.dataframe(records, use_container_width=True)

    else:
        st.info("No se ha generado auditoría aún.")

