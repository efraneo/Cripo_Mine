# ui/sidebar.py
"""
Sidebar PRO
- Login usuario/contraseña
- 2FA por correo
- Validación de IP con aprobación por admin (token firmado)
- Selector DEMO / REAL
- Selector de activo
- Control Analizar / Cancelar
- Bloqueo automático de IPs sospechosas
"""

import os
import streamlit as st
import logging
from datetime import datetime
from backend.notifier_core import DEFAULT_NOTIFIER

# Core
from core.cache_utils import cached_get_symbols, cached_get_balance
from core.rerun_utils import safe_rerun

# Backend
from backend.user_manager import UserManager
from backend.session_manager import SessionManager
from backend.ip_manager import IPManager
from backend.ip_tokens import generate_ip_token
from backend.activity_logger import log_user_activity

# Seguridad
try:
    from backend import auth_utils
except Exception:
    auth_utils = None

try:
    from backend.mailer import send_mail
except Exception:
    send_mail = None

try:
    from backend.telegram_notifier import send_telegram_message as telegram_send
except Exception:
    telegram_send = None

# Logging
try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")
    if not app_log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(
            logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
        )
        app_log.addHandler(h)
    app_log.setLevel(logging.INFO)

# DB
DB_PATH = os.path.join("data", "usuarios.db")
user_m = UserManager(DB_PATH)
session_m = SessionManager(DB_PATH)
ip_m = IPManager(DB_PATH)


# ============================================================
# UI MODE
# ============================================================

def _get_ui_mode():
    return st.session_state.get("ui_mode", "LOGIN")

def _set_ui_mode(mode: str):
    st.session_state["ui_mode"] = mode


# ============================================================
# HELPERS
# ============================================================

def _get_user_email(username: str):
    try:
        u = user_m.get_user_by_username(username)
        return u.get("email") if u else None
    except Exception:
        return None


def _get_display_name(username: str) -> str:
    try:
        u = user_m.get_user_by_username(username)
        return (
            u.get("full_name")
            or u.get("name")
            or u.get("display_name")
            or username
        ) if u else username
    except Exception:
        return username


def _get_client_ip_safe() -> str:
    try:
        ctx = st.runtime.scriptrunner.get_script_run_ctx()
        if ctx and ctx.request and ctx.request.headers:
            return (
                ctx.request.headers.get("x-forwarded-for", "")
                .split(",")[0]
                .strip()
                or ctx.request.remote_ip
            )
    except Exception:
        pass
    return "0.0.0.0"


def notify_admin_ip_request(username: str, ip: str):
    try:
        token = generate_ip_token(username, ip)
        link = f"http://localhost:8501/?approve_ip={token}"
    except Exception:
        return

    try:
        ip_m.log(username, ip, "ip_not_allowed")
    except Exception:
        pass

    msg = (
        "🚨 ALERTA DE SEGURIDAD — EL BOT DE EFRA\n\n"
        f"👤 Usuario: {username}\n"
        f"🌐 IP detectada: {ip}\n"
        f"🕒 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC\n\n"
        "Acción requerida:\n"
        f"{link}"
    )

    if telegram_send:
        try:
            telegram_send(msg)
            return
        except Exception:
            pass

    admin_email = os.environ.get("ADMIN_EMAIL")
    if send_mail and admin_email:
        try:
            send_mail(
                to=admin_email,
                subject="🚨 Nueva IP detectada — El Bot de EFRA",
                body=msg
            )
        except Exception:
            pass

def _reset_analysis_state():
    keys_to_clear = [
        "analizando_activo",
        "analysis_ready",
        "ia_decision",
        "ia_symbol",
        "selected_asset"
    ]

    for k in keys_to_clear:
        if k in st.session_state:
            del st.session_state[k]

# ============================================================
# SIDEBAR PRINCIPAL
# ============================================================

def render_sidebar():

    # 🔥 IMPORTANTE: NO sobrescribimos engine si ya existe
    defaults = {
        "session_id": None,
        "pending_2fa_user": None,
        "selected_asset": None,
        "analizando_activo": False,
        "bot_mode": "DEMO",
        "ui_mode": "LOGIN",
    }
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)

    st.sidebar.title("🔐 Acceso — El Bot de EFRA")

    # ========================================================
    # REGISTER MODE
    # ========================================================
    if _get_ui_mode() == "REGISTER":
        st.sidebar.info("🆕 Registro de nuevo usuario")
        st.sidebar.caption("Completa el formulario en el panel central.")

        if st.sidebar.button("⬅ Volver al login"):
            _set_ui_mode("LOGIN")
            safe_rerun()

        return

    # ========================================================
    # USUARIO AUTENTICADO
    # ========================================================
    sid = st.session_state.get("session_id")

    if sid:
        sess = session_m.get_session(sid)

        if sess:
            username = sess.get("username")
            display_name = _get_display_name(username)

            st.sidebar.success(f"Conectado como: **{display_name}**")

            # ==================================================
            # 🔥 ENGINE GLOBAL ÚNICO
            # ==================================================
            engine = st.session_state.get("engine")

#            st.sidebar.write("TYPE:", type(engine))
#            st.sidebar.write("CLASS:", engine.__class__)
#            st.sidebar.write("HAS METHOD:", hasattr(engine, "get_ohlc_df_for_ui"))
#            st.sidebar.write("DIR:", dir(engine))

            # ==================================================
            # 🚨 PASO 4 — VALIDACIÓN CRÍTICA DEL ENGINE
            # ==================================================
            if not engine:
                st.sidebar.error("❌ Engine no inicializado")
                return
            if not (hasattr(engine, "get_ohlc_df_for_ui") or hasattr(engine, "get_klines_df")):
                st.sidebar.error("❌ Engine inválido (sin método de datos)")
                return
            # ==================================================

            # Balance
            try:
                bal = engine.get_balance("USDT")
#                st.sidebar.write("DEBUG BALANCE:", bal)
                if isinstance(bal, (int, float)):
                    st.sidebar.caption(f"💰 Balance Spot: {bal:,.2f} USDT")
            except Exception:
                pass

            # Modo
            st.sidebar.markdown("### Modo del Bot")
            st.session_state["bot_mode"] = st.sidebar.selectbox(
                "Selecciona modo",
                ["DEMO", "REAL"],
                index=0 if st.session_state["bot_mode"] == "DEMO" else 1,
                disabled=st.session_state["analizando_activo"]
            )

            # Activo
            st.sidebar.markdown("### Selección de activo")

            symbols = cached_get_symbols(engine)
            st.session_state["selected_asset"] = st.sidebar.selectbox(
                "Activo",
                symbols,
                disabled=st.session_state["analizando_activo"]
            )

            st.sidebar.markdown("---")

            # ==================================================
            # ANALIZAR
            # ==================================================
            if not st.session_state["analizando_activo"]:

                if st.sidebar.button("🔍 Analizar activo"):

                    symbol = st.session_state.get("selected_asset")

                    if not symbol:
                        st.sidebar.error("Activo no seleccionado")
                        return

                    try:
                        with st.spinner("Analizando mercado..."):

                            # ==========================================================
                            # ADAPTER OHLC (COMPATIBLE CON TU ENGINE REAL)
                            # ==========================================================
                            if hasattr(engine, "get_ohlc_df_for_ui"):
                                df_5m = engine.get_ohlc_df_for_ui(symbol, timeframe="5m", limit=200)

                            elif hasattr(engine, "get_klines_df"):
                                df_5m = engine.get_klines_df(symbol=symbol, interval="5m", limit=200)

                            else:
                                raise RuntimeError("Engine no soporta OHLC")

                            from core.ia_pro_orchestrator import compute_ia_pro_decision

                            ia = compute_ia_pro_decision(
                                symbol=symbol,
                                data_by_tf={"5m": {"df": df_5m}}
                            )

                            st.session_state["ia_decision"] = ia

                            user_data = user_m.get_user_by_username(username)

                            log_user_activity(
                                username=username,
                                role=user_data.get("role", "user"),
                                ip=_get_client_ip_safe(),
                                action="ANALYZE_ASSET",
                                symbol=symbol,
                                extra=f"Confidence={ia.get('confidence')}"
                            )

                            st.session_state["analysis_ready"] = True
                            try:

                                DEFAULT_NOTIFIER.send_alert(
                                    f"""
                            🧠 NUEVO ANÁLISIS

                            👤 Usuario: {username}
                            📊 Activo: {symbol}
                            🎯 Dirección: {ia.get('direction')}
                            🔥 Confianza: {ia.get('confidence'):.2f}%
                            """
                                )

                            except Exception:
                                pass

                            st.session_state["ia_symbol"] = symbol
                            st.session_state["analizando_activo"] = True

                        st.sidebar.success("Análisis completado")
                        safe_rerun()

                    except Exception:
                        app_log.exception("error analizando activo")
                        st.sidebar.error("Error en análisis")

            else:
                if st.sidebar.button("❌ Cancelar análisis"):
                    _reset_analysis_state()
                    st.sidebar.warning("Análisis cancelado")
                    safe_rerun()

            st.sidebar.markdown("---")

            if st.sidebar.button("Cerrar sesión"):
                session_m.delete_session(sid)
                st.session_state.clear()
                safe_rerun()

            return

    # ========================================================
    # 2FA
    # ========================================================
    pending = st.session_state.get("pending_2fa_user")

    if pending:
        st.sidebar.info(f"Usuario: **{_get_display_name(pending)}**")

        code = st.sidebar.text_input("Código 2FA", type="password")

        if st.sidebar.button("Verificar 2FA"):

            valid = False
            try:
                if auth_utils:
                    valid = auth_utils.validate_2fa_token(pending, code)
            except Exception:
                pass

            if not valid:
                st.sidebar.error("Código incorrecto o expirado.")
                return

            ip = _get_client_ip_safe()
            sid = session_m.create_session(pending, ip=ip)

            st.session_state["session_id"] = sid

            try:

                role = "ADMIN" if user.get("is_admin") else "USER"

                DEFAULT_NOTIFIER.send_system(
                    f"""
            🔐 LOGIN EXITOSO

            👤 Usuario: {login_user}
            🛡️ Rol: {role}
            🌐 IP: {ip}
            🕒 Hora: {datetime.utcnow()}
            """
                )

            except Exception:
                pass

            user_data = user_m.get_user_by_username(pending)

            log_user_activity(
                username=pending,
                role=user_data.get("role", "user"),
                ip=ip,
                action="LOGIN_2FA_SUCCESS",
                extra="Usuario autenticado correctamente"
            )

            st.session_state["pending_2fa_user"] = None
            safe_rerun()

        return

    # ========================================================
    # LOGIN
    # ========================================================
    st.sidebar.info("Introduce tus credenciales")

    login_user = st.sidebar.text_input("Usuario")
    login_pass = st.sidebar.text_input("Contraseña", type="password")

    if st.sidebar.button("Ingresar"):

        result = user_m.validate_user(login_user, login_pass)

        if not result.get("ok"):
            st.sidebar.error("Credenciales inválidas.")
            return

        user = result.get("user")
        ip = _get_client_ip_safe()

        # 🔥 VALIDACIÓN IP ANTES DE TODO
        if not user.get("is_admin"):

            if not ip_m.is_allowed(login_user, ip):

                notify_admin_ip_request(login_user, ip)

                st.sidebar.error(
                    "🔒 IP no autorizada.\n"
                    "Se ha notificado al administrador."
                )
                return

        # =========================
        # SI PASA → 2FA
        # =========================

        token = auth_utils.make_2fa_token(login_user) if auth_utils else None
        email = _get_user_email(login_user)

        sent = False

        if token and email and send_mail:
            r = send_mail(
                to=email,
                subject="El Bot de EFRA — Código de acceso",
                body=f"Tu código 2FA es: {token}"
            )
            sent = bool(isinstance(r, dict) and r.get("ok"))

        if not sent and token:
            st.sidebar.warning("No se pudo enviar correo. Token mostrado (DEV).")
            st.sidebar.info(f"Código: {token}")

        st.session_state["pending_2fa_user"] = login_user
        safe_rerun()
        st.stop()

    st.sidebar.markdown("---")

    if st.sidebar.button("🆕 Registrarse"):
        _set_ui_mode("REGISTER")
        safe_rerun()
