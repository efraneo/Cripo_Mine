from pptx import Presentation
from pptx.util import Inches, Pt
import requests

# Crear presentación
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

def add_slide(prs, layout_index, title, content, img_url):
    slide_layout = prs.slide_layouts[layout_index]
    slide = prs.slides.add_slide(slide_layout)
    
    # Título
    title_shape = slide.shapes.title
    title_shape.text = title
    
    # Contenido
    body_shape = slide.placeholders[1]
    body_shape.text = content
    
    # Descargar e insertar imagen
    try:
        response = requests.get(img_url, stream=True)
        if response.status_code == 200:
            img_path = "temp_img.jpg"
            with open(img_path, 'wb') as f:
                for chunk in response.iter_content(1024):
                    f.write(chunk)
            slide.shapes.add_picture(img_path, Inches(8.5), Inches(1.5), width=Inches(4.5))
    except Exception as e:
        print(f"Error con la imagen: {e}")

# Datos de las diapositivas
slides_data = [
    {
        "title": "Will Robots Replace Humans?",
        "content": "The Future of Artificial Intelligence and Automation\n\nPresented by: [Your Name]\nSubject: English Class",
        "img": "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=800"
    },
    {
        "title": "A Question of the Future",
        "content": "• Technology is advancing faster than ever.\n• Artificial Intelligence (AI) is part of our daily lives.\n• The big question: Threat or Evolution?\n• Not just science fiction anymore; it is our reality.",
        "img": "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800"
    },
    {
        "title": "What are robots?",
        "content": "• Definition: Programmable machines performing complex tasks.\n• Physical Robots: Industrial arms, medical assistants.\n• Software Robots (AI): Algorithms, chatbots.\n• Key difference: They don't have feelings or consciousness.",
        "img": "https://images.unsplash.com/photo-1561557944-6e7860d1a7eb?w=800"
    },
    {
        "title": "Advantages and Disadvantages",
        "content": "✅ Advantages:\n• High efficiency and speed.\n• Perfect precision (fewer mistakes).\n• Can do dangerous jobs.\n\n❌ Disadvantages:\n• Job displacement.\n• Lack of emotional intelligence.",
        "img": "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800"
    },
    {
        "title": "The Future vs. Today",
        "content": "• Today: Robots are tools. They do repetitive tasks.\n• The Future: 'Cobots' (Collaborative robots).\n• AI will help doctors diagnose diseases.\n• The Shift: The goal is not replacement, but Augmentation.",
        "img": "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800"
    },
    {
        "title": "To Conclude...",
        "content": "• Robots will replace tasks, not necessarily humans.\n• Human qualities (creativity, empathy) are irreplaceable.\n• The future belongs to humans and machines working together.\n\nThank you for your attention!\nAny questions?",
        "img": "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=800"
    }
]

# Generar diapositivas
for data in slides_data:
    add_slide(prs, 1, data["title"], data["content"], data["img"])

# Guardar
prs.save('Will_Robots_Replace_Humans.pptx')
print("¡Presentación creada con éxito!")