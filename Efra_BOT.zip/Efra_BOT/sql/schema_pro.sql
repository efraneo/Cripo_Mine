-- schema_pro.sql
PRAGMA foreign_keys = ON;

BEGIN;

/*
 Core users table
*/
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT,
    is_admin INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1,
    created_at TEXT,
    password_hash TEXT,
    api_key_enc TEXT,
    api_secret_enc TEXT,
    must_reset INTEGER DEFAULT 0
);

-- investments
CREATE TABLE IF NOT EXISTS investments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    symbol TEXT,
    amount REAL,
    mode TEXT,
    ts TEXT
);

-- IP allowlist and logs
CREATE TABLE IF NOT EXISTS allowed_ips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    ip TEXT,
    approved_at TEXT
);

CREATE TABLE IF NOT EXISTS ip_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    ip TEXT,
    event TEXT,
    ts TEXT
);

-- login failed attempts & lockouts
CREATE TABLE IF NOT EXISTS failed_logins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT,
    ip TEXT,
    ts TEXT
);

CREATE TABLE IF NOT EXISTS lockouts (
    username TEXT PRIMARY KEY,
    until_ts INTEGER
);

-- sessions
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    username TEXT,
    created_at INTEGER,
    last_touch INTEGER,
    expires_at INTEGER
);

-- 2FA tokens
CREATE TABLE IF NOT EXISTS twofa_tokens (
    username TEXT,
    token TEXT,
    expires_at INTEGER,
    created_at INTEGER
);

-- reset tokens
CREATE TABLE IF NOT EXISTS reset_tokens (
    username TEXT,
    token TEXT,
    expires_at INTEGER,
    created_at INTEGER
);

COMMIT;
