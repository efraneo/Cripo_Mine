import sqlite3
import os

DB = os.path.join("data", "usuarios.db")

conn = sqlite3.connect(DB)
c = conn.cursor()

print("Eliminando tabla sessions si existe...")
c.execute("DROP TABLE IF EXISTS sessions")
conn.commit()

print("Listo. La tabla 'sessions' fue eliminada.")
