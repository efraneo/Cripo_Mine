# el_bot_de_efra.py
# Entrypoint institucional PRO seguro

import logging
import streamlit as st

# ============================================================
# CARGAR VARIABLES .ENV
# ============================================================
try:
    from core.env_loader import load_all_envs
    load_all_envs()
except Exception as e:
    print("Error cargando .env:", e)

from backend.telegram_notifier import register_telegram_notifier
from backend.notifier_core import DEFAULT_NOTIFIER
import os

if "telegram" not in DEFAULT_NOTIFIER.channels:
    register_telegram_notifier(os.environ)


# ============================================================
# LOGGING
# ============================================================

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")

    if not app_log.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
        )
        handler.setFormatter(formatter)
        app_log.addHandler(handler)
    app_log.setLevel(logging.INFO)

# ============================================================
# VALIDACIÓN TOKEN IP
# ============================================================

try:
    from backend.ip_tokens import validate_ip_token
    from backend.user_manager import UserManager

    params = st.query_params

    if "approve_ip" in params:
        res = validate_ip_token(params["approve_ip"])

        if res:
            username, ip = res
            um = UserManager("data/usuarios.db")
            um.approve_ip(username, ip)
            st.success(f"IP {ip} aprobada para {username}")
        else:
            st.error("Token inválido o expirado")
except Exception:
    app_log.warning("Error procesando token IP", exc_info=True)

# ============================================================
# IMPORTAR UI
# ============================================================

try:
    from ui import sidebar
    from ui.tabs_main import render_tabs
    from ui.register_view import render_register_view

except Exception:
    app_log.exception("Error importando UI")
    raise

# ============================================================
# ENGINE INITIALIZER
# ============================================================

def initialize_trading_engine():
    if "engine" in st.session_state:
        return st.session_state["engine"]

    try:
        from core.engine_factory import build_trading_engine

        engine = build_trading_engine()
        st.session_state["engine"] = engine

        app_log.info("TradingEngine inicializado correctamente (backend)")

        return engine

    except Exception:
        app_log.exception("Error inicializando TradingEngine")
        st.session_state["engine"] = None
        return None
# ============================================================
# MAIN
# ============================================================

def main():
    st.set_page_config(
        page_title="El BOT de EFRA",
        layout="wide",
        page_icon="⚡"
    )

    try:

        # ✅ ENGINE PRIMERO (CRÍTICO)
        engine = initialize_trading_engine()

        if engine is None:
            st.error("Trading Engine no disponible")
            return

        # ✅ Sidebar ahora sí tiene engine
        sidebar.render_sidebar()

        # =========================================
        # SESSION CONTROL
        # =========================================
        if st.session_state.get("session_id"):
            ctx = {
                "engine": engine,
                "session_id": st.session_state.get("session_id"),
                "user": st.session_state.get("user"),
                "role": st.session_state.get("role"),
            }
            render_tabs(ctx)
        else:
            st.info("🔐 Inicia sesión para acceder al panel.")

        # =========================================
        # VIEW CONTROL
        # =========================================

        mode = st.session_state.get("ui_mode", "LOGIN")

        if mode == "REGISTER":
            render_register_view()
    except Exception:
        app_log.exception("Error fatal en aplicación")
        st.error("Error crítico en aplicación")

# ============================================================
# ENTRYPOINT
# ============================================================

if __name__ == "__main__":
    main()