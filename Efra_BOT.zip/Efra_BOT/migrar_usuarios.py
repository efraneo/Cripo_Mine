import sqlite3
import pandas as pd
from backend.user_manager import hash_password

DB = "data/usuarios.db"
CSV = "data/claves.csv"

conn = sqlite3.connect(DB)
cur = conn.cursor()

# Asegurar columnas nuevas
cur.execute("ALTER TABLE users ADD COLUMN password_hash TEXT") if "password_hash" not in [c[1] for c in cur.execute("PRAGMA table_info(users)") ] else None
cur.execute("ALTER TABLE users ADD COLUMN ip TEXT") if "ip" not in [c[1] for c in cur.execute("PRAGMA table_info(users)") ] else None

conn.commit()

df = pd.read_csv(CSV)

for _, row in df.iterrows():
    username = str(row["usuario"]).strip()
    password_plain = str(row["clave"]).strip()
    email = str(row["correo"]).strip()
    is_admin = 1 if str(row["es_admin"]).strip().lower() == "true" else 0
    estado = str(row["estado"]).strip().lower()

    enabled = 1 if estado == "activo" else 0

    hashed = hash_password(password_plain)

    cur.execute("""
        INSERT OR REPLACE INTO users (id, username, email, is_admin, enabled, created_at, password_hash, ip)
        VALUES (
            (SELECT id FROM users WHERE username=?),
            ?, ?, ?, ?, datetime('now'), ?, ''
        )
    """, (username, username, email, is_admin, enabled, hashed))

    print(f"Usuario migrado: {username} → hash generado")

conn.commit()
conn.close()

print("\n✔ Migración completada")
print("Ahora puedes iniciar sesión con tus mismas contraseñas anteriores.")
