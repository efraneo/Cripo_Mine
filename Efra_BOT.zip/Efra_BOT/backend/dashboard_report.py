# backend/dashboard_report.py
"""
Dashboard / Report generator (HTML) para resultados de backtest/walk-forward.

Genera:
 - Gráficas (equity curve, histograma de probabilidades, prob vs label scatter)
 - Tabla resumen (accuracy, precision@thr, coverage, trades, max_drawdown)
 - HTML auto-contenido con imágenes embebidas (PNG)

Uso:
    from backend.dashboard_report import generate_dashboard
    generate_dashboard(results_list, output_html="reports/wf_report.html", threshold=0.80)

Parámetros:
 - results_list: lista retornada por run_walkforward (cada elemento contiene 'df_result' y métricas)
 - output_html: ruta del archivo de salida
 - threshold: umbral de probabilidad usado en el reporte
Requisitos:
    pip install matplotlib pandas numpy jinja2
"""
from __future__ import annotations
import os
import io
import base64
import math
from typing import List, Dict, Any

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from jinja2 import Template

# -----------------------------
# Helpers para convertir matplotlib -> base64 png
# -----------------------------
def _fig_to_base64(fig) -> str:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=120)
    buf.seek(0)
    data = base64.b64encode(buf.read()).decode("ascii")
    plt.close(fig)
    return f"data:image/png;base64,{data}"


# -----------------------------
# Crear gráficos principales
# -----------------------------
def _plot_equity(df: pd.DataFrame, title: str = "Equity Curve"):
    fig, ax = plt.subplots(figsize=(8, 3.5))
    if "equity" in df.columns:
        ax.plot(df["equity"].values, label="Equity")
    else:
        ax.plot(np.cumsum(df.get("returns", np.zeros(len(df)))), label="Equity")
    ax.set_title(title)
    ax.set_xlabel("Index")
    ax.set_ylabel("Equity")
    ax.grid(True)
    ax.legend()
    return _fig_to_base64(fig)


def _plot_prob_hist(df: pd.DataFrame, title: str = "Probabilities Histogram"):
    fig, ax = plt.subplots(figsize=(6, 3))
    if "prob" in df.columns:
        ax.hist(df["prob"].dropna(), bins=30)
    ax.set_title(title)
    ax.set_xlabel("Prob")
    ax.set_ylabel("Count")
    ax.grid(True)
    return _fig_to_base64(fig)


def _plot_prob_vs_label(df: pd.DataFrame, title: str = "Prob vs Label"):
    fig, ax = plt.subplots(figsize=(6, 3))
    if "prob" in df.columns and "label" in df.columns:
        jitter = (np.random.rand(len(df)) - 0.5) * 0.02
        ax.scatter(df["prob"] + jitter, df["label"], alpha=0.6, s=8)
    ax.set_title(title)
    ax.set_xlabel("Prob")
    ax.set_ylabel("Label (0/1)")
    ax.grid(True)
    return _fig_to_base64(fig)


# -----------------------------
# HTML template (simple and self-contained)
# -----------------------------
_HTML_TEMPLATE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Walk-Forward Report</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 18px; background: #f6f7fb; color: #222; }
    .card { background: #fff; border-radius: 8px; padding: 14px; margin-bottom: 12px; box-shadow: 0 1px 6px rgba(0,0,0,0.06); }
    h1 { margin-top: 4px; }
    .row { display:flex; gap:12px; flex-wrap: wrap; }
    .col { flex:1; min-width:260px; }
    table { border-collapse: collapse; width: 100%; }
    th, td { text-align:left; padding:8px; border-bottom: 1px solid #eee; }
    .small { font-size: 0.85em; color:#666; }
  </style>
</head>
<body>
  <h1>Walk-Forward Report</h1>
  <p class="small">Threshold = {{ threshold }}</p>

  <div class="card">
    <h3>Summary (aggregated)</h3>
    <table>
      <tr><th>Windows</th><td>{{ n_windows }}</td></tr>
      <tr><th>Avg precision@thr</th><td>{{ avg_prec_thr|round(4) }}</td></tr>
      <tr><th>Avg coverage</th><td>{{ avg_cov|round(4) }}</td></tr>
      <tr><th>Avg trades/window</th><td>{{ avg_trades|round(2) }}</td></tr>
    </table>
  </div>

  {% for item in items %}
  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <h3>Window {{ loop.index }}: test {{ item.test_start }} - {{ item.test_end }}</h3>
        <p class="small">accuracy={{ item.accuracy|round(4) }} precision@thr={{ item.precision_at_thr|round(4) }} coverage={{ item.coverage|round(4) }} trades={{ item.trades }}</p>
      </div>
      <div style="width:360px">
        <img src="{{ item.eq_img }}" style="width:100%; border-radius:6px; border:1px solid #ddd;">
      </div>
    </div>

    <div class="row" style="margin-top:10px;">
      <div class="col">
        <h4>Prob histogram</h4>
        <img src="{{ item.hist_img }}" style="width:100%; border-radius:6px; border:1px solid #ddd;">
      </div>
      <div class="col">
        <h4>Prob vs Label</h4>
        <img src="{{ item.scatter_img }}" style="width:100%; border-radius:6px; border:1px solid #ddd;">
      </div>
    </div>

    <h4 style="margin-top:10px">Metrics</h4>
    <table>
      <tr><th>Accuracy</th><td>{{ item.accuracy }}</td></tr>
      <tr><th>Precision (all)</th><td>{{ item.precision_all }}</td></tr>
      <tr><th>Precision @ thr</th><td>{{ item.precision_at_thr }}</td></tr>
      <tr><th>Recall</th><td>{{ item.recall }}</td></tr>
      <tr><th>F1</th><td>{{ item.f1 }}</td></tr>
      <tr><th>Coverage</th><td>{{ item.coverage }}</td></tr>
      <tr><th>Equity final</th><td>{{ item.equity_final }}</td></tr>
      <tr><th>Max drawdown</th><td>{{ item.max_drawdown }}</td></tr>
    </table>

  </div>
  {% endfor %}

  <div style="height:40px"></div>
  <footer class="small">Generated by dashboard_report.py</footer>
</body>
</html>
"""


# -----------------------------
# Main entry
# -----------------------------
def generate_dashboard(results_list: List[Dict[str, Any]],
                       output_html: str = "reports/wf_report.html",
                       threshold: float = 0.80):
    """
    results_list: lista de dicts (cada dict como el output de run_walkforward)
    Cada elemento debería tener keys: 'df_result', 'precision_at_threshold', 'coverage', 'total_trades', 'max_drawdown', 'accuracy', 'precision_all', 'recall', 'f1', 'equity_final'
    """
    os.makedirs(os.path.dirname(output_html) or ".", exist_ok=True)

    items = []
    precs = []
    covs = []
    trades = []

    for res in results_list:
        df = res.get("df_result")
        if df is None or df.empty:
            continue

        eq_img = _plot_equity(df, title="Equity")
        hist_img = _plot_prob_hist(df, title="Probabilities")
        scatter_img = _plot_prob_vs_label(df, title="Prob vs Label")

        item = {
            "test_start": res["test_range"][0],
            "test_end": res["test_range"][1],
            "accuracy": res.get("accuracy", 0),
            "precision_all": res.get("precision_all", 0),
            "precision_at_thr": res.get("precision_at_threshold", float("nan")),
            "recall": res.get("recall", 0),
            "f1": res.get("f1", 0),
            "coverage": res.get("coverage", 0),
            "trades": res.get("total_trades", 0),
            "equity_final": res.get("equity_final", 0),
            "max_drawdown": res.get("max_drawdown", 0),
            "eq_img": eq_img,
            "hist_img": hist_img,
            "scatter_img": scatter_img
        }
        items.append(item)
        if not math.isnan(item["precision_at_thr"]):
            precs.append(item["precision_at_thr"])
        covs.append(item["coverage"])
        trades.append(item["trades"])

    summary = {
        "n_windows": len(items),
        "avg_prec_thr": float(np.nanmean(precs)) if len(precs) > 0 else float("nan"),
        "avg_cov": float(np.mean(covs)) if len(covs) > 0 else 0.0,
        "avg_trades": float(np.mean(trades)) if len(trades) > 0 else 0.0
    }

    tpl = Template(_HTML_TEMPLATE)
    html = tpl.render(items=items, threshold=threshold, **summary)

    with open(output_html, "w", encoding="utf-8") as fh:
        fh.write(html)

    print(f"[REPORT] Report saved to {output_html}")
