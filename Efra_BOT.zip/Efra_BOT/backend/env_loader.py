# ============================================================
# backend/env_loader.py — Wrapper oficial hacia core.env_loader
# ============================================================

from core.env_loader import load_all_envs

# Alias de compatibilidad
def load_env():
    """
    Compatibilidad legacy.
    """
    load_all_envs()
    return __import__("os").environ
