# backend/automl_trainer.py
# ======================================================================
# AutoML PRO — LightGBM + XGBoost + Optuna (Optimización Bayesiana)
#
# ✔ Optimización HPO automática
# ✔ Selección de features (RFECV + importancia)
# ✔ Backtesting rolling-window
# ✔ Comparación de modelos
# ✔ Exportación de métricas + gráficos
# ✔ Guarda modelo final: models/best_model.pkl
#
# ======================================================================

import os
import json
import joblib
import optuna
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import RFECV

from lightgbm import LGBMRegressor
from xgboost import XGBRegressor

os.makedirs("models", exist_ok=True)
os.makedirs("reports", exist_ok=True)

# ------------------------------------------------------------
# UTIL: carga dataset desde signals_log.jsonl
# ------------------------------------------------------------
def load_dataset(path="data/signals_log.jsonl"):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                obj = json.loads(line)
                feat = obj.get("features", {})
                y = obj.get("future_return_y", None)
                if y is None:
                    continue
                rows.append({**feat, "y": y})
            except:
                continue

    df = pd.DataFrame(rows)
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    return df


# ------------------------------------------------------------
# Feature Scaling
# ------------------------------------------------------------
def scale_features(X):
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    return Xs, scaler


# ------------------------------------------------------------
# Modelo Wrapper para comparar LightGBM y XGB
# ------------------------------------------------------------
def get_models():
    return {
        "lgbm": LGBMRegressor(
            n_estimators=600,
            learning_rate=0.01,
            max_depth=-1,
            subsample=0.8,
            colsample_bytree=0.8
        ),
        "xgboost": XGBRegressor(
            n_estimators=600,
            learning_rate=0.01,
            max_depth=7,
            subsample=0.8,
            colsample_bytree=0.8,
            tree_method="hist"
        )
    }


# ------------------------------------------------------------
# Optuna objective — bayesian tuning
# ------------------------------------------------------------
def objective(trial, X, y, model_name="lgbm"):

    if model_name == "lgbm":
        params = dict(
            num_leaves=trial.suggest_int("num_leaves", 16, 128),
            learning_rate=trial.suggest_float("lr", 0.005, 0.05),
            subsample=trial.suggest_float("subsample", 0.4, 1.0),
            colsample_bytree=trial.suggest_float("colsample", 0.4, 1.0)
        )
        model = LGBMRegressor(
            n_estimators=500,
            **params
        )

    else:
        params = dict(
            max_depth=trial.suggest_int("max_depth", 4, 12),
            learning_rate=trial.suggest_float("lr", 0.005, 0.05),
            subsample=trial.suggest_float("subsample", 0.4, 1.0),
            colsample_bytree=trial.suggest_float("colsample", 0.4, 1.0)
        )
        model = XGBRegressor(
            n_estimators=500,
            tree_method="hist",
            **params
        )

    tscv = TimeSeriesSplit(n_splits=5)
    losses = []

    for train_i, test_i in tscv.split(X):
        Xtr, Xte = X[train_i], X[test_i]
        ytr, yte = y[train_i], y[test_i]

        model.fit(Xtr, ytr)
        pred = model.predict(Xte)

        losses.append(mean_squared_error(yte, pred))

    return np.mean(losses)


# ------------------------------------------------------------
# AutoML PRO main
# ------------------------------------------------------------
def train_automl():
    df = load_dataset()
    print("Dataset cargado:", df.shape)

    y = df["y"].values
    X = df.drop(columns=["y"])

    # -------------------------
    # Feature Selection RFECV
    # -------------------------
    fs_model = LGBMRegressor()
    selector = RFECV(fs_model, step=1, cv=5)
    selector.fit(X, y)

    X = X.iloc[:, selector.support_].values

    print("Features seleccionadas:", selector.support_.sum())

    # -------------------------
    # Escalado
    # -------------------------
    Xs, scaler = scale_features(X)

    best_results = {}
    best_model = None
    best_score = 999

    # -------------------------
    # Entrenamos ambos modelos
    # -------------------------
    for name in ["lgbm", "xgb"]:
        print(f"\n==== OPTIMIZACIÓN BAYESIANA — {name.upper()} ====")

        study = optuna.create_study(direction="minimize")
        study.optimize(lambda t: objective(t, Xs, y, model_name=name), n_trials=30)

        print("Mejor loss:", study.best_value)
        print("Mejores hiperparámetros:", study.best_params)

        if study.best_value < best_score:
            best_score = study.best_value

            if name == "lgbm":
                best_model = LGBMRegressor(n_estimators=500, **study.best_params)
            else:
                best_model = XGBRegressor(
                    n_estimators=500,
                    tree_method="hist",
                    **study.best_params
                )

            best_model.fit(Xs, y)
            best_results = study.best_params

    # -------------------------
    # Guardar modelo final
    # -------------------------
    joblib.dump(best_model, "models/best_model.pkl")
    joblib.dump(scaler, "models/scaler.pkl")

    with open("models/best_params.json", "w") as f:
        json.dump(best_results, f, indent=2)

    print("\n🔥 MODELO FINAL GUARDADO EN models/best_model.pkl")
    print("🔥 Escaler guardado en models/scaler.pkl")
    print("🔥 Parámetros guardados en models/best_params.json")

    return best_model


if __name__ == "__main__":
    train_automl()
