# monitor_integrity.py
"""
Monitors critical files for integrity using HMAC (HMAC_INTEGRITY_KEY).
If file content hash changes unexpectedly, sends Telegram alert.

Usage:
 - Call IntegrityMonitor.scan_and_alert() at app startup and periodically (e.g. background thread).
"""
from __future__ import annotations
import os
import hmac
import hashlib
import time
from typing import List
from notifier_telegram import send_alert
from logger_conf import get_logger

logger = get_logger("monitor_integrity")

HMAC_KEY = os.getenv("HMAC_INTEGRITY_KEY")  # must be set
CRITICAL_FILES = [
    "el_bot_de_Efra.py",
    "backend/trading_engine.py",
    "backend/binance_client.py",
    # add more relative paths as needed
]

class IntegrityMonitor:
    def __init__(self, base_path: str = "."):
        self.base = base_path
        if not HMAC_KEY:
            logger.warning("HMAC_INTEGRITY_KEY not set; integrity checks disabled.")
        self._cache = {}

    def _hmac(self, content: bytes) -> str:
        if not HMAC_KEY:
            return ""
        return hmac.new(HMAC_KEY.encode(), content, hashlib.sha256).hexdigest()

    def scan_and_alert(self) -> None:
        for rel in CRITICAL_FILES:
            path = os.path.join(self.base, rel)
            try:
                with open(path, "rb") as fh:
                    c = fh.read()
                sig = self._hmac(c)
                prev = self._cache.get(rel)
                if prev is None:
                    # store initial signature
                    self._cache[rel] = sig
                    logger.debug("Stored initial integrity for %s", rel)
                else:
                    if sig != prev:
                        msg = f"*ALERT*: integrity change detected for `{rel}` at {time.strftime('%Y-%m-%d %H:%M:%S')}"
                        logger.critical(msg)
                        send_alert(msg)
                        # update cache to avoid repeat alerts (optionally could keep alerting)
                        self._cache[rel] = sig
            except FileNotFoundError:
                logger.warning("IntegrityMonitor: file not found %s", path)
            except Exception as e:
                logger.exception("IntegrityMonitor scanning error for %s: %s", rel, e)
