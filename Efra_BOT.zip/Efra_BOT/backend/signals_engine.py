# backend/signals_engine.py
"""
SignalsEngine — Integración MonitorWS + TradingEngine + AntiHack + Alerts (PRO)

Guarda señales en:
 - data/signals_log.jsonl
 - data/executions_log.jsonl
Además intenta usar AuditManager (SQLite) si existe.
Diseñado para ser controlado por Streamlit UI (el_bot_de_efra.py).
"""
from __future__ import annotations
import time
import threading
import traceback
import json
import os
from typing import Dict, Any, Optional, Callable, List

import pandas as pd
import numpy as np

from backend.log_manager import get_logger
log = get_logger("signals")

# optional components
try:
    from backend.trading_engine import get_engine_singleton
except Exception:
    get_engine_singleton = None

try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

try:
    from backend.monitor_ws import BinanceKlineMonitor
except Exception:
    BinanceKlineMonitor = None

# Audit manager (optional) for DB writes
try:
    from backend.audit_manager import AuditManager
except Exception:
    AuditManager = None

# feature builder (optional) to compute expanded realtime features
try:
    from utils.feature_builder_pro import build_feature_set as build_feature_set_from_df
except Exception:
    build_feature_set_from_df = None

# Files
os.makedirs("data", exist_ok=True)
SIGNALS_JSONL = os.path.join("data", "signals_log.jsonl")
EXEC_JSONL = os.path.join("data", "executions_log.jsonl")

# Defaults
DEFAULT_IA_THRESHOLD = float(os.environ.get("MIN_CONFIDENCE", 0.8))
DEFAULT_ATR_ALERT = 0.015
DEFAULT_SPREAD_ALERT = 0.01
BURST_WINDOW_SECONDS = 30
BURST_COUNT_THRESHOLD = 6
MIN_VOLUME_ALERT = 0.0

def _safe_float(x, default=0.0):
    try:
        return float(x)
    except:
        return default

def _rel_spread(row: Dict[str, Any]) -> float:
    c = _safe_float(row.get("close", 0.0))
    h = _safe_float(row.get("high", 0.0))
    l = _safe_float(row.get("low", 0.0))
    if c == 0:
        return 0.0
    return (h - l) / c

def _append_jsonl(path: str, obj: Dict[str, Any]):
    try:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except Exception as e:
        log.exception("Failed append jsonl %s: %s", path, e)

class SignalsEngine:
    def __init__(
        self,
        symbols: List[str],
        interval: str = "1m",
        mode: str = "SIMULATE",
        ia_threshold: float = DEFAULT_IA_THRESHOLD,
        atr_alert_threshold: float = DEFAULT_ATR_ALERT,
        spread_alert_threshold: float = DEFAULT_SPREAD_ALERT,
        burst_seconds: int = BURST_WINDOW_SECONDS,
        burst_count: int = BURST_COUNT_THRESHOLD,
        min_volume: float = MIN_VOLUME_ALERT
    ):
        self.symbols = [s.upper() for s in symbols]
        self.interval = interval
        self.mode = mode.upper()
        self.ia_threshold = float(ia_threshold)
        self.atr_alert_threshold = float(atr_alert_threshold)
        self.spread_alert_threshold = float(spread_alert_threshold)
        self.burst_seconds = int(burst_seconds)
        self.burst_count = int(burst_count)
        self.min_volume = float(min_volume)

        # Monitor WS
        self.monitor = BinanceKlineMonitor() if BinanceKlineMonitor is not None else None

        # Engine singleton (call properly)
        try:
            self.engine = get_engine_singleton() if callable(get_engine_singleton) else (get_engine_singleton if get_engine_singleton is not None else None)
        except Exception:
            self.engine = None

        self.audit = AuditManager() if AuditManager is not None else None

        self._burst_buf: Dict[str, List[float]] = {s: [] for s in self.symbols}
        self._started = False
        self._lock = threading.Lock()

        log.info("SignalsEngine init symbols=%s interval=%s mode=%s", self.symbols, self.interval, self.mode)

    # -------------------------
    # Start / stop
    # -------------------------
    def start(self):
        with self._lock:
            if self._started:
                log.info("SignalsEngine already started")
                return
            for s in self.symbols:
                cb = self._make_callback_for_symbol(s)
                if self.monitor:
                    self.monitor.start_listening(s, self.interval, cb)
                    log.info("Attached to monitor for %s", s)
                else:
                    log.error("No monitor available; cannot start listening for %s", s)
            self._started = True
            log.info("SignalsEngine started")

    def stop(self):
        with self._lock:
            if not self._started:
                return
            if self.monitor:
                for s in self.symbols:
                    self.monitor.stop_listening(s, self.interval)
            self._started = False
            log.info("SignalsEngine stopped")

    # -------------------------
    # Callback factory
    # -------------------------
    def _make_callback_for_symbol(self, symbol: str) -> Callable[[Dict[str, Any], Dict[str, Any]], None]:
        def _on_kline_close(row: Dict[str, Any], raw_msg: Dict[str, Any]):
            try:
                volume = _safe_float(row.get("volume", 0.0))
                if self.min_volume > 0 and volume < self.min_volume:
                    log.debug("Ignored by min_volume: %s %s < %s", symbol, volume, self.min_volume)
                    return

                if self._detect_anti_hack(symbol, row):
                    return

                # Build df: prefer to request fuller history if engine provides it
                df = pd.DataFrame([{
                    "open": row["open"],
                    "high": row["high"],
                    "low": row["low"],
                    "close": row["close"],
                    "volume": row["volume"],
                }])
                if self.engine and hasattr(self.engine, "get_klines_df"):
                    try:
                        df_full = self.engine.get_klines_df(symbol, interval=self.interval, limit=200)
                        if df_full is not None and len(df_full) > 3:
                            df = df_full
                    except Exception:
                        log.debug("Could not fetch full klines; using single-row df")

                indicadores = {}
                if self.engine and hasattr(self.engine, "calcular_indicadores"):
                    try:
                        indicadores = self.engine.calcular_indicadores(df)
                    except Exception:
                        log.debug("calcular_indicadores failed")

                atr = indicadores.get("atr") or 0.0
                entry = _safe_float(row.get("close", 0.0))
                atr_rel = (atr / entry) if entry and atr else 0.0

                # features: prefer engine.preparar_features, else build from df using feature builder if available
                features = {}
                try:
                    if self.engine and hasattr(self.engine, "preparar_features"):
                        features = self.engine.preparar_features(df.iloc[-1], indicadores)
                    else:
                        # try to expand using the full feature builder
                        if build_feature_set_from_df is not None and isinstance(df, pd.DataFrame):
                            full = build_feature_set_from_df(df)
                            if not full.empty:
                                features = full.iloc[-1].to_dict()
                            else:
                                features = {
                                    "open": row.get("open"),
                                    "high": row.get("high"),
                                    "low": row.get("low"),
                                    "close": row.get("close"),
                                    "volume": row.get("volume")
                                }
                        else:
                            features = {
                                "open": row.get("open"),
                                "high": row.get("high"),
                                "low": row.get("low"),
                                "close": row.get("close"),
                                "volume": row.get("volume")
                            }
                except Exception:
                    features = {
                        "open": row.get("open"),
                        "high": row.get("high"),
                        "low": row.get("low"),
                        "close": row.get("close"),
                        "volume": row.get("volume")
                    }

                prob = 0.5
                try:
                    if self.engine and hasattr(self.engine, "predict_confidence"):
                        prob = float(self.engine.predict_confidence(features))
                except Exception:
                    prob = 0.5

                # burst buffer
                now_ts = time.time()
                buf = self._burst_buf.setdefault(symbol, [])
                buf.append(now_ts)
                cutoff = now_ts - self.burst_seconds
                while buf and buf[0] < cutoff:
                    buf.pop(0)

                # evaluate rules
                actions = []
                if atr_rel >= self.atr_alert_threshold:
                    actions.append(("ATR_ALERT", f"ATR_rel={atr_rel:.4f}"))
                if _rel_spread(row) >= self.spread_alert_threshold:
                    actions.append(("SPREAD_ALERT", f"rel_spread={_rel_spread(row):.4f}"))
                if len(buf) >= self.burst_count:
                    actions.append(("BURST_ALERT", f"{len(buf)} burns within {self.burst_seconds}s"))

                ia_action = None
                if prob >= self.ia_threshold:
                    ia_action = ("IA_BUY", f"prob={prob:.3f}")
                    actions.append(ia_action)
                elif prob <= (1.0 - self.ia_threshold):
                    ia_action = ("IA_SELL", f"prob={prob:.3f}")
                    actions.append(ia_action)

                # payload
                payload = {
                    "ts": time.time(),
                    "symbol": symbol,
                    "interval": self.interval,
                    "close": entry,
                    "atr": atr,
                    "atr_rel": atr_rel,
                    "prob": prob,
                    "actions": actions,
                    "features": features
                }

                # persist to JSONL
                try:
                    _append_jsonl(SIGNALS_JSONL, payload)
                except Exception:
                    log.exception("Could not append signals jsonl")

                # persist to audit DB if available
                if self.audit:
                    try:
                        self.audit.log_signal({**payload, "meta": {"via": "signals_engine", "mode": self.mode}})
                    except Exception:
                        log.exception("AuditManager.log_signal failed")

                # send alerts
                if actions:
                    lines = [
                        f"SignalsEngine — {symbol} @ {self.interval}",
                        f"Price: {entry:.8f} • IA: {prob:.3f} • ATR_rel: {atr_rel:.4f}"
                    ]
                    for a, m in actions:
                        lines.append(f"- {a}: {m}")
                    text = "\n".join(lines)
                    log.info(text)
                    if telegram_send:
                        try:
                            telegram_send(text)
                        except Exception:
                            log.debug("telegram send failed")

                # -----------------------------------------------------
                #               EJECUCIÓN AUTOMÁTICA (AUTO_EXEC)
                # -----------------------------------------------------
                if ia_action and self.mode == "AUTO_EXEC":
                    fake_user = {"usuario": "signals_engine_auto", "correo": "auto@local"}
                    side = "BUY" if ia_action[0] == "IA_BUY" else "SELL"
                    amount_usd = float(10.0)
                    try:
                        from utils.execution_queue import enqueue_order
                        try:
                            enqueue_order({
                                "usuario": fake_user,
                                "symbol": symbol,
                                "side": side,
                                "amount_usdt": amount_usd,
                                "steps": 1,
                                "source": "signals_engine",
                                "ts": time.time()
                            })
                            log.info("Order enqueued for %s %s (amount=%s)", symbol, side, amount_usd)
                        except Exception:
                            # fallback to direct execution if queue not present
                            if self.engine and hasattr(self.engine, "ejecutar_compound_order"):
                                res = self.engine.ejecutar_compound_order(
                                    usuario=fake_user,
                                    symbol=symbol,
                                    side=side,
                                    total_amount_usdt=amount_usd,
                                    steps=1,
                                    modo="REAL" if self.mode == "AUTO_EXEC" else "DEMO"
                                )
                                exec_record = {
                                    "ts": time.time(),
                                    "symbol": symbol,
                                    "side": side,
                                    "amount": amount_usd,
                                    "mode": "REAL" if self.mode == "AUTO_EXEC" else "DEMO",
                                    "result": res
                                }
                                _append_jsonl(EXEC_JSONL, exec_record)
                                if self.audit:
                                    try:
                                        self.audit.log_execution(exec_record)
                                    except Exception:
                                        log.exception("AuditManager.log_execution failed")
                                if telegram_send:
                                    try:
                                        telegram_send(f"SignalsEngine AUTO_EXEC {symbol} {side} -> {str(res)[:200]}")
                                    except Exception:
                                        pass
                    except Exception:
                        log.exception("AUTO_EXEC error")

                # -----------------------------------------------------
                #                     SIMULATE MODE
                # -----------------------------------------------------
                elif self.mode == "SIMULATE":
                    sim_record = {
                        "ts": time.time(),
                        "symbol": symbol,
                        "side": ia_action[0] if ia_action else "NONE",
                        "amount": 0.0,
                        "user": "simulate_engine",
                        "mode": "SIMULATE",
                        "result": payload,
                        "meta": {"via": "signals_engine", "mode": "SIMULATE"}
                    }
                    _append_jsonl(EXEC_JSONL, sim_record)
                    if self.audit:
                        try:
                            self.audit.log_execution(sim_record)
                        except Exception:
                            log.exception("AuditManager.log_execution (simulate) failed")

            except Exception:
                log.exception("Error in _on_kline_close for %s", symbol)
        return _on_kline_close

    # -------------------------
    # Anti-hack
    # -------------------------
    def _detect_anti_hack(self, symbol: str, row: Dict[str, Any]) -> bool:
        try:
            spread_rel = _rel_spread(row)
            if spread_rel > max(0.25, self.spread_alert_threshold * 5):
                msg = f"🚨 ANOMALY huge spread {spread_rel:.3f} for {symbol}"
                log.error(msg)
                if telegram_send:
                    try:
                        telegram_send(msg)
                    except Exception:
                        pass
                return True
            return False
        except Exception:
            log.exception("_detect_anti_hack error")
            return False

    # -------------------------
    # Utility
    # -------------------------
    def is_running(self) -> bool:
        return self._started

# end file
