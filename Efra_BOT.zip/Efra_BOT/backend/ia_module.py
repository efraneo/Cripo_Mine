"""
ia_module.py
----------------------------------------
Módulo de Inteligencia Artificial para el bot Efra_BOT.

Incluye:
- Preparación y limpieza de datos
- Generación de etiquetas (labeling) basado en ATR (Stop/Take-Profit dinámico)
- Extracción de características técnicas
- Entrenamiento del modelo LightGBM con validación walk-forward
- Calibración de probabilidades (Isotonic Regression)
- Predicción con probabilidad calibrada (0–1)

Autor: ChatGPT (optimizado para Efra Sarmiento)
----------------------------------------
"""

import numpy as np
import pandas as pd
import lightgbm as lgb

from sklearn.preprocessing import StandardScaler
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import TimeSeriesSplit


# ================================================================
# GENERACIÓN DE ETIQUETAS DINÁMICAS (ATR Stop/TP)
# ================================================================
def generate_labels(df: pd.DataFrame,
                    atr_mult_tp: float = 1.5,
                    atr_mult_sl: float = 1.0,
                    horizon: int = 20) -> pd.DataFrame:
    """
    Genera etiqueta ATR-based:
        1 = TP alcanzado primero
        0 = SL alcanzado primero
    Si nada se alcanza -> etiqueta según dirección final.

    Parámetros:
        df: OHLCV + ATR
        atr_mult_tp: multiplicador TP
        atr_mult_sl: multiplicador SL
        horizon: barras a futuro para evaluar
    """

    df = df.copy()

    if "ATR" not in df.columns:
        raise ValueError("El DataFrame debe contener columna 'ATR' antes del labeling.")

    labels = []
    for i in range(len(df)):

        if i + horizon >= len(df):
            labels.append(np.nan)
            continue

        entry = df["close"].iloc[i]
        atr = df["ATR"].iloc[i]

        tp = entry + atr * atr_mult_tp
        sl = entry - atr * atr_mult_sl

        future = df["close"].iloc[i:i + horizon].values

        hit_tp = np.any(future >= tp)
        hit_sl = np.any(future <= sl)

        if hit_tp and not hit_sl:
            labels.append(1)
        elif hit_sl and not hit_tp:
            labels.append(0)
        else:
            # Si ninguno se toca, decide por la dirección final
            labels.append(1 if df["close"].iloc[i + horizon] > entry else 0)

    df["label"] = labels
    df.dropna(subset=["label"], inplace=True)
    df["label"] = df["label"].astype(int)

    return df


# ================================================================
# EXTRAER FEATURES
# ================================================================
def extract_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Extrae características robustas:
    - Retornos
    - Volatilidad
    - Señales técnicas
    - Niveles de Fibonacci si están presentes
    """

    df = df.copy()

    # Retornos logarítmicos
    df["ret_1"] = np.log(df["close"] / df["close"].shift(1))
    df["ret_3"] = np.log(df["close"] / df["close"].shift(3))
    df["ret_6"] = np.log(df["close"] / df["close"].shift(6))

    # Volatilidad simple
    df["vol_10"] = df["ret_1"].rolling(10).std()
    df["vol_20"] = df["ret_1"].rolling(20).std()

    # Ratios con ATR
    if "ATR" in df.columns:
        df["atr_ratio"] = df["ATR"] / df["close"]
        df["atr_chg"] = df["ATR"].pct_change()

    # Momentum técnico simple
    df["mom_10"] = df["close"] - df["close"].shift(10)
    df["mom_20"] = df["close"] - df["close"].shift(20)

    # Medias móviles
    df["sma_10"] = df["close"].rolling(10).mean()
    df["sma_20"] = df["close"].rolling(20).mean()
    df["sma_ratio"] = df["sma_10"] / df["sma_20"]

    # Fibonacci (si existen)
    fib_cols = [c for c in df.columns if "fib_" in c.lower()]
    # Normalizamos contra el cierre
    for c in fib_cols:
        df[f"{c}_norm"] = df[c] / df["close"]

    df.dropna(inplace=True)
    return df


# ================================================================
# ENTRENAR MODELO + CALIBRACIÓN
# ================================================================
def train_and_calibrate(
        df: pd.DataFrame,
        n_splits: int = 5,
        num_leaves: int = 31,
        learning_rate: float = 0.03,
        n_estimators: int = 300
):
    """
    Entrena LightGBM usando validación temporal Walk-Forward.
    Luego calibra probabilidades usando Isotonic Regression.

    Devuelve:
        dict con:
            - pipeline
            - feature_list
            - scaler
            - gbdt_base
            - calibrated_model
    """

    df = df.copy()
    df.dropna(subset=["label"], inplace=True)

    # Features
    feature_cols = [
        c for c in df.columns
        if c not in ["open", "high", "low", "close", "volume", "label"]
    ]

    X = df[feature_cols].values
    y = df["label"].values

    # Escalador
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # LightGBM base
    model = lgb.LGBMClassifier(
        objective="binary",
        learning_rate=learning_rate,
        num_leaves=num_leaves,
        n_estimators=n_estimators,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42,
    )

    # TimeSeriesSplit
    tscv = TimeSeries
