import pandas as pd
from backend.binance_client import obtener_datos_ohlcv

import argparse
import os

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    print(f"Descargando OHLCV para {args.symbol}...")

    df = obtener_datos_ohlcv(symbol=args.symbol, interval="1h", limit=1000)

    if df is None or df.empty:
        print("ERROR: No se pudo descargar OHLCV.")
        return

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_csv(args.out, index=False)

    print(f"Guardado en {args.out}")

if __name__ == "__main__":
    main()
