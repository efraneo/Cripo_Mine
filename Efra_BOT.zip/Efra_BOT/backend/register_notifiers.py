# backend/register_notifiers.py

import os

from backend.telegram_notifier import (
    TelegramNotifier
)

from backend.notifier_core import (
    DEFAULT_NOTIFIER
)


def register_all_notifiers():

    env = {

        "TELEGRAM_CHAT_ID":
            os.getenv(
                "TELEGRAM_CHAT_ID"
            ),

        "TELEGRAM_BOT_TOKEN":
            os.getenv(
                "TELEGRAM_BOT_TOKEN"
            )
    }

    telegram = TelegramNotifier(
        env
    )

    DEFAULT_NOTIFIER.register(
        "telegram",
        telegram
    )

    return True
