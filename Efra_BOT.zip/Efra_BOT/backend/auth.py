# backend/auth.py
"""
Autenticación mínima basada en CSV/SQLite para el demo.
- validar_usuario(usuario, clave) -> dict | None
- es_admin(usuario_dict) -> bool
- get_usuario_por_email(email) -> dict | None
Este módulo está pensado para ser claro y fácil de reemplazar por un sistema real (JWT, OAuth2).
"""

import pandas as pd
import os
from backend.db import consultar
from backend.utils import leer_csv_seguro
from utils.logger import log_info, log_error

CLAVES_CSV = os.path.join("data", "claves.csv")

def validar_usuario(usuario: str, clave: str):
    """
    Valida usuario contra data/claves.csv
    Retorna un diccionario con la fila del usuario (campos como 'usuario','clave','nombre','correo','es_admin',...) o None.
    """
    try:
        df = leer_csv_seguro(CLAVES_CSV)
        if df.empty:
            log_error("Archivo claves.csv vacío o no encontrado", archivo="auth.py", funcion="validar_usuario")
            return None
        # Acepta búsqueda por campo 'usuario' o 'correo'
        fila = df[(df["usuario"].astype(str) == str(usuario)) | (df["correo"].astype(str) == str(usuario))]
        if fila.empty:
            return None
        fila = fila.iloc[0].to_dict()
        if str(fila.get("clave", "")) != str(clave):
            return None
        if str(fila.get("estado", "")).lower() != "activo":
            log_info(f"Intento de login con usuario inactivo: {usuario}")
            return None
        # Convertir campos booleanos claramente
        fila["es_admin"] = str(fila.get("es_admin", False)).lower() in ("true", "1", "yes")
        fila["usar_ia"] = str(fila.get("usar_ia", False)).lower() in ("true", "1", "yes")
        return fila
    except Exception as e:
        log_error(e, archivo="auth.py", funcion="validar_usuario")
        return None

def es_admin(usuario_dict):
    """
    Verifica si el usuario (dict) tiene rol admin.
    """
    try:
        if not usuario_dict:
            return False
        return bool(usuario_dict.get("es_admin", False))
    except Exception as e:
        log_error(e, archivo="auth.py", funcion="es_admin")
        return False

def get_usuario_por_email(email: str):
    """
    Busca un usuario por correo en data/claves.csv
    """
    try:
        df = leer_csv_seguro(CLAVES_CSV)
        if df.empty:
            return None
        fila = df[df["correo"].astype(str).str.lower() == str(email).lower()]
        if fila.empty:
            return None
        res = fila.iloc[0].to_dict()
        res["es_admin"] = str(res.get("es_admin", False)).lower() in ("true", "1", "yes")
        return res
    except Exception as e:
        log_error(e, archivo="auth.py", funcion="get_usuario_por_email")
        return None
