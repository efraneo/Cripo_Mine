"""
backend/environment_manager.py / backend/env_loader.py

Cargador de variables de entorno PRO (2025) — compatible con tu proyecto.

Características:
- load_all_envs(path="env", override=False): carga todos los archivos .env, .json, .yaml en la carpeta indicada
- load_dotenv_file(path, override=False): parsea un .env simple (KEY=VAL)
- load_json_file(path, override=False)
- load_yaml_file(path, override=False)  (usa PyYAML si está disponible; intenta fallback)
- get_env(key, default=None, cast=None)
- set_env(key, value, persist=False, filepath=None) -> persiste en .env si persist=True
- reload_envs(path="env", override=False)
- safe parsing y logging

Uso:
    from backend.env_loader import load_all_envs, get_env
    load_all_envs("env", override=True)
    API_KEY = get_env("BINANCE_API_KEY", "")
"""

from __future__ import annotations

import os
import sys
import shlex
import json
from pathlib import Path
from typing import Optional, Dict, Any

# Logging
try:
    from backend.log_manager import get_logger
    log = get_logger("env_loader")
except Exception:
    import logging as _logging
    log = _logging.getLogger("env_loader")
    if not log.handlers:
        ch = _logging.StreamHandler()
        ch.setFormatter(_logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(ch)
    log.setLevel(_logging.INFO)

# Try to import yaml if available
try:
    import yaml  # type: ignore
    _HAS_YAML = True
except Exception:
    _HAS_YAML = False

# Default env dir
DEFAULT_ENV_DIR = Path(os.getenv("PROJECT_BASE", ".")) / "env"

# Keep track of loaded files for debugging
_LOADED_FILES = []

# -------------------------
# Helpers: parse .env lines
# -------------------------
def _parse_env_line(line: str) -> Optional[tuple]:
    """
    Parse a single line of .env -> (key, value) or None for comments/empty.
    Supports:
      - KEY=VALUE
      - KEY="quoted value"
      - KEY='single quoted'
      - export KEY=VALUE
    """
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    # remove leading export
    if line.startswith("export "):
        line = line[len("export "):].strip()

    # Find first '='
    if "=" not in line:
        return None
    k, v = line.split("=", 1)
    key = k.strip()
    val = v.strip()

    # Remove surrounding quotes if present
    if (val.startswith('"') and val.endswith('"')) or (val.startswith("'") and val.endswith("'")):
        try:
            # Use shlex to handle escapes inside quotes
            val = shlex.split(val)[0]
        except Exception:
            val = val[1:-1]
    else:
        # unquoted, remove inline comments (after space #)
        if " #" in val:
            val = val.split(" #", 1)[0].strip()
        if val.endswith(" #"):
            val = val.rsplit(" #", 1)[0].strip()

    return key, val

# -------------------------
# Loaders
# -------------------------
def load_dotenv_file(path: str | Path, override: bool = False) -> Dict[str, str]:
    """
    Parse a .env file and set os.environ accordingly.
    Returns a dict of loaded values.
    """
    path = Path(path)
    loaded: Dict[str, str] = {}
    if not path.exists():
        log.debug("dotenv file not found: %s", str(path))
        return loaded

    try:
        with path.open("r", encoding="utf-8") as fh:
            for ln in fh:
                parsed = _parse_env_line(ln)
                if not parsed:
                    continue
                k, v = parsed
                if override or (os.getenv(k) is None):
                    os.environ[k]
