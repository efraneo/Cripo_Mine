# ============================================================
# backend/monitor_ws.py PRO
# ============================================================
"""
Monitor de mercado en tiempo real usando WebSocket público de Binance.

✔ Integrado con log_manager (logs rotativos)
✔ Reconexión automática (a prueba de fallos)
✔ Callback profesional al cerrar cada vela
✔ Compatible con trading_core.procesar_y_ejecutar
✔ Compatible con TradingEngine (IA, ATR, TP1-TP4)
✔ Detección de manipulación maliciosa (anti-hack WS)
✔ Telemetría y alertas Telegram
✔ Multi-stream manager
"""

from __future__ import annotations
import json
import threading
import time
import traceback
from typing import Callable, Optional, Dict, Any
import pandas as pd
import websocket  # websocket-client

from backend.log_manager import get_logger
ws_log = get_logger("ws")

# Telegram opcional
try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

# Trading Engine opcional
try:
    from backend.trading_engine import get_engine_singleton
except Exception:
    get_engine_singleton = None


# ============================================================
# UTILIDAD: Convertir la estructura kline → row usable
# ============================================================
def _kline_to_row(kline: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "symbol": kline.get("s"),
        "interval": kline.get("i"),
        "open_time": int(kline.get("t")),
        "close_time": int(kline.get("T")),
        "open": float(kline.get("o")),
        "high": float(kline.get("h")),
        "low": float(kline.get("l")),
        "close": float(kline.get("c")),
        "volume": float(kline.get("v")),
        "is_closed": bool(kline.get("x")),
        "trade_count": int(kline.get("n"))
    }


# ============================================================
#   Worker por símbolo/intervalo
# ============================================================
class _SymbolKlineWorker(threading.Thread):
    BASE_WS = "wss://stream.binance.com:9443/ws"

    def __init__(
        self,
        symbol: str,
        interval: str,
        on_kline_close: Callable[[Dict[str, Any], Dict[str, Any]], None],
        reconnect_delay: float = 5.0,
        name: Optional[str] = None
    ):
        super().__init__(daemon=True)
        self.symbol = symbol.upper()
        self.interval = interval
        self.on_kline_close = on_kline_close
        self.reconnect_delay = reconnect_delay
        self._stop_event = threading.Event()
        self.ws = None
        self.name = name or f"kline-{self.symbol}-{self.interval}"

        # Anti-manipulación WS
        self.last_ts = 0

    # --------------------------------------------------------
    def _ws_url(self) -> str:
        sym = self.symbol.lower()
        return f"{self.BASE_WS}/{sym}@kline_{self.interval}"

    # --------------------------------------------------------
    def stop(self):
        self._stop_event.set()
        try:
            if self.ws:
                self.ws.close()
        except Exception:
            pass

    def running(self) -> bool:
        return not self._stop_event.is_set()

    # --------------------------------------------------------
    #   Handlers del WebSocket
    # --------------------------------------------------------
    def _on_message(self, wsapp, message):
        try:
            msg = json.loads(message)
            k = msg.get("k")
            if not k:
                return

            row = _kline_to_row(k)

            # ----------------------------
            # 🔥 Anti-Manipulación / Anti-Hack
            # ----------------------------
            ts = row.get("close_time", 0)
            if ts < self.last_ts:
                ws_log.error("Anomalía detectada: timestamps regresivos en %s", self.name)
                if telegram_send:
                    telegram_send(f"⚠ WS anomaly en {self.symbol}: timestamps regresivos. Posible manipulación.")
                self.last_ts = ts  # actualizar igual para evitar loops

            self.last_ts = ts

            # ----------------------------
            # Procesar al cerrar la vela
            # ----------------------------
            if row.get("is_closed"):
                try:
                    self.on_kline_close(row, msg)
                except Exception:
                    ws_log.exception("Callback error en %s", self.name)

        except Exception:
            ws_log.exception("Error parsing message en %s", self.name)

    def _on_error(self, wsapp, error):
        ws_log.error("WebSocket error %s: %s", self.name, error)
        if telegram_send:
            telegram_send(f"⚠ WS error en {self.symbol}: {error}")

    def _on_close(self, wsapp, status, msg):
        ws_log.warning("WS CLOSED %s: %s %s", self.name, status, msg)

    def _on_open(self, wsapp):
        ws_log.info("WS OPEN %s", self.name)
        if telegram_send:
            telegram_send(f"🟢 WS abierto para {self.symbol} ({self.interval})")

    # --------------------------------------------------------
    def _create_and_run(self):
        url = self._ws_url()
        ws_log.info(f"Conectando WebSocket: {url}")

        wsapp = websocket.WebSocketApp(
            url,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close,
            on_open=self._on_open
        )
        self.ws = wsapp

        wsapp.run_forever(
            ping_interval=30,
            ping_timeout=10,
            reconnect=5
        )

    # --------------------------------------------------------
    def run(self):
        ws_log.info("Worker START %s (%s, %s)", self.name, self.symbol, self.interval)

        while not self._stop_event.is_set():
            try:
                self._create_and_run()
            except Exception as e:
                ws_log.error("Worker %s failed: %s", self.name, e)
                ws_log.debug(traceback.format_exc())

            if self._stop_event.is_set():
                break

            time.sleep(self.reconnect_delay)

        ws_log.info("Worker STOP %s", self.name)


# ============================================================
#   Manager de múltiples workers
# ============================================================
class BinanceKlineMonitor:
    def __init__(self):
        self.workers: Dict[str, _SymbolKlineWorker] = {}
        self.lock = threading.Lock()

    def _key(self, symbol: str, interval: str) -> str:
        return f"{symbol.upper()}__{interval}"

    def start_listening(self, symbol: str, interval: str, on_kline_close):
        key = self._key(symbol, interval)
        with self.lock:
            if key in self.workers and self.workers[key].running():
                ws_log.info("Worker ya existe para %s %s", symbol, interval)
                return True

            w = _SymbolKlineWorker(symbol, interval, on_kline_close)
            self.workers[key] = w
            w.start()
            ws_log.info("Worker creado para %s %s", symbol, interval)
            return True

    def stop_listening(self, symbol: str, interval: str):
        key = self._key(symbol, interval)
        with self.lock:
            w = self.workers.get(key)
            if w:
                w.stop()
                del self.workers[key]
                ws_log.info("Worker detenido para %s %s", symbol, interval)
                return True
        return False

    def stop_all(self):
        ws_log.warning("Deteniendo TODOS los workers…")
        with self.lock:
            for k, w in list(self.workers.items()):
                try:
                    w.stop()
                except Exception:
                    ws_log.exception("Error stopping worker %s", k)
                finally:
                    del self.workers[k]

        ws_log.info("Todos los workers detenidos.")


# ============================================================
# CALLBACK adaptado al trading_core
# ============================================================
def default_on_close_callback_factory(
    processor,
    executor,
    usuario: Optional[Dict[str, Any]] = None,
    account_balance: Optional[float] = None,
    local_bbe_path: Optional[str] = None
):
    from backend.trading_core import procesar_y_ejecutar

    def _callback(row: Dict[str, Any], raw_msg: Dict[str, Any]):
        try:
            hist_df = pd.DataFrame([{
                "open": row["open"],
                "high": row["high"],
                "low": row["low"],
                "close": row["close"],
                "volume": row["volume"],
                "atr": None
            }])

            price = float(row["close"])
            side = "BUY" if price > float(row["open"]) else "SELL"

            signal = {
                "symbol": row["symbol"],
                "signal": side,
                "price": price,
                "extra": {
                    "kline_interval": row["interval"],
                    "trade_count": row["trade_count"]
                }
            }

            out = procesar_y_ejecutar(
                signal, hist_df, executor, processor,
                usuario=usuario,
                account_balance=account_balance,
                local_bbe_path=local_bbe_path
            )

            ws_log.info(
                "Kline CLOSED %s %s → status=%s",
                row["symbol"],
                row["interval"],
                out["execution"].get("status")
            )

        except Exception:
            ws_log.exception("Error en callback kline close")

    return _callback
