# backend/bot_manager.py — BotManager PRO (2025)
# (Parcheado: soporte on_finish callbacks, job_id, TelegramNotifier class integration,
#  aliases 'asset' -> 'symbol', force_stop, callbacks map)

from __future__ import annotations
import threading
import queue
import time
import traceback
import uuid
from typing import Optional, Dict, Any, Callable, List
from datetime import datetime

# Dependencias del backend (intentar importar, fallback a None)
try:
    from backend.trading_engine import get_engine_singleton, TradingEngine
except Exception:
    TradingEngine = None
    get_engine_singleton = None

try:
    from backend.order_manager import OrderManager
except Exception:
    OrderManager = None

try:
    from backend.risk_manager import RiskManager
except Exception:
    RiskManager = None

try:
    from backend.session_manager import SessionManager
except Exception:
    SessionManager = None

try:
    from backend.results_manager import ResultsManager
except Exception:
    ResultsManager = None

# Telegram legacy functions
try:
    from backend.telegram_notifier import notificar_operacion, notificar_error, notificar_oportunidad_ia, enviar_mensaje
except Exception:
    notificar_operacion = None
    notificar_error = None
    notificar_oportunidad_ia = None
    enviar_mensaje = None

# Telegram class (optional, preferred)
try:
    from backend.telegram_notifier import TelegramNotifier  # optional class wrapper
except Exception:
    TelegramNotifier = None

# Logger preferiblemente desde log_manager
try:
    from backend.log_manager import get_logger
    log = get_logger("bot_manager")
except Exception:
    import logging
    log = logging.getLogger("bot_manager")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)


class BotManager:
    """
    Manager central para el flujo del bot.

    - Mantiene una cola (FIFO) de trabajos (análisis, previews, ejecuciones)
    - Worker thread que procesa la cola y respeta backoff/retries
    - Hooks para UI: on_status_change, on_new_result
    - Soporte para callbacks on_finish pasados desde UI (streamlit)
    """

    def __init__(
        self,
        engine: Optional[TradingEngine] = None,
        order_manager: Optional[OrderManager] = None,
        session_manager: Optional[SessionManager] = None,
        risk_manager: Optional[RiskManager] = None,
        results_manager: Optional[ResultsManager] = None,
        worker_count: int = 1,
        max_retries: int = 3,
        poll_interval: float = 0.5,
        rate_limit_per_min: int = 60
    ):
        self.engine = engine or (get_engine_singleton() if get_engine_singleton else None)
        self.order_manager = order_manager
        self.session_manager = session_manager or (SessionManager() if SessionManager else None)
        self.risk_manager = risk_manager or (RiskManager() if RiskManager else None)
        self.results_manager = results_manager or (ResultsManager() if ResultsManager else None)

        self.worker_count = max(1, int(worker_count))
        self.max_retries = max_retries
        self.poll_interval = poll_interval

        self._queue: queue.Queue = queue.Queue()
        self._workers: List[threading.Thread] = []
        self._stop_event = threading.Event()

        # rate limiting simple
        self._recent_exec_timestamps: List[float] = []
        self.rate_limit_per_min = rate_limit_per_min

        # callbacks / hooks
        self.on_status_change: Optional[Callable[[str, Dict[str, Any]], None]] = None
        self.on_new_result: Optional[Callable[[Dict[str, Any]], None]] = None

        # almacenar callbacks on_finish de jobs (no serializables dentro de la cola)
        self._callbacks: Dict[str, Callable[[Dict[str, Any]], None]] = {}

        # notifier (clase) si está disponible — preferible para integración limpia
        self.notifier = TelegramNotifier() if TelegramNotifier else None

        # flag para forzar parada de ejecuciones en OrderManager (delegado)
        self._force_stop_flag = threading.Event()

        log.info("BotManager inicializado (workers=%d)", self.worker_count)

    # -------------------------
    # Helpers internos
    # -------------------------
    def _emit_status(self, event: str, payload: Optional[Dict[str, Any]] = None):
        payload = payload or {}
        payload["ts"] = datetime.utcnow().isoformat()
        try:
            if callable(self.on_status_change):
                try:
                    self.on_status_change(event, payload)
                except Exception:
                    log.exception("on_status_change callback falló")
        except Exception:
            log.exception("on_status_change outer fail")
        log.info("Status event: %s %s", event, payload)

    def _throttle_ok(self) -> bool:
        """Very naive rate limiter: max executions per minute."""
        now = time.time()
        window_start = now - 60
        self._recent_exec_timestamps = [ts for ts in self._recent_exec_timestamps if ts >= window_start]
        if len(self._recent_exec_timestamps) >= self.rate_limit_per_min:
            return False
        self._recent_exec_timestamps.append(now)
        return True

    # -------------------------
    # Queue API
    # -------------------------
    def enqueue_analysis(
        self,
        symbol: str,
        session_id: str,
        usuario: Optional[Dict[str, Any]] = None,
        amount_usdt: float = 25.0,
        steps: int = 1,
        priority: int = 5,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Encola una petición de análisis+preview. Retorna un ID simple.
        """
        job_id = uuid.uuid4().hex
        job = {
            "job_id": job_id,
            "type": "analysis",
            "symbol": symbol,
            "session_id": session_id,
            "usuario": usuario,
            "amount_usdt": float(amount_usdt),
            "steps": int(steps),
            "retries": 0,
            "created_at": time.time(),
            "metadata": metadata or {}
        }
        self._queue.put(job)
        self._emit_status("job_enqueued", {"job_id": job_id, "symbol": symbol, "session_id": session_id})
        return {"status": "enqueued", "symbol": symbol, "job_id": job_id}

    def enqueue_execute(
        self,
        symbol: str,
        session_id: str,
        usuario: Dict[str, Any],
        amount_usdt: float,
        steps: int = 1,
        stop_loss_pct: float = 0.02,
        mode: str = "DEMO",
        metadata: Optional[Dict[str, Any]] = None,
        on_finish: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> Dict[str, Any]:
        """
        Encola ejecución. on_finish puede ser una función (callable) que se ejecutará
        en el mismo proceso cuando termine (no se persiste).
        """
        job = {
            "type": "execute",
            "symbol": symbol,
            "session_id": session_id,
            "usuario": usuario,
            "amount_usdt": float(amount_usdt),
            "steps": int(steps),
            "stop_loss_pct": float(stop_loss_pct),
            "mode": mode,
            "retries": 0,
            "created_at": time.time(),
            "metadata": metadata or {},
            # callback en memoria (NO serializable)
            "_on_finish": on_finish
        }
        self._queue.put(job)
        self._emit_status("job_enqueued", {"symbol": symbol, "action": "execute", "session_id": session_id})
        return {"status": "enqueued", "symbol": symbol, "action": "execute"}

    # -------------------------
    # Worker loop
    # -------------------------
    def _worker_loop(self, worker_id: int):
        log.info("Worker %d started", worker_id)
        while not self._stop_event.is_set():
            try:
                job = None
                try:
                    job = self._queue.get(timeout=self.poll_interval)
                except queue.Empty:
                    continue

                job_type = job.get("type")
                job_id = job.get("job_id")
                log.info("Worker %d handling job job_id=%s type=%s symbol=%s", worker_id, job_id, job_type, job.get("symbol"))

                # Respect basic rate limit
                if not self._throttle_ok():
                    log.warning("Rate limit reached; re-enqueueing job %s", job_id)
                    job["retries"] = job.get("retries", 0) + 1
                    if job["retries"] <= self.max_retries:
                        time.sleep(1.0)
                        self._queue.put(job)
                    else:
                        log.error("Job dropped due to rate limit retries: %s", job)
                        self._emit_status("job_dropped", {"job_id": job_id, "reason": "rate_limit"})
                    self._queue.task_done()
                    continue

                if job_type == "analysis":
                    result = self._handle_analysis_job(job) or {}
                    # if there is a callback stored, call it
                    cb = self._callbacks.pop(job_id, None)
                    if callable(cb):
                        try:
                            cb(result)
                        except Exception:
                            log.exception("analysis on_finish callback failed")
                elif job_type == "execute":
                    result = self._handle_execute_job(job) or {}
                    # on_finish callback (stored previously) — execute safely
                    cb = self._callbacks.pop(job_id, None)
                    if callable(cb):
                        try:
                            cb(result)
                        except Exception:
                            log.exception("execute on_finish callback failed")
                else:
                    log.warning("Job unknown type: %s", job_type)

                self._queue.task_done()

            except Exception as e:
                log.exception("Worker loop fatal error: %s", e)
                # non-fatal: continue
                time.sleep(0.5)

        log.info("Worker %d stopped", worker_id)

    # -------------------------
    # Job handlers
    # -------------------------
    def _handle_analysis_job(self, job: Dict[str, Any]):
        symbol = job.get("symbol")
        session_id = job.get("session_id")
        usuario = job.get("usuario")
        amount = job.get("amount_usdt", 25.0)

        try:
            # 1) Validate session & user
            if self.session_manager:
                sess = self.session_manager.get_session(session_id)
                if not sess:
                    log.warning("Session invalid for analysis job: %s", session_id)
                    self._emit_status("job_failed", {"reason": "session_invalid", "job": job})
                    return {"error": "session_invalid"}

            # 2) Fetch klines and compute preview
            df = None
            try:
                df = self.engine.get_klines_df(symbol)
            except Exception:
                log.exception("get_klines_df failed for %s", symbol)

            preview = None
            if df is not None:
                # engine.preview_order may accept different signatures; try robust call
                try:
                    preview = self.engine.preview_order(symbol, amount)
                except TypeError:
                    try:
                        preview = self.engine.preview_order(symbol, usd_amount=amount)
                    except Exception:
                        preview = None

            # 3) Notify UI and Telegram with preview summary
            self._emit_status("analysis_complete", {"symbol": symbol, "preview": preview or {}, "job_id": job.get("job_id")})

            # Telegram notification (best-effort)
            try:
                if preview and (self.notifier or notificar_oportunidad_ia):
                    mejor = {
                        "activo": symbol,
                        "accion": preview.get("action", preview.get("recommendation", "N/A")),
                        "precision": preview.get("ia_confidence_pct", 0.0),
                        "rsi": (preview.get("features") or {}).get("rsi", 0.0),
                        "macd": (preview.get("features") or {}).get("macd", 0.0),
                    }
                    if self.notifier and hasattr(self.notifier, "notify_opportunity"):
                        try:
                            self.notifier.notify_opportunity(mejor)
                        except Exception:
                            log.exception("notifier.notify_opportunity failed")
                    else:
                        try:
                            notificar_oportunidad_ia(mejor)
                        except Exception:
                            log.exception("legacy notificar_oportunidad_ia failed")
            except Exception:
                log.exception("Telegram notify preview failed")

            return {"status": "ok", "preview": preview, "job_id": job.get("job_id")}
        except Exception as e:
            log.exception("analysis job error: %s", e)
            self._emit_status("job_failed", {"reason": str(e), "job": job})
            return {"error": str(e), "job_id": job.get("job_id")}

    def _handle_execute_job(self, job: Dict[str, Any]):
        symbol = job.get("symbol")
        session_id = job.get("session_id")
        usuario = job.get("usuario")
        amount = job.get("amount_usdt", 25.0)
        steps = job.get("steps", 1)
        stop_loss_pct = job.get("stop_loss_pct", 0.02)
        mode = job.get("mode", "DEMO")
        job_id = job.get("job_id")

        try:
            # 1) Validate session
            if self.session_manager:
                sess = self.session_manager.get_session(session_id)
                if not sess:
                    log.warning("Session invalid for execute job: %s", session_id)
                    self._emit_status("job_failed", {"reason": "session_invalid", "job": job})
                    return {"error": "session_invalid", "job_id": job_id}

            # 1.5) Respect force stop flag (global)
            if self._force_stop_flag.is_set():
                log.warning("Global force stop set; aborting execute job %s", job_id)
                self._emit_status("job_cancelled", {"job_id": job_id, "reason": "force_stop"})
                # clear flag for next jobs (decision: clear here)
                self._force_stop_flag.clear()
                return {"status": "cancelled", "job_id": job_id, "reason": "force_stop"}

            # 2) Risk checks & generate parameters
            price = None
            try:
                price = self.engine.get_ticker_price(symbol) or (self.engine.get_klines_df(symbol).iloc[-1]["close"])
            except Exception:
                log.exception("Could not get price for %s", symbol)

            capital = float(self.engine.get_balance("USDT") or 1000.0)
            params = {}
            if self.risk_manager:
                params = self.risk_manager.generate_trade_parameters(
                    symbol=symbol,
                    price=float(price) if price is not None else 0.0,
                    side="BUY",
                    strategy="DCA",
                    capital=capital,
                    stop_loss_pct=stop_loss_pct,
                )

                if "error" in params:
                    log.error("RiskManager rejected trade: %s", params)
                    self._emit_status("job_failed", {"reason": "risk_rejected", "details": params, "job_id": job_id})
                    return {"error": "risk_rejected", "details": params, "job_id": job_id}

            # 3) Execute via TradingEngine (preferred) or OrderManager
            exec_result = None
            try:
                # prefer TradingEngine high-level API
                if self.engine:
                    # engine may offer execute_async or ejecutar_compound_order — try both
                    try:
                        exec_result = self.engine.ejecutar_compound_order(
                            usuario=usuario or {"usuario": sess.get("username")},
                            symbol=symbol,
                            total_amount_usdt=amount,
                            steps=steps,
                            risk_pct=stop_loss_pct,
                            modo=mode.upper()
                        )
                    except TypeError:
                        # older signature or different name
                        exec_result = self.engine.ejecutar_trade(
                            usuario=usuario or {"usuario": sess.get("username")},
                            symbol=symbol,
                            total_amount_usdt=amount,
                            steps=steps,
                            risk_pct=stop_loss_pct,
                            modo=mode.upper()
                        )
                elif self.order_manager:
                    # fallback: OrderManager direct call (attempt to map args)
                    # If order_manager supports request_cancel or force_stop, BotManager.force_stop will call it.
                    s = self.order_manager.crear_orden(session_id, symbol, "BUY", amount)
                    exec_result = {"order_manager": s}
                else:
                    raise RuntimeError("No executor available")
            except Exception as e:
                log.exception("Execution failed: %s", e)
                # notify via notifier / legacy function
                try:
                    if self.notifier and hasattr(self.notifier, "notify_error"):
                        self.notifier.notify_error(str(e))
                    elif notificar_error:
                        notificar_error(f"Error ejecutando orden {symbol}: {e}")
                except Exception:
                    log.exception("Telegram notify error failed")
                self._emit_status("job_failed", {"reason": str(e), "job_id": job_id})
                return {"error": str(e), "job_id": job_id}

            # 4) Post-processing: store results, notify 
            try:
                self._emit_status("execution_complete", {
                    "symbol": symbol,
                    "result": exec_result,
                    "job_id": job_id
                })

                # Callback para UI (Streamlit)
                if callable(self.on_new_result):
                    try:
                        self.on_new_result(exec_result)
                    except Exception:
                        log.exception("on_new_result callback failed")

                # -------------------------------------------------------
                #     🔔 Telegram Notifier (Versión unificada / PRO)
                # -------------------------------------------------------
                try:
                    entry = 0.0
                    if isinstance(exec_result, dict):
                        if "execution" in exec_result:
                            entry = exec_result["execution"].get("entry_price", 0.0)
                        elif exec_result.get("real"):
                            entry = exec_result.get("resultado", {}).get("entry_price", 0.0)

                    # -----------------------------
                    # Preferir clase TelegramNotifier
                    # -----------------------------
                    if self.notifier and hasattr(self.notifier, "notify_operation"):
                        try:
                            self.notifier.notify_operation(
                                symbol=symbol,
                                side="BUY",
                                amount=amount,
                                price=entry or price or 0.0,
                                mode=mode.upper()
                            )
                        except Exception:
                            log.exception("notifier.notify_operation failed")

                    # -----------------------------
                    # Fallback legacy
                    # -----------------------------
                    elif notificar_operacion:
                        try:
                            notificar_operacion(
                                symbol,
                                "BUY",
                                amount,
                                entry or price or 0.0,
                                mode.upper()
                            )
                        except Exception:
                            log.exception("legacy notificar_operacion failed")

                except Exception:
                    log.exception("Telegram notify after exec failed")
                # -------------------------------------------------------
                #     🔔 FIN DEL BLOQUE TELEGRAM
                # -------------------------------------------------------

            except Exception:
                log.exception("postprocessing after exec failed")

            return {
                "status": "ok",
                "execution": exec_result,
                "job_id": job_id
            }

    # -------------------------
    # Lifecycle
    # -------------------------
    def start(self):
        """Inicia worker threads."""
        if self._workers:
            log.info("BotManager already started")
            return
        self._stop_event.clear()
        for i in range(self.worker_count):
            t = threading.Thread(target=self._worker_loop, args=(i+1,), daemon=True)
            t.start()
            self._workers.append(t)
        self._emit_status("started", {"workers": self.worker_count})

    def shutdown(self, wait: bool = True):
        """Solicita parada y espera que terminen workers."""
        log.info("Shutdown requested")
        self._stop_event.set()
        self._emit_status("stopping", {})
        if wait:
            for t in self._workers:
                if t.is_alive():
                    t.join(timeout=5.0)
        self._workers = []
        self._emit_status("stopped", {})

    # -------------------------
    # Control externo: force stop
    # -------------------------
    def force_stop(self):
        """
        Señala al manager que detenga ejecuciones lo antes posible.
        Intenta propagar la petición al OrderManager si este expone request_cancel().
        """
        log.warning("Global force_stop requested")
        # set internal flag so workers can abort before starting new executions
        self._force_stop_flag.set()
        # if order_manager supports cancellation, call it
        try:
            if self.order_manager and hasattr(self.order_manager, "request_cancel"):
                try:
                    self.order_manager.request_cancel()
                except Exception:
                    log.exception("order_manager.request_cancel failed")
        except Exception:
            log.exception("force_stop propagation failed")

    # -------------------------
    # Utilities for UI / tests
    # -------------------------
    def status(self) -> Dict[str, Any]:
        qsize = self._queue.qsize()
        alive = sum(1 for t in self._workers if t.is_alive())
        return {
            "queue_size": qsize,
            "workers_alive": alive,
            "workers_total": self.worker_count,
            "recent_execs_last_min": len(self._recent_exec_timestamps)
        }

    def drain_queue(self, timeout: Optional[float] = None):
        """Bloqueante hasta que la cola esté vacía (útil en tests)."""
        start = time.time()
        while self._queue.qsize() > 0:
            if timeout and (time.time() - start) > timeout:
                break
            time.sleep(0.1)
