# backend/security_engine.py

import sqlite3
from datetime import datetime

DB_PATH = "data/usuarios.db"


class SecurityEngine:

    def __init__(self):
        self.db_path = DB_PATH
        self._ensure_tables()

    # =====================================================
    # CREAR TABLAS SI NO EXISTEN
    # =====================================================
    def _ensure_tables(self):

        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        cur.execute("""
        CREATE TABLE IF NOT EXISTS ip_risk (
            ip TEXT PRIMARY KEY,
            username TEXT,
            risk_score INTEGER,
            failed_attempts INTEGER DEFAULT 0,
            last_seen TEXT
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip TEXT,
            event TEXT,
            risk_score INTEGER,
            created_at TEXT
        )
        """)

        conn.commit()
        conn.close()

    # =====================================================
    # SCORE DINÁMICO IP
    # =====================================================
    def compute_ip_risk(self, ip: str, username: str):

        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        cur.execute(
            "SELECT risk_score, failed_attempts FROM ip_risk WHERE ip=?",
            (ip,)
        )

        row = cur.fetchone()

        failed_attempts = 0
        old_score = 0

        if row:
            old_score = row[0] or 0
            failed_attempts = row[1] or 0

        login_hour = datetime.utcnow().hour

        score = 0

        # intentos fallidos
        score += failed_attempts * 10

        # horario sospechoso
        if 2 <= login_hour <= 5:
            score += 15

        # ip nueva
        if not row:
            score += 10

        # persistir score
        cur.execute(
            """
            INSERT OR REPLACE INTO ip_risk
            (ip, username, risk_score, failed_attempts, last_seen)
            VALUES (?, ?, ?, ?, ?)
            """,
            (ip, username, score, failed_attempts, datetime.utcnow().isoformat())
        )

        conn.commit()
        conn.close()

        return score

    # =====================================================
    # REGISTRAR EVENTO
    # =====================================================
    def log_security_event(self, username, ip, event, risk):

        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        cur.execute("""
        INSERT INTO security_events
        (username, ip, event, risk_score, created_at)
        VALUES (?, ?, ?, ?, ?)
        """, (
            username,
            ip,
            event,
            risk,
            datetime.utcnow().isoformat()
        ))

        conn.commit()
        conn.close()

    # =====================================================
    # REGISTRAR INTENTO FALLIDO
    # =====================================================
    def record_failed_login(self, ip):

        conn = sqlite3.connect(self.db_path)
        cur = conn.cursor()

        cur.execute("""
        INSERT INTO ip_risk (ip, failed_attempts, last_seen)
        VALUES (?, 1, ?)
        ON CONFLICT(ip) DO UPDATE SET
            failed_attempts = failed_attempts + 1,
            last_seen = excluded.last_seen
        """, (ip, datetime.utcnow().isoformat()))

        conn.commit()
        conn.close()

    # =====================================================
    # DETECTAR ANOMALÍAS
    # =====================================================
    def detect_anomaly(
        self,
        username,
        ip,
        trade_amount
    ):

        score = self.compute_ip_risk(
            ip,
            username
        )

        anomaly = score

        try:

            trade_amount = float(
                trade_amount
            )

            # tamaño muy alto
            if trade_amount > 1000:
                anomaly += 30

            elif trade_amount > 500:
                anomaly += 15

        except Exception:
            pass

        return min(
            anomaly,
            100
        )


    # =====================================================
    # BLOQUEAR IP
    # =====================================================
    def auto_block_ip(
        self,
        ip,
        reason="AUTO_BLOCK"
    ):

        conn = sqlite3.connect(
            self.db_path
        )

        cur = conn.cursor()

        cur.execute(
            """
            INSERT OR REPLACE INTO ip_risk
            (
                ip,
                username,
                risk_score,
                failed_attempts,
                last_seen
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?
            )
            """,
            (
                ip,
                "BLOCKED",
                100,
                999,
                datetime.utcnow().isoformat()
            )
        )

        conn.commit()
        conn.close()

        self.log_security_event(
            "SYSTEM",
            ip,
            reason,
            100
        )
