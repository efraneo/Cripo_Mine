# backend/ids_manager.py
"""
IDSManager PRO
- Detección de intrusiones por comportamiento
- Scoring acumulativo
- Bloqueo automático de IPs
- Integrable con ML en el futuro
"""

import os
import sqlite3
from datetime import datetime, timedelta

DB = os.path.join(os.path.dirname(__file__), "..", "data", "usuarios.db")

# -------------------------------------------------
# Helpers
# -------------------------------------------------
def _conn():
    return sqlite3.connect(DB)

def _utcnow():
    return datetime.utcnow()

# -------------------------------------------------
# Schema (NO destructivo)
# -------------------------------------------------
def _ensure_schema():
    with _conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS ids_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip TEXT,
            event TEXT,
            score INTEGER,
            ts TEXT
        )
        """)

        c.execute("""
        CREATE TABLE IF NOT EXISTS ids_blocked_ips (
            ip TEXT PRIMARY KEY,
            reason TEXT,
            score INTEGER,
            blocked_at TEXT,
            permanent INTEGER DEFAULT 0
        )
        """)
        c.commit()

_ensure_schema()

# -------------------------------------------------
# IDSManager
# -------------------------------------------------
class IDSManager:
    ALERT_SCORE = 70
    BLOCK_SCORE = 100
    BAN_SCORE = 200

    def __init__(self):
        _ensure_schema()

    # -------------------------
    # Registro de eventos
    # -------------------------
    def register_event(self, username: str, ip: str, event: str, score: int):
        with _conn() as c:
            c.execute("""
            INSERT INTO ids_events(username, ip, event, score, ts)
            VALUES (?,?,?,?,?)
            """, (username, ip, event, score, _utcnow().isoformat()))
            c.commit()

        total = self._calculate_score(ip)

        if total >= self.BAN_SCORE:
            self._block_ip(ip, total, permanent=True)

        elif total >= self.BLOCK_SCORE:
            self._block_ip(ip, total, permanent=False)

        return total

    # -------------------------
    # Score acumulado
    # -------------------------
    def _calculate_score(self, ip: str) -> int:
        since = (_utcnow() - timedelta(minutes=30)).isoformat()

        with _conn() as c:
            r = c.execute("""
            SELECT SUM(score)
            FROM ids_events
            WHERE ip=? AND ts>=?
            """, (ip, since)).fetchone()

        return int(r[0] or 0)

    # -------------------------
    # Bloqueo IP
    # -------------------------
    def _block_ip(self, ip: str, score: int, permanent: bool = False):
        with _conn() as c:
            c.execute("""
            INSERT OR REPLACE INTO ids_blocked_ips
            (ip, reason, score, blocked_at, permanent)
            VALUES (?,?,?,?,?)
            """, (
                ip,
                "auto_ids",
                score,
                _utcnow().isoformat(),
                int(permanent)
            ))
            c.commit()

    # -------------------------
    # Consultas
    # -------------------------
    def is_blocked(self, ip: str) -> bool:
        with _conn() as c:
            r = c.execute("""
            SELECT ip FROM ids_blocked_ips WHERE ip=?
            """, (ip,)).fetchone()
        return bool(r)

    def list_blocked(self):
        with _conn() as c:
            rows = c.execute("""
            SELECT ip, reason, score, blocked_at, permanent
            FROM ids_blocked_ips
            ORDER BY blocked_at DESC
            """).fetchall()

        return [
            {
                "ip": r[0],
                "reason": r[1],
                "score": r[2],
                "blocked_at": r[3],
                "permanent": bool(r[4])
            }
            for r in rows
        ]

    def list_events(self, limit: int = 300):
        with _conn() as c:
            rows = c.execute("""
            SELECT username, ip, event, score, ts
            FROM ids_events
            ORDER BY ts DESC LIMIT ?
            """, (limit,)).fetchall()

        return [
            {
                "username": r[0],
                "ip": r[1],
                "event": r[2],
                "score": r[3],
                "ts": r[4]
            }
            for r in rows
        ]

    # -------------------------
    # Acciones admin
    # -------------------------
    def unblock_ip(self, ip: str):
        with _conn() as c:
            c.execute("DELETE FROM ids_blocked_ips WHERE ip=?", (ip,))
            c.commit()
