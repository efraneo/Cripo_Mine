# backend/equity_tracker.py

import json
import os
import time
from typing import Dict, Any

from backend.log_manager import get_logger

log = get_logger("equity_tracker")


class EquityTracker:
    """
    Institutional Equity Tracker for Spot Trading

    Tracks:
    - equity curve
    - max equity
    - drawdown
    - kill switch trigger
    """

    def __init__(
        self,
        data_file: str = "data/equity_curve.json",
        max_drawdown: float = 0.25,   # 25%
        kill_switch_dd: float = 0.30  # 30%
    ):
        self.data_file = data_file
        self.max_drawdown_limit = max_drawdown
        self.kill_switch_dd = kill_switch_dd

        os.makedirs("data", exist_ok=True)

        self.equity = 0.0
        self.max_equity = 0.0
        self.drawdown = 0.0
        self.kill_switch = False

        self._load()

    # =====================================================
    # LOAD / SAVE
    # =====================================================

    def _load(self):
        try:
            if not os.path.exists(self.data_file):
                return

            with open(self.data_file, "r") as f:
                data = json.load(f)

            self.equity = data.get("equity", 0.0)
            self.max_equity = data.get("max_equity", 0.0)
            self.drawdown = data.get("drawdown", 0.0)
            self.kill_switch = data.get("kill_switch", False)

        except Exception:
            log.exception("Failed loading equity tracker")

    def _save(self):
        try:
            data = {
                "equity": self.equity,
                "max_equity": self.max_equity,
                "drawdown": self.drawdown,
                "kill_switch": self.kill_switch,
                "timestamp": int(time.time())
            }

            with open(self.data_file, "w") as f:
                json.dump(data, f, indent=2)

        except Exception:
            log.exception("Failed saving equity tracker")

    # =====================================================
    # UPDATE EQUITY
    # =====================================================

    def update_equity(self, total_equity: float):

        if total_equity <= 0:
            return

        self.equity = total_equity

        if total_equity > self.max_equity:
            self.max_equity = total_equity

        if self.max_equity > 0:
            self.drawdown = (
                (self.max_equity - total_equity)
                / self.max_equity
            )

        # Kill switch trigger
        if self.drawdown >= self.kill_switch_dd:
            self.kill_switch = True
            log.critical(
                "KILL SWITCH ACTIVATED | Drawdown: %.2f%%",
                self.drawdown * 100
            )

        self._save()

    # =====================================================
    # CHECK
    # =====================================================

    def can_trade(self) -> bool:
        return not self.kill_switch

    def get_state(self) -> Dict[str, Any]:
        return {
            "equity": self.equity,
            "max_equity": self.max_equity,
            "drawdown": self.drawdown,
            "kill_switch": self.kill_switch
        }

    # =====================================================
    # MANUAL RESET
    # =====================================================

    def reset_kill_switch(self):

        self.kill_switch = False
        self.max_equity = self.equity

        log.warning("Kill switch reset manually")

        self._save()