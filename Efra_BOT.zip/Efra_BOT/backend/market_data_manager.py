# backend/market_data_manager.py
"""
MarketDataManager
-----------------
Módulo encargado de:
 - Descargar OHLCV desde Binance (REST)
 - Guardar en CSV
 - Cargar datos para Backtesting
 - Mantener último precio en memoria (cache)
"""

import pandas as pd
import os
import time
from datetime import datetime, timedelta

from .binance_rest_client import BinanceRestClient
from .utils.logger import log_info, log_error


class MarketDataManager:
    """
    Clase responsable de administrar datos de mercado.
    Provee funciones generales para cualquier símbolo e intervalo.
    """

    def __init__(self, data_folder="data/ohlcv"):
        self.rest = BinanceRestClient()
        self.data_folder = data_folder
        self.cache = {}  # { "BTCUSDT": { "price": 000, "timestamp": ... } }

        if not os.path.exists(self.data_folder):
            os.makedirs(self.data_folder)

    def _get_filename(self, symbol, interval):
        return os.path.join(self.data_folder, f"{symbol}_{interval}.csv")

    # ----------------------------------------------------------------------
    # 1) Descargar OHLCV desde Binance y almacenar CSV
    # ----------------------------------------------------------------------
    def download_ohlcv(self, symbol, interval="1m", days=30):
        """
        Descarga OHLCV de X días atrás y lo guarda localmente.
        """

        log_info(f"[MarketDataManager] Descargando {symbol}-{interval} ({days} días)")

        since_ms = int((datetime.utcnow() - timedelta(days=days)).timestamp() * 1000)

        candles = self.rest.get_klines(
            symbol=symbol,
            interval=interval,
            limit=1000,
            start_time=since_ms
        )

        if not candles:
            log_error("❌ No se recibieron datos OHLCV")
            return False

        # Convertir a DataFrame
        df = pd.DataFrame(candles, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_volume", "num_trades",
            "taker_buy_base", "taker_buy_quote", "ignore"
        ])

        # Convertir tipos
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
        df["close_time"] = pd.to_datetime(df["close_time"], unit="ms")
        float_cols = ["open", "high", "low", "close", "volume"]
        df[float_cols] = df[float_cols].astype(float)

        # Guardar CSV
        out_file = self._get_filename(symbol, interval)
        df.to_csv(out_file, index=False)

        log_info(f"[MarketDataManager] Guardado en {out_file}")
        return out_file

    # ----------------------------------------------------------------------
    # 2) Cargar OHLCV desde CSV
    # ----------------------------------------------------------------------
    def load_ohlcv(self, symbol, interval="1m"):
        """
        Carga el CSV generado previamente.
        """
        file_path = self._get_filename(symbol, interval)

        if not os.path.exists(file_path):
            log_error(f"[MarketDataManager] CSV no encontrado: {file_path}")
            return None

        df = pd.read_csv(file_path)
        df["open_time"] = pd.to_datetime(df["open_time"])
        df["close_time"] = pd.to_datetime(df["close_time"])

        return df

    # ----------------------------------------------------------------------
    # 3) Obtener último precio (con caché)
    # ----------------------------------------------------------------------
    def get_last_price(self, symbol):
        """
        Devuelve último precio, usando caché para evitar saturar API.
        Actualiza cada 2 segundos.
        """

        now = time.time()
        cached = self.cache.get(symbol)

        if cached and now - cached["timestamp"] < 2:
            return cached["price"]

        # Consultar ticker
        ticker = self.rest.get_ticker_price(symbol)
        if not ticker:
            return None

        price = float(ticker.get("price", 0))

        self.cache[symbol] = {
            "price": price,
            "timestamp": now
        }

        return price


# ----------------------------------------------------------------------
# Script ejecutable: descargar OHLCV rápido
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", type=str, default="BTCUSDT")
    parser.add_argument("--interval", type=str, default="1m")
    parser.add_argument("--days", type=int, default=30)
    args = parser.parse_args()

    md = MarketDataManager()
    md.download_ohlcv(args.symbol, args.interval, args.days)
