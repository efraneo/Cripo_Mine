# backend/log_manager.py
# -------------------------------------------------------
# Sistema de logs rotativos profesional
# -------------------------------------------------------

import os
import logging
from logging.handlers import RotatingFileHandler

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")

os.makedirs(LOG_DIR, exist_ok=True)

# -------------------------------------------------------
# Formato profesional
# -------------------------------------------------------
LOG_FORMAT = (
    "%(asctime)s | %(levelname)s | %(name)s | "
    "User=%(user)s | IP=%(ip)s | Message=%(message)s"
)

class ContextFilter(logging.Filter):
    """
    Filtro que garantiza que cada log lleve user, ip.
    Si no se envían, se rellenan con '-'.
    """
    def filter(self, record):
        if not hasattr(record, "user"):
            record.user = "-"
        if not hasattr(record, "ip"):
            record.ip = "-"
        return True


def _build_console_handler(formatter: logging.Formatter) -> logging.Handler:
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    return console


def _build_file_handler(logfile: str, formatter: logging.Formatter) -> logging.Handler | None:
    try:
        handler = RotatingFileHandler(
            logfile,
            maxBytes=5 * 1024 * 1024,  # 5MB por archivo
            backupCount=10,            # mantiene 10 archivos anteriores
            encoding="utf-8"
        )
        handler.setFormatter(formatter)
        return handler
    except OSError:
        return None


# -------------------------------------------------------
# Función principal para obtener logger rotativo
# -------------------------------------------------------
def get_logger(name: str):
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # evitar duplicados

    logger.setLevel(logging.INFO)
    logger.propagate = False

    formatter = logging.Formatter(LOG_FORMAT)
    logger.addFilter(ContextFilter())

    logfile = os.path.join(LOG_DIR, f"{name}.log")
    file_handler = _build_file_handler(logfile, formatter)

    if file_handler:
        logger.addHandler(file_handler)

    # Siempre dejamos salida a consola para no romper imports/tests
    logger.addHandler(_build_console_handler(formatter))

    if not file_handler:
        logger.warning(
            "File logging disabled for %s; falling back to console only.",
            name,
        )

    return logger
