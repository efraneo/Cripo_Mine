# backend/db.py
"""
Manejador ligero para la base SQLite usada por la app.
Provee conexión y funciones utilitarias.
Nota: Este es un helper sencillo, para producción reemplazar por SQLAlchemy.
"""
import sqlite3
import os
from utils.logger import log_error, log_info

DB_PATH = os.path.join("data", "usuarios.db")

def get_connection():
    """
    Obtiene una conexión SQLite. Crea la carpeta data si hace falta.
    """
    try:
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        if not os.path.exists(DB_PATH):
            # crear esquema inicial sencillo si no existe (tabla usuarios)
            conn = sqlite3.connect(DB_PATH)
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    usuario TEXT UNIQUE,
                    nombre TEXT,
                    correo TEXT,
                    ganancias REAL DEFAULT 0,
                    perdidas REAL DEFAULT 0,
                    ip TEXT,
                    fecha_creacion TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
            conn.close()
            log_info(f"Base de datos creada en {DB_PATH}")
        return sqlite3.connect(DB_PATH, check_same_thread=False)
    except Exception as e:
        log_error(e, archivo="db.py", funcion="get_connection")
        raise

def ejecutar_query(query: str, params: tuple = None):
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(query, params or ())
        conn.commit()
        return cur.lastrowid
    except Exception as e:
        log_error(e, archivo="db.py", funcion="ejecutar_query")
        raise
    finally:
        if conn:
            conn.close()

def consultar(query: str, params: tuple = None):
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(query, params or ())
        rows = cur.fetchall()
        return rows
    except Exception as e:
        log_error(e, archivo="db.py", funcion="consultar")
        return []
    finally:
        if conn:
            conn.close()
