import sqlite3
from datetime import datetime

DB_PATH = "data/ia_memory.db"


class IAMemory:

    def __init__(self):
        self._ensure_schema()

    def _conn(self):
        return sqlite3.connect(DB_PATH)

    def _ensure_schema(self):
        with self._conn() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS memory (
                symbol TEXT,
                score REAL,
                result INTEGER,
                created_at TEXT
            )
            """)
            c.commit()

    def record(self, symbol, score, result):
        with self._conn() as c:
            c.execute(
                "INSERT INTO memory VALUES (?,?,?,?)",
                (symbol, score, result, datetime.utcnow().isoformat())
            )
            c.commit()

    def bias(self, symbol):
        with self._conn() as c:
            cur = c.execute("""
                SELECT AVG(result) FROM memory
                WHERE symbol=? AND score >= 85
            """, (symbol,))
            row = cur.fetchone()

            if row and row[0] is not None:
                return (row[0] - 0.5) * 10  # ajuste fino

        return 0
