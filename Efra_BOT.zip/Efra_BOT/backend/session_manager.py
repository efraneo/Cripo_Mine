# backend/session_manager.py
"""
SessionManager PRO: sesiones en SQLite (table sessions)
 - create_session(username, ttl_sec=7200)
 - get_session(session_id)
 - touch_session(session_id)
 - delete_session(session_id)
 - list_active_sessions()
 - get_time_left(session_id)
"""

import sqlite3, os, time, uuid
from datetime import datetime, timedelta
#from backend.ip_manager import IPManager

DEFAULT_TTL = 7200  # 2 horas

def _conn(db_path):
    return sqlite3.connect(db_path)

class SessionManager:
    def __init__(self, db_path: str = None):
        self.db_path = db_path or DB
        # ensure schema exists (migrator should have created it)
        with _conn(self.db_path) as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                username TEXT,
                ip TEXT,
                created_at INTEGER,
                last_touch INTEGER,
                expires_at INTEGER
            )
            """)
            c.commit()

    def create_session(self, username: str, ip: str = None, ttl_sec: int = None) -> str:
        ttl_sec = ttl_sec or DEFAULT_TTL

        sid = uuid.uuid4().hex
        now = int(time.time())
        exp = now + int(ttl_sec)

        with _conn(self.db_path) as c:
            c.execute("""
                INSERT INTO sessions
                (session_id, username, ip, created_at, last_touch, expires_at)
                VALUES (?,?,?,?,?,?)
            """, (sid, username, ip, now, now, exp))
            c.commit()

        return sid


    def get_session(self, session_id: str):
        with _conn(self.db_path) as c:
            r = c.execute("SELECT session_id, username, created_at, last_touch, expires_at FROM sessions WHERE session_id=?",
                          (session_id,)).fetchone()
            if not r:
                return None
            sid, username, created_at, last_touch, expires_at = r
            if int(time.time()) > int(expires_at):
                # expired -> delete
                c.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))
                c.commit()
                return None
            return {"session_id": sid, "username": username, "created_at": created_at, "last_touch": last_touch, "expires_at": expires_at}

    def touch_session(self, session_id: str, extend: bool = False):
        now = int(time.time())
        with _conn(self.db_path) as c:
            r = c.execute("SELECT expires_at FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if not r:
                return False
            exp = r[0]
            if extend:
                # extend by original TTL (approx)
                new_exp = now + DEFAULT_TTL
            else:
                new_exp = exp
            c.execute("UPDATE sessions SET last_touch=?, expires_at=? WHERE session_id=?", (now, new_exp, session_id))
            c.commit()
            return True

    def delete_session(self, session_id: str):
        with _conn(self.db_path) as c:
            c.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))
            c.commit()

    def list_active_sessions(self):
        with _conn(self.db_path) as c:
            rows = c.execute("SELECT session_id, username, created_at, last_touch, expires_at FROM sessions").fetchall()
            out = []
            for r in rows:
                out.append({"session_id": r[0], "username": r[1], "created_at": r[2], "last_touch": r[3], "expires_at": r[4]})
            return out

    def get_time_left(self, session_id: str) -> int:
        with _conn(self.db_path) as c:
            r = c.execute("SELECT expires_at FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if not r:
                return 0
            return max(0, int(r[0]) - int(time.time()))

    def get_active_sessions(self):
        """
        Alias para compatibilidad con UI
        """
        return self.list_active_sessions()

