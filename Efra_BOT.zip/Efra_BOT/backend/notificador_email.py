# backend/notificador_email.py
"""
Envío de notificaciones por correo.
Lee credenciales desde env/clave_correo.env
Proporciona 'enviar_email' y alias 'enviar_correo'
"""

import os
import smtplib
from email.message import EmailMessage
from dotenv import load_dotenv
from utils.logger import log_error, log_info

# Cargar variables de entorno específicas
_env_path = os.path.join("env", "clave_correo.env")
if os.path.exists(_env_path):
    load_dotenv(_env_path)

EMAIL_REMITENTE = os.getenv("CORREO_ORIGEN")
EMAIL_PASSWORD = os.getenv("CLAVE_CORREO")
EMAIL_SMTP = os.getenv("SERVIDOR_SMTP", "smtp.gmail.com")
EMAIL_PUERTO = int(os.getenv("PUERTO_SMTP", 587))
EMAIL_ADMIN = os.getenv("CORREO_ADMIN")

def enviar_email(destino: str, asunto: str, cuerpo: str, html: str = None):
    """
    Envía un email en texto plano (o HTML si se provee).
    Retorna True si se envió, False si falló.
    """
    try:
        if not EMAIL_REMITENTE or not EMAIL_PASSWORD:
            log_error("Credenciales correo no encontradas en env/clave_correo.env", archivo="notificador_email.py", funcion="enviar_email")
            return False

        msg = EmailMessage()
        if html:
            msg.add_alternative(html, subtype='html')
        else:
            msg.set_content(cuerpo)

        msg["Subject"] = asunto
        msg["From"] = EMAIL_REMITENTE
        msg["To"] = destino

        with smtplib.SMTP(EMAIL_SMTP, EMAIL_PUERTO, timeout=20) as server:
            server.starttls()
            server.login(EMAIL_REMITENTE, EMAIL_PASSWORD)
            server.send_message(msg)
        log_info(f"Email enviado a {destino} asunto='{asunto}'")
        return True
    except Exception as e:
        log_error(e, archivo="notificador_email.py", funcion="enviar_email")
        return False

# Alias
enviar_correo = enviar_email
