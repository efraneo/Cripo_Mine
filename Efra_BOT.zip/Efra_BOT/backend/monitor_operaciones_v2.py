# backend/monitor_operaciones_v2.py
"""
Monitor Avanzado v2 - vigilancia y cierre automático de operaciones.

Características:
- Polling configurable por símbolo (intervalo en segundos).
- Stop-loss dinámico (porcentaje o price-based) y Take-profit.
- Notificaciones a Telegram al abrir/cerrar/errores.
- Guarda log / estado en SQLite para visualización en Streamlit.
- Funciona tanto en modo DEMO (simula cierre) como REAL (intenta usar binance_client.place_market_order_with_stop).
- Dispara callbacks opcionales (funciones) cuando hay update para que la UI refresque si lo integra.

Uso (ejemplo):
    from backend.monitor_operaciones_v2 import MonitorOperaciones
    monitor = MonitorOperaciones(modo="DEMO", check_interval=20)
    monitor.start_monitor(operaciones_list)  # ejecuta en thread daemon

Notas:
- Streamlit no acepta que un thread modifique directamente UI; usamos DB/estado para que Streamlit lea.
- Requiere backend.telegram_notifier (para enviar mensajes).
"""
import os
import time
import threading
import sqlite3
import json
import datetime
from typing import List, Dict, Optional, Callable

from utils.logger import log_info, log_error
from backend.binance_client import obtener_datos_ohlcv, ejecutar_orden_simulada
from backend.telegram_notifier import enviar_mensaje

# Config por defecto
DEFAULT_CHECK_INTERVAL = 30  # segundos
DEFAULT_STOP_LOSS_PCT = 0.02  # 2%
DEFAULT_TAKE_PROFIT_PCT = 0.03  # 3%
DB_PATH = os.path.join("data", "monitor_operaciones.db")

# =========================
# HELPER DB
# =========================
def _ensure_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    cur = conn.cursor()
    cur.execute(
        """CREATE TABLE IF NOT EXISTS monitor_state (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               symbol TEXT,
               side TEXT,
               entry_price REAL,
               qty REAL,
               status TEXT,
               last_price REAL,
               pnl_pct REAL,
               started_at TEXT,
               updated_at TEXT,
               meta TEXT
           )"""
    )
    conn.commit()
    return conn

# =========================
# Monitor class
# =========================
class MonitorOperaciones:
    def __init__(
        self,
        modo: str = "DEMO",
        check_interval: int = DEFAULT_CHECK_INTERVAL,
        stop_loss_pct: float = DEFAULT_STOP_LOSS_PCT,
        take_profit_pct: float = DEFAULT_TAKE_PROFIT_PCT,
        telegram_notify: bool = True,
    ):
        self.modo = modo.upper()
        self.check_interval = check_interval
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._conn = _ensure_db()
        self._lock = threading.Lock()
        self.telegram_notify = telegram_notify

    # -------------------------
    # Estado / utilitarios DB
    # -------------------------
    def _insert_op(self, op: Dict):
        cur = self._conn.cursor()
        cur.execute(
            """INSERT INTO monitor_state (symbol, side, entry_price, qty, status, last_price, pnl_pct, started_at, updated_at, meta)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                op["symbol"],
                op["side"],
                float(op["entry_price"]),
                float(op["qty"]),
                "OPEN",
                float(op.get("entry_price", 0.0)),
                0.0,
                datetime.datetime.utcnow().isoformat(),
                datetime.datetime.utcnow().isoformat(),
                json.dumps(op.get("meta", {})),
            ),
        )
        self._conn.commit()
        return cur.lastrowid

    def _update_op(self, row_id: int, **kwargs):
        keys = []
        vals = []
        for k, v in kwargs.items():
            keys.append(f"{k} = ?")
            vals.append(v)
        vals.append(row_id)
        sql = f"UPDATE monitor_state SET {', '.join(keys)}, updated_at = ? WHERE id = ?"
        vals.insert(-1, datetime.datetime.utcnow().isoformat())  # updated_at before id
        cur = self._conn.cursor()
        cur.execute(sql, tuple(vals))
        self._conn.commit()

    def _delete_op(self, row_id: int):
        cur = self._conn.cursor()
        cur.execute("DELETE FROM monitor_state WHERE id = ?", (row_id,))
        self._conn.commit()

    def list_open_operations(self) -> List[Dict]:
        cur = self._conn.cursor()
        cur.execute("SELECT id, symbol, side, entry_price, qty, status, last_price, pnl_pct, started_at, updated_at, meta FROM monitor_state WHERE status = 'OPEN'")
        rows = cur.fetchall()
        cols = ["id", "symbol", "side", "entry_price", "qty", "status", "last_price", "pnl_pct", "started_at", "updated_at", "meta"]
        res = []
        for r in rows:
            d = dict(zip(cols, r))
            try:
                d["meta"] = json.loads(d.get("meta") or "{}")
            except Exception:
                d["meta"] = {}
            res.append(d)
        return res

    # -------------------------
    # Monitor core
    # -------------------------
    def start_monitor(self, operaciones: List[Dict], background: bool = True, callback: Optional[Callable[[Dict], None]] = None):
        """
        Inicia el monitor. `operaciones` es una lista de dicts con:
          { "symbol": str, "side": "BUY"/"SELL", "entry_price": float, "qty": float, "meta": {...} }
        - background: si True lanza en thread daemon
        - callback: función opcional que recibe cada evento de cierre/open/update
        """
        try:
            # insertar operaciones en DB
            with self._lock:
                for op in operaciones:
                    op_meta = op.copy()
                    op_meta.setdefault("meta", {})
                    self._insert_op(op_meta)

            self._running = True
            if background:
                self._thread = threading.Thread(target=self._monitor_loop, args=(callback,), daemon=True)
                self._thread.start()
            else:
                self._monitor_loop(callback)
            return True
        except Exception as e:
            log_error(e, archivo="monitor_operaciones_v2.py", funcion="start_monitor")
            return False

    def stop_monitor(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        log_info("Monitor detenido.")

    def _monitor_loop(self, callback: Optional[Callable[[Dict], None]] = None):
        log_info("Monitor iniciado (v2).")
        try:
            while self._running:
                open_ops = self.list_open_operations()
                if not open_ops:
                    # si no hay operaciones, dormir y re-check
                    time.sleep(self.check_interval)
                    continue

                for op in open_ops:
                    try:
                        symbol = op["symbol"]
                        side = op["side"]
                        entry_price = float(op["entry_price"])
                        qty = float(op["qty"])
                        row_id = int(op["id"])

                        # obtener último precio (1m)
                        df = obtener_datos_ohlcv(symbol, market="binance", periodo="1m", limite=3)
                        if df is None or df.empty:
                            time.sleep(1)
                            continue
                        last_price = float(df["close"].iloc[-1])

                        # calcular pnl relativo en la dirección correcta
                        pnl_pct = (last_price - entry_price) / entry_price if side == "BUY" else (entry_price - last_price) / entry_price
                        # actualizar estado en DB
                        self._update_op(row_id, last_price=last_price, pnl_pct=pnl_pct)

                        # preparar mensajes / acciones
                        # Stop-loss
                        if pnl_pct <= -abs(self.stop_loss_pct):
                            reason = "STOP_LOSS"
                            res = self._close_operation(op, last_price, reason)
                            if self.telegram_notify:
                                enviar_mensaje(self._format_close_message(op, last_price, pnl_pct, "Stop-Loss"))
                            if callback:
                                callback({"event": "closed", "row": op, "result": res})
                            continue

                        # Take-profit
                        if pnl_pct >= abs(self.take_profit_pct):
                            reason = "TAKE_PROFIT"
                            res = self._close_operation(op, last_price, reason)
                            if self.telegram_notify:
                                enviar_mensaje(self._format_close_message(op, last_price, pnl_pct, "Take-Profit"))
                            if callback:
                                callback({"event": "closed", "row": op, "result": res})
                            continue

                        # si llegó aquí, operación sigue abierta -> opcional callback update
                        if callback:
                            callback({"event": "update", "row": op, "last_price": last_price, "pnl_pct": pnl_pct})

                    except Exception as e:
                        log_error(e, archivo="monitor_operaciones_v2.py", funcion="_monitor_loop_inner")
                        continue

                time.sleep(self.check_interval)

        except Exception as e:
            log_error(e, archivo="monitor_operaciones_v2.py", funcion="_monitor_loop")
            if self.telegram_notify:
                enviar_mensaje(f"❌ Monitor error: {e}")

    # -------------------------
    # Cierre de operación
    # -------------------------
    def _close_operation(self, op: Dict, price: float, reason: str):
        """
        Cierra en DEMO (simulado) o REAL (intenta ejecutar orden inversa con stop).
        Actualiza DB y deja registro de cierre.
        """
        try:
            symbol = op["symbol"]
            side_close = "SELL" if op["side"] == "BUY" else "BUY"
            qty = float(op["qty"])

            if self.modo == "DEMO":
                # ejecuta cierre simulado
                res = ejecutar_orden_simulada(symbol, side_close, price * qty, modo="DEMO")
                status = "CLOSED_DEMO"
            else:
                # intentar cierre real (delegar a binance_client)
                try:
                    from backend.binance_client import place_market_order_with_stop
                    res = place_market_order_with_stop(
                        os.getenv("BINANCE_API_KEY"),
                        os.getenv("BINANCE_API_SECRET"),
                        symbol,
                        side_close,
                        price * qty,
                        stop_loss_pct=self.stop_loss_pct,
                        testnet=False,
                    )
                    status = "CLOSED_REAL"
                except Exception as e:
                    log_error(e, archivo="monitor_operaciones_v2.py", funcion="_close_operation_real")
                    # fallback demo
                    res = ejecutar_orden_simulada(symbol, side_close, price * qty, modo="DEMO")
                    status = "CLOSED_FALLBACK_DEMO"

            # actualizar DB: status, last_price, pnl_pct
            pnl_pct = (price - float(op["entry_price"])) / float(op["entry_price"]) if op["side"] == "BUY" else (float(op["entry_price"]) - price) / float(op["entry_price"])
            cur = self._conn.cursor()
            cur.execute(
                "UPDATE monitor_state SET status = ?, last_price = ?, pnl_pct = ?, updated_at = ?, meta = ? WHERE id = ?",
                (
                    status,
                    price,
                    pnl_pct,
                    datetime.datetime.utcnow().isoformat(),
                    json.dumps({"close_reason": reason, "raw_close_res": res}),
                    int(op["id"]),
                ),
            )
            self._conn.commit()

            log_info(f"Operación cerrada: {symbol} reason={reason} pnl={pnl_pct:.4f}")
            return {"status": status, "pnl_pct": pnl_pct, "raw": res}
        except Exception as e:
            log_error(e, archivo="monitor_operaciones_v2.py", funcion="_close_operation")
            return {"error": str(e)}

    # -------------------------
    # Mensajes formateados
    # -------------------------
    def _format_close_message(self, op: Dict, price: float, pnl_pct: float, title: str) -> str:
        try:
            now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            return (
                f"🔔 <b>{title}</b>\n"
                f"• Activo: {op['symbol']}\n"
                f"• Lado: {op['side']}\n"
                f"• Entrada: ${float(op['entry_price']):.4f}\n"
                f"• Precio cierre: ${price:.4f}\n"
                f"• PnL: {pnl_pct*100:.2f}%\n"
                f"• Tiempo: {now}"
            )
        except Exception as e:
            log_error(e, archivo="monitor_operaciones_v2.py", funcion="_format_close_message")
            return "Operación cerrada."

# =========================
# FUNCIONES CONVENIENCIA
# =========================
def start_monitor_background(operaciones: List[Dict], modo: str = "DEMO", check_interval: int = 30, stop_loss_pct: float = 0.02):
    """
    Conveniencia rápida para iniciar monitor en background sin manejar instancias.
    """
    try:
        moni = MonitorOperaciones(modo=modo, check_interval=check_interval, stop_loss_pct=stop_loss_pct)
        moni.start_monitor(operaciones, background=True)
        return moni
    except Exception as e:
        log_error(e, archivo="monitor_operaciones_v2.py", funcion="start_monitor_background")
        return None
