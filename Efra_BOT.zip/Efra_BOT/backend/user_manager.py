# backend/user_manager.py
"""
UserManager PRO (HARDENED)
- Control de usuarios
- IP lock (1 dispositivo)
- Aprobación explícita de IP
- Kill automático por cambio de IP
- Auditoría + IDS
- Notificación Telegram (PASO 11)
"""

import sqlite3
import hashlib
import os
from typing import List, Dict, Optional
from datetime import datetime
from backend.ids_manager import IDSManager
from backend.telegram_notifier import send_telegram_message, notify_security_event

# Logger
try:
    from backend.log_manager import get_logger
    log = get_logger("user_manager")
except Exception:
    import logging
    log = logging.getLogger("user_manager")


# ============================================================
# Helpers HASH
# ============================================================

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    pwd_hash = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt,
        200000
    )
    return salt.hex() + ":" + pwd_hash.hex()


def check_password(stored: str, password: str) -> bool:
    try:
        salt_hex, hash_hex = stored.split(":")
        salt = bytes.fromhex(salt_hex)
        check_hash = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            200000
        )
        return check_hash.hex() == hash_hex
    except Exception:
        return False


# ============================================================
# UserManager
# ============================================================

class UserManager:

    def __init__(self, db_path: str):
        self.db_path = db_path
        self._ensure_schema()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    # ========================================================
    # SCHEMA
    # ========================================================

    def _ensure_schema(self):
        with self._conn() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                email TEXT,
                full_name TEXT,
                password_hash TEXT,
                is_admin INTEGER DEFAULT 0,
                enabled INTEGER DEFAULT 1,
                created_at TEXT,
                ip_whitelist TEXT,
                last_ip TEXT,
                ip_verified INTEGER DEFAULT 0,
                has_membership INTEGER DEFAULT 0,
                membership_expires_at TEXT
            )
            """)
            c.commit()

    # ========================================================
    # GETTERS
    # ========================================================

    def get_user_by_username(self, username: str) -> Optional[Dict]:
        with self._conn() as c:
            cur = c.execute(
                "SELECT * FROM users WHERE username=?",
                (username,)
            )
            row = cur.fetchone()
            if not row:
                return None
            cols = [d[0] for d in cur.description]
            return dict(zip(cols, row))

    def list_users(self) -> List[Dict]:
        """
        Devuelve listado básico de usuarios registrados
        (solo lectura para panel admin).
        """
        try:
            with self._conn() as c:
                cur = c.execute("""
                    SELECT
                        id,
                        username,
                        email,
                        created_at,
                        last_ip,
                        enabled,
                        is_admin
                    FROM users
                    ORDER BY created_at DESC
                """)
                rows = cur.fetchall()
                cols = [d[0] for d in cur.description]
                return [dict(zip(cols, r)) for r in rows]
        except Exception:
            log.exception("list_users failed")
            return []

    # ========================================================
    # AUTH
    # ========================================================

    def validate_user(self, username: str, password: str) -> dict:
        """
        Autenticación PRO en dos fases.
        NO mezcla credenciales con reglas de entorno.
        """
        ids = IDSManager()
        u = self.get_user_by_username(username)

        if not u:
            ids.register_event(username, "-", "login_user_not_found", 20)
            return {"ok": False, "reason": "USER_NOT_FOUND"}

        if not u.get("enabled"):
            ids.register_event(username, "-", "login_user_disabled", 30)
            return {"ok": False, "reason": "USER_DISABLED"}

        if not check_password(u.get("password_hash", ""), password):
            ids.register_event(username, "-", "login_bad_password", 20)
            return {"ok": False, "reason": "BAD_PASSWORD"}

        # ✅ Credenciales correctas
        return {"ok": True, "user": u}

    # ========================================================
    # IP CONTROL (CRÍTICO)
    # ========================================================

    def update_last_ip(self, username: str, ip: str):
        """
        Registra IP detectada y revoca aprobación previa.
        """
        if not ip:
            return

        with self._conn() as c:
            c.execute("""
                UPDATE users
                SET last_ip=?, ip_verified=0
                WHERE username=?
            """, (str(ip), username))
            c.commit()

    def is_ip_allowed(self, username: str, ip: str) -> bool:
        u = self.get_user_by_username(username)
        if not u:
            return False

        if u.get("is_admin"):
            return True

        if not u.get("ip_verified"):
            return False

        wl = (u.get("ip_whitelist") or "").split(",")
        wl = [x.strip() for x in wl if x.strip()]

        return str(ip) in wl

    def approve_ip(self, username: str, ip: str):
        """
        Aprueba UNA SOLA IP (reemplaza whitelist).
        """
        if not ip:
            raise ValueError("IP inválida para aprobar")

        with self._conn() as c:
            c.execute("""
                UPDATE users
                SET ip_whitelist=?, ip_verified=1
                WHERE username=?
            """, (str(ip), username))
            c.commit()
    
    # ============================================================
    # CREATE USER
    # ============================================================

    def create_user(self, username, email, full_name, password, is_admin=0):
        pwd_hash = hash_password(password)
        with self._conn() as c:
            c.execute("""
                INSERT INTO users
                (username, email, full_name, password_hash,
                 is_admin, enabled, created_at)
                VALUES (?, ?, ?, ?, ?, 1, ?)
            """, (
                username,
                email,
                full_name,
                pwd_hash,
                is_admin,
                datetime.utcnow().isoformat()
            ))
            c.commit()

    # ============================================================
    # ENABLE USER
    # ============================================================
    def enable_user(self, username):
        with self._conn() as c:
            c.execute(
                "UPDATE users SET enabled=1 WHERE username=?",
                (username,)
            )
            c.commit()

    # ============================================================
    # DISABLE USER
    # ============================================================
    def disable_user(self, username):
        with self._conn() as c:
            c.execute(
                "UPDATE users SET enabled=0 WHERE username=?",
                (username,)
            )
            c.commit()

    # ============================================================
    # DELETE USER
    # ============================================================
    def delete_user(self, username):
        with self._conn() as c:
            c.execute(
                "DELETE FROM users WHERE username=?",
                (username,)
            )
            c.commit()

    # ============================================================
    # GET ALL USERS
    # ============================================================

    def get_all_users(self):
        """
        Devuelve todos los usuarios desde la base de datos
        """
        return self.list_users()

