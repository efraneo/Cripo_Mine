# backend/session_timer.py
"""
SessionTimer - manejar sesiones de 120 minutos por usuario.
Tabla: sessions (session_id, username, started_at, expires_at, closed_at, closed_reason)
"""

import sqlite3
from datetime import datetime, timedelta
import uuid
import os

try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

DB_DEFAULT = os.path.join("data","usuarios.db")

class SessionTimer:
    def __init__(self, db_path: str = DB_DEFAULT):
        self.db_path = db_path
        self._ensure()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _ensure(self):
        with self._conn() as c:
            c.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                username TEXT,
                started_at TEXT,
                expires_at TEXT,
                closed_at TEXT,
                closed_reason TEXT
            )""")
            c.commit()

    def start_session(self, username: str, minutes: int = 120) -> str:
        sid = str(uuid.uuid4())
        now = datetime.utcnow()
        exp = now + timedelta(minutes=minutes)
        with self._conn() as c:
            c.execute("INSERT INTO sessions (session_id,username,started_at,expires_at) VALUES (?,?,?,?)",
                      (sid, username, now.isoformat(), exp.isoformat()))
            c.commit()
        return sid

    def get_time_left(self, session_id: str) -> int:
        with self._conn() as c:
            r = c.execute("SELECT expires_at, closed_at FROM sessions WHERE session_id=?", (session_id,)).fetchone()
            if not r:
                return 0
            expires_at, closed_at = r
            if closed_at:
                return 0
            exp = datetime.fromisoformat(expires_at)
            delta = exp - datetime.utcnow()
            return max(0, int(delta.total_seconds()//60))

    def list_active_sessions(self):
        with self._conn() as c:
            rows = c.execute("SELECT session_id,username,started_at,expires_at FROM sessions WHERE closed_at IS NULL").fetchall()
            return [{"session_id": r[0], "username": r[1], "started_at": r[2], "expires_at": r[3]} for r in rows]

    def close_session(self, session_id: str, reason: str = "timeout"):
        now = datetime.utcnow().isoformat()
        with self._conn() as c:
            c.execute("UPDATE sessions SET closed_at=?, closed_reason=? WHERE session_id=?", (now, reason, session_id))
            c.commit()
        # notify user and admin (placeholder)
        if telegram_send:
            telegram_send(f"Sesión {session_id} cerrada: {reason}")

def expire_sessions_check(self):
    """
    Revisa sesiones activas. Si alguna expiró:
    1. Se cierra la sesión.
    2. Se calcula el P&L de la operación.
    3. Se registra el resultado en SQLite (results).
    4. Se envían notificaciones al usuario y al administrador.
    """

    from backend.order_manager import OrderManager
    from backend.results_manager import ResultsManager
    from backend.binance_client import BinanceClient

    om = OrderManager()
    rm = ResultsManager()
    bc = BinanceClient()

    with self._conn() as c:
        rows = c.execute("""
            SELECT session_id, username, symbol, entry_price, qty, opened_at, expires_at
            FROM sessions
            WHERE closed_at IS NULL
        """).fetchall()

        for sid, user, symbol, entry_price, qty, opened_at, exp in rows:
            # verificar expiración
            if datetime.fromisoformat(exp) <= datetime.utcnow():

                # ---------------------------------------------------------
                # obtener precio actual del mercado para cierre
                # ---------------------------------------------------------
                try:
                    precio_actual = bc.get_symbol_price(symbol)
                except Exception:
                    precio_actual = entry_price  # fallback seguro

                # ---------------------------------------------------------
                # cerrar sesión
                # ---------------------------------------------------------
                self.close_session(sid, motivo="timeout")

                # ---------------------------------------------------------
                # registrar el resultado en results.sqlite
                # ---------------------------------------------------------
                try:
                    rm.save_result(
                        user_id=user,
                        symbol=symbol,
                        entry_price=entry_price,
                        exit_price=precio_actual,
                        qty=qty,
                        opened_at=opened_at,
                        closed_at=datetime.utcnow().isoformat(),
                        session_id=sid,
                        notes="Cierre automático por sesión expirada"
                    )
                except Exception as e:
                    if telegram_send:
                        telegram_send(f"[ERROR] No se pudo registrar P&L de sesión expirada: {e}")

                # ---------------------------------------------------------
                # notificaciones
                # ---------------------------------------------------------
                mensaje = (
                    f"⏳ Sesión expirada para usuario **{user}**\n"
                    f"Session ID: {sid}\n"
                    f"Símbolo: {symbol}\n"
                    f"Precio entrada: {entry_price}\n"
                    f"Precio cierre: {precio_actual}\n"
                    f"Cantidad: {qty}\n"
                    f"Resultado (USD): {round((precio_actual - entry_price) * qty, 4)}"
                )

                if telegram_send:
                    telegram_send(mensaje)
