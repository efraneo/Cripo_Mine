# backend/circuit_breaker.py

from backend.log_manager import get_logger

log = get_logger("circuit_breaker")


class CircuitBreaker:
    """
    Institutional Dynamic Risk Scaling based on Drawdown
    """

    def __init__(self):

        # Thresholds institucionales
        self.thresholds = [

            (0.25, 0.0),   # 25% DD → stop trading
            (0.20, 0.25),  # 20% DD → 25% risk
            (0.10, 0.50),  # 10% DD → 50% risk
            (0.05, 0.75),  # 5% DD  → 75% risk
            (0.00, 1.00),  # normal
        ]

    # =====================================================
    # GET RISK SCALE
    # =====================================================

    def get_risk_scale(self, drawdown: float) -> float:

        for dd_threshold, scale in self.thresholds:

            if drawdown >= dd_threshold:

                if scale == 0.0:
                    log.critical(
                        "Circuit breaker STOP TRADING | DD: %.2f%%",
                        drawdown * 100
                    )
                else:
                    log.warning(
                        "Circuit breaker scaling risk | DD: %.2f%% → scale %.2f",
                        drawdown * 100,
                        scale
                    )

                return scale

        return 1.0