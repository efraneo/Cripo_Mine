# backend/results_manager.py

import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional


DB_PATH = "data/usuarios.db"


class ResultsManager:

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._ensure_table()

    # -----------------------------------------------------------
    # Crear tabla si no existe
    # -----------------------------------------------------------
    def _ensure_table(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        c.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            symbol TEXT NOT NULL,
            entry_price REAL NOT NULL,
            exit_price REAL NOT NULL,
            qty REAL NOT NULL,
            pnl REAL NOT NULL,
            roi REAL NOT NULL,
            opened_at TEXT NOT NULL,
            closed_at TEXT NOT NULL,
            session_id TEXT,
            notes TEXT
        );
        """)

        conn.commit()
        conn.close()

    # -----------------------------------------------------------
    # Registrar resultado de una operación REAL o DEMO
    # -----------------------------------------------------------
    def save_result(
        self,
        user_id: str,
        symbol: str,
        entry_price: float,
        exit_price: float,
        qty: float,
        opened_at: str,
        closed_at: Optional[str] = None,
        session_id: Optional[str] = None,
        notes: Optional[str] = None
    ) -> Dict[str, Any]:

        if closed_at is None:
            closed_at = datetime.utcnow().isoformat()

        pnl = round((exit_price - entry_price) * qty, 4)
        roi = round(((exit_price - entry_price) / entry_price) * 100, 3)

        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        c.execute("""
            INSERT INTO results (user_id, symbol, entry_price, exit_price, qty,
            pnl, roi, opened_at, closed_at, session_id, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id, symbol, entry_price, exit_price, qty,
            pnl, roi, opened_at, closed_at, session_id, notes
        ))

        conn.commit()
        conn.close()

        return {
            "user_id": user_id,
            "symbol": symbol,
            "entry_price": entry_price,
            "exit_price": exit_price,
            "qty": qty,
            "pnl": pnl,
            "roi": roi,
            "opened_at": opened_at,
            "closed_at": closed_at,
            "session_id": session_id
        }

    # -----------------------------------------------------------
    # Ranking por periodo
    # -----------------------------------------------------------
    def ranking(self, period: str = "month") -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        # Filtro temporal
        filter_sql = {
            "day":   "DATE(closed_at) = DATE('now')",
            "week":  "strftime('%W', closed_at) = strftime('%W', 'now')",
            "month": "strftime('%m', closed_at) = strftime('%m', 'now')",
            "all":   "1=1"
        }[period]

        c.execute(f"""
            SELECT user_id, SUM(pnl) AS total_pnl, SUM(roi) AS total_roi, COUNT(*)
            FROM results
            WHERE {filter_sql}
            GROUP BY user_id
            ORDER BY total_pnl DESC;
        """)

        rows = c.fetchall()
        conn.close()

        result = []
        for r in rows:
            result.append({
                "user_id": r[0],
                "total_pnl": r[1],
                " total_roi": r[2],
                "trades": r[3]
            })

        return result

    # -----------------------------------------------------------
    # Obtener historial por usuario
    # -----------------------------------------------------------
    def get_user_results(self, user_id: str) -> List[Dict[str, Any]]:
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()

        c.execute("""
            SELECT symbol, entry_price, exit_price, qty, pnl, roi,
                   opened_at, closed_at, session_id, notes
            FROM results
            WHERE user_id = ?
            ORDER BY closed_at DESC
        """, (user_id,))

        rows = c.fetchall()
        conn.close()

        return [
            {
                "symbol": r[0],
                "entry_price": r[1],
                "exit_price": r[2],
                "qty": r[3],
                "pnl": r[4],
                "roi": r[5],
                "opened_at": r[6],
                "closed_at": r[7],
                "session_id": r[8],
                "notes": r[9],
            }
            for r in rows
        ]
