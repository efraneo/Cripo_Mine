# backend/patrones_velas.py
# Detector robusto de patrones de velas (adaptado)
import logging
from typing import List
import pandas as pd
import numpy as np

_logger = logging.getLogger("patrones_velas")
if not _logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | [patrones] %(message)s"))
    _logger.addHandler(ch)
    _logger.setLevel(logging.INFO)

try:
    import talib
    _HAS_TALIB = True
except Exception:
    _HAS_TALIB = False
    _logger.info("TA-Lib no disponible — usando heurísticas en patrones_velas.py")

def _last_row(df: pd.DataFrame) -> pd.Series:
    return df.iloc[-1] if (df is not None and not df.empty) else pd.Series()

def _is_doji(open_, close_, high_, low_, threshold=0.1) -> bool:
    size = abs(high_ - low_)
    if size == 0:
        return False
    cuerpo = abs(close_ - open_)
    return (cuerpo / size) <= threshold

def _hammer(open_, high_, low_, close_) -> bool:
    cuerpo = abs(close_ - open_)
    cola_inferior = min(open_, close_) - low_
    cola_superior = high_ - max(open_, close_)
    return (cola_inferior >= 2*cuerpo) and (cola_superior <= cuerpo)

def _shooting_star(open_, high_, low_, close_) -> bool:
    cuerpo = abs(close_ - open_)
    cola_superior = high_ - max(open_, close_)
    cola_inferior = min(open_, close_) - low_
    return (cola_superior >= 2*cuerpo) and (cola_inferior <= cuerpo)

def _engulfing(prev_o, prev_c, o, c) -> str:
    if (c > o) and (prev_c < prev_o) and (c > prev_o) and (o < prev_c):
        return "bull"
    if (c < o) and (prev_c > prev_o) and (c < prev_o) and (o > prev_c):
        return "bear"
    return ""

def _three_white_soldiers(df: pd.DataFrame) -> bool:
    if len(df) < 3:
        return False
    last3 = df.iloc[-3:]
    if not all(last3['close'] > last3['open']):
        return False
    corpos = (last3['close'] - last3['open']).abs()
    return (corpos.iloc[2] > corpos.iloc[1] > corpos.iloc[0])

def _three_black_crows(df: pd.DataFrame) -> bool:
    if len(df) < 3:
        return False
    last3 = df.iloc[-3:]
    if not all(last3['close'] < last3['open']):
        return False
    corpos = (last3['open'] - last3['close']).abs()
    return (corpos.iloc[2] > corpos.iloc[1] > corpos.iloc[0])

def detectar_patrones_velas(df: pd.DataFrame) -> List[str]:
    patrones = []
    try:
        if df is None or df.empty:
            return ["⚠️ DataFrame vacío o inválido."]
        required_columns = {'open', 'high', 'low', 'close'}
        if not required_columns.issubset(set(df.columns)):
            return ["⚠️ Faltan columnas necesarias para detectar patrones de velas."]
        if _HAS_TALIB:
            try:
                talib_funcs = {
                    'CDLHAMMER': talib.CDLHAMMER,
                    'CDLSHOOTINGSTAR': talib.CDLSHOOTINGSTAR,
                    'CDLENGULFING': talib.CDLENGULFING,
                    'CDLDOJI': talib.CDLDOJI,
                    'CDLMORNINGSTAR': getattr(talib, 'CDLMORNINGSTAR', None),
                    'CDLEVENINGSTAR': getattr(talib, 'CDLEVENINGSTAR', None),
                    'CDL3WHITESOLDIERS': getattr(talib, 'CDL3WHITESOLDIERS', None),
                    'CDL3BLACKCROWS': getattr(talib, 'CDL3BLACKCROWS', None),
                    'CDLPIERCING': getattr(talib, 'CDLPIERCING', None),
                    'CDLDARKCLOUDCOVER': getattr(talib, 'CDLDARKCLOUDCOVER', None),
                    'CDLHARAMI': getattr(talib, 'CDLHARAMI', None),
                }
                o = df['open'].values
                h = df['high'].values
                l = df['low'].values
                c = df['close'].values
                for name, func in talib_funcs.items():
                    if func is None:
                        continue
                    try:
                        res = func(o, h, l, c)
                        if len(res) and res[-1] != 0:
                            label = name.replace('CDL', '')
                            patrones.append(label.title())
                    except Exception:
                        continue
                if patrones:
                    return patrones
            except Exception as e:
                _logger.warning(f"TA-Lib falló al detectar patrones: {e}")
        # Heurísticas locales
        if len(df) >= 1:
            last = df.iloc[-1]
            o, h, l, c = float(last['open']), float(last['high']), float(last['low']), float(last['close'])
            if _is_doji(o, c, h, l, threshold=0.15):
                patrones.append("Doji")
            if _hammer(o, h, l, c):
                patrones.append("Hammer")
            if _shooting_star(o, h, l, c):
                patrones.append("ShootingStar")
        if len(df) >= 2:
            prev = df.iloc[-2]
            direction = _engulfing(prev['open'], prev['close'], df.iloc[-1]['open'], df.iloc[-1]['close'])
            if direction == "bull":
                patrones.append("EngulfingBull")
            elif direction == "bear":
                patrones.append("EngulfingBear")
        try:
            if _three_white_soldiers(df):
                patrones.append("ThreeWhiteSoldiers")
            if _three_black_crows(df):
                patrones.append("ThreeBlackCrows")
        except Exception:
            pass
        if len(df) >= 2:
            prev = df.iloc[-2]
            last = df.iloc[-1]
            if (prev['close'] < prev['open']) and (last['close'] > last['open']) and (last['close'] > (prev['open'] + prev['close'])/2):
                patrones.append("Piercing")
            if (prev['close'] > prev['open']) and (last['close'] < last['open']) and (last['close'] < (prev['open'] + prev['close'])/2):
                patrones.append("DarkCloudCover")
        if len(df) >= 2:
            prev = df.iloc[-2]
            last = df.iloc[-1]
            if (prev['close'] < prev['open']) and (last['close'] > last['open']) and (last['open'] > prev['close']) and (last['close'] < prev['open']):
                patrones.append("HaramiBull")
            if (prev['close'] > prev['open']) and (last['close'] < last['open']) and (last['open'] < prev['close']) and (last['close'] > prev['open']):
                patrones.append("HaramiBear")
        if len(df) >= 2:
            prev = df.iloc[-2]
            last = df.iloc[-1]
            if abs(prev['high'] - last['high']) / max(prev['high'], last['high']) < 0.001:
                patrones.append("TweezerTop")
            if abs(prev['low'] - last['low']) / max(prev['low'], last['low']) < 0.001:
                patrones.append("TweezerBottom")
        patrones = list(dict.fromkeys([p for p in patrones if p]))
        if not patrones:
            return ["No pattern detected"]
        return patrones
    except Exception as e:
        _logger.error(f"❌ Error en detectar_patrones_velas: {e}")
        return [f"Error detecting patterns: {e}"]
