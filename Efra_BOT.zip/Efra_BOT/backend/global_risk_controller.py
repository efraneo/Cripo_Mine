# backend/global_risk_controller.py

import os
import json
import logging
from datetime import datetime

log = logging.getLogger("GLOBAL_RISK")


class GlobalRiskController:

    def __init__(self):

        self.max_global_exposure_pct = 0.60
        self.max_concurrent_trades = 7
        self.max_drawdown_pct = 0.25

        self.data_file = os.path.join("data", "global_risk_state.json")

        self.state = {
            "peak_equity": 0,
            "current_equity": 0,
            "drawdown": 0,
            "blocked": False
        }

        self._load()

    # ==========================================
    # LOAD / SAVE
    # ==========================================

    def _load(self):

        try:

            if os.path.exists(self.data_file):

                with open(self.data_file, "r") as f:
                    self.state = json.load(f)

        except Exception:

            log.exception("Failed loading global risk state")

    def _save(self):

        try:

            with open(self.data_file, "w") as f:
                json.dump(self.state, f, indent=2)

        except Exception:

            log.exception("Failed saving global risk state")

    # ==========================================
    # EQUITY UPDATE
    # ==========================================

    def update_equity(self, equity):

        self.state["current_equity"] = equity

        if equity > self.state["peak_equity"]:

            self.state["peak_equity"] = equity

        peak = self.state["peak_equity"]

        if peak > 0:

            dd = (peak - equity) / peak

            self.state["drawdown"] = dd

            if dd >= self.max_drawdown_pct:

                self.state["blocked"] = True

                log.critical(
                    "GLOBAL RISK BLOCKED - MAX DRAWDOWN REACHED",
                    extra={"drawdown": dd}
                )

        self._save()

    # ==========================================
    # VALIDATION
    # ==========================================

    def can_open_trade(self, active_trades, equity, new_trade_size):

        if self.state["blocked"]:

            return False, "global_blocked"

        if len(active_trades) >= self.max_concurrent_trades:

            return False, "max_concurrent_trades"

        total_exposure = sum(
            t.get("usdt", 0)
            for t in active_trades.values()
        )

        if (total_exposure + new_trade_size) / equity > self.max_global_exposure_pct:

            return False, "max_exposure"

        return True, "ok"

    # ==========================================
    # MANUAL RESET
    # ==========================================

    def reset_block(self):

        self.state["blocked"] = False

        self._save()

        log.warning("GLOBAL RISK RESET")