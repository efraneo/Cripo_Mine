# ============================================================
# backend/config_loader.py
# Cargador ÚNICO de variables de entorno para TODO el BOT
# ============================================================

import os
from dotenv import load_dotenv

# Evita recargar .env múltiples veces
if not os.environ.get("__EFRA_ENV_LOADED__"):
    load_dotenv("binance.env")
    load_dotenv("credenciales.env")
    load_dotenv("telegram.env")
    load_dotenv("clave_correo.env")

    os.environ["__EFRA_ENV_LOADED__"] = "1"
    print("[config_loader] Variables cargadas una sola vez.")

# ============================================================
# VARIABLES PARA BINANCE (REAL MAINNET)
# ============================================================

BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET", "")
BINANCE_USE_TESTNET = False  # 🔥 Siempre REAL

if not BINANCE_API_KEY or not BINANCE_API_SECRET:
    print("[config_loader] ⚠️ ADVERTENCIA: API Keys de Binance no están definidas.")

# URL PRINCIPAL REAL (MAINNET)
BINANCE_BASE_URL = "https://api.binance.com"

# ============================================================
# FORMATEO UNIFICADO PARA EL RESTO DEL SISTEMA
# ============================================================

CONFIG = {
    "binance": {
        "api_key": BINANCE_API_KEY,
        "api_secret": BINANCE_API_SECRET,
        "testnet": BINANCE_USE_TESTNET,
        "base_url": BINANCE_BASE_URL,
    }
}

def get_config():
    return CONFIG
