# ============================================================
# backend/auth_utils.py  (Versión PRO 2025)
# ============================================================

import sqlite3
import os
import time
import hmac
import hashlib
import secrets
from datetime import datetime, timedelta

DB = os.path.join(os.path.dirname(__file__), "..", "data", "usuarios.db")

LOCK_THRESHOLD = 5             # intentos fallidos permitidos
LOCK_WINDOW_SEC = 300          # 5 minutos
LOCK_DURATION_SEC = 600        # 10 minutos
TWO_FA_TTL = 300               # token 2FA válido 5 min
RESET_TTL = 86400              # reset válido 24h


# ============================================================
#   CONEXIÓN
# ============================================================

def _conn():
    return sqlite3.connect(DB)


# ============================================================
#   SELF-HEALING: CREAR TODAS LAS TABLAS NECESARIAS
# ============================================================

def _ensure_tables():
    with _conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS failed_logins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip TEXT,
            ts TEXT
        )
        """)

        c.execute("""
        CREATE TABLE IF NOT EXISTS lockouts (
            username TEXT PRIMARY KEY,
            until_ts INTEGER
        )
        """)

        c.execute("""
        CREATE TABLE IF NOT EXISTS twofa_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            token TEXT,
            expires_at INTEGER,
            created_at INTEGER
        )
        """)

        c.execute("""
        CREATE TABLE IF NOT EXISTS reset_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            token TEXT,
            expires_at INTEGER,
            created_at INTEGER
        )
        """)

        c.commit()

# Crear tablas al importar módulo
_ensure_tables()


# ============================================================
#     FAILED ATTEMPTS & LOCKOUTS
# ============================================================

def record_failed_attempt(username: str, ip: str = None):
    cutoff = (datetime.utcnow() - timedelta(seconds=LOCK_WINDOW_SEC)).isoformat()

    with _conn() as c:
        c.execute("INSERT INTO failed_logins(username, ip, ts) VALUES (?,?,?)",
                  (username, ip or "", datetime.utcnow().isoformat()))

        count = c.execute("""
            SELECT COUNT(*) FROM failed_logins
            WHERE username=? AND ts>=?
        """, (username, cutoff)).fetchone()[0]

        if count >= LOCK_THRESHOLD:
            until = int((datetime.utcnow() + timedelta(seconds=LOCK_DURATION_SEC)).timestamp())
            c.execute("""
                INSERT OR REPLACE INTO lockouts(username, until_ts)
                VALUES(?,?)
            """, (username, until))

        c.commit()


def clear_failed_attempts(username: str):
    with _conn() as c:
        c.execute("DELETE FROM failed_logins WHERE username=?", (username,))
        c.execute("DELETE FROM lockouts WHERE username=?", (username,))
        c.commit()


def is_locked(username: str):
    with _conn() as c:
        r = c.execute("SELECT until_ts FROM lockouts WHERE username=?", (username,)).fetchone()
        if not r:
            return None

        until = r[0]
        now = int(time.time())

        if until > now:
            return until

        # limpiar lockout expirado
        c.execute("DELETE FROM lockouts WHERE username=?", (username,))
        c.commit()
        return None


# ============================================================
#  PASSWORD CHECK (PBKDF2 / compatible con UserManager PRO)
# ============================================================

def password_ok(username: str, password: str) -> bool:
    """
    Para compatibilidad con UserManager PRO.
    Devuelve False si no existe hash o si el usuario está deshabilitado.
    """

    with _conn() as c:
        r = c.execute("SELECT password_hash, enabled FROM users WHERE username=?",
                      (username,)).fetchone()
        if not r:
            return False

        stored, enabled = r
        if not enabled:
            return False
        if not stored:
            return False

    try:
        salt_hex, hash_hex = stored.split(":")
        salt = bytes.fromhex(salt_hex)

        chk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000)

        return chk.hex() == hash_hex
    except Exception:
        return False


# ============================================================
#                2FA TOKENS
# ============================================================

def make_2fa_token(username: str) -> str:
    token = "%06d" % secrets.randbelow(1_000_000)
    expires = int(time.time() + TWO_FA_TTL)

    with _conn() as c:
        c.execute("""
            INSERT INTO twofa_tokens(username, token, expires_at, created_at)
            VALUES (?,?,?,?)
        """, (username, token, expires, int(time.time())))
        c.commit()

    return token


def validate_2fa_token(username: str, token: str) -> bool:
    with _conn() as c:
        r = c.execute("""
            SELECT token, expires_at
            FROM twofa_tokens
            WHERE username=?
            ORDER BY created_at DESC
            LIMIT 1
        """, (username,)).fetchone()

    if not r:
        return False

    tok, exp = r
    now = int(time.time())

    if now > exp:
        return False

    return secrets.compare_digest(tok, token)


# ============================================================
#             RESET TOKENS
# ============================================================

def create_reset_token(db_path: str, username: str) -> str:
    token = secrets.token_urlsafe(32)
    expires = int(time.time() + RESET_TTL)

    with _conn() as c:
        c.execute("""
            INSERT INTO reset_tokens(username, token, expires_at, created_at)
            VALUES (?,?,?,?)
        """, (username, token, expires, int(time.time())))
        c.commit()

    return token


def validate_reset_token(username: str, token: str) -> bool:
    with _conn() as c:
        r = c.execute("""
            SELECT token, expires_at
            FROM reset_tokens
            WHERE username=?
            ORDER BY created_at DESC
            LIMIT 1
        """, (username,)).fetchone()

    if not r:
        return False

    tok, exp = r
    now = int(time.time())

    if now > exp:
        return False

    return secrets.compare_digest(tok, token)
