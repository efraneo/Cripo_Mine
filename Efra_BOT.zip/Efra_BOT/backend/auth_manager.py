"""
backend/auth_manager.py — Autenticación y políticas PRO

Funciones / API expuestas (compatibles con tu código existente):
 - is_locked(username) -> int|None    # devuelve timestamp unix until_ts o None
 - record_failed_attempt(username, ip=None)
 - clear_failed_attempts(username)
 - make_2fa_token(username, ttl_sec=300) -> str
 - validate_2fa_token(username, token) -> bool
 - generate_reset_token(username, ttl_sec=1800) -> str
 - validate_reset_token(username, token) -> bool

Clase:
 - AuthManager(db_path="data/usuarios.db")

Características:
 - Registro de intentos fallidos con bloqueo temporal (lockout)
 - 2FA token generación/validación (almacenado en twofa_tokens)
 - Reset tokens (reset_tokens)
 - Helpers seguros (secrets, hashing, tiempo UTC)
 - Integración con telegram_notifier (envío tolerante)
 - Logs con backend/log_manager.py
"""

from __future__ import annotations

import os
import sqlite3
import time
import secrets
import string
from datetime import datetime, timedelta
from typing import Optional

from backend.log_manager import get_logger

from backend.security_engine import SecurityEngine


# Optional integrations (no obligatorias)
try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

# DB path — coincide con otros módulos
DB_PATH = os.getenv("USERS_DB_PATH", os.path.join("data", "usuarios.db"))

# Lockout policy (configurable via env)
FAILED_WINDOW_SEC = int(os.getenv("AUTH_FAILED_WINDOW_SEC", "300"))     # ventana para contaje (ej: 5 min)
FAILED_MAX_ATTEMPTS = int(os.getenv("AUTH_FAILED_MAX_ATTEMPTS", "5"))   # intentos fallidos máximos en ventana
LOCKOUT_SEC = int(os.getenv("AUTH_LOCKOUT_SEC", "900"))                 # bloqueo al alcanzar max (ej: 15 min)
TWOFA_TTL = int(os.getenv("AUTH_2FA_TTL_SEC", "300"))                  # 2FA token TTL (5 min)
RESET_TTL = int(os.getenv("AUTH_RESET_TTL_SEC", "1800"))               # reset token TTL (30 min)

log = get_logger("auth_manager")


def _conn(path: str = None):
    p = path or DB_PATH
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return sqlite3.connect(p, detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)


class AuthManager:
    """
    Clase que encapsula la lógica de autenticación y políticas.
    """

    def __init__(self, db_path: str = None):
        self.db_path = db_path or DB_PATH
        # Ensure tables exist (some are created elsewhere but guard here)
        self.security = SecurityEngine()
        self._ensure_tables()

    def _ensure_tables(self):
        with _conn(self.db_path) as c:
            # failed_logins: id, username, ip, ts
            c.execute("""
            CREATE TABLE IF NOT EXISTS failed_logins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                ip TEXT,
                ts INTEGER
            )
            """)
            # lockouts: username primary, until_ts int
            c.execute("""
            CREATE TABLE IF NOT EXISTS lockouts (
                username TEXT PRIMARY KEY,
                until_ts INTEGER
            )
            """)
            # twofa_tokens: username, token, expires_at, created_at
            c.execute("""
            CREATE TABLE IF NOT EXISTS twofa_tokens (
                username TEXT,
                token TEXT,
                expires_at INTEGER,
                created_at INTEGER
            )
            """)
            # reset_tokens: username, token, expires_at, created_at
            c.execute("""
            CREATE TABLE IF NOT EXISTS reset_tokens (
                username TEXT,
                token TEXT,
                expires_at INTEGER,
                created_at INTEGER
            )
            """)
            c.commit()

    # ---------------------------
    # Failed attempts & lockouts
    # ---------------------------
    def record_failed_attempt(self, username: str, ip: Optional[str] = None):
        """Registra intento fallido y aplica lockout si corresponde."""
        now = int(time.time())
        with _conn(self.db_path) as c:
            # insert attempt
            c.execute("INSERT INTO failed_logins (username, ip, ts) VALUES (?, ?, ?)", (username, ip or "", now))
            c.commit()

            if ip:
                try:
                    self.security.record_failed_login(ip)
                except Exception:
                    pass

            # count recent attempts
            window_start = now - FAILED_WINDOW_SEC
            cur = c.execute("SELECT COUNT(*) FROM failed_logins WHERE username=? AND ts>=?", (username, window_start))
            cnt = cur.fetchone()[0] if cur else 0

            log.info("Failed attempts for %s in window: %s", username, cnt, extra={"user": username, "ip": ip or "-"})

            if cnt >= FAILED_MAX_ATTEMPTS:
                until = now + LOCKOUT_SEC
                # upsert into lockouts
                c.execute("INSERT OR REPLACE INTO lockouts (username, until_ts) VALUES (?, ?)", (username, until))
                c.commit()
                # Optionally notify (non-blocking)
                try:
                    msg = f"🔒 Cuenta bloqueada: usuario={username}. Bloqueo hasta {datetime.utcfromtimestamp(until).isoformat()} UTC"
                    _try_telegram_send(msg)
                except Exception:
                    pass

    def clear_failed_attempts(self, username: str):
        """Elimina intentos fallidos (por ejemplo tras login exitoso)."""
        with _conn(self.db_path) as c:
            c.execute("DELETE FROM failed_logins WHERE username=?", (username,))
            # also remove lockout if present
            c.execute("DELETE FROM lockouts WHERE username=?", (username,))
            c.commit()
            log.info("Cleared failed attempts & lockouts for %s", username, extra={"user": username})

    def is_locked(self, username: str) -> Optional[int]:
        """Devuelve until_ts (timestamp unix) si está bloqueado; sino None."""
        now = int(time.time())
        with _conn(self.db_path) as c:
            r = c.execute("SELECT until_ts FROM lockouts WHERE username=?", (username,)).fetchone()
            if not r:
                return None
            until_ts = int(r[0])
            if until_ts <= now:
                # expired -> remove
                c.execute("DELETE FROM lockouts WHERE username=?", (username,))
                c.commit()
                return None
            return until_ts

    # ---------------------------
    # 2FA tokens
    # ---------------------------
    def make_2fa_token(self, username: str, ttl_sec: int = TWOFA_TTL) -> str:
        """
        Genera token 2FA de 6 dígitos y lo guarda con expiración.
        """
        token = "{:06d}".format(secrets.randbelow(10**6))

        now = int(time.time())
        exp = now + int(ttl_sec)

        with _conn(self.db_path) as c:

            c.execute(
                """
                INSERT INTO twofa_tokens
                (username, token, expires_at, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (username, token, exp, now)
            )

            c.commit()

        log.info(
            "2FA token generado",
            extra={"user": username}
        )

        return token

    def validate_2fa_token(self, username: str, token: str, ip: str = None) -> bool:
        """
        Valida token 2FA almacenado.
        """

        risk = self.security.compute_ip_risk(ip, username)

        if risk >= 60:
            self.security.log_security_event(
                username,
                ip,
                "LOGIN_BLOCKED_RISK",
                risk
            )
            return False

        now = int(time.time())

        with _conn(self.db_path) as c:

            cur = c.execute(
                """
                SELECT token, expires_at
                FROM twofa_tokens
                WHERE username=?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (username,)
            )

            row = cur.fetchone()

            if not row:
                log.warning("2FA token inexistente", extra={"user": username})
                return False

            db_token, expires_at = row

            if now > expires_at:
                log.warning("2FA token expirado", extra={"user": username})
                return False

            if token != db_token:
                log.warning("2FA token inválido", extra={"user": username})
                return False

            # token correcto → eliminar tokens usados
            c.execute(
                "DELETE FROM twofa_tokens WHERE username=?",
                (username,)
            )

            c.commit()

        log.info(
            "2FA validado correctamente",
            extra={"user": username, "ip": ip or "-"}
        )

        return True

    def generate_reset_token(self, username: str, ttl_sec: int = RESET_TTL) -> str:
        """
        Genera token seguro para reset de contraseña.
        """

        alphabet = string.ascii_letters + string.digits
        token = "".join(secrets.choice(alphabet) for _ in range(48))

        now = int(time.time())
        exp = now + int(ttl_sec)

        with _conn(self.db_path) as c:

            c.execute(
                """
                INSERT INTO reset_tokens
                (username, token, expires_at, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (username, token, exp, now)
            )

            c.commit()

        log.info(
            "Reset token generado",
            extra={"user": username}
        )

        return token

    def validate_reset_token(self, username: str, token: str) -> bool:
        """
        Valida token de recuperación de contraseña.
        """

        now = int(time.time())

        with _conn(self.db_path) as c:

            cur = c.execute(
                """
                SELECT token, expires_at
                FROM reset_tokens
                WHERE username=?
                ORDER BY created_at DESC
                LIMIT 1
                """,
                (username,)
            )

            row = cur.fetchone()

            if not row:
                return False

            db_token, expires_at = row

            if now > expires_at:
                return False

            if token != db_token:
                return False

            # eliminar token usado
            c.execute(
                "DELETE FROM reset_tokens WHERE username=?",
                (username,)
            )

            c.commit()

        log.info(
            "Reset token validado",
            extra={"user": username}
        )

        return True

