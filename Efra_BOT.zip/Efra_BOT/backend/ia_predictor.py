# backend/ia_predictor.py
"""
IAPredictor robusto — ensemble LGBM / XGBoost / MLP + fallback heuristics
- Lee models/ meta.json (feature_order, weights, threshold)
- predict_proba(sample:dict) -> float 0..1
- predict_signal(sample:dict) -> "BUY"/"SELL"/"HOLD"
- calibrate threshold helper
- reload_threshold
"""

import os
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

import numpy as np

logger = logging.getLogger("ia_predictor")
if not logger.handlers:
    fh = logging.FileHandler("ia_predictor.log")
    fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(fh)
logger.setLevel(logging.INFO)

BASE = Path(os.getcwd())
MODELS_DIR = BASE / "models"
LGB_PATH = MODELS_DIR / "model_lgbm.txt"
XGB_PATH = MODELS_DIR / "model_xgb.json"
MLP_PATH = MODELS_DIR / "model_mlp.joblib"
META_PATH = MODELS_DIR / "meta.json"
THRESHOLD_PATH = MODELS_DIR / "threshold.json"


def _try_import(name: str):
    try:
        module = __import__(name)
        return module
    except Exception:
        logger.debug("Module %s not available.", name)
        return None


def load_meta() -> Dict[str, Any]:
    if META_PATH.exists():
        try:
            with open(META_PATH, "r", encoding="utf-8") as f:
                m = json.load(f)
                return m if isinstance(m, dict) else {}
        except Exception as e:
            logger.exception("Error loading meta.json: %s", e)
            return {}
    return {}


def load_threshold(path: Path = THRESHOLD_PATH) -> float:
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
                return float(d.get("threshold", 0.5))
    except Exception as e:
        logger.warning("Could not load threshold: %s", e)
    return 0.5


def save_threshold(value: float, path: Path = THRESHOLD_PATH):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"threshold": float(value)}, f)
        logger.info("Saved threshold %s to %s", value, str(path))
    except Exception as e:
        logger.exception("Could not save threshold: %s", e)


class IAPredictor:
    def __init__(self, models_dir: Optional[str] = None):
        if models_dir:
            self.models_dir = Path(models_dir)
        else:
            self.models_dir = MODELS_DIR

        self.meta = load_meta()
        self.feature_order: List[str] = self.meta.get("feature_order", [
            "open", "high", "low", "close", "volume",
            "ma_fast", "ma_slow", "rsi", "macd", "macd_signal", "atr"
        ])
        # weights for ensemble (keys: lgb, xgb, mlp)
        self.weights: Dict[str, float] = self.meta.get("weights", {"lgb": 0.4, "xgb": 0.4, "mlp": 0.2})
        self.threshold: float = load_threshold()

        # models
        self.lgb = None
        self.xgb = None
        self.mlp = None

        # try loading models
        self._load_models()

        logger.info("IAPredictor initialized. models_dir=%s threshold=%s", str(self.models_dir), self.threshold)

    def _load_models(self):
        # LightGBM
        lgb = _try_import("lightgbm")
        if lgb and (LGB_PATH.exists()):
            try:
                self.lgb = lgb.Booster(model_file=str(LGB_PATH))
                logger.info("Loaded LightGBM model from %s", str(LGB_PATH))
            except Exception as e:
                logger.exception("Failed loading LightGBM: %s", e)

        # XGBoost
        xgb = _try_import("xgboost")
        if xgb and XGB_PATH.exists():
            try:
                # support both native Booster JSON and sklearn wrapper
                try:
                    from xgboost import XGBClassifier
                    clf = XGBClassifier()
                    clf.load_model(str(XGB_PATH))
                    self.xgb = clf
                except Exception:
                    # fallback to Booster
                    booster = xgb.Booster()
                    booster.load_model(str(XGB_PATH))
                    self.xgb = booster
                logger.info("Loaded XGBoost model from %s", str(XGB_PATH))
            except Exception as e:
                logger.exception("Failed loading XGBoost: %s", e)

        # MLP / sklearn
        joblib = _try_import("joblib")
        if joblib and MLP_PATH.exists():
            try:
                self.mlp = joblib.load(str(MLP_PATH))
                logger.info("Loaded MLP model from %s", str(MLP_PATH))
            except Exception as e:
                logger.exception("Failed loading MLP: %s", e)

    def _vectorize(self, sample: Dict[str, Any]) -> np.ndarray:
        # ensure deterministic ordering
        vals = []
        for f in self.feature_order:
            v = sample.get(f, 0)
            try:
                vals.append(float(v))
            except Exception:
                vals.append(0.0)
        arr = np.array(vals, dtype=float).reshape(1, -1)
        return arr

    def predict_proba(self, sample: Dict[str, Any]) -> float:
        """
        sample: dict of features (keys in feature_order)
        returns: probability float in [0,1] of BUY
        """
        try:
            x = self._vectorize(sample)
        except Exception as e:
            logger.exception("Vectorize failed: %s", e)
            x = None

        probs: List[float] = []
        weights: List[float] = []

        # LGB
        if self.lgb is not None and x is not None:
            try:
                p = float(self.lgb.predict(x)[0])
                probs.append(p)
                weights.append(self.weights.get("lgb", 1.0))
            except Exception as e:
                logger.debug("LGB predict error: %s", e)

        # XGB
        if self.xgb is not None and x is not None:
            try:
                # if sklearn wrapper exists it has predict_proba
                if hasattr(self.xgb, "predict_proba"):
                    p = float(self.xgb.predict_proba(x)[0][1])
                else:
                    # Booster -> create DMatrix
                    import xgboost as xgb
                    dm = xgb.DMatrix(x, feature_names=self.feature_order)
                    p = float(self.xgb.predict(dm)[0])
                probs.append(p)
                weights.append(self.weights.get("xgb", 1.0))
            except Exception as e:
                logger.debug("XGB predict error: %s", e)

        # MLP
        if self.mlp is not None and x is not None:
            try:
                # sklearn style
                p = float(self.mlp.predict_proba(x)[0][1])
                probs.append(p)
                weights.append(self.weights.get("mlp", 1.0))
            except Exception as e:
                logger.debug("MLP predict error: %s", e)

        # Weighted average if any model produced
        try:
            if probs and weights:
                probs_arr = np.array(probs, dtype=float)
                w_arr = np.array(weights, dtype=float)
                wavg = float(np.sum(probs_arr * w_arr) / (np.sum(w_arr) + 1e-12))
                # clamp numeric stability
                wavg = max(0.0, min(1.0, wavg))
                return wavg
        except Exception as e:
            logger.exception("Weighted avg fail: %s", e)

        # Fallback heuristic: simple rules -> return reasonable prob
        try:
            score = 0.5
            rsi = float(sample.get("rsi", 50.0))
            ma_fast = float(sample.get("ma_fast", sample.get("ema_fast", 0.0)))
            ma_slow = float(sample.get("ma_slow", sample.get("ema_slow", 0.0)))
            macd = float(sample.get("macd", 0.0))
            macd_signal = float(sample.get("macd_signal", 0.0))

            if ma_fast > ma_slow:
                score += 0.12
            else:
                score -= 0.12

            if macd > macd_signal:
                score += 0.08
            else:
                score -= 0.08

            # RSI contrarian: lower rsi -> higher buy prob (simple)
            score += (50.0 - rsi) / 200.0
            score = max(0.01, min(0.99, score))
            return float(score)
        except Exception as e:
            logger.exception("Heuristic fallback fail: %s", e)
            return 0.5

    def predict_signal(self, sample: Dict[str, Any], threshold: Optional[float] = None) -> str:
        if threshold is None:
            threshold = self.threshold
        try:
            p = float(self.predict_proba(sample))
        except Exception:
            p = 0.5
        if p >= threshold:
            return "BUY"
        if p <= (1.0 - threshold):
            return "SELL"
        return "HOLD"

    def reload_threshold(self, path: Optional[str] = None):
        try:
            self.threshold = load_threshold(Path(path) if path else THRESHOLD_PATH)
            logger.info("Threshold reloaded: %s", self.threshold)
        except Exception as e:
            logger.exception("reload_threshold error: %s", e)

    def calibrate_threshold(self, y_true: List[int], y_proba: List[float], metric: str = "precision", target: float = 0.85) -> float:
        # uses sklearn.metrics
        try:
            from sklearn.metrics import precision_score, recall_score, f1_score
            ys = np.asarray(y_true)
            ps = np.asarray(y_proba)
            best_th = 0.5
            best_val = -1.0
            for th in np.linspace(0.01, 0.99, 99):
                ypred = (ps >= th).astype(int)
                if metric == "precision":
                    val = precision_score(ys, ypred, zero_division=0)
                elif metric == "recall":
                    val = recall_score(ys, ypred, zero_division=0)
                else:
                    val = f1_score(ys, ypred, zero_division=0)
                if val > best_val:
                    best_val = val
                    best_th = th
                if val >= target:
                    break
            save_threshold(best_th)
            self.threshold = float(best_th)
            logger.info("Calibrated threshold=%s (metric=%s best_val=%s)", best_th, metric, best_val)
            return float(best_th)
        except Exception as e:
            logger.exception("calibrate_threshold fail: %s", e)
            return self.threshold
