# backend/stats_manager.py
"""
StatsManager - cálculos sobre inversiones en SQLite
"""

import sqlite3
from typing import List, Dict
from datetime import datetime
import os

DB_DEFAULT = os.path.join("data","usuarios.db")

class StatsManager:
    def __init__(self, db_path: str = DB_DEFAULT):
        self.db_path = db_path

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def get_total_invested_by_period(self, start_date, end_date) -> List[Dict]:
        # start_date and end_date are date/datetime or string
        s = start_date.isoformat() if hasattr(start_date, "isoformat") else str(start_date)
        e = end_date.isoformat() if hasattr(end_date, "isoformat") else str(end_date)
        with self._conn() as c:
            rows = c.execute("""
                SELECT username, SUM(amount) as total
                FROM investments
                WHERE date(ts) BETWEEN date(?) AND date(?)
                GROUP BY username
                ORDER BY total DESC
            """, (s, e)).fetchall()
            return [{"username": r[0], "total_invested": r[1]} for r in rows]

    # --------------- NEW SAFE AUTO-CHECK LOOP ---------------
    def run_auto_expirer(self, interval_sec: int = 60):
        """
        Hilo seguro que revisa cada X segundos sesiones vencidas.
        Se ejecuta en background desde Streamlit.
        No bloquea UI.
        """
        import threading, time

        def _loop():
            while True:
                try:
                    self.expire_sessions_check()
                except Exception as e:
                    if telegram_send:
                        telegram_send(f"[ERROR] auto-expirer: {e}")
                time.sleep(interval_sec)

        th = threading.Thread(target=_loop, daemon=True)
        th.start()
        return th
