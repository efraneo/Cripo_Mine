# backend/binance_core.py
"""
binance_core.py

Refactor del BLOQUE A1 original de tu binance_client.py.
Contiene:
 - Carga global de .env (carpeta env/)
 - Imports y flags (_BINANCE_AVAILABLE, _YF_AVAILABLE)
 - Helpers comunes (safe_float, _simular_ohlcv)
 - Rutas y locks para I/O (data/, usuarios/, operaciones/)
 - Lectura de credenciales BBE (_leer_bbe_from_paths)
 - Creación de cliente por usuario (get_binance_client_for_user)
 - Registro y gestión de operaciones (record_user_operation_start, get_user_first_real_op_ts,
   check_time_limit_exceeded, mark_operation_closed)
 - Utilidades de parsing de timestamps
 - __all__ con los nombres expuestos (mantenemos compatibilidad con el original)
Notas:
 - No se elimina ni altera la lógica: es una reubicación del BLOQUE A1 original, con
   algunos safeguards en logging y excepciones.
"""

from __future__ import annotations
from typing import Optional, Tuple, Dict, Any, List
import os
import time
import math
import json
import datetime
import threading
import pandas as pd
import numpy as np
from pathlib import Path

# dotenv para cargar env files en env/
from dotenv import load_dotenv

# -------------------------
# Logger: preferir utils.logger si existe
# -------------------------
try:
    from utils.logger import log_info, log_error
except Exception:
    def log_info(msg, archivo=None, funcion=None):
        prefix = f"[{archivo or 'binance_core'}::{funcion or ''}]"
        print(f"{datetime.datetime.utcnow().isoformat()} [INFO] {prefix} {msg}")
    def log_error(e, archivo=None, funcion=None):
        prefix = f"[{archivo or 'binance_core'}::{funcion or ''}]"
        print(f"{datetime.datetime.utcnow().isoformat()} [ERROR] {prefix} {e}")

# -------------------------
# GLOBAL ENV LOADING (once per process)
# -------------------------
def _cargar_env_global(path_env_dir: str = "env"):
    """
    Carga todos los .env del directorio (no sobrescribe variables ya definidas).
    """
    try:
        if os.path.isdir(path_env_dir):
            for f in sorted(os.listdir(path_env_dir)):
                if f.endswith(".env"):
                    full = os.path.join(path_env_dir, f)
                    try:
                        load_dotenv(full, override=False)
                        log_info(f"✅ Variables cargadas desde {f}", archivo="binance_core.py", funcion="_cargar_env_global")
                    except Exception as e:
                        log_error(e, archivo="binance_core.py", funcion="_cargar_env_global")
            log_info("🌍 Variables de entorno cargadas correctamente.", archivo="binance_core.py", funcion="_cargar_env_global")
        else:
            log_info("No se encontró carpeta env; asumiendo variables de entorno ya cargadas.", archivo="binance_core.py", funcion="_cargar_env_global")
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="_cargar_env_global")

# Ejecutar carga global solo una vez
if "BINANCE_CORE_ENV_LOADED" not in globals():
    try:
        _cargar_env_global("env")
        globals()["BINANCE_CORE_ENV_LOADED"] = True
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="global_env_load")

# -------------------------
# Intento importar python-binance y yfinance (opcional)
# -------------------------
_BINANCE_AVAILABLE = False
try:
    from binance.client import Client as _BinanceClient
    from binance.exceptions import BinanceAPIException, BinanceOrderException
    _BINANCE_AVAILABLE = True
    log_info("python-binance disponible.", archivo="binance_core.py", funcion="imports")
except Exception as e:
    _BINANCE_AVAILABLE = False
    log_info("python-binance no disponible: funciones reales de orden estarán deshabilitadas (usar DEMO).", archivo="binance_core.py", funcion="imports")

_YF_AVAILABLE = False
try:
    import yfinance as yf  # type: ignore
    _YF_AVAILABLE = True
    log_info("yfinance disponible.", archivo="binance_core.py", funcion="imports")
except Exception:
    _YF_AVAILABLE = False
    log_info("yfinance no disponible: fallback a simulación para datos OHLCV.", archivo="binance_core.py", funcion="imports")

# -------------------------
# UTIL HELPERS
# -------------------------
def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        return float(x)
    except Exception:
        return default

def _simular_ohlcv(limite: int = 200, seed: int = 0) -> pd.DataFrame:
    """
    Generador de OHLCV sintético (demo) — útil para pruebas offline.
    """
    np.random.seed(seed or int(time.time()) % 100000)
    end = datetime.datetime.utcnow()
    # frecuencia por defecto: H (horaria)
    t = pd.date_range(end=end, periods=limite, freq="H")
    base = 100 + np.cumsum(np.random.randn(limite) * 0.5)
    open_ = base + np.random.randn(limite) * 0.2
    close = base + np.random.randn(limite) * 0.2
    high = np.maximum(open_, close) + np.abs(np.random.randn(limite) * 0.5)
    low = np.minimum(open_, close) - np.abs(np.random.randn(limite) * 0.5)
    volume = np.abs(np.random.randn(limite) * 1000)
    df = pd.DataFrame({
        "time": t,
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": volume
    })
    return df

# -------------------------
# RUTAS Y LOCKS PARA I/O
# -------------------------
BASE_DIR = os.path.abspath(os.getcwd())
DATA_DIR = os.path.join(BASE_DIR, "data")
USUARIOS_DIR = os.path.join(DATA_DIR, "usuarios")
OPERACIONES_DIR = os.path.join(DATA_DIR, "operaciones")  # registros de operaciones activas / stamps
os.makedirs(USUARIOS_DIR, exist_ok=True)
os.makedirs(OPERACIONES_DIR, exist_ok=True)

# Locks en memoria para evitar escritura concurrente del mismo archivo (por proceso)
_file_locks: Dict[str, threading.Lock] = {}
_file_locks_lock = threading.Lock()

def _get_lock_for_path(path: str) -> threading.Lock:
    """
    Obtener (y crear si es necesario) un lock por ruta para accesos locales.
    No funciona entre procesos — para eso usar un lock file externo si se necesita.
    """
    with _file_locks_lock:
        key = os.path.abspath(path)
        if key not in _file_locks:
            _file_locks[key] = threading.Lock()
        return _file_locks[key]

# -------------------------
# LECTURA DE CREDENCIALES (BBE)
# -------------------------
def _leer_bbe_from_paths(usuario_identifier: str, local_path: Optional[str] = None) -> Optional[Dict[str, str]]:
    """
    Intenta cargar credenciales BBE (CSV) en prioridad:
    1) local_path (archivo en dispositivo del usuario)
    2) servidor: data/usuarios/BBE_{usuario_identifier}.csv
    3) variables de entorno globales (BINANCE_API_KEY / BINANCE_API_SECRET)
    Retorna dict de credenciales o None.
    """
    try:
        # 1) local (expande ~)
        if local_path:
            try:
                local_path_exp = os.path.expanduser(local_path)
                if os.path.exists(local_path_exp):
                    df = pd.read_csv(local_path_exp, dtype=str)
                    if not df.empty:
                        row = df.iloc[0].to_dict()
                        log_info(f"BBE cargado desde local: {local_path_exp}", archivo="binance_core.py", funcion="_leer_bbe_from_paths")
                        return {k.strip(): str(v).strip() for k, v in row.items() if pd.notna(v)}
            except Exception as e:
                log_error(e, archivo="binance_core.py", funcion="_leer_bbe_from_paths_local")

        # 2) servidor
        try:
            servidor_path = os.path.join(USUARIOS_DIR, f"BBE_{usuario_identifier}.csv")
            if os.path.exists(servidor_path):
                df = pd.read_csv(servidor_path, dtype=str)
                if not df.empty:
                    row = df.iloc[0].to_dict()
                    log_info(f"BBE cargado desde servidor: {servidor_path}", archivo="binance_core.py", funcion="_leer_bbe_from_paths")
                    return {k.strip(): str(v).strip() for k, v in row.items() if pd.notna(v)}
        except Exception as e:
            log_error(e, archivo="binance_core.py", funcion="_leer_bbe_from_paths_servidor")

        # 3) variables de entorno
        env_key = os.getenv("BINANCE_API_KEY") or os.getenv("API_KEY") or None
        env_secret = os.getenv("BINANCE_API_SECRET") or os.getenv("API_SECRET") or None
        if env_key and env_secret:
            log_info("Usando credenciales BINANCE desde variables de entorno globales.", archivo="binance_core.py", funcion="_leer_bbe_from_paths")
            return {"API_KEY": env_key, "API_SECRET": env_secret, "TESTNET": str(os.getenv("MODO_DEMO", "True"))}

        return None
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="_leer_bbe_from_paths")
        return None

# -------------------------
# CREAR CLIENTE BINANCE POR USUARIO
# -------------------------
def get_binance_client_for_user(usuario: Optional[Dict] = None, local_bbe_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    Intenta construir cliente de python-binance para el usuario.
    Retorna dict: {"client": BinanceClient, "testnet": bool, "api_key":..., "api_secret":...}
    o None si no hay credenciales o python-binance no está instalado.
    """
    try:
        user_id = None
        if usuario:
            # usa 'usuario' campo (ID), si no usar correo/nombre como fallback
            user_id = str(usuario.get("usuario") or usuario.get("id") or usuario.get("correo") or usuario.get("nombre"))

        creds = _leer_bbe_from_paths(user_id or "master", local_path=local_bbe_path)
        if not creds:
            log_info("No se encontraron credenciales BBE para el usuario.", archivo="binance_core.py", funcion="get_binance_client_for_user")
            return None

        api_key = creds.get("API_KEY") or creds.get("KEY") or creds.get("BINANCE_API_KEY")
        api_secret = creds.get("API_SECRET") or creds.get("SECRET") or creds.get("BINANCE_API_SECRET")
        testnet_flag = str(creds.get("TESTNET", creds.get("MODO_DEMO", "True"))).lower() in ("true", "1", "yes", "y")

        if not api_key or not api_secret:
            log_info("Credenciales incompletas para Binance (API_KEY/API_SECRET faltantes).", archivo="binance_core.py", funcion="get_binance_client_for_user")
            return None

        if not _BINANCE_AVAILABLE:
            log_info("python-binance no instalado; no se puede crear cliente real.", archivo="binance_core.py", funcion="get_binance_client_for_user")
            return None

        client = _BinanceClient(api_key, api_secret)
        log_info(f"Cliente Binance creado para usuario {user_id} (testnet={testnet_flag}).", archivo="binance_core.py", funcion="get_binance_client_for_user")
        return {"client": client, "testnet": testnet_flag, "api_key": api_key, "api_secret": api_secret}
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="get_binance_client_for_user")
        return None

# -------------------------
# REGISTRO / GESTIÓN DE PRIMERA OPERACIÓN REAL (para límite 120 minutos)
# -------------------------
def _user_operations_file(usuario_identifier: str) -> str:
    """
    Ruta JSON por usuario donde se almacenan operaciones activas y metadata.
    """
    safe_user = str(usuario_identifier or "unknown").replace("/", "_")
    return os.path.join(OPERACIONES_DIR, f"{safe_user}.json")

def record_user_operation_start(usuario_identifier: str, operation_id: str, symbol: str, is_real: bool = True, timestamp: Optional[str] = None) -> bool:
    """
    Registra una operación (estructura mínima) en data/operaciones/{user}.json.
    """
    try:
        path = _user_operations_file(usuario_identifier)
        lock = _get_lock_for_path(path)
        with lock:
            now = timestamp or datetime.datetime.utcnow().isoformat()
            data = {"operations": [], "first_real_op_ts": None}
            if os.path.exists(path):
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f) or data
                except Exception:
                    data = {"operations": [], "first_real_op_ts": None}

            op = {
                "id": operation_id,
                "symbol": symbol,
                "is_real": bool(is_real),
                "timestamp": now,
                "status": "OPEN"
            }
            data.setdefault("operations", []).append(op)

            # Si es real y first_real_op_ts no existe, fijarla
            if is_real and not data.get("first_real_op_ts"):
                data["first_real_op_ts"] = now
                log_info(f"Primera operación real registrada para {usuario_identifier} en {now}", archivo="binance_core.py", funcion="record_user_operation_start")

            # Guardar
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="record_user_operation_start")
        return False

def get_user_first_real_op_ts(usuario_identifier: str) -> Optional[str]:
    """
    Devuelve la timestamp ISO de la primera operación real registrada para el usuario (si existe).
    """
    try:
        path = _user_operations_file(usuario_identifier)
        lock = _get_lock_for_path(path)
        with lock:
            if not os.path.exists(path):
                return None
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("first_real_op_ts")
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="get_user_first_real_op_ts")
        return None

def _parse_iso(ts: str) -> Optional[datetime.datetime]:
    try:
        return datetime.datetime.fromisoformat(ts)
    except Exception:
        try:
            return datetime.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S.%f")
        except Exception:
            try:
                return datetime.datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S")
            except Exception:
                return None

def check_time_limit_exceeded(usuario_identifier: str, limit_minutes: int = 120) -> Tuple[bool, Optional[float]]:
    """
    Comprueba si el usuario excedió el tiempo límite (limit_minutes) desde su primera operación real.
    Retorna (excedido_bool, minutes_elapsed or None)
    """
    try:
        ts = get_user_first_real_op_ts(usuario_identifier)
        if not ts:
            return False, None
        dt = _parse_iso(ts)
        if not dt:
            return False, None
        now = datetime.datetime.utcnow()
        elapsed = (now - dt).total_seconds() / 60.0
        exceeded = elapsed >= float(limit_minutes)
        return exceeded, elapsed
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="check_time_limit_exceeded")
        return False, None

# -------------------------
# FUNCIONES AUXILIARES PARA MARCAR OPERACIONES COMO CERRADAS
# -------------------------
def mark_operation_closed(usuario_identifier: str, operation_id: str, close_info: Optional[Dict[str, Any]] = None) -> bool:
    """
    Marca una operación en el archivo del usuario como 'CLOSED' y agrega close_info (dict) si se da.
    """
    try:
        path = _user_operations_file(usuario_identifier)
        lock = _get_lock_for_path(path)
        with lock:
            if not os.path.exists(path):
                return False
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            ops = data.get("operations", [])
            changed = False
            for o in ops:
                if o.get("id") == operation_id:
                    o["status"] = "CLOSED"
                    o["closed_at"] = datetime.datetime.utcnow().isoformat()
                    if close_info:
                        o["close_info"] = close_info
                    changed = True
            # Optionally, if no more open real operations exist, clear first_real_op_ts
            still_open_real = any(o.get("status") == "OPEN" and o.get("is_real") for o in ops)
            if not still_open_real:
                data["first_real_op_ts"] = None
            data["operations"] = ops
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        return changed
    except Exception as e:
        log_error(e, archivo="binance_core.py", funcion="mark_operation_closed")
        return False

# -------------------------
# EXPORTS (core)
# -------------------------
__all__ = [
    # env + helpers
    "_cargar_env_global",
    "safe_float",
    "_simular_ohlcv",
    # BBE & client
    "_leer_bbe_from_paths",
    "get_binance_client_for_user",
    # operaciones / tiempo-límite
    "record_user_operation_start",
    "get_user_first_real_op_ts",
    "check_time_limit_exceeded",
    "mark_operation_closed",
    # paths/constants (útiles para otras partes)
    "DATA_DIR",
    "USUARIOS_DIR",
    "OPERACIONES_DIR",
]
