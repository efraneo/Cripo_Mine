"""
backend/risk_manager.py
Sistema de Gestión de Riesgo PRO – 2025
Autor: Efra BOT AI Upgrade

Este módulo controla:
✔ Tamaño de posición (DCA, compuesto, fixed fractional, ATR, Kelly modificado)
✔ Stop loss automático (por defecto 2%, configurable)
✔ Take profits escalonados (TP1, TP2, TP3, TP4)
✔ Exposición global del portafolio
✔ Límite diario y mensual de pérdidas
✔ Validación Anti-OverTrading
✔ Modo live/paper/backtest
✔ Integración con Binance Manager

Usos en tu flujo:
    rm = RiskManager()
    order_payload = rm.generate_trade_parameters(
        symbol="BTCUSDT",
        price=43250.00,
        side="BUY",
        strategy="DCA",
        risk_pct=0.01,
        stop_loss_pct=0.02
    )
    # luego se envía al order_manager/binance_manager
"""

from __future__ import annotations
import math
import time
import statistics
from typing import Dict, Any, Optional, List

try:
    from backend.log_manager import get_logger
    log = get_logger("risk_manager")
except:
    import logging
    log = logging.getLogger("risk_manager")
    if not log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(h)
    log.setLevel(logging.INFO)


class RiskManager:
    """
    Clase principal para la gestión de riesgo profesional.
    """

    def __init__(
        self,
        max_portfolio_risk: float = 0.10,    # 10% exposición global
        max_trade_risk: float = 0.02,        # 2% por trade (STOP default)
        max_daily_loss: float = 0.04,        # 4% máximo del día
        max_monthly_loss: float = 0.15,      # 15% máximo al mes
        max_positions: int = 10,             # máximo posiciones simultáneas
        allow_compound: bool = True,
        mode: str = "live"                   # live | paper | backtest
    ):
        self.max_portfolio_risk = max_portfolio_risk
        self.max_trade_risk = max_trade_risk
        self.max_daily_loss = max_daily_loss
        self.max_monthly_loss = max_monthly_loss
        self.max_positions = max_positions
        self.allow_compound = allow_compound
        self.mode = mode

        # estadísticas internas
        self.daily_losses = 0.0
        self.monthly_losses = 0.0
        self.open_positions: Dict[str, Dict] = {}

        log.info(
            "RiskManager inicializado | mode=%s maxTrade=%.3f maxPortfolio=%.3f",
            self.mode, self.max_trade_risk, self.max_portfolio_risk
        )

    # ---------------------------------------------------------------------
    # Utilidades internas
    # ---------------------------------------------------------------------

    def _check_overtrading(self) -> bool:
        """Evita exceso de operaciones."""
        if len(self.open_positions) >= self.max_positions:
            log.warning("Bloqueado: max_positions=%d alcanzado", self.max_positions)
            return False
        return True

    def _check_daily_monthly_limits(self) -> bool:
        if self.daily_losses <= -abs(self.max_daily_loss):
            log.error("Bloqueado: límite de pérdida diaria excedido")
            return False
        if self.monthly_losses <= -abs(self.max_monthly_loss):
            log.error("Bloqueado: límite de pérdida mensual excedido")
            return False
        return True

    def _kelly_fraction(self, winrate: float, rr: float) -> float:
        """
        Kelly Modificado:
        winrate: 0-1
        rr: riesgo:recompensa
        """
        try:
            k = winrate - ((1 - winrate) / rr)
            return max(0.0, min(k, 0.20))   # limite 20%
        except:
            return 0.0

    def _bayesian_kelly(
        self,
        winrate: float,
        rr: float,
        confidence: float,
        drawdown: float
    ) -> float:
        """
        Kelly Bayesian Institucional con penalización por drawdown.
        """

        if rr <= 0:
            return 0.0

        adj_win = winrate * (confidence / 100)
        risk_penalty = max(0.3, 1 - drawdown * 2)

        edge = (adj_win * rr) - (1 - adj_win)
        kelly = edge / rr

        kelly *= risk_penalty

        return max(0.0, min(kelly, 0.25))

    def _regime_scale(self, kelly_fraction: float, regime: Optional[str]) -> float:
        """
        Escala la fracción Kelly según régimen de mercado.
        """

        scale_map = {
            "CRISIS": 0.2,
            "HIGH_VOL": 0.4,
            "TREND_BULL": 1.0,
            "TREND_BEAR": 0.7,
            "RANGE": 0.5
        }

        if not regime:
            return kelly_fraction * 0.5  # Default conservador

        scale = scale_map.get(regime.upper(), 0.3)

        return max(0.0, kelly_fraction * scale)


    def _calculate_atr_position(self, atr: float, capital: float, price: float) -> float:
        """
        Tamaño basado en volatilidad (ATR).
        """
        if atr <= 0:
            return 0
        risk_per_unit = atr
        qty = (capital * self.max_trade_risk) / risk_per_unit
        return qty

    # ---------------------------------------------------------------------
    # Tamaño de posición PRO
    # ---------------------------------------------------------------------
    def calculate_position_size(
        self,
        capital: float,
        price: float,
        strategy: str,
        volatility: Optional[float] = None,
        winrate: Optional[float] = None,
        confidence: Optional[float] = None,
        drawdown: Optional[float] = None,
        rr: Optional[float] = None,
        regime: Optional[str] = None
    ) -> float:
        """
        Calcula el tamaño óptimo según estrategia.
        """
        if capital <= 0 or price <= 0:
            return 0

        if strategy.upper() == "DCA":
            pos = (capital * self.max_trade_risk) / price

        elif strategy.upper() == "COMPOUND":
            if not self.allow_compound:
                pos = (capital * self.max_trade_risk) / price
            else:
                pos = (capital * (self.max_trade_risk * 1.8)) / price  

        elif strategy.upper() == "ATR":
            pos = self._calculate_atr_position(volatility or 0.0, capital, price)

        elif strategy.upper() == "KELLY":
            base_fraction = self._bayesian_kelly(
                winrate=winrate or 0.50,
                rr=rr or 1.5,
                confidence=confidence or 70,
                drawdown=drawdown or 0.0
            )

            regime_fraction = self._regime_scale(
                kelly_fraction=base_fraction,
                regime=regime
            )

            pos = (capital * regime_fraction) / price

        else:  # FALLBACK
            pos = (capital * self.max_trade_risk) / price

        return max(pos, 0)

    # ---------------------------------------------------------------------
    # Stop Loss y Take Profits (TP1..TP4)
    # ---------------------------------------------------------------------
    def generate_stops_and_targets(
        self,
        price: float,
        side: str,
        stop_loss_pct: float = None
    ) -> Dict[str, float]:

        sl_pct = stop_loss_pct if stop_loss_pct else self.max_trade_risk

        if side.upper() == "BUY":
            sl = price * (1 - sl_pct)
            tps = {
                "TP1": price * 1.015,
                "TP2": price * 1.030,
                "TP3": price * 1.050,
                "TP4": price * 1.080,
            }
        else:
            sl = price * (1 + sl_pct)
            tps = {
                "TP1": price * 0.985,
                "TP2": price * 0.970,
                "TP3": price * 0.950,
                "TP4": price * 0.920,
            }

        return {
            "stop_loss": round(sl, 6),
            **{k: round(v, 6) for k, v in tps.items()}
        }

    # ---------------------------------------------------------------------
    # Generación de payload final para la orden
    # ---------------------------------------------------------------------
    def generate_trade_parameters(
        self,
        symbol: str,
        price: float,
        side: str,
        strategy: str,
        capital: float = 1000,
        risk_pct: float = None,
        stop_loss_pct: float = None,
        volatility: Optional[float] = None,
        winrate: Optional[float] = None,
        rr: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Genera todo lo necesario para enviar al order_manager/binance_manager.
        """

        # Validaciones previas
        if not self._check_overtrading():
            return {"error": "Overtrading detected"}
        if not self._check_daily_monthly_limits():
            return {"error": "Risk limits exceeded"}

        risk_pct = risk_pct or self.max_trade_risk

        # Tamaño óptimo
        qty = self.calculate_position_size(
            capital=capital,
            price=price,
            strategy=strategy,
            volatility=volatility,
            winrate=winrate,
            rr=rr
        )

        stops_targets = self.generate_stops_and_targets(
            price=price,
            side=side,
            stop_loss_pct=stop_loss_pct
        )

        payload = {
            "symbol": symbol,
            "side": side.upper(),
            "type": "MARKET",
            "quantity": round(qty, 6),
            "entry_price": price,
            "strategy": strategy,
            "stop_loss": stops_targets["stop_loss"],
            "take_profits": {
                "TP1": stops_targets["TP1"],
                "TP2": stops_targets["TP2"],
                "TP3": stops_targets["TP3"],
                "TP4": stops_targets["TP4"],
            },
            "timestamp": int(time.time())
        }

        log.info(
            "TradeParameters | %s | qty=%.5f SL=%.6f TPS=[%.6f %.6f %.6f %.6f]",
            symbol, qty,
            payload["stop_loss"],
            payload["take_profits"]["TP1"],
            payload["take_profits"]["TP2"],
            payload["take_profits"]["TP3"],
            payload["take_profits"]["TP4"],
        )

        return payload
