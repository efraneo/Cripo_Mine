# backend/ip_approval_api.py
# ---------------------------------------------------------
# API de aprobación de IPs con FastAPI + página HTML segura
# ---------------------------------------------------------

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from backend.log_manager import get_logger
from backend.ip_manager import IPManager
from backend.telegram_bot import telegram_send

log = get_logger("ip_approval_api")

app = FastAPI(title="IP Approval API")

ipm = IPManager()

@app.get("/approve_ip", response_class=HTMLResponse)
async def approve_ip(token: str):
    log.info(f"Solicitud de aprobación recibida: token={token}")

    try:
        result = ipm.approve_from_token(token)
    except Exception as e:
        log.exception("Error approving IP token")
        return f"""
        <html><body>
        <h2 style="color:red;">Error interno.</h2>
        <p>{str(e)}</p>
        </body></html>
        """

    if not result:
        return """
        <html><body>
        <h2 style="color:red;">Token inválido o expirado.</h2>
        </body></html>
        """

    user, ip = result

    msg = f"✅ IP aprobada vía API\nUsuario: {user}\nIP: {ip}"
    log.info(msg)

    if telegram_send:
        try:
            telegram_send(msg)
        except:
            pass

    return f"""
    <html>
        <body style="font-family:Arial; text-align:center;">
            <h2 style="color:green;">✔ IP Aprobada Correctamente</h2>
            <p>Usuario: <b>{user}</b></p>
            <p>IP: <b>{ip}</b></p>
            <p>Ya puede ingresar al bot.</p>
        </body>
    </html>
    """
