# backend/ip_manager.py
"""
IPManager PRO (extendido con membresías)
 - IP válida SOLO si membresía activa
 - IP expira con la membresía
 - Admin exento de reglas
 - Limpieza automática de IPs vencidas
"""

import os
import sqlite3
import hmac
import hashlib
import base64
from datetime import datetime
import calendar
from backend.ids_manager import IDSManager


DB = os.path.join(os.path.dirname(__file__), "..", "data", "usuarios.db")

# -------------------------------------------------
# Helpers
# -------------------------------------------------

def _conn():
    return sqlite3.connect(DB)

def _utcnow():
    return datetime.utcnow()

def _end_of_month(dt: datetime) -> datetime:
    last_day = calendar.monthrange(dt.year, dt.month)[1]
    return datetime(dt.year, dt.month, last_day, 23, 59, 59)

def _end_of_year(dt: datetime) -> datetime:
    return datetime(dt.year, 12, 31, 23, 59, 59)

# -------------------------------------------------
# Schema (NO destructivo)
# -------------------------------------------------

def _ensure_schema():
    with _conn() as c:
        # ---------------------------
        # Tabla IPs aprobadas
        # ---------------------------
        c.execute("""
        CREATE TABLE IF NOT EXISTS allowed_ips (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip TEXT,
            approved_at TEXT,
            expires_at TEXT
        )
        """)

        # ---------------------------
        # Tabla logs de IP
        # ---------------------------
        c.execute("""
        CREATE TABLE IF NOT EXISTS ip_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            ip TEXT,
            event TEXT,
            ts TEXT
        )
        """)

        # ---------------------------
        # Migraciones NO destructivas
        # ---------------------------

        # allowed_ips: asegurar expires_at
        cols_ips = {
            r[1] for r in c.execute(
                "PRAGMA table_info(allowed_ips)"
            ).fetchall()
        }

        if "expires_at" not in cols_ips:
            c.execute(
                "ALTER TABLE allowed_ips ADD COLUMN expires_at TEXT"
            )

        # users: asegurar columnas de membresía
        cols_users = {
            r[1] for r in c.execute(
                "PRAGMA table_info(users)"
            ).fetchall()
        }

        if "membership_active" not in cols_users:
            c.execute(
                "ALTER TABLE users ADD COLUMN membership_active INTEGER DEFAULT 0"
            )

        if "membership_type" not in cols_users:
            c.execute(
                "ALTER TABLE users ADD COLUMN membership_type TEXT"
            )

        if "membership_expires_at" not in cols_users:
            c.execute(
                "ALTER TABLE users ADD COLUMN membership_expires_at TEXT"
            )

        c.commit()

_ensure_schema()

# -------------------------------------------------
# IPManager
# -------------------------------------------------

class IPManager:
    def __init__(self, db_path: str = None):
        self.db_path = db_path or DB
        _ensure_schema()
        self.ids = IDSManager()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    # -------------------------
    # Logs
    # -------------------------

    def log(self, username: str, ip: str, event: str):
        with self._conn() as c:
            c.execute(
                "INSERT INTO ip_logs(username, ip, event, ts) VALUES (?,?,?,?)",
                (username, ip, event, _utcnow().isoformat())
            )
            c.commit()

    # -------------------------
    # Membership helpers
    # -------------------------

    def _membership_valid(self, username: str) -> bool:
        """
        Valida membresía REAL desde tabla users.
        Admin siempre válido.
        """
        with self._conn() as c:
            r = c.execute("""
            SELECT is_admin, has_membership, membership_expires_at
            FROM users WHERE username=?
            """, (username,)).fetchone()

        if not r:
            return False

        is_admin, has_membership, expires_at = r

        if is_admin:
            return True

        if not has_membership or not expires_at:
            return False

        return _utcnow() <= datetime.fromisoformat(expires_at)

    def get_membership_expiry(self, username: str):
        with self._conn() as c:
            r = c.execute("""
            SELECT membership_expires_at
            FROM users WHERE username=?
            """, (username,)).fetchone()
        return r[0] if r else None

    # -------------------------
    # IP Control
    # -------------------------

    def approve_ip(self, username: str, ip: str):
        """
        Aprueba IP:
        - Admin: sin expiración
        - Usuario: expira con membresía
        - IDS: registra intentos ilegales
        """
        with self._conn() as c:
            r = c.execute(
                "SELECT is_admin FROM users WHERE username=?",
                (username,)
            ).fetchone()

        if not r:
            # Evento IDS: usuario inexistente
            try:
                self.ids.register_event(username, ip, "approve_ip_user_not_found", 50)
            except Exception:
                pass
            raise RuntimeError("Usuario no existe")

        is_admin = bool(r[0])

        expires_at = None
        if not is_admin:
            if not self._membership_valid(username):
                # 🔐 IDS: intento de aprobar IP sin membresía
                try:
                    self.ids.register_event(
                        username,
                        ip,
                        "approve_ip_without_membership",
                        40
                    )
                except Exception:
                    pass
                raise RuntimeError("Usuario sin membresía activa")

            expires_at = self.get_membership_expiry(username)

        with self._conn() as c:
            c.execute("""
            INSERT INTO allowed_ips(username, ip, approved_at, expires_at)
            VALUES (?,?,?,?)
            """, (
                username,
                ip,
                _utcnow().isoformat(),
                expires_at
            ))
            c.commit()

        self.log(username, ip, "ip_approved")


    def _cleanup_if_expired(self, username: str, ip: str, expires_at: str):
        """
        Marca IP vencida (NO borra por auditoría).
        """
        if expires_at and _utcnow() > datetime.fromisoformat(expires_at):
            self.log(username, ip, "ip_expired_auto")
            return True
        return False

    def is_allowed(self, username: str, ip: str) -> bool:
        """
        Gate central de seguridad.
        """
        # IDS: IP bloqueada automáticamente
        if self.ids.is_blocked(ip):
            self.log(username, ip, "blocked_by_ids")
            return False

        with self._conn() as c:
            r = c.execute("""
            SELECT a.expires_at, u.is_admin
            FROM allowed_ips a
            JOIN users u ON u.username = a.username
            WHERE a.username=? AND a.ip=?
            ORDER BY a.approved_at DESC
            LIMIT 1
            """, (username, ip)).fetchone()

        if not r:
            return False

        expires_at, is_admin = r

        if is_admin:
            return True

        # IP expirada
        if self._cleanup_if_expired(username, ip, expires_at):
            return False

        # Membresía aún válida
        if not self._membership_valid(username):
            self.log(username, ip, "membership_expired")
            return False

        return True

    # -------------------------
    # Admin listings
    # -------------------------

    def list_allowed(self):
        with self._conn() as c:
            rows = c.execute("""
            SELECT username, ip, approved_at, expires_at
            FROM allowed_ips
            ORDER BY approved_at DESC
            """).fetchall()

        return [
            {
                "username": r[0],
                "ip": r[1],
                "approved_at": r[2],
                "expires_at": r[3]
            }
            for r in rows
        ]

    def list_logs(self, limit: int = 200):
        with self._conn() as c:
            rows = c.execute("""
            SELECT username, ip, event, ts
            FROM ip_logs
            ORDER BY ts DESC
            LIMIT ?
            """, (limit,)).fetchall()

        return [
            {
                "username": r[0],
                "ip": r[1],
                "event": r[2],
                "ts": r[3]
            }
            for r in rows
        ]

    # -------------------------
    # Riesgo IP
    # -------------------------
    def add_risk(self, username: str, ip: str, points: int, reason: str):
        now = _utcnow()

        with self._conn() as c:
            r = c.execute("""
            SELECT score FROM ip_risk WHERE username=? AND ip=?
            """, (username, ip)).fetchone()

            if r:
                score = r[0] + points
                c.execute("""
                UPDATE ip_risk
                SET score=?, last_event=?, updated_at=?
                WHERE username=? AND ip=?
                """, (score, reason, now.isoformat(), username, ip))
            else:
                score = points
                c.execute("""
                INSERT INTO ip_risk(ip, username, score, last_event, updated_at)
                VALUES (?,?,?,?,?)
                """, (ip, username, score, reason, now.isoformat()))

            c.commit()

        if score >= 10:
            self.block_ip(username, ip, reason="auto_block_risk_score")

    # -------------------------
    # Bloqueo IP
    # -------------------------
    def block_ip(self, username: str, ip: str, reason: str, hours: int = 24):
        expires = _utcnow() + timedelta(hours=hours)

        with self._conn() as c:
            c.execute("""
            INSERT INTO ip_blocks(username, ip, reason, blocked_at, expires_at)
            VALUES (?,?,?,?,?)
            """, (
                username,
                ip,
                reason,
                _utcnow().isoformat(),
                expires.isoformat()
            ))
            c.commit()

        self.log(username, ip, f"ip_blocked:{reason}")

    def is_blocked(self, username: str, ip: str) -> bool:
        with self._conn() as c:
            r = c.execute("""
            SELECT expires_at FROM ip_blocks
            WHERE username=? AND ip=?
            ORDER BY blocked_at DESC LIMIT 1
            """, (username, ip)).fetchone()

        if not r:
            return False

        expires_at = r[0]
        return _utcnow() <= datetime.fromisoformat(expires_at)


    def get_all(self):
        """
        Devuelve TODAS las IPs relevantes:
        - autorizadas
        - logs recientes (pendientes)
        """

        with self._conn() as c:

            # IPs aprobadas
            allowed = c.execute("""
                SELECT username, ip, approved_at, expires_at, 1 as approved
                FROM allowed_ips
            """).fetchall()

            # Últimos intentos (no aprobados)
            logs = c.execute("""
                SELECT username, ip, ts as approved_at, NULL as expires_at, 0 as approved
                FROM ip_logs
                WHERE event='ip_not_allowed'
                ORDER BY ts DESC
                LIMIT 50
            """).fetchall()

        rows = allowed + logs

        return [
            {
                "username": r[0],
                "ip": r[1],
                "approved_at": r[2],
                "expires_at": r[3],
                "approved": bool(r[4])
            }
            for r in rows
        ]
