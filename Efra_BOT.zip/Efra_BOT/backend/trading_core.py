# backend/trading_core.py
"""
trading_core.py

Orquestador principal:
 - SignalProcessor: enriquece señales técnicas con IA (probabilidades)
 - TradeExecutor: ejecuta órdenes PAPER/REAL integrando binance_core + binance_orders
 - Registro/auditoría de operaciones (logs JSONL)
 - Guardrails de seguridad: min_confidence, size_by_risk, time-limit checks

Requisitos:
 - backend/binance_core.py              (get_binance_client_for_user, record_user_operation_start, mark_operation_closed, check_time_limit_exceeded)
 - backend/binance_ohlcv.py             (get_ohlcv)    -> opcional para fallback data
 - backend/binance_client.py            (BinanceClient class or REST helper) OR
   backend/binance_orders.py            (place_market_order_with_stop) -- adaptado a tu proyecto
 - backend/ia_predictor.py              (IaPredictor class OR ia_predictor wrapper)
 - backend/backtester.py (opcional)     (Backtester)
"""

from __future__ import annotations
import os
import time
import json
import math
import logging
from typing import Dict, Any, Optional

import pandas as pd

# ============================================================
# IA — Import flexible y robusto
# ============================================================

IaPredictor = None
IaModelPredictor = None
ia_predictor = None
IA_HAS_CLASS = False

# 1) Intentar cargar IaModelPredictor (model calibrado moderno)
try:
    from backend.ia_predictor import IaModelPredictor
    IA_HAS_CLASS = True
except Exception:
    pass

# 2) Intentar cargar IaPredictor (versión clásica)
if not IA_HAS_CLASS:
    try:
        from backend.ia_predictor import IaPredictor
        IA_HAS_CLASS = True
    except Exception:
        pass

# 3) Intentar cargar singleton
if not IA_HAS_CLASS:
    try:
        from backend.ia_predictor import ia_predictor
        IA_HAS_CLASS = False   # es singleton, no class
    except Exception:
        ia_predictor = None

# Core utilities (BBE, registro, client factory)
try:
    from backend.binance_core import (
        get_binance_client_for_user,
        record_user_operation_start,
        mark_operation_closed,
        check_time_limit_exceeded,
        DATA_DIR
    )
except Exception:
    # Fallback stubs to avoid failures during import
    def get_binance_client_for_user(*a, **k): return None
    def record_user_operation_start(*a, **k): return False
    def mark_operation_closed(*a, **k): return False
    def check_time_limit_exceeded(*a, **k): return (False, None)
    DATA_DIR = "data"

# Orders adapter (prefer place_market_order_with_stop signature used earlier)
try:
    # If you have a module that exposes this function
    from backend.binance_client import place_market_order_with_stop
    ORDERS_FN = place_market_order_with_stop
except Exception:
    try:
        # If you created a wrapper in binance_orders.py
        from backend.binance_orders import place_market_order_with_stop
        ORDERS_FN = place_market_order_with_stop
    except Exception:
        ORDERS_FN = None

# Optional get_ohlcv fallback
try:
    from backend.binance_ohlcv import get_ohlcv
except Exception:
    get_ohlcv = None

# Logging
logger = logging.getLogger("trading_core")
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s"))
    logger.addHandler(ch)

# Audit log path
AUDIT_LOG_PATH = os.path.join(DATA_DIR, "trade_audit.jsonl")
os.makedirs(os.path.dirname(AUDIT_LOG_PATH), exist_ok=True)


# -----------------------
# Helpers
# -----------------------
def _append_audit(record: dict, path: str = AUDIT_LOG_PATH):
    try:
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, default=str) + "\n")
    except Exception:
        logger.exception("Fallo guardando audit log")


def _size_from_risk(balance: float, price: float, max_risk_pct: float, stop_loss_price: Optional[float] = None) -> float:
    """
    Calcula cantidad (qty) del asset a comprar para arriesgar max_risk_pct del balance.
    Si stop_loss_price no está, usa una aproximación conservadora (1% del precio).
    """
    if price <= 0 or balance <= 0:
        return 0.0
    # distancia al stop
    if stop_loss_price:
        risk_per_unit = abs(price - stop_loss_price)
    else:
        risk_per_unit = price * 0.01  # asumir 1% si no hay SL

    if risk_per_unit <= 0:
        return 0.0

    risk_amount = balance * float(max_risk_pct)
    qty = risk_amount / risk_per_unit
    return float(qty)


# -----------------------
# SignalProcessor
# -----------------------
class SignalProcessor:
    """
    Encapsula la lógica para enriquecer una señal técnica con IA.
    """

    def __init__(self, model_path: Optional[str] = None, min_confidence: float = 0.80):
        self.min_confidence = float(min_confidence)
        self.model = None
        self.predictor_instance = None

        # Instanciar predictor si es posible
        if IaPredictor and IA_HAS_CLASS:
            try:
                self.predictor_instance = IaPredictor(model_path or "backend/model_storage/model_calibrated.pkl",
                                                      min_confidence_for_real=self.min_confidence)
            except Exception as e:
                logger.warning("IaPredictor init failed: %s", e)
                self.predictor_instance = None
        else:
            # try instance import
            try:
                from backend.ia_predictor import ia_predictor as predictor_singleton
                self.predictor_instance = predictor_singleton
            except Exception:
                self.predictor_instance = None

    def enrich(self, signal: Dict[str, Any], hist_df: pd.DataFrame) -> Dict[str, Any]:
        """
        signal: dict con keys 'symbol', 'price', 'side_hint' (opcional), 'extra' (fibs...)
        hist_df: DataFrame OHLCV con historial (necesario para feature calc)
        Returns enriched signal including ia subdict
        """
        out = dict(signal)
        ia_block = {"prob": None, "action": None, "ready_for_real": False, "debug": {}}

        try:
            # preparar row: tomar último OHLCV + valores extra
            last_row = {}
            if hist_df is not None and isinstance(hist_df, pd.DataFrame) and len(hist_df) > 0:
                lr = hist_df.iloc[-1].to_dict()
                # preferir close from hist if price not given
                last_row = {
                    "open": lr.get("open"),
                    "high": lr.get("high"),
                    "low": lr.get("low"),
                    "close": lr.get("close"),
                    "volume": lr.get("volume"),
                    "ATR": lr.get("atr") or lr.get("ATR") if isinstance(lr.get("atr") or lr.get("ATR"), (int, float)) else None
                }
            # override with explicit fields from signal
            for k in ("open", "high", "low", "close", "volume", "ATR"):
                if k in signal:
                    last_row[k] = signal[k]

            if "price" in signal and ("close" not in last_row or last_row.get("close") is None):
                last_row["close"] = signal["price"]

            # merge any extras (fibs...)
            if "extra" in signal and isinstance(signal["extra"], dict):
                last_row.update(signal["extra"])

            # If predictor available: call it
            if self.predictor_instance:
                # predictor may expect dict of features - predictor handles missing features internally
                if hasattr(self.predictor_instance, "predict_row"):
                    pred_out = self.predictor_instance.predict_row(last_row, side_hint=signal.get("side_hint"))
                    prob = float(pred_out.get("prob", 0.0))
                    action = pred_out.get("action", None)
                else:
                    # try function style: predecir_probabilidad or predecir
                    if hasattr(self.predictor_instance, "predecir_probabilidad"):
                        r = self.predictor_instance.predecir_probabilidad(last_row)
                        prob = float(r.get("prob", 0.0))
                        action = "BUY" if int(r.get("label", 0)) == 1 else "HOLD"
                    else:
                        prob = 0.0
                        action = None

                ia_block["prob"] = prob
                ia_block["action"] = action
                ia_block["debug"]["model_loaded"] = True
                ia_block["debug"]["features_sample"] = last_row

                ia_block["ready_for_real"] = (prob is not None and prob >= float(self.min_confidence))
            else:
                ia_block["debug"]["model_loaded"] = False
                ia_block["debug"]["reason"] = "predictor_not_available"

        except Exception as e:
            logger.exception("Error enriching signal: %s", e)
            ia_block["debug"]["error"] = str(e)

        out["ia"] = ia_block
        return out


# -----------------------
# TradeExecutor
# -----------------------
class TradeExecutor:
    """
    Ejecuta órdenes en PAPER/REAL, aplica tamaños por riesgo, SL/TP heurístico,
    registra operaciones y maneja integridad.
    """

    def __init__(self, mode: str = "PAPER", max_risk_pct: float = 0.01, default_stop_atr_mult: float = 1.0,
                 default_tp_atr_mult: float = 1.5, min_confidence: float = 0.80):
        self.mode = mode.upper()
        self.max_risk_pct = float(max_risk_pct)
        self.default_stop_atr_mult = float(default_stop_atr_mult)
        self.default_tp_atr_mult = float(default_tp_atr_mult)
        self.min_confidence = float(min_confidence)

    def execute(self, enriched_signal: Dict[str, Any], account_balance: Optional[float] = None,
                usuario: Optional[Dict[str, Any]] = None, local_bbe_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Ejecuta la orden basada en enriched_signal.
        enriched_signal debe contener:
          - symbol
          - signal (BUY/SELL/HOLD)
          - price (float)
          - ia {prob, action, ready_for_real, debug}
          - extras: ATR, stop_loss/take_profit optionally
        """
        now_ts = int(time.time() * 1000)
        res_base = {
            "timestamp": now_ts,
            "mode": self.mode,
            "symbol": enriched_signal.get("symbol"),
            "engine_signal": enriched_signal.get("signal"),
            "ia": enriched_signal.get("ia", {}),
            "price": enriched_signal.get("price"),
            "user": usuario.get("usuario") if usuario else None
        }

        # sanity
        if enriched_signal.get("signal") not in ("BUY", "SELL"):
            res_base.update({"status": "NO_TRADE", "reason": "not_actionable"})
            _append_audit(res_base)
            logger.info("No action: signal not actionable.")
            return res_base

        ia = enriched_signal.get("ia", {})
        prob = ia.get("prob", 0.0)
        ready = ia.get("ready_for_real", False)

        # if REAL mode ensure IA ready
        if self.mode == "REAL" and not ready:
            res_base.update({"status": "NO_TRADE", "reason": "prob_below_threshold", "prob": prob})
            _append_audit(res_base)
            logger.info("Blocked REAL trade: prob below threshold (%.4f)", prob)
            return res_base

        # determine account balance
        if account_balance is None:
            # try to get user balance via client if possible
            account_balance = 1000.0  # fallback small notional
            try:
                client_info = get_binance_client_for_user(usuario, local_bbe_path)
                if client_info and client_info.get("client"):
                    # prefer USDT
                    # if client has get_asset_balance
                    try:
                        bal = client_info["client"].get_asset_balance(asset="USDT")
                        if bal:
                            account_balance = float(bal.get("free", account_balance))
                    except Exception:
                        pass
            except Exception:
                pass

        price = float(enriched_signal.get("price") or enriched_signal.get("close") or 0.0)
        atr = enriched_signal.get("ATR") or enriched_signal.get("ia", {}).get("debug", {}).get("atr") or None

        # infer stop/take if not present
        stop_price = enriched_signal.get("stop_loss")
        take_price = enriched_signal.get("take_profit")
        if not stop_price and atr:
            if enriched_signal.get("signal") == "BUY":
                stop_price = price - float(atr) * self.default_stop_atr_mult
                take_price = price + float(atr) * self.default_tp_atr_mult
            else:
                stop_price = price + float(atr) * self.default_stop_atr_mult
                take_price = price - float(atr) * self.default_tp_atr_mult

        # compute qty by risk
        qty = _size_from_risk(account_balance, price, self.max_risk_pct, stop_price)
        if qty <= 0:
            res_base.update({"status": "NO_TRADE", "reason": "invalid_qty", "qty": qty})
            _append_audit(res_base)
            logger.warning("Calculated qty <=0, aborting trade.")
            return res_base

        # PAPER flow
        if self.mode == "PAPER":
            # simulate execution price with simple slippage
            slippage = price * 0.0007
            exec_price = price + slippage if enriched_signal.get("signal") == "BUY" else price - slippage
            notional = exec_price * qty
            result = {
                **res_base,
                "status": "FILLED_PAPER",
                "exec_price": exec_price,
                "qty": qty,
                "notional": notional,
                "stop_price": stop_price,
                "take_price": take_price,
                "slippage": slippage
            }
            # record simulated operation (not real)
            _append_audit(result)
            logger.info("PAPER executed: %s %s qty=%.6f @%.6f", enriched_signal.get("signal"), enriched_signal.get("symbol"), qty, exec_price)
            return result

        # REAL flow
        if self.mode == "REAL":
            # obtain client for user (or master)
            client_info = get_binance_client_for_user(usuario, local_bbe_path)
            if not client_info or not client_info.get("client"):
                res_base.update({"status": "NO_TRADE", "reason": "client_unavailable"})
                _append_audit(res_base)
                logger.error("Client for user not available. Aborting REAL trade.")
                return res_base

            client = client_info["client"]
            # call underlying order function (signature may vary)
            try:
                # If ORDERS_FN exists with signature used before
                if ORDERS_FN:
                    # ORDERS_FN(api_key, api_secret, symbol, side, amount_usdt, stop_loss_pct=..., take_profit_pct=..., testnet=..., client_override=client, usuario_identifier=usuario_id)
                    # Common way used earlier: pass amount in USDT (not qty)
                    amount_usdt = account_balance * self.max_risk_pct
                    usuario_id = usuario.get("usuario") if usuario else None
                    resp = ORDERS_FN(
                        client_info.get("api_key"),
                        client_info.get("api_secret"),
                        enriched_signal.get("symbol"),
                        enriched_signal.get("signal"),
                        float(amount_usdt),
                        stop_loss_pct=abs((price - stop_price) / price) if stop_price else 0.02,
                        take_profit_pct=abs((take_price - price) / price) if take_price else 0.03,
                        testnet=client_info.get("testnet", False),
                        client_override=client,
                        usuario_identifier=usuario_id
                    )
                else:
                    # try instance method of client (BinanceClient class)
                    # expected interface: client.place_market_order_with_stop(symbol, side, qty, stop_price, take_price)
                    if hasattr(client, "place_market_order_with_stop"):
                        # prepare qty or amount depending on implementation
                        # try to call with qty first
                        try:
                            resp = client.place_market_order_with_stop(
                                enriched_signal.get("symbol"),
                                enriched_signal.get("signal"),
                                qty,
                                stop_price,
                                take_price
                            )
                        except TypeError:
                            # maybe expects amount_usdt instead
                            amount_usdt = account_balance * self.max_risk_pct
                            resp = client.place_market_order_with_stop(
                                enriched_signal.get("symbol"),
                                enriched_signal.get("signal"),
                                amount_usdt,
                                stop_loss_pct=abs((price - stop_price) / price) if stop_price else 0.02,
                                take_profit_pct=abs((take_price - price) / price) if take_price else 0.03
                            )
                    else:
                        raise RuntimeError("Client lacks place_market_order_with_stop interface")
                # record op start
                op_id = None
                try:
                    # try to obtain order id from response
                    if isinstance(resp, dict):
                        op_id = resp.get("order", {}).get("orderId") or resp.get("orderId") or resp.get("market_order", {}).get("orderId")
                except Exception:
                    op_id = None

                # register the operation (real)
                try:
                    if usuario:
                        op_id_reg = str(op_id or f"order-{int(time.time())}")
                        record_user_operation_start(usuario.get("usuario"), op_id_reg, enriched_signal.get("symbol"), is_real=True)
                except Exception as e:
                    logger.exception("Error registrando operación real: %s", e)

                result = {
                    **res_base,
                    "status": "SENT_REAL",
                    "order_response": resp,
                    "qty": qty,
                    "notional_usdt": float(account_balance) * self.max_risk_pct,
                    "stop_price": stop_price,
                    "take_price": take_price
                }
                _append_audit(result)
                logger.info("REAL order sent: %s %s qty=%s", enriched_signal.get("signal"), enriched_signal.get("symbol"), qty)
                return result

            except Exception as e:
                logger.exception("Error executing REAL order: %s", e)
                res_base.update({"status": "ERROR", "reason": str(e)})
                _append_audit(res_base)
                return res_base

        # fallback unknown mode
        res_base.update({"status": "NO_TRADE", "reason": "unknown_mode"})
        _append_audit(res_base)
        return res_base


# -----------------------
# Convenience functions for quick flows
# -----------------------
def procesar_y_ejecutar(signal: Dict[str, Any], hist_df: pd.DataFrame, executor: TradeExecutor,
                        processor: SignalProcessor, usuario: Optional[Dict] = None,
                        account_balance: Optional[float] = None, local_bbe_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Flujo rapido: enriquecer señal con IA y ejecutarla (PAPER/REAL) devolviendo el resultado.
    """
    enriched = processor.enrich(signal, hist_df)
    result = executor.execute(enriched, account_balance=account_balance, usuario=usuario, local_bbe_path=local_bbe_path)
    return {"enriched": enriched, "execution": result}


# -----------------------
# If this module is run directly, provide a small demo
# -----------------------
if __name__ == "__main__":
    # Demo: necesitas tener un IA model o el ia_predictor compatible para que el demo muestre prob.
    sp = SignalProcessor(min_confidence=0.80)
    te = TradeExecutor(mode="PAPER", max_risk_pct=0.01)

    # fake hist DF
    df = pd.DataFrame([{"open": 100, "high": 101, "low": 99, "close": 100.5, "volume": 10, "atr": 0.8}])

    sig = {"symbol": "BTCUSDT", "signal": "BUY", "price": 100.5, "extra": {"fib_0.618": 98.2}}
    out = procesar_y_ejecutar(sig, df, te, sp, usuario={"usuario": "demo"})
    print(json.dumps(out, indent=2, default=str))
