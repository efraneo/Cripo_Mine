# ============================================================
# backend/backtester.py
# Backtester robusto + métricas + conexión IA (versión integrada)
# ------------------------------------------------------------
# Mejora del backtester original: tolerancia, export, métricas,
# posibilidad de pasar una función de predicción externa, y
# guardado de equity.csv para mostrar en el dashboard.
# ============================================================

from __future__ import annotations
import os
import json
import logging
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional, Callable, List, Dict, Any

# Intentar importar IAProcessor (fallback tolerante)
try:
    from backend.ia_module import IAProcessor  # tu wrapper de IA (si existe)
    IA_AVAILABLE = True
except Exception:
    IAProcessor = None
    IA_AVAILABLE = False

# Logger local
logger = logging.getLogger("backtester")
if not logger.handlers:
    handler = logging.FileHandler("backtester.log")
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


class Backtester:
    """
    Motor de backtesting conectado opcionalmente con IA.

    Uso básico:
        bt = Backtester(initial_balance=1000, fee=0.0004)
        df = bt.load_csv("data/BTCUSDT_1m.csv")
        df_prepared = bt.prepare_dataset(df)
        report = bt.run(df_prepared)  # usa IA integrada si existe
    """

    def __init__(self, initial_balance: float = 1000.0, fee: float = 0.0004):
        self.initial_balance = float(initial_balance)
        self.fee = float(fee)
        self.reset_state()
        if IA_AVAILABLE:
            try:
                self.ia = IAProcessor()
                logger.info("IAProcessor cargado en Backtester.")
            except Exception as e:
                logger.exception("Error iniciando IAProcessor: %s", e)
                self.ia = None
        else:
            self.ia = None
            logger.info("IAProcessor no disponible; usar predict_fn externo o probar sin IA.")

    def reset_state(self):
        """Resetear variables internas del backtester."""
        self.balance = float(self.initial_balance)
        self.position = 0.0
        self.entry_price = 0.0
        self.equity_curve: List[float] = []
        self.operations: List[Dict[str, Any]] = []
        self.timestamps: List[Any] = []

    # --------------------------
    # Cargar OHLCV desde CSV
    # --------------------------
    def load_csv(self, filepath: str) -> pd.DataFrame:
        """
        Carga CSV con columnas mínimas: timestamp, open, high, low, close, volume
        Acepta timestamps en ms unix o ISO strings.
        """
        if not os.path.exists(filepath):
            logger.error("Archivo no encontrado: %s", filepath)
            raise FileNotFoundError(f"Archivo CSV no encontrado: {filepath}")

        df = pd.read_csv(filepath)

        required_cols = ["timestamp", "open", "high", "low", "close", "volume"]
        for c in required_cols:
            if c not in df.columns:
                raise ValueError(f"Falta columna obligatoria en CSV: {c}")

        # Normalizar timestamp: aceptar ints (ms) o ISO
        try:
            if np.issubdtype(df["timestamp"].dtype, np.number):
                # posible unix ms
                df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", errors="coerce")
            else:
                df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        except Exception:
            df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")

        df = df.dropna(subset=["timestamp"]).sort_values("timestamp").reset_index(drop=True)

        # Asegurar tipos numéricos
        for c in ["open", "high", "low", "close", "volume"]:
            df[c] = pd.to_numeric(df[c], errors="coerce")

        df = df.dropna().reset_index(drop=True)
        logger.info("CSV cargado: %s (rows=%d)", filepath, len(df))
        return df

    # --------------------------
    # Preparar dataset para IA
    # --------------------------
    def prepare_dataset(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Crea features simples: retornos, medias móviles, volatilidad, ATR aproximada.
        Retorna DataFrame limpio listo para predicción.
        """
        df = df.copy().reset_index(drop=True)
        # retornos y vol
        df["ret"] = df["close"].pct_change()
        df["ma_fast"] = df["close"].rolling(window=10, min_periods=1).mean()
        df["ma_slow"] = df["close"].rolling(window=50, min_periods=1).mean()
        df["volatility"] = df["close"].pct_change().rolling(window=20, min_periods=1).std()
        # ATR aproximado (True Range simple)
        df["high_low"] = df["high"] - df["low"]
        df["high_close_prev"] = (df["high"] - df["close"].shift(1)).abs()
        df["low_close_prev"] = (df["low"] - df["close"].shift(1)).abs()
        df["tr"] = df[["high_low", "high_close_prev", "low_close_prev"]].max(axis=1)
        df["atr"] = df["tr"].rolling(window=14, min_periods=1).mean()

        # limpieza ligera
        df = df.dropna().reset_index(drop=True)
        logger.info("Dataset preparado (rows=%d)", len(df))
        return df

    # --------------------------
    # Ejecutar backtest
    # --------------------------
    def run(self,
            df: pd.DataFrame,
            predict_fn: Optional[Callable[[Dict[str, Any]], str]] = None,
            save_equity: bool = True,
            equity_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Ejecuta backtest sobre df preparado.
        - predict_fn(sample) -> devuelve 'BUY'|'SELL'|'HOLD' (si se pasa, tiene prioridad sobre self.ia)
        - si no hay predict_fn ni IA, se hace no-op (no entra en trades)
        - guarda equity.csv si save_equity True (path por defecto data/equity.csv)
        """

        self.reset_state()
        if df is None or len(df) == 0:
            raise ValueError("DataFrame vacío en run().")

        # usar IA si no se pasó predict_fn
        use_ia = False
        if predict_fn is None and self.ia is not None and hasattr(self.ia, "predict_signal"):
            use_ia = True

        try:
            for i in range(len(df)):
                row = df.iloc[i]
                sample = {
                    "open": float(row["open"]),
                    "high": float(row["high"]),
                    "low": float(row["low"]),
                    "close": float(row["close"]),
                    "volume": float(row["volume"]),
                    "ma_fast": float(row.get("ma_fast", 0)),
                    "ma_slow": float(row.get("ma_slow", 0)),
                    "volatility": float(row.get("volatility", 0)),
                    "atr": float(row.get("atr", 0)),
                    "ret": float(row.get("ret", 0)),
                    "index": int(i),
                    "timestamp": row["timestamp"]
                }

                # obtener señal
                signal = None
                try:
                    if predict_fn:
                        signal = predict_fn(sample)
                    elif use_ia:
                        signal = self.ia.predict_signal(sample)
                    else:
                        signal = "HOLD"
                except Exception as e:
                    logger.exception("Error en predict_fn/IA: %s", e)
                    signal = "HOLD"

                # Ejecutar lógica simple: BUY abre posición si no hay; SELL cierra si hay
                if signal == "BUY":
                    self._handle_buy(row)
                elif signal == "SELL":
                    self._handle_sell(row)

                # registrar equity actual (balance + valor posicional)
                pos_value = self.position * float(row["close"]) if self.position and float(row["close"]) else 0.0
                current_equity = float(self.balance) + float(pos_value)
                self.equity_curve.append(current_equity)
                self.timestamps.append(row["timestamp"])

        except Exception as e:
            logger.exception("Error corriendo el backtest: %s", e)

        report = self.generate_report()

        # guardar equity
        if save_equity:
            try:
                out_path = equity_path or os.path.join("data", "equity.csv")
                self.save_equity_csv(out_path)
                logger.info("Equity guardada en %s", out_path)
            except Exception as e:
                logger.exception("No se pudo guardar equity CSV: %s", e)

        return report

    # --------------------------
    # Compras / Ventas (mecanismo)
    # --------------------------
    def _handle_buy(self, row: pd.Series):
        """Abrir posición completa (todo el balance) si no hay posición."""
        try:
            price = float(row["close"])
            if self.position == 0 and price > 0:
                # comprar con todo el balance (ejemplo). Puedes adaptar tamaño por riesgo.
                qty = (self.balance / price)
                fee_cost = qty * self.fee
                qty_net = max(0.0, qty - fee_cost)
                self.position = qty_net
                self.entry_price = price
                # registrar operación
                self.operations.append({
                    "type": "BUY",
                    "price": price,
                    "timestamp": row["timestamp"],
                    "qty": qty_net
                })
                logger.debug("BUY @%s qty=%s", price, qty_net)
        except Exception:
            logger.exception("Error en _handle_buy")

    def _handle_sell(self, row: pd.Series):
        """Cerrar posición si existe y registrar PnL neto."""
        try:
            price = float(row["close"])
            if self.position > 0 and price > 0:
                pnl = (price - self.entry_price) * self.position
                # restar comisiones aproximadas
                pnl_after_fee = pnl - (abs(pnl) * self.fee)
                self.balance = float(self.balance) + float(pnl_after_fee)
                # registrar venta
                self.operations.append({
                    "type": "SELL",
                    "price": price,
                    "timestamp": row["timestamp"],
                    "pnl": float(pnl_after_fee)
                })
                # reset position
                self.position = 0.0
                self.entry_price = 0.0
                logger.debug("SELL @%s pnl=%s", price, pnl_after_fee)
        except Exception:
            logger.exception("Error en _handle_sell")

    # --------------------------
    # Reporte y métricas
    # --------------------------
    def generate_report(self) -> Dict[str, Any]:
        """Genera reporte con métricas de desempeño basadas en equity_curve y operaciones."""
        try:
            if not self.equity_curve:
                # no se ejecutó nada -> devolver estado base
                return {
                    "initial_balance": self.initial_balance,
                    "final_balance": float(self.balance),
                    "total_return": 0.0,
                    "sharpe_ratio": 0.0,
                    "max_drawdown": 0.0,
                    "accuracy": 0.0,
                    "profit_factor": 0.0,
                    "num_operations": len(self.operations)
                }

            curve = np.array(self.equity_curve, dtype=float)
            # returns periódicos
            rets = pd.Series(curve).pct_change().dropna()
            sharpe = float((rets.mean() / (rets.std() + 1e-9)) * np.sqrt(252)) if not rets.empty else 0.0
            max_dd = float(self._max_drawdown(curve))
            total_return = float((curve[-1] / curve[0]) - 1.0) if curve[0] != 0 else 0.0
            accuracy = float(self._accuracy())
            profit_factor = float(self._profit_factor())

            report = {
                "initial_balance": float(self.initial_balance),
                "final_balance": float(curve[-1]),
                "total_return": float(total_return),
                "sharpe_ratio": round(sharpe, 6),
                "max_drawdown": round(max_dd, 6),
                "accuracy": round(accuracy, 6),
                "profit_factor": round(profit_factor, 6),
                "num_operations": len(self.operations)
            }
            logger.info("Reporte generado: %s", report)
            return report
        except Exception:
            logger.exception("Error generating report")
            return {}

    def _max_drawdown(self, curve: np.ndarray) -> float:
        """Calcula drawdown máximo (negative number)"""
        try:
            max_curve = np.maximum.accumulate(curve)
            dd = (curve - max_curve) / (max_curve + 1e-9)
            return float(dd.min())
        except Exception:
            logger.exception("Error calculando max drawdown")
            return 0.0

    def _accuracy(self) -> float:
        """Accuracy simple: win rate sobre operaciones SELL (si aplica)"""
        try:
            wins = 0
            total = 0
            for op in self.operations:
                if op.get("type") == "SELL":
                    total += 1
                    if float(op.get("pnl", 0)) > 0:
                        wins += 1
            return (wins / total) if total > 0 else 0.0
        except Exception:
            logger.exception("Error calculando accuracy")
            return 0.0

    def _profit_factor(self) -> float:
        """Profit factor = sum(profits) / sum(losses)"""
        try:
            profits = [op["pnl"] for op in self.operations if op.get("type") == "SELL" and float(op.get("pnl", 0)) > 0]
            losses = [abs(op["pnl"]) for op in self.operations if op.get("type") == "SELL" and float(op.get("pnl", 0)) <= 0]
            sum_losses = sum(losses)
            if sum_losses == 0:
                return float("inf") if profits else 0.0
            return float(sum(profits) / sum_losses)
        except Exception:
            logger.exception("Error calculando profit factor")
            return 0.0


    # ============================================================
    # (NUEVO) — Calibración de threshold para señales IA
    # ============================================================
    def calibrate_threshold(self,
                            y_true: List[int],
                            y_proba: List[float],
                            metric: str = "precision",
                            target: Optional[float] = None,
                            save_path: str = "models/threshold.json") -> float:
        """
        Calcula el umbral óptimo (threshold) para BUY/SELL basado en probabilidades.
        metric:
            - "precision": maximize precision
            - "recall": maximize recall
            - "f1": maximize F1 score
            - "profit": maximize backtesting profit (requiere dataset OHLC)
        target:
            si se fija (p.ej target=0.70 precision), busca threshold mínimo que lo cumpla
        Guarda threshold óptimo en models/threshold.json
        """

        import numpy as np
        from sklearn.metrics import precision_score, recall_score, f1_score

        thresholds = np.linspace(0.01, 0.99, 99)
        best_th = 0.5
        best_value = -1

        for th in thresholds:
            preds = [1 if p >= th else 0 for p in y_proba]

            # Elegir métrica
            if metric == "precision":
                value = precision_score(y_true, preds, zero_division=0)
            elif metric == "recall":
                value = recall_score(y_true, preds, zero_division=0)
            elif metric == "f1":
                value = f1_score(y_true, preds, zero_division=0)
            else:
                # default precision
                value = precision_score(y_true, preds, zero_division=0)

            # Si hay target, buscamos el threshold MÍNIMO que lo cumpla
            if target is not None and value >= target:
                best_th = th
                best_value = value
                break

            # Si no hay target, maximizamos métrica
            if target is None and value > best_value:
                best_th = th
                best_value = value

        # Guardar threshold
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        with open(save_path, "w") as f:
            json.dump({"threshold": float(best_th)}, f, indent=2)

        logger.info("Threshold calibrado = %.4f (metric=%s)", best_th, metric)
        return float(best_th)


    # --------------------------
    # Export helpers
    # --------------------------
    def save_equity_csv(self, path: str):
        """
        Guarda equity curve en CSV con columnas ['timestamp','equity'].
        Si no hay timestamps, genera indices incrementales.
        """
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            df = pd.DataFrame({
                "timestamp": self.timestamps if self.timestamps else list(range(len(self.equity_curve))),
                "equity": self.equity_curve
            })
            # Asegurar datetime serializable
            try:
                df["timestamp"] = pd.to_datetime(df["timestamp"])
            except Exception:
                pass
            df.to_csv(path, index=False)
            logger.info("Equity CSV guardado: %s", path)
        except Exception:
            logger.exception("Error guardando equity CSV")

    def to_json_report(self, path: str):
        """Exportar reporte y operaciones a JSON"""
        try:
            report = self.generate_report()
            out = {
                "report": report,
                "operations": self.operations,
                "timestamp": datetime.utcnow().isoformat()
            }
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(out, fh, default=str, indent=2)
            logger.info("Reporte JSON guardado en %s", path)
        except Exception:
            logger.exception("Error guardando reporte JSON")

    # --------------------------
    # Métrica auxiliar: precision si tienes etiquetas (y_true)
    # --------------------------
    @staticmethod
    def precision_from_labels(y_true: List[int], y_pred: List[int]) -> float:
        """
        Calcula precision (0..1) de forma robusta.
        """
        try:
            from sklearn.metrics import precision_score
            p = precision_score(y_true, y_pred, zero_division=0)
            return float(p)
        except Exception:
            logger.exception("Error calculando precision (sklearn required)")
            # fallback manual
            tp = sum(1 for yt, yp in zip(y_true, y_pred) if yt == 1 and yp == 1)
            pred_pos = sum(1 for yp in y_pred if yp == 1)
            if pred_pos == 0:
                return 0.0
            return tp / pred_pos

# ============================================================
# Fin backend/backtester.py
# ============================================================
