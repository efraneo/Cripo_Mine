# backend/ranking_manager.py
"""
RankingManager - genera ranking por ganancias/inversiones
Nota: Suponemos que la tabla investments registra tanto DEMO como REAL y que
la ganancia/ perdida se puede inferir (si dispones de registros de resultado, integrarlos aquí).
Por ahora ranking por total invertido (puedes cambiar a P&L si registras resultados).
"""

import sqlite3
import os
from datetime import datetime
from typing import List, Dict

DB_DEFAULT = os.path.join("data","usuarios.db")

class RankingManager:
    def __init__(self, db_path: str = DB_DEFAULT):
        self.db_path = db_path

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def get_ranking(self, start_date, end_date, granularity="mensual") -> List[Dict]:
        # For now ranking by total invested
        s = start_date.isoformat() if hasattr(start_date, "isoformat") else str(start_date)
        e = end_date.isoformat() if hasattr(end_date, "isoformat") else str(end_date)
        with self._conn() as c:
            rows = c.execute("""
                SELECT username, SUM(amount) as total
                FROM investments
                WHERE date(ts) BETWEEN date(?) AND date(?)
                GROUP BY username
                ORDER BY total DESC
            """, (s, e)).fetchall()
            return [{"username": r[0], "total": r[1]} for r in rows]
