# backend/backtest_walkforward.py
# ------------------------------------------------------------
# Walk-forward validation para el pipeline LightGBM+Scaler
# Usa:
#   - ia_module.load_model
#   - ia_module.predict_row_proba
#   - IaPredictor (para respetar min_confidence)
#
# Evalúa:
#   * precision@threshold
#   * preds vs. reality
#   * matriz de confusión
#   * curva de capital (equity)
#   * drawdown máximo
#   * cobertura (qué % de filas toma el modelo)
#
# ------------------------------------------------------------

import os
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix
)

from backend.ia_module import load_model, predict_row_proba


# ------------------------------------------------------------
# Métricas auxiliares
# ------------------------------------------------------------
def max_drawdown(equity):
    """
    equity: Series o np.array de equity
    Devuelve drawdown máximo en porcentaje
    """
    peaks = np.maximum.accumulate(equity)
    dd = (equity - peaks) / peaks
    return dd.min()


def equity_curve_from_preds(df, prob_column="prob", label_column="label", threshold=0.80):
    """
    Calcula curva de equity:
        - Si prob>=threshold y label==1 → +1
        - Si prob>=threshold y label==0 → -1
        - Si prob<threshold → 0
    """

    signals = []
    returns = []

    for prob, label in zip(df[prob_column], df[label_column]):
        if prob >= threshold:
            signals.append(1)   # trade tomado
            returns.append(1 if label == 1 else -1)
        else:
            signals.append(0)
            returns.append(0)

    equity = np.cumsum(returns)
    return equity, returns, signals


# ------------------------------------------------------------
# Walk-forward principal
# ------------------------------------------------------------
def run_walkforward(
    df: pd.DataFrame,
    pipeline_path: str,
    feature_cols: list,
    label_column: str = "label",
    threshold: float = 0.80,
    train_window: int = 1000,
    test_window: int = 200
):
    """
    df: dataframe OHLCV+indicadores+label
    pipeline_path: modelo entrenado con ia_module
    feature_cols: columnas de features usadas por el modelo
    """

    if not os.path.exists(pipeline_path):
        raise FileNotFoundError("No existe pipeline en ruta: " + pipeline_path)

    pipeline = load_model(pipeline_path)

    all_results = []
    start = 0
    end = len(df)

    print("Iniciando Walk-Forward...")
    print(f"Total filas={end}, train_window={train_window}, test_window={test_window}")

    while True:
        train_start = start
        train_end   = start + train_window
        test_end    = train_end + test_window

        if test_end > end:
            break

        df_train = df.iloc[train_start:train_end]
        df_test  = df.iloc[train_end:test_end]

        print(f"\nVentana: Train {train_start}:{train_end}  | Test {train_end}:{test_end}")

        # Evaluamos solo la parte test
        preds = []
        probs = []
        labels = df_test[label_column].values

        for _, row in df_test.iterrows():
            row_dict = {c: float(row[c]) for c in feature_cols if c in row}
            pred, prob = predict_row_proba(pipeline, row_dict)
            preds.append(pred)
            probs.append(prob)

        df_out = df_test.copy()
        df_out["pred"] = preds
        df_out["prob"] = probs
        df_out["prob_take"] = (df_out["prob"] >= threshold).astype(int)

        # Equity curve
        equity, returns, signals = equity_curve_from_preds(df_out, "prob", label_column, threshold)
        df_out["equity"] = equity
        df_out["returns"] = returns
        df_out["signal_taken"] = signals

        # Métricas clásicas
        taken_df = df_out[df_out["prob"] >= threshold]
        if len(taken_df) > 0:
            prec = precision_score(taken_df[label_column], taken_df["pred"])
        else:
            prec = np.nan

        acc = accuracy_score(df_out[label_column], df_out["pred"])
        rec = recall_score(df_out[label_column], df_out["pred"])
        f1  = f1_score(df_out[label_column], df_out["pred"])

        # Drawdown
        dd = max_drawdown(equity)

        # Confusion matrix
        cm = confusion_matrix(df_out[label_column], df_out["pred"])

        result = {
            "train_range": (train_start, train_end),
            "test_range": (train_end, test_end),
            "accuracy": acc,
            "precision_all": precision_score(df_out[label_column], df_out["pred"]),
            "precision_at_threshold": prec,
            "recall": rec,
            "f1": f1,
            "coverage": df_out["prob_take"].mean(),
            "max_drawdown": dd,
            "total_trades": df_out["signal_taken"].sum(),
            "equity_final": equity[-1] if len(equity) > 0 else 0,
            "confusion_matrix": cm.tolist(),
            "df_result": df_out
        }

        all_results.append(result)

        print(f" - accuracy={acc:.4f}  precision@{threshold}={prec:.4f}  coverage={result['coverage']:.3f}")
        print(f" - trades={result['total_trades']}  equity={result['equity_final']}  DD={dd:.3f}")
        print(f" - CM={cm.tolist()}")

        # Avanzar ventana
        start += test_window

    return all_results


# ------------------------------------------------------------
# Ejecución desde consola
# ------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Walk-Forward Testing para modelo IA")
    parser.add_argument("--csv", required=True, help="CSV con OHLCV+indicadores+label")
    parser.add_argument("--pipeline", required=True, help="Ruta .pkl del modelo")
    parser.add_argument("--threshold", type=float, default=0.80)
    args = parser.parse_args()

    df = pd.read_csv(args.csv)

    pipeline = load_model(args.pipeline)
    feature_cols = pipeline["feature_cols"]

    results = run_walkforward(
        df,
        pipeline_path=args.pipeline,
        feature_cols=feature_cols,
        threshold=args.threshold
    )

    # Guardar resumen
    summary = []
    for r in results:
        summary.append({
            "train_start": r["train_range"][0],
            "train_end": r["train_range"][1],
            "test_start": r["test_range"][0],
            "test_end": r["test_range"][1],
            "accuracy": r["accuracy"],
            "precision_at_thr": r["precision_at_threshold"],
            "coverage": r["coverage"],
            "equity_final": r["equity_final"],
            "max_drawdown": r["max_drawdown"],
            "trades": r["total_trades"]
        })

    summary_df = pd.DataFrame(summary)
    summary_df.to_csv("walkforward_summary.csv", index=False)
    print("\nResumen guardado en walkforward_summary.csv")
