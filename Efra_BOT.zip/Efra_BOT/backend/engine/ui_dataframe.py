# backend/engine/ui_dataframe.py

import pandas as pd

from backend.patrones_velas import detectar_patrones_velas


class UIDataFrameBuilder:

    def __init__(self, engine):

        self.engine = engine

    # ======================================================
    # MAIN
    # ======================================================

    def build(
        self,
        symbol,
        timeframe,
        limit=200
    ):

        rows = self.engine.get_ohlcv(
            symbol=symbol,
            timeframe=timeframe,
            limit=limit
        )

        if not rows:
            raise RuntimeError("No OHLCV data")

        df = pd.DataFrame(rows)

        # ==================================================
        # NORMALIZATION
        # ==================================================

        df["time"] = pd.to_datetime(
            df["timestamp"],
            unit="ms",
            errors="coerce"
        )

        df = df.drop(columns=["timestamp"])

        for col in [
            "open",
            "high",
            "low",
            "close",
            "volume"
        ]:
            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

        df = df.dropna()

        # ==================================================
        # PATTERNS
        # ==================================================

        try:

            patterns = detectar_patrones_velas(df)

            df.attrs["patterns"] = patterns

        except Exception:

            df.attrs["patterns"] = []

        return df
