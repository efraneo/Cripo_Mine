# 📄 backend/engine/market_data.py

```python
import pandas as pd


class MarketDataMixin:

    def get_ohlcv(self, symbol, timeframe, limit=200):

        self._ensure_market_client()

        klines = self._market_client.get_klines(
            symbol=symbol,
            interval=timeframe,
            limit=limit
        )

        return [
            {
                "timestamp": int(k[0]),
                "open": float(k[1]),
                "high": float(k[2]),
                "low": float(k[3]),
                "close": float(k[4]),
                "volume": float(k[5]),
            }
            for k in klines
        ]

    def get_ohlc_df_for_ui(self, symbol, timeframe, limit=200):

        rows = self.get_ohlcv(symbol, timeframe, limit)

        df = pd.DataFrame(rows)

        df["time"] = pd.to_datetime(df["timestamp"], unit="ms")

        return df
