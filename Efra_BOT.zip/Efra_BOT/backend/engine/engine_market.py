# backend/engine/engine_market.py

import logging
import pandas as pd

log = logging.getLogger("engine_market")


class MarketMixin:

    # ==========================================================
    # BALANCE
    # ==========================================================

    def get_balance(self, asset="USDT"):

        try:

            data = self.binance.get_spot_balance_full(asset)

            if not data:
                return 0.0

            if not data.get("ok"):
                return 0.0

            return float(
                data.get("total", 0.0)
            )

        except Exception as e:

            log.exception(
                "ENGINE BALANCE ERROR"
            )

            return 0.0

    # ==========================================================
    # SYMBOLS
    # ==========================================================

    def get_symbols(self):

        try:

            symbols = self.binance.get_symbols()

            if not symbols:
                return []

            # ==========================================
            # FILTRO INSTITUCIONAL
            # ==========================================

            clean = []

            for s in symbols:

                try:

                    s = str(s).upper().strip()

                    # evitar basura
                    if len(s) < 6:
                        continue

                    if not s.endswith("USDT"):
                        continue

                    # evitar leveraged tokens
                    banned = [
                        "UPUSDT",
                        "DOWNUSDT",
                        "BULLUSDT",
                        "BEARUSDT"
                    ]

                    if any(
                        x in s
                        for x in banned
                    ):
                        continue

                    clean.append(s)

                except Exception:
                    continue

            return sorted(
                list(set(clean))
            )

        except Exception:

            log.exception(
                "GET SYMBOLS ERROR"
            )

            return []

    # ==========================================================
    # VALID SYMBOL
    # ==========================================================

    def is_valid_symbol(self, symbol):

        try:

            if not symbol:
                return False

            symbol = str(symbol).upper()

            symbols = self.get_symbols()

            return symbol in symbols

        except Exception:
            return False

    # ==========================================================
    # KLINES DF
    # ==========================================================

    def get_klines_df(
        self,
        symbol,
        interval="1m",
        limit=500
    ):

        try:

            # ======================================
            # VALIDACIÓN
            # ======================================

            symbol = str(symbol).upper().strip()

            if not self.is_valid_symbol(symbol):

                raise ValueError(
                    f"Símbolo inválido: {symbol}"
                )

            raw = self.binance.get_klines(
                symbol=symbol,
                interval=interval,
                limit=limit
            )

            log.info(
                f"KLINES {symbol} {interval} -> {len(raw) if raw else 0}"
            )

            if raw is None:

                raise ValueError(
                    "RAW klines = None"
                )

            if len(raw) == 0:

                raise ValueError(
                    "RAW klines vacío"
                )

            # ======================================
            # DATAFRAME
            # ======================================

            df = pd.DataFrame(
                raw,
                columns=[
                    "time",
                    "open",
                    "high",
                    "low",
                    "close",
                    "volume",
                    "close_time",
                    "quote_asset_volume",
                    "number_of_trades",
                    "taker_buy_base",
                    "taker_buy_quote",
                    "ignore"
                ]
            )

            if df.empty:

                raise ValueError(
                    "DF inicial vacío"
                )

            # ======================================
            # NUMÉRICOS
            # ======================================

            numeric_cols = [
                "open",
                "high",
                "low",
                "close",
                "volume"
            ]

            for col in numeric_cols:

                df[col] = pd.to_numeric(
                    df[col],
                    errors="coerce"
                )

            # ======================================
            # TIME
            # ======================================

            df["time"] = pd.to_datetime(
                df["time"],
                unit="ms",
                errors="coerce"
            )

            # ======================================
            # LIMPIEZA
            # ======================================

            df = df.dropna(
                subset=[
                    "time",
                    "open",
                    "high",
                    "low",
                    "close"
                ]
            )

            if df.empty:

                raise ValueError(
                    "DF vacío tras limpieza"
                )

            # ======================================
            # SORT
            # ======================================

            df = df.sort_values(
                "time"
            ).reset_index(drop=True)

            return df

        except Exception as e:

            log.exception(
                f"KLINES DF ERROR [{symbol}]"
            )

            return pd.DataFrame()

    # ==========================================================
    # OHLCV
    # ==========================================================

    def get_ohlcv(
        self,
        symbol,
        timeframe="1m",
        limit=200
    ):

        try:

            df = self.get_klines_df(
                symbol=symbol,
                interval=timeframe,
                limit=limit
            )

            if df.empty:
                return []

            rows = []

            for _, row in df.iterrows():

                rows.append({

                    "timestamp": int(
                        row["time"].timestamp()
                        * 1000
                    ),

                    "open": float(row["open"]),

                    "high": float(row["high"]),

                    "low": float(row["low"]),

                    "close": float(row["close"]),

                    "volume": float(row["volume"])
                })

            return rows

        except Exception:

            log.exception(
                f"OHLCV ERROR [{symbol}]"
            )

            return []

    # ==========================================================
    # UI OHLC DATA
    # ==========================================================

    def get_ohlc_df_for_ui(
        self,
        symbol,
        timeframe="5m",
        limit=300
    ):

        try:

            df = self.get_klines_df(
                symbol=symbol,
                interval=timeframe,
                limit=limit
            )

            if df is None:
                return pd.DataFrame()

            return df.copy()

        except Exception:

            log.exception(
                f"OHLC UI ERROR [{symbol}]"
            )

            return pd.DataFrame()
