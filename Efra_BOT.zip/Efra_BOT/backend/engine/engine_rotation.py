# backend/engine/engine_rotation.py

import logging

logger = logging.getLogger(__name__)


class RotationMixin:

    # ==========================================================
    # ROTATE PORTFOLIO
    # ==========================================================
    async def rotate_portfolio(self):

        try:

            results = await self.run_multi_asset_cycle()

            trades = getattr(
                self.trade_manager,
                "trades",
                {}
            )

            for symbol, trade in list(trades.items()):

                try:

                    # ======================================
                    # IGNORE CLOSED
                    # ======================================

                    if getattr(trade, "closed", False):
                        continue

                    confidence = getattr(
                        trade,
                        "confidence",
                        100
                    )

                    # ======================================
                    # WEAK POSITION
                    # ======================================

                    if confidence < 70:

                        self.order_manager.close_position(
                            symbol=symbol,
                            reason="PORTFOLIO_ROTATION"
                        )

                        logger.warning(
                            f"Position rotated: {symbol}"
                        )

                except Exception:
                    logger.exception(
                        f"Rotation failed: {symbol}"
                    )

            return results

        except Exception:
            logger.exception(
                "rotate_portfolio failed"
            )

            return []
