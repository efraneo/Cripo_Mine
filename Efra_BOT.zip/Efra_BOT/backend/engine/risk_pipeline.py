# backend/engine/risk_pipeline.py

from core.risk.risk_engine import (
    dynamic_risk,
    detect_session
)


class RiskPipeline:

    def __init__(self, engine):

        self.engine = engine

    # ======================================================
    # MAIN
    # ======================================================

    def compute(self, symbol, ia_decision):

        session = detect_session()

        confidence = float(
            ia_decision.get("confidence", 0)
        )

        signal_type = (
            "CONTINUATION"
            if ia_decision.get("direction") != "neutral"
            else "REVERSAL"
        )

        risk_cfg = dynamic_risk(
            score=confidence,
            session=session,
            signal_type=signal_type,
            is_late_entry=False
        )

        if not risk_cfg["allowed"]:

            return {
                "allowed": False,
                "reason": risk_cfg["reason"]
            }

        # ==================================================
        # POSITION SIZE
        # ==================================================

        balance = float(
            self.engine.binance.get_balance("USDT")
        )

        price = float(
            self.engine.binance.get_price(symbol)
        )

        equity_state = self.engine.equity_tracker.get_state()

        current_equity = equity_state.get(
            "equity",
            balance
        )

        current_drawdown = equity_state.get(
            "drawdown",
            0.0
        )

        qty = self.engine.risk.calculate_position_size(
            capital=current_equity,
            price=price,
            strategy="KELLY",
            winrate=0.55,
            confidence=confidence,
            drawdown=current_drawdown,
            rr=1.5,
            regime=ia_decision.get("regime")
        )

        return {
            "allowed": True,
            "risk": risk_cfg,
            "qty": qty,
            "usd_size": qty * price,
            "session": session
        }
