# backend/engine/engine_execution.py

import asyncio
from datetime import datetime


class ExecutionMixin:

    # ==========================================================
    # EXECUTE TRADE
    # ==========================================================
    async def execute_trade(
        self,
        symbol,
        usd_amount,
        ia_decision=None,
        steps=1,
        mode=None,
        user=None,
        **kwargs
    ):

        if not ia_decision:
            return {
                "success": False,
                "reason": "IA decision requerida"
            }

        confidence = float(
            ia_decision.get("confidence", 0)
        )

        # ======================================================
        # FILTRO IA
        # ======================================================

        if confidence < 90:

            return {
                "success": False,
                "reason": "IA confidence too low",
                "confidence": confidence
            }

        # ======================================================
        # DIRECCIÓN
        # ======================================================

        direction = ia_decision.get(
            "direction",
            "LONG"
        )

        side = (
            "BUY"
            if direction in ["LONG", "BUY", "UP"]
            else "SELL"
        )

        # ======================================================
        # PRECIO
        # ======================================================

        try:

            price = float(
                self.binance.get_price(symbol)
            )

        except Exception as e:

            return {
                "success": False,
                "reason": f"Price error: {e}"
            }

        # ======================================================
        # QTY
        # ======================================================

        quantity = usd_amount / max(price, 0.0000001)

        # ======================================================
        # REAL EXECUTION
        # ======================================================

        try:

            loop = asyncio.get_event_loop()

            order = await loop.run_in_executor(
                None,
                lambda: self.order_manager.execute_compound_order(
                    symbol=symbol,
                    usdt_amount=float(usd_amount),
                    dca_levels=int(steps),
                    ai_confidence=confidence / 100.0,
                    user=user
                )
            )

        except Exception as e:

            return {
                "success": False,
                "reason": str(e)
            }

        # ======================================================
        # TRADE MANAGER
        # ======================================================

        try:

            if hasattr(self, "trade_manager"):

                self.trade_manager.open_trade(
                    symbol=symbol,
                    entry_price=price,
                    qty=quantity,
                    atr=ia_decision.get("atr"),
                    confidence=confidence
                )

        except Exception as e:

            print("TRADE MANAGER ERROR:", e)

        # ======================================================
        # TELEGRAM
        # ======================================================

        try:

            from backend.telegram_notifier import (
                send_telegram_message
            )

            send_telegram_message(
                f"🚀 TRADE EJECUTADO\n"
                f"Symbol: {symbol}\n"
                f"Side: {side}\n"
                f"Confidence: {confidence:.2f}%\n"
                f"Price: {price}\n"
                f"USDT: {usd_amount}"
            )

        except Exception as e:

            print("TELEGRAM ERROR:", e)

        # ======================================================
        # RESPONSE
        # ======================================================

        return {
            "success": True,
            "symbol": symbol,
            "side": side,
            "price": price,
            "quantity": quantity,
            "usd_amount": usd_amount,
            "confidence": confidence,
            "timestamp": datetime.utcnow().isoformat(),
            "order": order
        }

    # ==========================================================
    # AUTO TRADE
    # ==========================================================
    def run_auto_trade(
        self,
        symbol,
        ia
    ):

        return asyncio.run(
            self.execute_trade(
                symbol=symbol,
                usd_amount=ia.get("capital", 10),
                ia_decision=ia
            )
        )
