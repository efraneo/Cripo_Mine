# backend/engine/engine_portfolio.py

import logging

logger = logging.getLogger(__name__)


class PortfolioMixin:

    # ==========================================================
    # MULTI ASSET CYCLE
    # ==========================================================
    async def run_multi_asset_cycle(self):

        try:

            # ==============================================
            # MARKET SCAN
            # ==============================================

            results = self.scanner.scan_market()

            if not results:
                return []

            # ==============================================
            # BEST TRADES
            # ==============================================

            best = self.multi_asset_engine.select_best_trades(
                results
            )

            if not best:
                return []

            # ==============================================
            # CAPITAL ALLOCATION
            # ==============================================

            allocation = self.multi_asset_engine.allocate_capital(
                best
            )

            executed = []

            # ==============================================
            # EXECUTION
            # ==============================================

            for trade in allocation:

                try:

                    result = await self.auto_trader.run_cycle(
                        trade["symbol"],
                        {
                            **trade["ia"],
                            "capital": trade["usd"]
                        }
                    )

                    executed.append({
                        "symbol": trade["symbol"],
                        "result": result
                    })

                except Exception:
                    logger.exception(
                        "Portfolio execution failed"
                    )

            return executed

        except Exception:
            logger.exception(
                "run_multi_asset_cycle failed"
            )

            return []
