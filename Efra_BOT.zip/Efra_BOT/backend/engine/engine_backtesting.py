# backend/engine/engine_backtesting.py

import logging

logger = logging.getLogger(__name__)


class BacktestingMixin:

    # ==========================================================
    # BACKTEST WITH IA SNAPSHOT
    # ==========================================================
    def backtest_with_ia_snapshot(
        self,
        symbol: str,
        data_by_tf: dict,
        ia_decision: dict,
        initial_usd: float = 1000.0
    ):

        try:

            results = []

            tf_data = data_by_tf.get("5m", {})
            df = tf_data.get("df")

            if df is None:
                return []

            if "close" not in df:
                return []

            price_series = df["close"]

            if len(price_series) == 0:
                return []

            direction = ia_decision.get(
                "direction",
                "LONG"
            )

            entry_price = float(
                price_series.iloc[0]
            )

            for price in price_series:

                price = float(price)

                if direction in ["LONG", "BUY"]:

                    pnl = (
                        (price - entry_price)
                        / entry_price
                    ) * 100

                else:

                    pnl = (
                        (entry_price - price)
                        / entry_price
                    ) * 100

                results.append({
                    "symbol": symbol,
                    "price": price,
                    "pnl": pnl,
                    "confidence": ia_decision.get(
                        "confidence",
                        0
                    ),
                    "direction": direction
                })

            return results

        except Exception:
            logger.exception(
                "Backtesting failed"
            )

            return []

    # ==========================================================
    # SIMPLE EQUITY CURVE
    # ==========================================================
    def build_equity_curve(
        self,
        backtest_results,
        initial_balance=1000
    ):

        balance = initial_balance

        curve = []

        try:

            for row in backtest_results:

                pnl = row.get("pnl", 0)

                balance = balance * (
                    1 + (pnl / 100)
                )

                curve.append({
                    "balance": balance,
                    "pnl": pnl
                })

            return curve

        except Exception:
            logger.exception(
                "Equity curve failed"
            )

            return []
