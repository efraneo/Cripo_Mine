# backend/engine/engine_multi_asset.py

import logging

logger = logging.getLogger(__name__)


class MultiAssetMixin:

    # ==========================================================
    # MULTI ASSET EXECUTION
    # ==========================================================
    async def execute_multi_asset_strategy(
        self,
        trades
    ):
        if not trades:
            return []
        import asyncio
        tasks=[]

        for trade in trades:
            symbol=trade.get(
                "symbol"
            )
            ia=trade.get(
                "ia",
                {}
            )
            usd=trade.get(
                "usd",
                10
            )
            tasks.append(
                self.execute_trade(
                    symbol=symbol,
                    usd_amount=usd,
                    ia_decision=ia
                )
            )
        results=await asyncio.gather(
            *tasks,
            return_exceptions=True
        )
        executed=[]
        for i,result in enumerate(results):
            if isinstance(
                result,
                Exception
            ):
                continue
            executed.append({
                "symbol":
                trades[i]["symbol"],
                "result":
                result
            })
        return executed

    # ==========================================================
    # CAPITAL DISTRIBUTION
    # ==========================================================
    def compute_multi_asset_allocation(
        self,
        candidates,
        total_capital
    ):

        if not candidates:
            return []

        total_score = sum(
            x.get("ia", {}).get("confidence", 0)
            for x in candidates
        )

        if total_score <= 0:
            return []

        allocation = []

        for asset in candidates:

            conf = asset.get(
                "ia",
                {}
            ).get(
                "confidence",
                0
            )

            kelly_fraction = asset.get(
                "capital_fraction",
                0.05
            )

            vol_scale = asset.get(
                "volatility_scale",
                1.0
            )

            fraction = (
                conf / total_score
            ) * kelly_fraction * vol_scale

            fraction = min(
                fraction,
                0.30
            )

            usd = total_capital * fraction

            allocation.append({
                **asset,
                "usd": usd
            })

        return allocation

    # ==========================================================
    # FILTER BEST ASSETS
    # ==========================================================
    def filter_best_assets(
        self,
        scan_results,
        min_confidence=90
    ):

        if not scan_results:
            return []

        valid = []

        for asset in scan_results:

            ia = asset.get("ia", {})

            confidence = ia.get(
                "confidence",
                0
            )

            if confidence >= min_confidence:
                valid.append(asset)

        valid.sort(
            key=lambda x: x.get(
                "ia",
                {}
            ).get(
                "confidence",
                0
            ),
            reverse=True
        )

        return valid
