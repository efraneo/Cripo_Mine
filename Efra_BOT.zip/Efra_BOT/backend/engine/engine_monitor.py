# backend/engine/engine_monitor.py

import asyncio
import logging

logger = logging.getLogger(__name__)


class MonitorMixin:

    # ==========================================================
    # MONITOR OPEN TRADES
    # ==========================================================
    async def monitor_open_trades(
        self,
        interval_sec: int = 5
    ):
        """
        Monitor institucional de posiciones abiertas.
        """

        logger.info(
            "Monitor de trades iniciado",
            extra={
                "interval_sec": interval_sec
            }
        )

        while True:

            try:

                trades = getattr(
                    self.trade_manager,
                    "trades",
                    {}
                )

                for symbol, trade in list(trades.items()):

                    try:

                        # ======================================
                        # CLOSED
                        # ======================================

                        if getattr(trade, "closed", False):
                            continue

                        # ======================================
                        # PRICE
                        # ======================================

                        price = self.binance.get_price(symbol)

                        # ======================================
                        # IA LIVE UPDATE
                        # ======================================

                        ia_score = 0.0

                        try:

                            klines = self.get_ohlcv(
                                symbol=symbol,
                                timeframe="1m",
                                limit=200
                            )

                            if klines:

                                prediction = self.get_ia_pro_decision(
                                    symbol,
                                    {
                                        "1m": {
                                            "df": klines
                                        }
                                    }
                                )

                                ia_score = float(
                                    prediction.get(
                                        "confidence",
                                        0
                                    )
                                )

                        except Exception:
                            logger.exception(
                                "IA update failed"
                            )

                        # ======================================
                        # UPDATE TRADE STATE
                        # ======================================

                        result = self.update_trade_state(
                            symbol=symbol,
                            ia_score=ia_score,
                            atr=getattr(trade, "atr", None)
                        )

                        # ======================================
                        # CLOSE SIGNAL
                        # ======================================

                        if result == "CLOSE_SIGNAL":

                            try:

                                self.order_manager.close_position(
                                    symbol=symbol,
                                    reason="ENGINE_MONITOR_CLOSE"
                                )

                            except Exception:
                                logger.exception(
                                    "Close position failed"
                                )

                    except Exception:
                        logger.exception(
                            f"Monitor trade error: {symbol}"
                        )

            except Exception:
                logger.exception(
                    "Global monitor loop error"
                )

            await asyncio.sleep(interval_sec)
