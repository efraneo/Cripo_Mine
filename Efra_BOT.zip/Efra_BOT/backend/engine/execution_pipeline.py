# 📄 backend/engine/execution_pipeline.py

```python
import asyncio
import logging
from datetime import datetime

log = logging.getLogger(__name__)


class ExecutionPipelineMixin:

    async def execute_trade(
        self,
        symbol,
        usd_amount,
        ia_decision,
        **kwargs
    ):

        if ia_decision.get("confidence", 0) < 90:
            return {
                "success": False,
                "reason": "LOW_CONFIDENCE"
            }

        loop = asyncio.get_running_loop()

        res = await loop.run_in_executor(
            None,
            lambda: self.order_manager.execute_compound_order(
                symbol=symbol,
                usdt_amount=float(usd_amount),
                ai_confidence=ia_decision["confidence"] / 100.0,
            )
        )

        return {
            "success": True,
            "symbol": symbol,
            "price": getattr(res, "average_price", None),
            "qty": getattr(res, "amount_executed", None),
            "timestamp": datetime.utcnow().isoformat()
        }
