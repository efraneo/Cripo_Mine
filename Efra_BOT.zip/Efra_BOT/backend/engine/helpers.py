# backend/engine/helpers.py

import pandas as pd


# ==========================================================
# ENSURE DF
# ==========================================================

def ensure_dataframe(data):

    if data is None:
        return None

    if isinstance(data, pd.DataFrame):
        return data.copy()

    try:
        return pd.DataFrame(data)
    except Exception:
        return None


# ==========================================================
# NORMALIZE BINANCE DF
# ==========================================================

def normalize_klines_dataframe(df):

    if df is None or df.empty:
        return df

    mapping = {}

    for c in df.columns:

        lc = c.lower()

        if lc in ["t", "time", "open_time"]:
            mapping[c] = "time"

        elif lc in ["o", "open"]:
            mapping[c] = "open"

        elif lc in ["h", "high"]:
            mapping[c] = "high"

        elif lc in ["l", "low"]:
            mapping[c] = "low"

        elif lc in ["c", "close"]:
            mapping[c] = "close"

        elif lc in ["v", "volume"]:
            mapping[c] = "volume"

    df = df.rename(columns=mapping)

    for col in [
        "open",
        "high",
        "low",
        "close",
        "volume"
    ]:

        if col in df.columns:

            df[col] = pd.to_numeric(
                df[col],
                errors="coerce"
            )

    return df


# ==========================================================
# SAFE FLOAT
# ==========================================================

def safe_float(value, default=0.0):

    try:
        return float(value)
    except Exception:
        return default


# ==========================================================
# SAFE INT
# ==========================================================

def safe_int(value, default=0):

    try:
        return int(value)
    except Exception:
        return default
