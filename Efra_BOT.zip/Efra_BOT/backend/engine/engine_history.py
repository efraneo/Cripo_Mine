# backend/engine/engine_history.py

import os
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

TRADE_HISTORY_FILE = "data/trade_history.json"


class HistoryMixin:

    # ==========================================================
    # ENSURE FILE
    # ==========================================================
    def _ensure_trade_history_file(self):

        try:

            os.makedirs(
                "data",
                exist_ok=True
            )

            if not os.path.exists(TRADE_HISTORY_FILE):

                with open(
                    TRADE_HISTORY_FILE,
                    "w",
                    encoding="utf-8"
                ) as f:

                    json.dump([], f)

        except Exception:
            logger.exception(
                "Trade history init failed"
            )

    # ==========================================================
    # RECORD TRADE
    # ==========================================================
    def record_trade(
        self,
        trade_data: dict
    ):

        try:

            self._ensure_trade_history_file()

            with open(
                TRADE_HISTORY_FILE,
                "r",
                encoding="utf-8"
            ) as f:

                history = json.load(f)

            record = {
                "timestamp": datetime.utcnow().isoformat(),
                **trade_data
            }

            history.append(record)

            with open(
                TRADE_HISTORY_FILE,
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    history,
                    f,
                    indent=2
                )

            return True

        except Exception:
            logger.exception(
                "record_trade failed"
            )

            return False

    # ==========================================================
    # GET HISTORY
    # ==========================================================
    def get_trade_history(
        self,
        limit=200
    ):

        try:

            self._ensure_trade_history_file()

            with open(
                TRADE_HISTORY_FILE,
                "r",
                encoding="utf-8"
            ) as f:

                history = json.load(f)

            return list(
                reversed(history)
            )[:limit]

        except Exception:
            logger.exception(
                "get_trade_history failed"
            )

            return []
