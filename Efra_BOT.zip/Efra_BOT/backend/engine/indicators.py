# 📄 backend/engine/indicators.py

```python
import numpy as np
import pandas as pd


def rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)

    ma_up = up.ewm(alpha=1 / period).mean()
    ma_down = down.ewm(alpha=1 / period).mean()

    rs = ma_up / ma_down.replace(0, np.nan)

    return 100 - (100 / (1 + rs))


def atr(df, period=14):
    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()

    tr = pd.concat([
        high_low,
        high_close,
        low_close
    ], axis=1).max(axis=1)

    return tr.rolling(period).mean()
```

---

