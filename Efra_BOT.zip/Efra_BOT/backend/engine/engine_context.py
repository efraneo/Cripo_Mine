# backend/engine/engine_context.py

from datetime import datetime
import random


class ContextMixin:

    # ==========================================================
    # CONTEXTO INSTITUCIONAL GLOBAL
    # ==========================================================

    def get_market_context(self):

        session_name = self.get_session_dominance()

        news = self.get_news_risk()

        macro = self.get_macro_context()

        # ==========================================
        # MAPEO PARA UI
        # ==========================================

        session_bias = {
            "NEW_YORK": "VOLATILE",
            "LONDON": "TREND",
            "ASIA": "RANGE",
            "OVERLAP": "HIGH_VOL"
        }.get(
            session_name,
            "NEUTRAL"
        )

        ui_session = {
            "active": session_name,
            "bias": session_bias
        }

        ui_news = {
            "risk": news.get(
                "risk",
                "LOW"
            ),
            "headline_count": news.get(
                "events",
                0
            )
        }

        # ==========================================
        # RETORNO HÍBRIDO
        # mantiene compatibilidad
        # ==========================================

        return {

            # NUEVO (UI)
            "session": ui_session,
            "news": ui_news,

            # LEGACY
            "session_dominance": session_name,
            "news_risk": news,
            "macro_context": macro
        }

    # ==========================================================
    # SESSION DOMINANCE
    # ==========================================================

    def get_session_dominance(self):

        hour = datetime.utcnow().hour

        # NEW YORK
        if 13 <= hour <= 21:
            return "NEW_YORK"

        # LONDON
        elif 7 <= hour <= 15:
            return "LONDON"

        # ASIA
        elif 0 <= hour <= 8:
            return "ASIA"

        return "OVERLAP"

    # ==========================================================
    # NEWS RISK
    # ==========================================================

    def get_news_risk(self):

        try:

            simulated_events = random.randint(
                0,
                3
            )

            if simulated_events >= 2:

                risk = "HIGH"

            elif simulated_events == 1:

                risk = "MEDIUM"

            else:

                risk = "LOW"

            return {
                "risk": risk,
                "events": simulated_events
            }

        except Exception:

            return {
                "risk": "LOW",
                "events": 0
            }

    # ==========================================================
    # MACRO CONTEXT
    # ==========================================================

    def get_macro_context(self):

        try:

            btc_dominance = random.uniform(
                48,
                63
            )

            if btc_dominance > 58:

                bias = "RISK_OFF"

            else:

                bias = "RISK_ON"

            return {

                "btc_dominance": round(
                    btc_dominance,
                    2
                ),

                "market_bias": bias
            }

        except Exception:

            return {

                "btc_dominance": 55.0,
                "market_bias": "NEUTRAL"
            }
