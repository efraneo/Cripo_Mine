# backend/engine/predictor_fallback.py

import numpy as np
import pandas as pd
from typing import Dict, Any


# ==========================================================
# HELPERS
# ==========================================================

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()

    up = delta.clip(lower=0.0)
    down = -1.0 * delta.clip(upper=0.0)

    ma_up = up.ewm(alpha=1 / period, min_periods=period).mean()
    ma_down = down.ewm(alpha=1 / period, min_periods=period).mean()

    rs = ma_up / (ma_down.replace(0, np.nan))

    return (100 - (100 / (1 + rs))).fillna(50.0)


def macd(series, fast=12, slow=26, signal=9):

    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()

    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()

    hist = macd_line - signal_line

    return {
        "macd": macd_line,
        "signal": signal_line,
        "hist": hist
    }


def atr(df: pd.DataFrame, period: int = 14):

    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()

    tr = pd.concat(
        [high_low, high_close, low_close],
        axis=1
    ).max(axis=1)

    return tr.rolling(period).mean().fillna(0.0)


# ==========================================================
# FALLBACK PREDICTOR
# ==========================================================

class FallbackPredictor:

    def __init__(self):

        self.max_confidence = 93.0

    def predict(self, df: pd.DataFrame) -> Dict[str, Any]:

        if df is None or len(df) < 50:
            return self._neutral()

        try:

            close = df["close"]

            rsi_value = float(rsi(close).iloc[-1])

            macd_data = macd(close)

            macd_hist = float(macd_data["hist"].iloc[-1])

            atr_value = float(atr(df).iloc[-1])

            direction = "neutral"

            score = 50.0

            # ==================================================
            # RSI
            # ==================================================

            if rsi_value < 30:
                score += 20
                direction = "LONG"

            elif rsi_value > 70:
                score += 20
                direction = "SHORT"

            # ==================================================
            # MACD
            # ==================================================

            if macd_hist > 0:
                score += 15
            else:
                score -= 15

            # ==================================================
            # ATR FILTER
            # ==================================================

            volatility = atr_value / max(close.iloc[-1], 1)

            if volatility > 0.03:
                score -= 10

            confidence = max(
                0,
                min(
                    self.max_confidence,
                    score
                )
            )

            return {
                "direction": direction,
                "confidence": confidence,
                "atr": atr_value,
                "source": "FALLBACK_PREDICTOR"
            }

        except Exception:
            return self._neutral()

    def _neutral(self):

        return {
            "direction": "neutral",
            "confidence": 0.0,
            "source": "FALLBACK_PREDICTOR"
        }
