# backend/engine/engine_cycle.py

import logging
import pandas as pd
import numpy as np
from core.risk.risk_engine import dynamic_risk


logger = logging.getLogger(__name__)


class CycleMixin:

    MAX_LONG_EXPOSURE = 0.60
    MAX_SHORT_EXPOSURE = 0.60
    MAX_SINGLE_ASSET = 0.25

    # ======================================================
    # MAIN CYCLE
    # ======================================================

    async def run_multi_asset_cycle(self):

        try:

            logger.info(
                "STARTING INSTITUTIONAL CYCLE"
            )

            # ======================================================
            # 1 SCAN
            # ======================================================

            results = self.scanner.scan_market()

            if not results:
                return self._fail(
                    "No scan results"
                )

            # ======================================================
            # 2 BEST
            # ======================================================

            candidates = self.filter_best_assets(
                results,
                min_confidence=65
            )

            if not candidates:
                return self._fail(
                    "No valid candidates"
                )

            # ======================================================
            # 3 OPEN POSITIONS FILTER
            # ======================================================

            candidates = self.remove_open_positions(
                candidates
            )

            # ======================================================
            # 4 CORRELATION FILTER
            # ======================================================

            candidates = self.correlation_filter(
                candidates
            )

            # ======================================================
            # 5 REGIME FILTER
            # ======================================================

            candidates = self.regime_filter(
                candidates
            )

            if not candidates:
                return self._fail(
                    "No regime candidates"
                )

            # ======================================================
            # 5.1 VOLATILITY TARGETING
            # ======================================================

            candidates = self.volatility_targeting(
                candidates
            )

            # ======================================================
            # 5.2 KELLY POSITION SIZE
            # ======================================================

            candidates = self.kelly_position_sizing(
                candidates
            )

            # ======================================================
            # 6 HEDGE ALLOCATION
            # ======================================================

            candidates = self.hedge_allocator(
                candidates
            )

            # ======================================================
            # 7 EXPOSURE CONTROL
            # ======================================================

            candidates = self.exposure_manager(
                candidates
            )

            if not candidates:
                return self._fail(
                    "Exposure exceeded"
                )

            # ======================================================
            # CAPITAL
            # ======================================================

            balance = self.get_balance(
                "USDT"
            )

            allocation = (
                self.compute_multi_asset_allocation(
                    candidates,
                    balance
                )
            )

            # ======================================================
            # 8 EXECUTION VALIDATION
            # ======================================================

            allocation = self.execution_validation(
                allocation
            )

            if not allocation:

                return self._fail(
                    "Execution validation failed"
                )

            # ======================================================
            # 9 EXECUTE
            # ======================================================

            executed = await self.execute_multi_asset_strategy(
                allocation
            )

            # ======================================================
            # 10 MONITOR
            # ======================================================

            if hasattr(
                self,
                "monitor_positions"
            ):
                self.monitor_positions()

            return {
                "executed": len(executed) > 0,
                "orders": executed,
                "type": "INSTITUTIONAL_CYCLE"
            }

        except Exception as e:

            logger.exception(
                "Cycle failed"
            )

            return self._fail(str(e))

    # ======================================================
    # CORRELATION FILTER
    # ======================================================
    def correlation_filter(
        self,
        candidates,
        max_corr=0.75
    ):
        if len(candidates) <= 1:
            return candidates
        returns = {}

        # ==============================
        # OBTENER RETORNOS
        # ==============================
        for asset in candidates:
            symbol = asset["symbol"]
            try:
                df = self.get_klines_df(
                    symbol=symbol,
                    interval="5m",
                    limit=100
                )
                if df is None or df.empty:
                    continue

                r = (
                    df["close"]
                    .pct_change()
                    .dropna()
                )
                returns[symbol] = r
            except Exception:
                continue

        if len(returns) <= 1:
            return candidates

        # ==============================
        # MATRIZ CORRELACIÓN
        # ==============================
        returns_df = pd.DataFrame(
            returns
        )
        corr_matrix = returns_df.corr()
        selected = []
        for asset in candidates:
            symbol = asset["symbol"]
            keep = True
            for s in selected:
                try:
                    corr = abs(
                        corr_matrix.loc[
                            symbol,
                            s
                        ]
                    )
                    if corr >= max_corr:
                        keep = False
                        break
                except Exception:
                    pass

            if keep:
                selected.append(symbol)

        return [
            a for a in candidates
            if a["symbol"] in selected
        ]

    # ======================================================
    # HEDGE ALLOCATOR
    # ======================================================

    def hedge_allocator(
        self,
        candidates
    ):

        longs=[]
        shorts=[]

        for c in candidates:

            direction=(
                c.get(
                    "ia",
                    {}
                ).get(
                    "direction",
                    "LONG"
                )
            )

            if direction=="SHORT":
                shorts.append(c)

            else:
                longs.append(c)

        result=[]

        result.extend(
            longs[:2]
        )

        result.extend(
            shorts[:2]
        )

        return result

    # ======================================================
    # EXPOSURE MANAGER
    # ======================================================
    def exposure_manager(
        self,
        candidates
    ):

        filtered=[]
        current_risk=0
        MAX_PORTFOLIO_RISK=0.06

        for asset in candidates:

            ia=asset.get(
                "ia",
                {}
            )

            confidence=ia.get(
                "confidence",
                90
            )

            trade_risk=(
                0.02*
                (
                    confidence/100
                )
            )

            if (
                current_risk+
                trade_risk
                >
                MAX_PORTFOLIO_RISK
            ):
                continue

            current_risk+=trade_risk
            filtered.append(
                asset
            )
        return filtered

    # ======================================================
    # EXECUTION VALIDATION
    # ======================================================
    def execution_validation(
        self,
        allocation
    ):
        validated=[]
        for trade in allocation:
            ia=trade.get(
                "ia",
                {}
            )
            confidence=ia.get(
                "confidence",
                0
            )
            risk=dynamic_risk(
                score=confidence
            )
            if not risk.get(
                "allowed"
            ):
                continue
            trade["risk"]=risk
            validated.append(
                trade
            )
        return validated

    # ======================================================
    # OPEN FILTER
    # ======================================================

    def remove_open_positions(
        self,
        assets
    ):

        active={}

        if hasattr(
            self,
            "auto_trader"
        ):
            active=(
                self.auto_trader
                .active_positions
            )

        return [

            a for a in assets

            if a["symbol"]
            not in active
        ]

    # ======================================================
    # REGIME FILTER
    # ======================================================

    def regime_filter(
        self,
        assets
    ):

        valid=[]

        blocked={

            "CRISIS",
            "SIDEWAYS",
            "UNKNOWN"
        }

        for a in assets:

            regime=(
                a.get(
                    "ia",
                    {}
                ).get(
                    "regime",
                    "UNKNOWN"
                )
            )

            if regime not in blocked:
                valid.append(a)

        return valid

    # ======================================================
    # VOLATILITY TARGETING
    # ======================================================
    def volatility_targeting(
        self,
        candidates,
        target_vol=0.015
    ):
        adjusted=[]
        for asset in candidates:
            symbol=asset["symbol"]
            try:
                df=self.get_klines_df(
                    symbol=symbol,
                    interval="5m",
                    limit=100
                )
                if df is None or df.empty:
                    continue

                vol=(
                    df["close"]
                    .pct_change()
                    .std()
                )
                vol=max(
                    vol,
                    0.001
                )
                scale=min(
                    2.0,
                    target_vol/vol
                )
                asset["volatility_scale"]=scale
                adjusted.append(
                    asset
                )
            except Exception:
                continue

        return adjusted

    # ======================================================
    # KELLY POSITION SIZE
    # ======================================================
    def kelly_position_sizing(
        self,
        candidates
    ):

        for asset in candidates:

            ia=asset.get(
                "ia",
                {}
            )

            confidence=(
                ia.get(
                    "confidence",
                    50
                )/100
            )

            reward=2.0
            risk=1.0

            kelly=(
                (
                    confidence*
                    reward
                )
            -
                (
                    (1-confidence)
                    /risk
                )
            )/reward

            kelly=max(
                0.01,
                min(
                    0.25,
                    kelly
                )
            )

            asset[
                "capital_fraction"
            ]=kelly

        return candidates

    # ======================================================
    # FAIL
    # ======================================================

    def _fail(
        self,
        reason
    ):

        return {

            "executed":False,
            "reason":reason
        }
