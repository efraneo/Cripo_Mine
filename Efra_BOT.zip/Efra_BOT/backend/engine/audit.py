# backend/engine/audit.py

from datetime import datetime

from core.ia_audit_log import get_ia_audit_logger


class EngineAudit:

    def __init__(self):

        self.audit = get_ia_audit_logger()

    # ======================================================
    # IA DECISION
    # ======================================================

    def log_ia(
        self,
        symbol,
        context,
        ia_decision,
        data_by_tf=None
    ):

        try:

            self.audit.log_decision(
                symbol=symbol,
                context=context,
                ia_decision=ia_decision,
                data_by_tf=data_by_tf
            )

        except Exception:
            pass

    # ======================================================
    # EXECUTION
    # ======================================================

    def log_execution(
        self,
        symbol,
        side,
        confidence
    ):

        try:

            print(
                f"[AUDIT] "
                f"{datetime.utcnow().isoformat()} | "
                f"{symbol} | "
                f"{side} | "
                f"{confidence}"
            )

        except Exception:
            pass
