# backend/user_activity_db.py

import sqlite3
from datetime import datetime

DB = "data/user_activity.db"

def init_activity_db():

    conn = sqlite3.connect(DB)

    conn.execute("""
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        role TEXT,
        ip TEXT,
        action TEXT,
        symbol TEXT,
        extra TEXT,
        timestamp TEXT
    )
    """)

    conn.commit()
    conn.close()

def save_activity(
    username,
    role,
    ip,
    action,
    symbol="",
    extra=""
):

    conn = sqlite3.connect(DB)

    conn.execute("""
    INSERT INTO activity_logs (
        username,
        role,
        ip,
        action,
        symbol,
        extra,
        timestamp
    )
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        username,
        role,
        ip,
        action,
        symbol,
        extra,
        datetime.utcnow().isoformat()
    ))

    conn.commit()
    conn.close()
