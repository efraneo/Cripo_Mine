# backend/exec_real.py
"""
Módulo responsable de ejecutar órdenes REALES en Binance, validando:
- Balance disponible
- Cantidad mínima permitida
- Riesgo básico
- Ejecución de mercado
- Manejo de errores

Este módulo está diseñado para integrarse con:
  ▶ backend/binance_client.py
  ▶ trading_engine.py
  ▶ el_bot_de_Efra.py

IMPORTANTE: Esta es una implementación profesional,
compatible con tu arquitectura actual.
Puedes expandirlo según tus necesidades.
"""

import logging
from typing import Optional, Dict, Any


class ExecutionError(Exception):
    """Excepción personalizada para errores en ejecución real."""
    pass


def check_balance_and_execute(client, symbol: str, quantity: float, side: str) -> Optional[Dict[str, Any]]:
    """
    Ejecuta una orden REAL en Binance.

    Parámetros:
        client  (BinanceClient): Cliente configurado con API KEY y SECRET.
        symbol  (str)          : Par de trading (ej: "BTCUSDT").
        quantity(float)        : Cantidad a comprar/vender.
        side    (str)          : "BUY" o "SELL".

    Return:
        dict | None: Resultado de la orden o None en caso de error.
    """

    logging.info(f"🚀 Iniciando ejecución real para {symbol} - {side} {quantity}")

    try:
        # 1️⃣ Validación inicial
        if quantity <= 0:
            raise ExecutionError("La cantidad debe ser mayor a 0.")

        if side not in ("BUY", "SELL"):
            raise ExecutionError("El parámetro 'side' debe ser 'BUY' o 'SELL'.")

        # 2️⃣ Verificación de balance
        base_asset = symbol.replace("USDT", "")

        if side == "BUY":
            balance = client.get_asset_balance("USDT")
            price = client.get_symbol_price(symbol)
            required_usdt = price * quantity

            logging.info(f"💲 Precio actual {symbol}: {price} | Requerido USDT: {required_usdt}")

            if balance < required_usdt:
                raise ExecutionError(
                    f"Fondos insuficientes. Requerido: {required_usdt}, Disponible: {balance}"
                )

        else:  # SELL
            balance = client.get_asset_balance(base_asset)
            if balance < quantity:
                raise ExecutionError(
                    f"Fondos insuficientes para vender {quantity} {base_asset}. Disponible: {balance}"
                )

        logging.info(f"✔ Balance verificado correctamente.")

        # 3️⃣ Ejecutar orden real
        logging.info(f"📤 Enviando orden REAL: {side} {quantity} {symbol}")

        order = client.place_market_order(symbol=symbol, side=side, quantity=quantity)

        logging.info(f"✅ Orden ejecutada correctamente: {order}")

        return order

    except ExecutionError as e:
        logging.error(f"❌ Error de ejecución: {e}")
        return None

    except Exception as e:
        logging.exception(f"❌ Error inesperado ejecutando la orden REAL: {e}")
        return None
