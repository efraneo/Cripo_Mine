# backend/backup_manager.py
# ---------------------------------------------------------
# Backup automático diario del archivo usuarios.db
# Seguro, con rotación, notificación Telegram y thread daemon
# ---------------------------------------------------------

import os
import shutil
import threading
import time
from datetime import datetime, timedelta
from backend.telegram_bot import telegram_send

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "usuarios.db")
BACKUP_DIR = os.path.join(BASE_DIR, "data", "backups")


class BackupManager:

    def __init__(self, retention_days: int = 30, run_at_midnight: bool = False):
        """
        retention_days: días que se conservarán los backups
        run_at_midnight: si True → ejecuta a las 00:00 hora del sistema,
                         si False → ejecuta cada 24 horas exactas
        """
        self.retention_days = retention_days
        self.run_at_midnight = run_at_midnight

    # ---------------------------------------------------------------
    # Core: ejecutar backup
    # ---------------------------------------------------------------
    def perform_backup(self):
        try:
            os.makedirs(BACKUP_DIR, exist_ok=True)

            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            backup_name = f"usuarios_backup_{timestamp}.db"
            path_out = os.path.join(BACKUP_DIR, backup_name)

            # Copia segura sin bloquear SQLite
            shutil.copy2(DB_PATH, path_out)

            # Rotación de backups
            self._rotate_backups()

            if telegram_send:
                telegram_send(f"🗄 Backup realizado correctamente:\n{backup_name}")

            return True

        except Exception as e:
            if telegram_send:
                telegram_send(f"❌ Error al crear backup: {e}")
            return False

    # ---------------------------------------------------------------
    # Rotación
    # ---------------------------------------------------------------
    def _rotate_backups(self):
        now = datetime.utcnow()
        limit = now - timedelta(days=self.retention_days)

        for f in os.listdir(BACKUP_DIR):
            try:
                full = os.path.join(BACKUP_DIR, f)
                if os.path.isfile(full):
                    mtime = datetime.utcfromtimestamp(os.path.getmtime(full))
                    if mtime < limit:
                        os.remove(full)
                        if telegram_send:
                            telegram_send(f"♻ Backup eliminado por rotación: {f}")
            except:
                pass

    # ---------------------------------------------------------------
    # Lógica para ejecutar cada 24H o a medianoche
    # ---------------------------------------------------------------
    def start_auto_backup(self):
        def _loop():
            while True:
                try:
                    if self.run_at_midnight:
                        # esperar hasta medianoche
                        now = datetime.now()
                        tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
                        wait = (tomorrow - now).total_seconds()
                        time.sleep(wait)
                    else:
                        # cada 24 horas exactas
                        time.sleep(24 * 60 * 60)

                    self.perform_backup()
                except Exception as e:
                    if telegram_send:
                        telegram_send(f"[Backup Error] {e}")

        t = threading.Thread(target=_loop, daemon=True)
        t.start()
        return t
