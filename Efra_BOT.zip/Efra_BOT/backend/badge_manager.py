# backend/badge_manager.py
"""
BadgeManager PRO — generación y cache de badges SVG/PNG para usuarios
-------------------------------------------------------------------
- Genera badges SVG estilizados con nombre, nivel, operaciones, precisión IA.
- Convierte a PNG si cairosvg está disponible; si no, usa Pillow para rasterizar (limitado).
- Cache en disco en data/badges/{user_id}.{svg|png}
- API orientada a objetos:
    bm = BadgeManager(base_path="data/badges")
    svg_bytes = bm.get_badge_svg(user, stats)
    png_bytes = bm.get_badge_png(user, stats)
- También puede crear un pequeño sparkline a partir de una lista de valores (pnl_history)
- Integrable con TelegramNotifier (enviar bytes) y Streamlit
"""

from __future__ import annotations

import os
import io
import hashlib
import json
from typing import Optional, Dict, Any, List, Tuple

# try optional deps
try:
    import cairosvg
except Exception:
    cairosvg = None

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = None

# utils logger if available
try:
    from backend.log_manager import get_logger
    log = get_logger("badge_manager")
except Exception:
    import logging
    log = logging.getLogger("badge_manager")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)


class BadgeManager:
    def __init__(self, base_path: str = "data/badges", cache_enabled: bool = True):
        self.base_path = base_path
        self.cache_enabled = bool(cache_enabled)
        os.makedirs(self.base_path, exist_ok=True)
        log.info("BadgeManager iniciado (base_path=%s cache=%s)", self.base_path, self.cache_enabled)

    # ---------------------------
    # Helpers
    # ---------------------------
    def _user_id_safe(self, user: Dict[str, Any]) -> str:
        uid = str(user.get("usuario") or user.get("id") or user.get("username") or user.get("email") or user.get("nombre") or "anon")
        # short hash to avoid long filenames / unsafe chars
        h = hashlib.sha1(uid.encode("utf-8")).hexdigest()[:10]
        return f"{uid.replace(' ', '_')}_{h}"

    def _cache_paths(self, user_id_safe: str) -> Tuple[str, str]:
        svg_path = os.path.join(self.base_path, f"{user_id_safe}.svg")
        png_path = os.path.join(self.base_path, f"{user_id_safe}.png")
        meta_path = os.path.join(self.base_path, f"{user_id_safe}.json")
        return svg_path, png_path, meta_path

    # ---------------------------
    # SVG generation core
    # ---------------------------
    def generate_badge_svg(self, user: Dict[str, Any], stats: Optional[Dict[str, Any]] = None, width: int = 360, height: int = 110) -> bytes:
        """
        Genera el SVG del badge dinámico.
        stats: {"nivel":int,"operaciones":int,"precision":float,"pnl_history":[...]}
        """
        try:
            stats = stats or {}
            nivel = int(stats.get("nivel", 1))
            operaciones = int(stats.get("operaciones", 0))
            precision = float(stats.get("precision", 0.0))
            pnl_hist = stats.get("pnl_history", []) or []

            name = (user.get("nombre") or user.get("usuario") or "Usuario").replace("&", "&amp;")
            role = "Admin" if user.get("es_admin") else "User"

            # Colors derived from name hash to give consistent branding
            seed = abs(hash(name)) % 360
            # primary color HSL -> convert quick
            hue = seed
            primary = f"hsl({hue}, 78%, 54%)"
            accent = f"hsl({(hue + 55) % 360}, 65%, 60%)"
            on_dark = "#e6eef8"

            # small sparkline path if pnl_hist provided
            spark_svg = ""
            if pnl_hist and len(pnl_hist) >= 2:
                try:
                    # normalize history into viewbox
                    vals = [float(x) for x in pnl_hist]
                    mn, mx = min(vals), max(vals)
                    rng = mx - mn if mx - mn > 0 else 1.0
                    w_plot = width * 0.48
                    h_plot = 32
                    step = w_plot / (len(vals) - 1)
                    points = []
                    for i, v in enumerate(vals):
                        x = 20 + i * step
                        y = height - 18 - ((v - mn) / rng) * h_plot
                        points.append(f"{x:.1f},{y:.1f}")
                    path_d = "M " + " L ".join(points)
                    spark_svg = f'<path d="{path_d}" fill="none" stroke="{on_dark}" stroke-opacity="0.9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
                except Exception:
                    spark_svg = ""

            svg = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Badge">
  <defs>
    <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-color="#000" flood-opacity="0.15"/>
    </filter>
    <linearGradient id="g1" x1="0" x2="1" y1="0" y2="1">
      <stop offset="0%" stop-color="{primary}" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="{accent}" stop-opacity="0.95"/>
    </linearGradient>
  </defs>

  <rect x="6" y="6" rx="14" width="{width-12}" height="{height-12}" fill="#071029" opacity="0.98" />
  <rect x="6" y="6" rx="14" width="{width-12}" height="64" fill="url(#g1)" filter="url(#shadow)" />

  <g font-family="Segoe UI, Roboto, Arial, sans-serif">
    <text x="22" y="36" font-size="18" fill="#ffffff" font-weight="700">{name}</text>
    <text x="{width-22}" y="36" font-size="12" fill="#ffffff" text-anchor="end" opacity="0.9">{role}</text>

    <text x="22" y="60" font-size="13" fill="#e6eef8">Nivel: <tspan font-weight="700">{nivel}</tspan></text>
    <text x="120" y="60" font-size="13" fill="#e6eef8">Operaciones: <tspan font-weight="700">{operaciones}</tspan></text>

    <g transform="translate(22,78)">
      <rect x="0" y="0" rx="8" width="{width-48}" height="28" fill="#071029" stroke-opacity="0.08"/>
      <text x="12" y="18" font-size="12" fill="{on_dark}">Precisión IA: <tspan font-weight="700">{precision:.1f}%</tspan></text>
    </g>

    <!-- Sparkline area -->
    <g>
      {spark_svg}
    </g>

  </g>
</svg>'''
            return svg.encode("utf-8")
        except Exception as e:
            log.exception("generate_badge_svg failed: %s", e)
            # fallback minimal svg
            fallback = f'<svg xmlns="http://www.w3.org/2000/svg" width="320" height="90"><rect width="100%" height="100%" fill="#111"/><text x="16" y="24" fill="#fff">Badge error</text></svg>'
            return fallback.encode("utf-8")

    # ---------------------------
    # PNG conversion
    # ---------------------------
    def svg_to_png_bytes(self, svg_bytes: bytes, scale: int = 1) -> Optional[bytes]:
        """
        Convierte SVG a PNG usando cairosvg si está disponible, si no intenta usar Pillow rasterizando con Image (limitado).
        """
        try:
            if cairosvg:
                png = cairosvg.svg2png(bytestring=svg_bytes, scale=scale)
                return png
            # fallback rudimentario: render via Pillow by drawing text only (approx)
            if Image:
                # Very rough rasterization: put SVG as background text (not accurate)
                # Prefer to return None so callers know cairosvg is required for high fidelity
                log.warning("cairosvg no está disponible — PNG generado con Pillow limitado (no fiel al SVG).")
                # create blank image and draw key pieces
                im = Image.new("RGBA", (720 * scale, 220 * scale), (7,16,41,255))
                draw = ImageDraw.Draw(im)
                try:
                    font = ImageFont.truetype("arial.ttf", 28 * scale)
                except Exception:
                    font = ImageFont.load_default()
                draw.text((20*scale, 20*scale), "Badge (low-fidelity)", fill=(230,238,248), font=font)
                buf = io.BytesIO()
                im.save(buf, format="PNG")
                return buf.getvalue()
            # else no conversion possible
            return None
        except Exception as e:
            log.exception("svg_to_png_bytes failed: %s", e)
            return None

    # ---------------------------
    # Public API: get badge bytes (svg/png), with cache
    # ---------------------------
    def get_badge_svg(self, user: Dict[str, Any], stats: Optional[Dict[str, Any]] = None, force_regen: bool = False) -> bytes:
        uid = self._user_id_safe(user)
        svg_path, png_path, meta_path = self._cache_paths(uid)

        # check cache meta: simple equality of stats json
        try:
            stats_json = json.dumps(stats or {}, sort_keys=True)
        except Exception:
            stats_json = str(stats or {})

        if self.cache_enabled and not force_regen and os.path.exists(svg_path) and os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as fh:
                    meta = json.load(fh)
                if meta.get("stats_hash") == hashlib.sha1(stats_json.encode("utf-8")).hexdigest():
                    with open(svg_path, "rb") as fh:
                        return fh.read()
            except Exception:
                # continue to regenerate
                pass

        svg_bytes = self.generate_badge_svg(user, stats)
        try:
            with open(svg_path, "wb") as fh:
                fh.write(svg_bytes)
            with open(meta_path, "w", encoding="utf-8") as fh:
                json.dump({"stats_hash": hashlib.sha1(stats_json.encode("utf-8")).hexdigest()}, fh)
        except Exception:
            log.exception("Could not write badge cache to disk")

        return svg_bytes

    def get_badge_png(self, user: Dict[str, Any], stats: Optional[Dict[str, Any]] = None, force_regen: bool = False, scale: int = 1) -> Optional[bytes]:
        uid = self._user_id_safe(user)
        svg_path, png_path, meta_path = self._cache_paths(uid)

        # try cached png if same stats
        try:
            stats_json = json.dumps(stats or {}, sort_keys=True)
        except Exception:
            stats_json = str(stats or {})

        if self.cache_enabled and not force_regen and os.path.exists(png_path) and os.path.exists(meta_path):
            try:
                with open(meta_path, "r", encoding="utf-8") as fh:
                    meta = json.load(fh)
                if meta.get("stats_hash") == hashlib.sha1(stats_json.encode("utf-8")).hexdigest():
                    with open(png_path, "rb") as fh:
                        return fh.read()
            except Exception:
                pass

        svg_bytes = self.get_badge_svg(user, stats, force_regen=force_regen)
        png_bytes = self.svg_to_png_bytes(svg_bytes, scale=scale)
        if png_bytes:
            try:
                with open(png_path, "wb") as fh:
                    fh.write(png_bytes)
            except Exception:
                log.exception("Could not save badge PNG to disk")
        return png_bytes

    def save_badge(self, user: Dict[str, Any], stats: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        """
        Guarda SVG (+PNG si posible) en disco y retorna paths.
        """
        uid = self._user_id_safe(user)
        svg_path, png_path, meta_path = self._cache_paths(uid)
        svg = self.get_badge_svg(user, stats, force_regen=True)
        png = self.get_badge_png(user, stats, force_regen=True)
        return {"svg": svg_path if os.path.exists(svg_path) else "", "png": png_path if png and os.path.exists(png_path) else ""}

    def badge_bytes(self, user: Dict[str, Any], stats: Optional[Dict[str, Any]] = None, prefer_png: bool = True) -> Tuple[Optional[bytes], str]:
        """
        Retorna (bytes, mime) preferentemente PNG si posible, else SVG bytes.
        """
        if prefer_png:
            png = self.get_badge_png(user, stats)
            if png:
                return png, "image/png"
        svg = self.get_badge_svg(user, stats)
        return svg, "image/svg+xml"

# module-level singleton
_default_badge_manager: Optional[BadgeManager] = None


def get_badge_manager(base_path: Optional[str] = None) -> BadgeManager:
    global _default_badge_manager
    if _default_badge_manager is None:
        _default_badge_manager = BadgeManager(base_path or "data/badges")
    return _default_badge_manager
