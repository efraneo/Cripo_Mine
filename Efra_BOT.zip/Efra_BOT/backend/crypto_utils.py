# backend/crypto_utils.py
import os
import base64
import hmac
import hashlib
from typing import Tuple
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Clave maestra (debe definirse en env, 32 bytes base64 o raw)
MASTER_KEY = os.getenv("BBE_MASTER_KEY")  # debe ser base64 urlsafe o hex
if MASTER_KEY:
    try:
        # si viene en base64
        MASTER_KEY_BYTES = base64.urlsafe_b64decode(MASTER_KEY)
    except Exception:
        MASTER_KEY_BYTES = MASTER_KEY.encode()[:32]
else:
    MASTER_KEY_BYTES = b"\x00"*32  # fallback (no seguro)

def aesgcm_encrypt(plaintext: bytes, aad: bytes = b"") -> Tuple[bytes, bytes]:
    """
    Devuelve (nonce || ciphertext || tag) en bytes, y nonce por separado (ambos en raw bytes).
    """
    aesgcm = AESGCM(MASTER_KEY_BYTES)
    nonce = os.urandom(12)
    ct = aesgcm.encrypt(nonce, plaintext, aad)
    return nonce + ct, nonce

def aesgcm_decrypt(payload: bytes, aad: bytes = b"") -> bytes:
    """
    payload = nonce || ciphertext_and_tag
    """
    aesgcm = AESGCM(MASTER_KEY_BYTES)
    nonce = payload[:12]
    ct = payload[12:]
    pt = aesgcm.decrypt(nonce, ct, aad)
    return pt

# Token HMAC simple: firma payload con SECRET_TOKEN (env)
SECRET_TOKEN = os.getenv("BBE_SYNC_SECRET", "change-me-secret")

def make_token_for_user(user_id: str, expires_seconds: int = 300) -> str:
    ts = str(int(time.time()) + int(expires_seconds))
    msg = f"{user_id}:{ts}".encode()
    sig = hmac.new(SECRET_TOKEN.encode(), msg, hashlib.sha256).hexdigest()
    return f"{user_id}:{ts}:{sig}"

def verify_token(token: str) -> bool:
    try:
        user_id, ts, sig = token.split(":")
        expected = hmac.new(SECRET_TOKEN.encode(), f"{user_id}:{ts}".encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, sig):
            return False
        if int(ts) < int(time.time()):
            return False
        return True
    except Exception:
        return False


# -------------------------------------------------------------------
# Helpers SPECÍFICOS para cifrado de API keys de usuarios
# Uso: texto -> base64
# -------------------------------------------------------------------

def encrypt_api_secret(plaintext: str) -> str:
    """
    Encripta un texto (API KEY o SECRET KEY) con AES-GCM usando la MASTER_KEY_BYTES.
    Devuelve base64(payload).
    """
    payload, _ = aesgcm_encrypt(plaintext.encode("utf-8"))
    return base64.urlsafe_b64encode(payload).decode()


def decrypt_api_secret(b64_payload: str) -> str:
    """
    Desencripta la API KEY / SECRET KEY desde base64(previo).
    Devuelve string texto plano.
    """
    raw = base64.urlsafe_b64decode(b64_payload.encode())
    pt = aesgcm_decrypt(raw)
    return pt.decode("utf-8")
