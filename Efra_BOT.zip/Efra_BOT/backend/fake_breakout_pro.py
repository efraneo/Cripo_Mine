# backend/fake_breakout_pro.py
import numpy as np

# ==================================================
# FAKE BREAKOUT PRO (LIQUIDITY GRAB)
# ==================================================

def detect_fake_breakout_pro(df):
    """
    Detecta fake breakouts institucionales (liquidity grabs)

    Requisitos:
    - Sweep de liquidez
    - Rechazo (wick dominante)
    - Volumen anómalo
    - Fallo estructural
    """

    if df is None or len(df) < 30:
        return False, "Datos insuficientes"

    last = df.iloc[-1]
    prev = df.iloc[-2]

    highs = df["high"].iloc[-30:-1]
    lows = df["low"].iloc[-30:-1]

    prev_high = highs.max()
    prev_low = lows.min()

    avg_vol = df["volume"].iloc[-30:-1].mean()

    # ==================================================
    # 1️⃣ SWEEP DE LIQUIDEZ
    # ==================================================
    sweep_high = last["high"] > prev_high
    sweep_low = last["low"] < prev_low

    if not (sweep_high or sweep_low):
        return False, None

    # ==================================================
    # 2️⃣ RECHAZO FUERTE (WICK)
    # ==================================================
    body = abs(last["close"] - last["open"])
    wick_upper = last["high"] - max(last["close"], last["open"])
    wick_lower = min(last["close"], last["open"]) - last["low"]

    rejection = (
        wick_upper > body * 1.5 if sweep_high else
        wick_lower > body * 1.5
    )

    if not rejection:
        return False, None

    # ==================================================
    # 3️⃣ VOLUMEN ANÓMALO
    # ==================================================
    if last["volume"] < avg_vol * 1.5:
        return False, None

    # ==================================================
    # 4️⃣ FALLO ESTRUCTURAL
    # ==================================================
    # Alcista falso → cierre por debajo del nivel roto
    if sweep_high and last["close"] < prev_high:
        return True, "Fake breakout alcista (liquidity grab)"

    # Bajista falso → cierre por encima del nivel roto
    if sweep_low and last["close"] > prev_low:
        return True, "Fake breakout bajista (liquidity grab)"

    return False, None
