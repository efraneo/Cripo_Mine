# backend/build_features.py
import pandas as pd
import numpy as np
import talib as ta
import argparse
import os

def build(df):
    # ---------------------------------------------
    # Normalizar columna de tiempo (timestamp / time)
    # ---------------------------------------------
    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"])
    elif "time" in df.columns:
        df["timestamp"] = pd.to_datetime(df["time"])
    else:
        raise ValueError("No existe columna 'timestamp' ni 'time' en el archivo OHLCV")

    df = df.sort_values("timestamp").reset_index(drop=True)

    df['close'] = df['close'].astype(float)
    df['open'] = df['open'].astype(float)
    df['high'] = df['high'].astype(float)
    df['low'] = df['low'].astype(float)
    df['volume'] = df['volume'].astype(float)

    # moving averages
    df['ma_fast'] = df['close'].rolling(10).mean()
    df['ma_slow'] = df['close'].rolling(50).mean()

    # rsi
    df['rsi'] = ta.RSI(df['close'].values, timeperiod=14)

    # macd
    macd, macd_sig, macd_hist = ta.MACD(df['close'].values, fastperiod=12, slowperiod=26, signalperiod=9)
    df['macd'] = macd
    df['macd_signal'] = macd_sig

    # atr
    df['atr'] = ta.ATR(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

    # returns
    df['ret1'] = df['close'].pct_change()
    df['ret5'] = df['close'].pct_change(5)

    # label: example - next 3-bar return > 0.5% -> buy
    df['future_ret3'] = df['close'].shift(-3) / df['close'] - 1.0
    df['label'] = (df['future_ret3'] > 0.005).astype(int)

    df = df.dropna().reset_index(drop=True)
    return df

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--ohlcv", required=True, help="CSV OHLCV with timestamp,open,high,low,close,volume")
    p.add_argument("--out", default="data/features_train.csv")
    args = p.parse_args()
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df = pd.read_csv(args.ohlcv)
    df = build(df)
    df.to_csv(args.out, index=False)
    print("Saved features to", args.out)
