"""
backend/signals_manager.py — SignalsManager PRO (2025)

Responsabilidades:
- Polling de múltiples fuentes (exchange, modelos IA, ficheros)
- Debounce y deduplicación de señales
- Backpressure / rate limiting para no spamear al BotManager
- Hooks/callbacks para UI (StreamlitController / BotManager)
- Integración con IAPredictor para anotar precisión estimada
- Filtros (whitelist, blacklist, min_confidence)
"""

from __future__ import annotations

import threading
import time
import traceback
from typing import Optional, Dict, Any, Callable, List, Iterable
from datetime import datetime, timedelta

# Logging
try:
    from backend.log_manager import get_logger
    log = get_logger("signals_manager")
except Exception:
    import logging
    log = logging.getLogger("signals_manager")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)

# Optional dependencies
try:
    from backend.ia_predictor import IAPredictor
except Exception:
    IAPredictor = None

try:
    from backend.config_manager import ConfigManager
except Exception:
    ConfigManager = None

# Simple Signal data structure
class Signal:
    def __init__(self, symbol: str, signal: str, score: float = 0.5, ts: Optional[str] = None, source: str = "unknown", meta: Optional[Dict[str, Any]] = None):
        self.symbol = symbol.upper()
        self.signal = signal.upper()  # e.g., BUY / SELL / HOLD
        self.score = float(score)
        self.ts = ts or datetime.utcnow().isoformat()
        self.source = source
        self.meta = meta or {}

    def to_dict(self):
        return {
            "symbol": self.symbol,
            "signal": self.signal,
            "score": float(self.score),
            "ts": self.ts,
            "source": self.source,
            "meta": self.meta
        }

    def __repr__(self):
        return f"<Signal {self.symbol} {self.signal} {self.score:.3f} src={self.source} ts={self.ts}>"

# ---------------------------------------------------------------------
# SignalsManager
# ---------------------------------------------------------------------
class SignalsManager:
    """
    SignalsManager PRO:

    - start()/stop() controla el polling thread
    - register_source(callable) permite añadir funciones que devuelvan List[Signal]
    - on_new_signal(callback) hook que recibe (Signal)
    - get_latest(symbol) devuelve la última señal conocida para un símbolo
    - dedup + debounce por símbolo + rate-limit global
    """

    def __init__(
        self,
        poll_interval: float = 5.0,
        dedupe_window_sec: int = 30,
        min_confidence: float = 0.6,
        max_signals_per_min: int = 30,
        ia_predictor: Optional[IAPredictor] = None,
        config: Optional[ConfigManager] = None
    ):
        self.poll_interval = float(poll_interval)
        self.dedupe_window = timedelta(seconds=int(dedupe_window_sec))
        self.min_confidence = float(min_confidence)
        self.max_signals_per_min = int(max_signals_per_min)

        self._sources: List[Callable[[], List[Signal]]] = []
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.RLock()

        # caches
        self._last_signal_by_symbol: Dict[str, Signal] = {}
        self._last_emit_ts: Dict[str, datetime] = {}
        self._recent_emits: List[float] = []

        # hooks
        self._on_new_signal: Optional[Callable[[Signal], None]] = None
        self._on_status: Optional[Callable[[str, Dict[str, Any]], None]] = None

        # external helpers
        self.ia_predictor = ia_predictor or (IAPredictor() if IAPredictor else None)
        self.config = config or (ConfigManager() if ConfigManager else None)

        # filters
        self.whitelist: Optional[Iterable[str]] = None
        self.blacklist: Optional[Iterable[str]] = None

        log.info("SignalsManager inicializado (poll_interval=%.2fs)", self.poll_interval)

    # -----------------------
    # Source management
    # -----------------------
    def register_source(self, fn: Callable[[], List[Signal]]):
        """
        Registra una función que cuando se invoca devuelve List[Signal].
        Ejemplos: scraping exchange, lectura de archivos, llamada a IA.
        """
        if not callable(fn):
            raise ValueError("source must be callable")
        self._sources.append(fn)
        log.info("Source registered: %s", getattr(fn, "__name__", str(fn)))

    # -----------------------
    # Hooks
    # -----------------------
    def on_new_signal(self, fn: Callable[[Signal], None]):
        self._on_new_signal = fn

    def on_status(self, fn: Callable[[str, Dict[str, Any]], None]):
        self._on_status = fn

    def _emit_status(self, event: str, payload: Optional[Dict[str, Any]] = None):
        payload = payload or {}
        payload["ts"] = datetime.utcnow().isoformat()
        try:
            if callable(self._on_status):
                self._on_status(event, payload)
        except Exception:
            log.exception("on_status hook failed")

    # -----------------------
    # Filters
    # -----------------------
    def set_whitelist(self, symbols: Optional[Iterable[str]]):
        self.whitelist = set(s.upper() for s in symbols) if symbols else None

    def set_blacklist(self, symbols: Optional[Iterable[str]]):
        self.blacklist = set(s.upper() for s in symbols) if symbols else None

    def _passes_filters(self, sig: Signal) -> bool:
        if self.whitelist is not None and sig.symbol not in self.whitelist:
            return False
        if self.blacklist is not None and sig.symbol in self.blacklist:
            return False
        if sig.score < self.min_confidence:
            return False
        return True

    # -----------------------
    # Rate limiting
    # -----------------------
    def _throttle_ok(self) -> bool:
        now = time.time()
        window_start = now - 60
        self._recent_emits = [ts for ts in self._recent_emits if ts >= window_start]
        if len(self._recent_emits) >= self.max_signals_per_min:
            return False
        self._recent_emits.append(now)
        return True

    # -----------------------
    # Internal: process signals from a source
    # -----------------------
    def _process_signals(self, src_name: str, signals: List[Signal]):
        if not signals:
            return
        for s in signals:
            try:
                if not isinstance(s, Signal):
                    continue

                # annotate with IA predictor if available and score low
                if self.ia_predictor and (s.score is None or s.score < 0.8):
                    try:
                        p = float(self.ia_predictor.predict_proba(s.meta or {})) if hasattr(self.ia_predictor, "predict_proba") else None
                        if p is not None:
                            s.score = max(s.score, p)
                    except Exception:
                        log.debug("IA predict_proba annotation failed for %s", s.symbol)

                # normalize
                s.symbol = s.symbol.upper()
                now = datetime.utcnow()

                # filters
                if not self._passes_filters(s):
                    log.debug("Signal filtered out: %s (score=%.3f)", s, s.score)
                    continue

                last = self._last_signal_by_symbol.get(s.symbol)
                if last:
                    try:
                        last_ts = datetime.fromisoformat(last.ts)
                    except Exception:
                        last_ts = now - timedelta(days=1)
                else:
                    last_ts = now - timedelta(days=1)

                # dedupe + debounce
                if (now - last_ts) < self.dedupe_window and last and last.signal == s.signal:
                    log.debug("Deduped signal %s (last @ %s)", s.symbol, last.ts)
                    continue

                # global throttle
                if not self._throttle_ok():
                    log.warning("Global signal throttle reached — dropping %s", s)
                    self._emit_status("throttle_drop", {"signal": s.to_dict()})
                    continue

                # accept & store
                s.ts = now.isoformat()
                self._last_signal_by_symbol[s.symbol] = s
                self._last_emit_ts[s.symbol] = now

                log.info("New signal accepted: %s", s)

                # emit hook
                try:
                    if callable(self._on_new_signal):
                        self._on_new_signal(s)
                except Exception:
                    log.exception("on_new_signal hook failed for %s", s)

            except Exception as e:
                log.exception("Processing single signal failed: %s", e)

    # -----------------------
    # Main polling loop
    # -----------------------
    def _poll_loop(self):
        log.info("SignalsManager poll loop started (sources=%d)", len(self._sources))
        self._emit_status("started", {"sources": len(self._sources)})
        while self._running:
            try:
                if not self._sources:
                    time.sleep(max(0.5, self.poll_interval))
                    continue

                for src in list(self._sources):
                    try:
                        src_name = getattr(src, "__name__", str(src))
                        # call source
                        signals = []
                        try:
                            signals = src()
                        except Exception as e:
                            log.exception("Source %s failed: %s", src_name, e)
                            self._emit_status("source_error", {"source": src_name, "error": str(e)})
                            continue

                        # normalize return: allow single Signal or list
                        if isinstance(signals, Signal):
                            signals = [signals]
                        if not isinstance(signals, list):
                            continue

                        # process
                        self._process_signals(src_name, signals)

                    except Exception as e:
                        log.exception("Error processing source %s: %s", src_name, e)

                # sleep before next full round
                time.sleep(self.poll_interval)

            except Exception as e:
                log.exception("Polling loop fatal error: %s", e)
                time.sleep(1.0)

        self._emit_status("stopped", {})
        log.info("SignalsManager poll loop stopped")

    # -----------------------
    # Public control
    # -----------------------
    def start(self):
        with self._lock:
            if self._running:
                log.info("SignalsManager already running")
                return
            self._running = True
            self._thread = threading.Thread(target=self._poll_loop, daemon=True)
            self._thread.start()
            log.info("SignalsManager started")

    def stop(self, wait: bool = True):
        with self._lock:
            if not self._running:
                return
            self._running = False
        if wait and self._thread:
            self._thread.join(timeout=5.0)
        log.info("SignalsManager stopped")

    # -----------------------
    # Query API
    # -----------------------
    def get_latest(self, symbol: str) -> Optional[Signal]:
        return self._last_signal_by_symbol.get(symbol.upper())

    def list_latest(self) -> List[Signal]:
        return list(self._last_signal_by_symbol.values())

    def clear_cache(self):
        with self._lock:
            self._last_signal_by_symbol.clear()
            self._last_emit_ts.clear()
            self._recent_emits.clear()
        log.info("SignalsManager cache cleared")

# ---------------------------------------------------------------------
# Helper: simple source adapters
# ---------------------------------------------------------------------
def source_from_callable(fn: Callable[[], List[Dict[str, Any]]]):
    """
    Adapts a callable that returns list-of-dicts into list-of-Signal.
    Each dict should contain keys: symbol, signal, score (optional), ts (optional), source (optional).
    """
    def _wrapper():
        out = []
        try:
            raw = fn()
            if not raw:
                return out
            for r in raw:
                try:
                    s = Signal(
                        symbol=r.get("symbol") or r.get("ticker") or r.get("asset"),
                        signal=r.get("signal") or r.get("action") or "HOLD",
                        score=r.get("score", 0.5),
                        ts=r.get("ts"),
                        source=r.get("source", getattr(fn, "__name__", "callable_source")),
                        meta=r.get("meta", {})
                    )
                    out.append(s)
                except Exception:
                    log.exception("Failed building Signal from raw dict: %s", r)
        except Exception:
            log.exception("source_from_callable wrapper failed for %s", getattr(fn, "__name__", str(fn)))
        return out
    return _wrapper

# ---------------------------------------------------------------------
# END
# ---------------------------------------------------------------------
