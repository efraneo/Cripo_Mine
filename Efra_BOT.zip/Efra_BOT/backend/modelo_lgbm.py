# backend/modelo_lgbm.py

import os
import numpy as np

class ModeloDummy:
    """
    Modelo placeholder para evitar errores cuando
    no existe un modelo LightGBM entrenado.
    """

    def predict(self, X):
        # Devuelve probabilidad fija neutra
        return np.array([0.5])


def cargar_modelo(path="models/model_lightgbm.json"):
    """
    Si existe un modelo entrenado, cárgalo.
    Si no, devuelve un modelo dummy.
    """
    if os.path.exists(path):
        try:
            import lightgbm as lgb
            return lgb.Booster(model_file=path)
        except Exception:
            return ModeloDummy()

    return ModeloDummy()
