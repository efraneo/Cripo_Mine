# backend/audit_manager.py
"""
AuditManager - Escrituración de señales y ejecuciones (JSONL + SQLite)

Crea/usa:
 - data/audit.db (SQLite) con tablas: signals, executions
 - data/signals_log.jsonl
 - data/executions_log.jsonl

API principal:
 - AuditManager().log_signal(payload: dict)
 - AuditManager().log_execution(exec_record: dict)
 - AuditManager().get_signals(limit=500)
 - AuditManager().get_executions(limit=500)
 - AuditManager().get_ranking_by_user(period_start=None, period_end=None)

Notas:
 - Guarda la carga original (raw_json) en las tablas para trazabilidad.
 - Añade campos ts (unix epoch) y iso_ts (ISO 8601) automáticamente si no vienen.
"""

from __future__ import annotations
import os
import json
import sqlite3
import threading
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone

from backend.log_manager import get_logger

log = get_logger("audit")

# Paths
os.makedirs("data", exist_ok=True)
DB_PATH = os.path.join("data", "audit.db")
SIGNALS_JSONL = os.path.join("data", "signals_log.jsonl")
EXEC_JSONL = os.path.join("data", "executions_log.jsonl")

# Ensure DB schema
_INIT_SQL = """
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER,
    iso_ts TEXT,
    symbol TEXT,
    interval TEXT,
    payload_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);

CREATE TABLE IF NOT EXISTS executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts INTEGER,
    iso_ts TEXT,
    symbol TEXT,
    side TEXT,
    user TEXT,
    amount REAL,
    result_json TEXT,
    pnl REAL   -- optional profit/loss if available in result
);
CREATE INDEX IF NOT EXISTS idx_executions_ts ON executions(ts);
CREATE INDEX IF NOT EXISTS idx_executions_user ON executions(user);
"""

class AuditManager:
    def __init__(self, db_path: str = DB_PATH, signals_jsonl: str = SIGNALS_JSONL, exec_jsonl: str = EXEC_JSONL):
        self.db_path = db_path
        self.signals_jsonl = signals_jsonl
        self.exec_jsonl = exec_jsonl
        self._lock = threading.Lock()
        self._ensure_db()

    def _conn(self):
        return sqlite3.connect(self.db_path, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)

    def _ensure_db(self):
        try:
            with self._conn() as c:
                c.executescript(_INIT_SQL)
                c.commit()
        except Exception as e:
            log.exception("AuditManager failed to initialize DB: %s", e)

    # -------------------------
    # Helpers
    # -------------------------
    def _now_ts_iso(self, supplied: Optional[float] = None):
        ts = int(supplied if supplied is not None else datetime.now(tz=timezone.utc).timestamp())
        iso = datetime.fromtimestamp(ts, tz=timezone.utc).isoformat()
        return ts, iso

    def _append_jsonl(self, path: str, obj: Dict[str, Any]):
        try:
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
        except Exception:
            log.exception("Failed writing jsonl %s", path)

    # -------------------------
    # Main API: log_signal
    # -------------------------
    def log_signal(self, payload: Dict[str, Any]):
        """
        Guarda la señal en JSONL y en SQLite (tabla signals).
        payload: dict libre. Se agregarán ts/iso_ts si faltan.
        """
        try:
            with self._lock:
                # ensure timestamps
                if "ts" in payload:
                    ts = int(payload["ts"])
                    iso = payload.get("iso_ts", datetime.fromtimestamp(ts, tz=timezone.utc).isoformat())
                else:
                    ts, iso = self._now_ts_iso()

                record = {
                    "ts": ts,
                    "iso_ts": iso,
                    "symbol": payload.get("symbol"),
                    "interval": payload.get("interval"),
                    "payload": payload
                }

                # write jsonl
                try:
                    self._append_jsonl(self.signals_jsonl, record)
                except Exception:
                    log.exception("Could not append signal jsonl")

                # write sqlite
                try:
                    with self._conn() as c:
                        c.execute(
                            "INSERT INTO signals (ts, iso_ts, symbol, interval, payload_json) VALUES (?,?,?,?,?)",
                            (ts, iso, record["symbol"], record["interval"], json.dumps(payload, ensure_ascii=False))
                        )
                        c.commit()
                except Exception:
                    log.exception("Could not insert signal into audit DB")

        except Exception as e:
            log.exception("log_signal error: %s", e)

    # -------------------------
    # Main API: log_execution
    # -------------------------
    def log_execution(self, exec_record: Dict[str, Any]):
        """
        Guarda ejecución en JSONL y en SQLite (table executions).
        exec_record puede contener keys: ts, symbol, side, user, amount, result (dict), pnl (optional)
        """
        try:
            with self._lock:
                # timestamps
                if "ts" in exec_record:
                    ts = int(exec_record["ts"])
                    iso = exec_record.get("iso_ts", datetime.fromtimestamp(ts, tz=timezone.utc).isoformat())
                else:
                    ts, iso = self._now_ts_iso()

                symbol = exec_record.get("symbol")
                side = exec_record.get("side")
                user = exec_record.get("user") or (exec_record.get("meta", {}).get("user") if isinstance(exec_record.get("meta"), dict) else None)
                amount = float(exec_record.get("amount", 0.0))

                # try to extract pnl if present inside result
                pnl = None
                try:
                    res = exec_record.get("result")
                    if isinstance(res, dict):
                        if "pnl" in res:
                            pnl = float(res.get("pnl"))
                        elif "profit" in res:
                            pnl = float(res.get("profit"))
                except Exception:
                    pnl = None

                rec = {
                    "ts": ts,
                    "iso_ts": iso,
                    "symbol": symbol,
                    "side": side,
                    "user": user,
                    "amount": amount,
                    "result": exec_record.get("result"),
                    "pnl": pnl
                }

                # jsonl
                try:
                    self._append_jsonl(self.exec_jsonl, rec)
                except Exception:
                    log.exception("Could not append execution jsonl")

                # sqlite
                try:
                    with self._conn() as c:
                        c.execute(
                            "INSERT INTO executions (ts, iso_ts, symbol, side, user, amount, result_json, pnl) VALUES (?,?,?,?,?,?,?,?)",
                            (ts, iso, symbol, side, user, amount, json.dumps(exec_record.get("result", {}), ensure_ascii=False), pnl)
                        )
                        c.commit()
                except Exception:
                    log.exception("Could not insert execution into audit DB")

        except Exception as e:
            log.exception("log_execution error: %s", e)

    # -------------------------
    # Queries
    # -------------------------
    def get_signals(self, limit: int = 500) -> List[Dict[str, Any]]:
        """Devuelve las últimas `limit` señales (más recientes último)."""
        rows: List[Dict[str, Any]] = []
        try:
            # Try reading sqlite first for structured query
            with self._conn() as c:
                cur = c.execute("SELECT ts, iso_ts, symbol, interval, payload_json FROM signals ORDER BY ts DESC LIMIT ?", (limit,))
                for r in cur.fetchall():
                    try:
                        payload = json.loads(r[4]) if r[4] else {}
                    except Exception:
                        payload = {}
                    rows.append({"ts": r[0], "iso_ts": r[1], "symbol": r[2], "interval": r[3], "payload": payload})
            return rows
        except Exception:
            log.debug("SQLite read failed for signals, falling back to JSONL")
            # fallback to JSONL
            try:
                if not os.path.exists(self.signals_jsonl):
                    return []
                with open(self.signals_jsonl, "r", encoding="utf-8") as fh:
                    for line in fh:
                        try:
                            rows.append(json.loads(line.strip()))
                        except:
                            continue
                return rows[-limit:][::-1]
            except Exception:
                log.exception("Failed reading signals JSONL")
                return []

    def get_executions(self, limit: int = 500) -> List[Dict[str, Any]]:
        """Devuelve las últimas ejecuciones (más recientes primero)."""
        rows: List[Dict[str, Any]] = []
        try:
            with self._conn() as c:
                cur = c.execute("SELECT ts, iso_ts, symbol, side, user, amount, result_json, pnl FROM executions ORDER BY ts DESC LIMIT ?", (limit,))
                for r in cur.fetchall():
                    try:
                        result = json.loads(r[6]) if r[6] else {}
                    except Exception:
                        result = {}
                    rows.append({"ts": r[0], "iso_ts": r[1], "symbol": r[2], "side": r[3], "user": r[4], "amount": r[5], "result": result, "pnl": r[7]})
            return rows
        except Exception:
            log.debug("SQLite read failed for executions, falling back to JSONL")
            try:
                if not os.path.exists(self.exec_jsonl):
                    return []
                with open(self.exec_jsonl, "r", encoding="utf-8") as fh:
                    for line in fh:
                        try:
                            rows.append(json.loads(line.strip()))
                        except:
                            continue
                return rows[-limit:][::-1]
            except Exception:
                log.exception("Failed reading executions JSONL")
                return []

    # -------------------------
    # Ranking helper (simple)
    # -------------------------
    def get_ranking_by_user(self, period_start: Optional[str] = None, period_end: Optional[str] = None, top_n: int = 50) -> List[Dict[str, Any]]:
        """
        Simple ranking: suma pnl por usuario en período. Si pnl no está, intenta inferir por 'result' structure.
        period_start/period_end: ISO date strings or None (no filter).
        """
        try:
            q = "SELECT user, SUM(COALESCE(pnl,0)) as total_pnl, COUNT(*) as trades FROM executions WHERE 1=1"
            params: List[Any] = []
            if period_start:
                q += " AND date(iso_ts) >= date(?)"
                params.append(period_start)
            if period_end:
                q += " AND date(iso_ts) <= date(?)"
                params.append(period_end)
            q += " GROUP BY user ORDER BY total_pnl DESC LIMIT ?"
            params.append(top_n)

            with self._conn() as c:
                cur = c.execute(q, tuple(params))
                rows = cur.fetchall()
                out = []
                for r in rows:
                    out.append({"user": r[0], "total_pnl": float(r[1] or 0.0), "trades": int(r[2] or 0)})
                return out
        except Exception:
            log.debug("Ranking via SQLite failed, attempting JSONL fallback")
            # fallback: aggregate JSONL
            try:
                agg = {}
                if os.path.exists(self.exec_jsonl):
                    with open(self.exec_jsonl, "r", encoding="utf-8") as fh:
                        for line in fh:
                            try:
                                rec = json.loads(line)
                                user = rec.get("user") or (rec.get("meta", {}).get("user") if isinstance(rec.get("meta"), dict) else None)
                                pnl = rec.get("pnl") or (rec.get("result", {}).get("pnl") if isinstance(rec.get("result"), dict) else None)
                                if user is None:
                                    continue
                                agg.setdefault(user, {"total_pnl": 0.0, "trades": 0})
                                if pnl is not None:
                                    try:
                                        agg[user]["total_pnl"] += float(pnl)
                                    except Exception:
                                        pass
                                agg[user]["trades"] += 1
                            except Exception:
                                continue
                out = [{"user": u, "total_pnl": v["total_pnl"], "trades": v["trades"]} for u, v in agg.items()]
                out_sorted = sorted(out, key=lambda x: x["total_pnl"], reverse=True)[:top_n]
                return out_sorted
            except Exception:
                log.exception("Ranking fallback failed")
                return []

# If used as module-level singleton convenience
_audit_singleton: Optional[AuditManager] = None

def get_audit_manager() -> AuditManager:
    global _audit_singleton
    if _audit_singleton is None:
        _audit_singleton = AuditManager()
    return _audit_singleton
