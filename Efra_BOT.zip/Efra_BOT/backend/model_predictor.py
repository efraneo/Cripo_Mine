# backend/model_predictor.py
"""
ModelPredictor PRO (2025)
- Wrapper útil alrededor de IAPredictor / modelos ML
- Caching inteligente (in-memory) para evitar recálculos en UIs
- Funciones:
    - predict(sample: dict) -> float (0..1)
    - predict_signal(sample: dict) -> "BUY"/"SELL"/"HOLD"
    - predict_asset(symbol, df=None) -> dict (summary ready for UI)
    - batch_predict(df, window=None) -> list of (ts, prob)
    - calibrate_threshold(y_true, y_proba, metric="precision", target=0.85)
    - save/load state (thresholds, meta)
- Designed to be safe when IAPredictor or dependencies are missing — falls back to heuristics.
"""
from __future__ import annotations

import os
import json
import time
import math
import logging
from typing import Optional, Dict, Any, List, Tuple

# Prefer backend logger if present
try:
    from backend.log_manager import get_logger
    log = get_logger("model_predictor")
except Exception:
    logging.basicConfig(level=logging.INFO)
    log = logging.getLogger("model_predictor")

# Try to import the heavy predictor (optional)
try:
    from backend.ia_predictor import IAPredictor
except Exception:
    IAPredictor = None

# Basic config
BASE_DIR = os.getenv("PROJECT_BASE", ".")
MODELS_DIR = os.path.join(BASE_DIR, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

STATE_PATH = os.path.join(MODELS_DIR, "model_predictor_state.json")


class ModelPredictor:
    def __init__(self, models_dir: Optional[str] = None, cache_ttl: int = 5):
        """
        cache_ttl: seconds to keep in-memory cache for identical calls (UI-friendly)
        """
        self.models_dir = models_dir or MODELS_DIR
        self.cache_ttl = int(cache_ttl)
        self._predictor = None
        self._state: Dict[str, Any] = {"threshold": 0.5, "meta": {}}
        self._cache: Dict[str, Tuple[float, float]] = {}  # key -> (ts, prob)
        self._load_predictor()
        self._load_state()
        log.info("ModelPredictor iniciado (models_dir=%s cache_ttl=%s)", self.models_dir, self.cache_ttl)

    # -------------------------
    # Internal: load heavy predictor
    # -------------------------
    def _load_predictor(self):
        if IAPredictor is None:
            self._predictor = None
            log.warning("IAPredictor no disponible. Usando heurístico fallback.")
            return
        try:
            self._predictor = IAPredictor(models_dir=self.models_dir)
            # synchronize threshold if predictor has one
            try:
                th = getattr(self._predictor, "threshold", None)
                if th is not None:
                    self._state["threshold"] = float(th)
            except Exception:
                pass
            log.info("IAPredictor cargado correctamente.")
        except Exception as e:
            log.exception("Fallo cargando IAPredictor: %s", e)
            self._predictor = None

    # -------------------------
    # State persistence
    # -------------------------
    def _load_state(self):
        try:
            if os.path.exists(STATE_PATH):
                with open(STATE_PATH, "r", encoding="utf-8") as fh:
                    self._state.update(json.load(fh))
                log.info("State cargado desde %s", STATE_PATH)
        except Exception as e:
            log.exception("No se pudo cargar state: %s", e)

    def _save_state(self):
        try:
            with open(STATE_PATH, "w", encoding="utf-8") as fh:
                json.dump(self._state, fh, indent=2)
            log.info("State guardado en %s", STATE_PATH)
        except Exception as e:
            log.exception("No se pudo guardar state: %s", e)

    # -------------------------
    # Cache helpers
    # -------------------------
    def _cache_key(self, sample: Dict[str, Any]) -> str:
        # deterministic key for small dicts
        try:
            # sort keys for determinism; fall back to repr
            ks = sorted(sample.items())
            return json.dumps(ks, sort_keys=True, default=str)
        except Exception:
            return repr(sample)

    def _get_cached(self, key: str) -> Optional[float]:
        v = self._cache.get(key)
        if not v:
            return None
        ts, prob = v
        if (time.time() - ts) > self.cache_ttl:
            # stale
            try:
                del self._cache[key]
            except Exception:
                pass
            return None
        return prob

    def _set_cache(self, key: str, prob: float):
        try:
            self._cache[key] = (time.time(), float(prob))
        except Exception:
            pass

    # -------------------------
    # Public: predict a single sample (probability)
    # -------------------------
    def predict(self, sample: Dict[str, Any], use_cache: bool = True) -> float:
        """
        sample: dict with numeric features expected by the predictor.
        returns: float in [0,1] representing buy probability.
        """
        try:
            key = self._cache_key(sample)
            if use_cache:
                c = self._get_cached(key)
                if c is not None:
                    return float(c)

            # prefer IAPredictor if available
            if self._predictor:
                try:
                    p = float(self._predictor.predict_proba(sample))
                    p = max(0.0, min(1.0, p))
                    self._set_cache(key, p)
                    return p
                except Exception as e:
                    log.debug("IAPredictor.predict_proba fallo: %s", e)

            # fallback heuristic (lightweight)
            try:
                score = 0.5
                ma_fast = float(sample.get("ma_fast", sample.get("ema_fast", 0.0) or 0.0))
                ma_slow = float(sample.get("ma_slow", sample.get("ema_slow", 0.0) or 0.0))
                rsi = float(sample.get("rsi", 50.0) or 50.0)
                macd = float(sample.get("macd", 0.0) or 0.0)
                macd_signal = float(sample.get("macd_signal", 0.0) or 0.0)

                if ma_fast > ma_slow:
                    score += 0.12
                else:
                    score -= 0.09

                if macd > macd_signal:
                    score += 0.08
                else:
                    score -= 0.05

                # RSI contrarian
                score += (50.0 - rsi) / 200.0

                score = max(0.01, min(0.99, score))
                self._set_cache(key, score)
                return float(score)
            except Exception as e:
                log.exception("Heuristic fallback failed: %s", e)
                return 0.5

        except Exception as e:
            log.exception("predict error: %s", e)
            return 0.5

    def predict_signal(self, sample: Dict[str, Any], threshold: Optional[float] = None) -> str:
        th = float(threshold if threshold is not None else self._state.get("threshold", 0.5))
        try:
            p = float(self.predict(sample))
            if p >= th:
                return "BUY"
            if p <= (1.0 - th):
                return "SELL"
            return "HOLD"
        except Exception as e:
            log.exception("predict_signal error: %s", e)
            return "HOLD"

    # -------------------------
    # High-level: predict for an asset (df optional)
    # returns a dict ready for UI/telegram
    # -------------------------
    def predict_asset(self, symbol: str, df: Optional[Any] = None) -> Dict[str, Any]:
        """
        If df provided (pandas.DataFrame), compute indicators and produce features for the last row.
        Returns summary: { symbol, prob, signal, rsi, macd, ma_fast, ma_slow, ts }
        """
        try:
            features = {}
            ts = ""
            # lazy import pandas to avoid heavy deps if not needed
            if df is not None:
                try:
                    import pandas as pd
                    last = df.iloc[-1]
                    ts = str(last.get("time", last.name)) if hasattr(last, "__getitem__") else ""
                    # minimal features (compatible with feature builder)
                    features["open"] = float(last.get("open", last.get("Open", 0.0)))
                    features["high"] = float(last.get("high", last.get("High", 0.0)))
                    features["low"] = float(last.get("low", last.get("Low", 0.0)))
                    features["close"] = float(last.get("close", last.get("Close", 0.0)))
                    features["volume"] = float(last.get("volume", last.get("Volume", 0.0)))
                    # compute small indicators
                    try:
                        # sma/ema quick calc on df if contains close
                        closes = pd.to_numeric(df["close"], errors="coerce")
                        features["ma_fast"] = float(closes.ewm(span=12, adjust=False).mean().iloc[-1])
                        features["ma_slow"] = float(closes.ewm(span=26, adjust=False).mean().iloc[-1])
                        # rsi quick
                        delta = closes.diff()
                        up = delta.clip(lower=0)
                        down = (-delta).clip(lower=0)
                        ma_up = up.rolling(14, min_periods=1).mean()
                        ma_down = down.rolling(14, min_periods=1).mean()
                        rs = ma_up / (ma_down.replace(0, 1e-9))
                        rsi = 100 - (100 / (1 + rs))
                        features["rsi"] = float(rsi.iloc[-1])
                        # macd
                        ema12 = closes.ewm(span=12, adjust=False).mean()
                        ema26 = closes.ewm(span=26, adjust=False).mean()
                        macd = ema12 - ema26
                        features["macd"] = float(macd.iloc[-1])
                        features["macd_signal"] = float(macd.ewm(span=9, adjust=False).mean().iloc[-1])
                    except Exception:
                        pass
                except Exception:
                    # df provided but cannot parse — ignore
                    pass

            prob = float(self.predict(features or {}))
            sig = self.predict_signal(features or {})
            out = {
                "symbol": symbol,
                "prob": prob,
                "prob_pct": prob * 100.0,
                "signal": sig,
                "features": features,
                "ts": ts,
                "threshold": float(self._state.get("threshold", 0.5))
            }
            return out
        except Exception as e:
            log.exception("predict_asset error: %s", e)
            return {"error": str(e)}

    # -------------------------
    # Batch predict across dataframe (sliding window)
    # -------------------------
    def batch_predict(self, df: Any, feature_builder: Optional[callable] = None, window: int = 1) -> List[Dict[str, Any]]:
        """
        df: pandas.DataFrame with time-indexed candles.
        feature_builder: optional function(df)->df_features (like utils.feature_builder_pro.build_feature_set)
        window: step size for sampling (1 => every row)
        returns: list of {ts, prob, signal}
        """
        out = []
        try:
            import pandas as pd
            n = len(df)
            if n == 0:
                return out
            # if feature_builder provided, precompute features
            if feature_builder is not None:
                try:
                    feat_df = feature_builder(df)
                except Exception as e:
                    log.exception("feature_builder failed: %s", e)
                    feat_df = None
            else:
                feat_df = None

            for i in range(0, n, max(1, int(window))):
                row = df.iloc[i]
                ts = str(row.get("time", row.name))
                sample = {}
                if feat_df is not None:
                    try:
                        r = feat_df.iloc[i].to_dict()
                        sample = {k: float(v) for k, v in r.items() if (isinstance(v, (int, float)) or (isinstance(v, str) and v.replace('.', '', 1).lstrip('-').isdigit()))}
                    except Exception:
                        sample = {}
                else:
                    # minimal features
                    sample["close"] = float(row.get("close", 0.0))
                    sample["volume"] = float(row.get("volume", 0.0))
                prob = float(self.predict(sample))
                sig = self.predict_signal(sample)
                out.append({"ts": ts, "prob": prob, "prob_pct": prob * 100.0, "signal": sig})
            return out
        except Exception as e:
            log.exception("batch_predict error: %s", e)
            return out

    # -------------------------
    # Calibration utility (delegates to IAPredictor if available)
    # -------------------------
    def calibrate_threshold(self, y_true: List[int], y_proba: List[float], metric: str = "precision", target: float = 0.85) -> float:
        """
        Calibra y guarda nuevo umbral basado en datos de validación.
        retorna el umbral seleccionado.
        """
        try:
            # Prefer predictor's calibrate if available
            if self._predictor and hasattr(self._predictor, "calibrate_threshold"):
                try:
                    new_th = float(self._predictor.calibrate_threshold(y_true, y_proba, metric=metric, target=target))
                    self._state["threshold"] = new_th
                    # sync back to predictor if it has reload/save
                    try:
                        if hasattr(self._predictor, "save_threshold"):
                            self._predictor.save_threshold(new_th)
                    except Exception:
                        pass
                    self._save_state()
                    return new_th
                except Exception as e:
                    log.debug("predictor.calibrate_threshold failed: %s", e)

            # local calibration (grid search)
            best_th = float(self._state.get("threshold", 0.5))
            best_val = -1.0
            try:
                from sklearn.metrics import precision_score, recall_score, f1_score
                import numpy as np
                ys = np.asarray(y_true)
                ps = np.asarray(y_proba)
                for th in [x / 100.0 for x in range(1, 100)]:
                    preds = (ps >= th).astype(int)
                    if metric == "precision":
                        val = precision_score(ys, preds, zero_division=0)
                    elif metric == "recall":
                        val = recall_score(ys, preds, zero_division=0)
                    else:
                        val = f1_score(ys, preds, zero_division=0)
                    if val > best_val:
                        best_val = val
                        best_th = th
                    if val >= target:
                        break
            except Exception as e:
                log.exception("calibration grid search failed: %s", e)

            self._state["threshold"] = float(best_th)
            self._save_state()
            return float(best_th)
        except Exception as e:
            log.exception("calibrate_threshold error: %s", e)
            return float(self._state.get("threshold", 0.5))

    # -------------------------
    # Admin utilities
    # -------------------------
    def reload(self):
        """Recarga predictor and state from disk."""
        self._load_state()
        self._load_predictor()
        # clear cache
        self._cache = {}
        log.info("ModelPredictor recargado.")

    def set_threshold(self, value: float):
        try:
            v = max(0.01, min(0.99, float(value)))
            self._state["threshold"] = v
            # try to sync to predictor
            try:
                if self._predictor and hasattr(self._predictor, "save_threshold"):
                    self._predictor.save_threshold(v)
                if self._predictor and hasattr(self._predictor, "threshold"):
                    self._predictor.threshold = v
            except Exception:
                pass
            self._save_state()
            return v
        except Exception as e:
            log.exception("set_threshold error: %s", e)
            return float(self._state.get("threshold", 0.5))

    def get_threshold(self) -> float:
        return float(self._state.get("threshold", 0.5))

    def summary_for_ui(self) -> Dict[str, Any]:
        """Small summary object for dashboards."""
        return {
            "threshold": float(self._state.get("threshold", 0.5)),
            "predictor_loaded": self._predictor is not None,
            "cache_entries": len(self._cache)
        }


# -------------------------
# Convenience: module-level singleton (optional)
# -------------------------
_model_predictor_singleton: Optional[ModelPredictor] = None


def get_model_predictor_singleton(models_dir: Optional[str] = None) -> ModelPredictor:
    global _model_predictor_singleton
    if _model_predictor_singleton is None:
        _model_predictor_singleton = ModelPredictor(models_dir=models_dir)
    return _model_predictor_singleton

# ============================================================
# Compatibilidad retro (muy importante)
# trading_engine.py puede pedir IA_Predictor — lo redirigimos
# ============================================================

# Si existe backend.ia_predictor.IAPredictor → úsalo
if IAPredictor is not None:
    IA_Predictor = IAPredictor
else:
    # Fallback: usar ModelPredictor como IA_Predictor (API compatible)
    class IA_Predictor(ModelPredictor):
        """
        Alias retrocompatible para sistemas antiguos que importaban
        IA_Predictor desde model_predictor.py.
        """
        pass
