# backend/order_manager.py

import time
import threading
import json
import os
from datetime import datetime
from dataclasses import dataclass
from typing import Optional, Callable, Any

from backend.log_manager import get_logger

log = get_logger("order_manager")


# ======================================================
# ----------- HELPERS PRO: SL / TP / POSITION SIZE -----
# ======================================================

def compute_sl_tp_structural(
    direction: str,
    entry_price: float,
    atr: float,
):
    """
    SL y TP institucionales usando ATR (estructura-ready)
    """
    if not atr or atr <= 0 or not entry_price:
        return None, {}

    if direction == "LONG":
        sl = entry_price - atr * 1.5
        tps = {
            "TP1": entry_price + atr * 1.0,
            "TP2": entry_price + atr * 2.0,
            "TP3": entry_price + atr * 3.0,
            "TP4": entry_price + atr * 4.0,
        }
    else:
        sl = entry_price + atr * 1.5
        tps = {
            "TP1": entry_price - atr * 1.0,
            "TP2": entry_price - atr * 2.0,
            "TP3": entry_price - atr * 3.0,
            "TP4": entry_price - atr * 4.0,
        }

    return round(sl, 6), {k: round(v, 6) for k, v in tps.items()}


class OrderManagerError(Exception):
    pass

@dataclass
class OrderResult:
    status: str
    symbol: str
    entry_price: Optional[float]
    average_price: Optional[float]
    amount_executed: Optional[float]
    stop_loss_price: Optional[float]
    dca_levels: Optional[list]
    timestamp: str
    raw: Optional[dict]


class OrderManager:
    """
    OrderManager PRO con:
    - Órdenes DEMO y REAL
    - Confirmación MODO REAL con 2FA
    - Límite global y por usuario para monto máximo por operación
    - DCA, stop-loss
    - Auditoría persistente
    """

    def __init__(
        self,
        client: Any = None,
        base_investment: float = 10,
        stop_loss_pct: float = 0.02,
        max_usdt_per_order_global: float = 500  # límite global por defecto
    ):
        self.client = client
        self.base_investment = float(base_investment)
        self.stop_loss_pct = float(stop_loss_pct)

        # cancel flags
        self._cancel_requested = False
        self._lock = threading.Lock()

        # real-confirmation
        self._real_confirmed_users = set()
        self._confirm_file = os.path.join("data", "real_confirmations.jsonl")
        os.makedirs("data", exist_ok=True)
        self._load_confirmations_from_disk()

        # --- NEW: límite máximo por operación ---
        self.max_usdt_per_order_global = float(max_usdt_per_order_global)
        self.max_usdt_per_order_by_user = {}  # p.ej: {"efra": 300}
        self._limits_file = os.path.join("data", "real_limits.jsonl")

        # ======================================================
        # REGISTRO INSTITUCIONAL DE POSICIONES ACTIVAS
        # ======================================================

        self._active_trades_file = "data/active_trades.json"
        self._load_active_trades()

        # ======================================================
        # CONTROL DE RIESGO POR USUARIO
        # ======================================================
        self.max_drawdown_by_user = {}
        self.session_risk_tracker = {}

    # ======================================================
    # ----------- REGISTER TRADE RESULT ------------
    # ======================================================

    def register_trade_result(self, username, pnl):
        if username not in self.session_risk_tracker:
            self.session_risk_tracker[username] = 0

        self.session_risk_tracker[username] += pnl

        max_dd = self.max_drawdown_by_user.get(username, -1000)

        if self.session_risk_tracker[username] < max_dd:
            raise OrderManagerError("Drawdown máximo excedido")

    # ======================================================
    # ----------- LÓGICA PARA LÍMITES DE MONTO ------------
    # ======================================================

    def set_global_limit(self, amount: float):
        """Define un límite USDT para todos los usuarios."""
        self.max_usdt_per_order_global = float(amount)
        log.info("Nuevo límite global por operación: %s USDT", amount)

    def set_user_limit(self, username: str, amount: float):
        """Define un límite USDT para un usuario específico."""
        self.max_usdt_per_order_by_user[str(username)] = float(amount)
        log.info("Nuevo límite por usuario '%s': %s USDT", username, amount)

    def _get_effective_limit(self, username: Optional[str]):
        """Determina el límite efectivo (usuario -> global)."""
        if username and username in self.max_usdt_per_order_by_user:
            return self.max_usdt_per_order_by_user[username]
        return self.max_usdt_per_order_global

    def _audit_limit_violation(self, username: str, symbol: str, usdt_amount: float, limit: float):
        """Registro JSONL cuando una orden REAL intenta exceder límite."""
        record = {
            "timestamp": datetime.utcnow().isoformat(),
            "username": username,
            "symbol": symbol,
            "usdt_amount": usdt_amount,
            "limit": limit,
            "event": "limit_violation"
        }
        try:
            with open(self._limits_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception:
            log.exception("Error al registrar violación de límite")

    def _check_amount_limit(self, username: Optional[str], usdt_amount: float, symbol: str):
        """Valida si un monto excede el límite; lanza error si excede."""
        limit = self._get_effective_limit(username)
        if float(usdt_amount) > float(limit):
            self._audit_limit_violation(username or "N/A", symbol, usdt_amount, limit)
            raise OrderManagerError(
                f"El monto solicitado ({usdt_amount} USDT) excede el límite permitido ({limit} USDT)."
            )

    # ======================================================
    # ----------- CONFIRMACIÓN MODO REAL ------------------
    # ======================================================

    def _load_confirmations_from_disk(self):
        try:
            if not os.path.exists(self._confirm_file):
                return
            with open(self._confirm_file, "r", encoding="utf-8") as fh:
                for ln in fh:
                    try:
                        rec = json.loads(ln)
                        user = rec.get("username")
                        if user:
                            self._real_confirmed_users.add(user)
                    except:
                        continue
        except Exception as e:
            log.exception("Error loading confirmations: %s", e)

    # ======================================================
    # ----------- ACTIVE TRADES REGISTRY -------------------
    # ======================================================

    def _load_active_trades(self):
        try:
            if not os.path.exists(self._active_trades_file):
                self.active_trades = {}
                with open(self._active_trades_file, "w") as f:
                    json.dump({}, f)
                return
            with open(self._active_trades_file, "r") as f:
                content = f.read().strip()
                if not content:
                    self.active_trades = {}
                    return
                self.active_trades = json.loads(content)
        except Exception:
            log.exception("Failed loading active trades")
            self.active_trades = {}

    # =====================================
    # SAVE ACTIVE TRADES
    # =====================================
    def _save_active_trades(self):
        try:
            with open(self._active_trades_file, "w", encoding="utf-8") as f:
                json.dump(self.active_trades, f, indent=2)
        except Exception as e:
            log.exception("Failed saving active trades safely: %s", e)

    # =====================================
    # APPEND
    # =====================================
    def _append_confirmation_to_disk(self, username: str, metadata: dict):
        try:
            rec = {"username": username, "timestamp": datetime.utcnow().isoformat(), "meta": metadata}
            with open(self._confirm_file, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec) + "\n")
        except Exception:
            log.exception("Failed to persist real confirmation")

    def confirm_real_operation(self, token: str, username: str, confirm_callback: Optional[Callable] = None) -> dict:
        """Validación 2FA para modo REAL."""
        if not username:
            return {"ok": False, "error": "username required"}

        try:
            valid = False

            # Prefer callback
            if callable(confirm_callback):
                valid = bool(confirm_callback(username, token))
            else:
                # fallback a auth_utils (si existe)
                try:
                    from backend import auth_utils
                    if getattr(auth_utils, "validate_2fa_token", None):
                        valid = bool(auth_utils.validate_2fa_token(username, token))
                except Exception:
                    pass

            if not valid:
                return {"ok": False, "error": "Invalid token"}

            with self._lock:
                self._real_confirmed_users.add(username)

            self._append_confirmation_to_disk(username, {"method": "2fa"})
            return {"ok": True, "message": "Real mode confirmed"}

        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _is_real_confirmed(self, username: Optional[str] = None) -> bool:
        if username:
            return username in self._real_confirmed_users
        return len(self._real_confirmed_users) > 0

    # ======================================================
    # ----------- CANCELACIÓN / UTILIDADES ----------------
    # ======================================================

    def request_cancel(self):
        with self._lock:
            self._cancel_requested = True

    def _check_cancel(self):
        with self._lock:
            if self._cancel_requested:
                raise OrderManagerError("OPERACIÓN CANCELADA")

    def reset_cancel(self):
        with self._lock:
            self._cancel_requested = False

    # ======================================================
    # ----------- WRAPPERS DE MERCADO ----------------------
    # ======================================================

    def _market_buy(self, symbol: str, usdt_amount: float):
        self._check_cancel()

        if not self.client:
            raise OrderManagerError("Client not configured")

        try:
            price = float(self.client.get_symbol_price(symbol))
            if price <= 0:
                raise OrderManagerError("Invalid market price")

            qty = round(usdt_amount / price, 6)
            order = self.client.market_buy(symbol, qty)

            if not order:
                raise OrderManagerError("Empty order response")

            # ===============================
            # EXTRAER PRECIO REAL DE FILLS
            # ===============================
            avg_price = price
            commission = 0.0

            if isinstance(order, dict):
                fills = order.get("fills")
                if fills:
                    total_cost = 0.0
                    total_qty = 0.0
                    for f in fills:
                        fill_price = float(f.get("price", 0))
                        fill_qty = float(f.get("qty", 0))
                        total_cost += fill_price * fill_qty
                        total_qty += fill_qty
                        commission += float(f.get("commission", 0))

                    if total_qty > 0:
                        avg_price = total_cost / total_qty

            return avg_price, qty, order

        except Exception as e:
            log.exception("Market buy failed: %s", e)
            raise OrderManagerError(str(e))

    def market_sell_all(
        self,
        symbol: str,
        qty: float,
        reduce_only: bool = False,
        reason: str = "manual_close"
    ):
        self._check_cancel()

        if not self.client:
            raise OrderManagerError("Client not configured")

        try:
            order = self.client.market_sell(symbol, qty)

            # ===============================
            # CÁLCULO REAL DE PNL
            # ===============================
            exit_price = float(self.client.get_symbol_price(symbol))
            pnl = None

            if symbol in self.active_trades:
                entry_price = float(self.active_trades[symbol]["entry_price"])
                pnl = (exit_price - entry_price) * qty

            log.warning(
                "Cierre TOTAL ejecutado",
                extra={
                    "symbol": symbol,
                    "qty": qty,
                    "exit_price": exit_price,
                    "pnl": pnl,
                    "reason": reason
                }
            )

            return {
                "order": order,
                "exit_price": exit_price,
                "pnl": pnl
            }

        except Exception as e:
            log.exception("Error en cierre total")
            raise OrderManagerError(str(e))

    # ======================================================
    # ----------- EJECUCIÓN SIMPLE -------------------------
    # ======================================================

    def execute_trade(self, symbol: str, usdt_amount: Optional[float] = None, username: Optional[str] = None) -> OrderResult:
        self.reset_cancel()
        usdt = usdt_amount or self.base_investment

        # --- NEW: validar límite de operación ---
        self._check_amount_limit(username, usdt, symbol)

        entry_price, qty, raw = self._market_buy(symbol, usdt)
        stop = entry_price * (1 - self.stop_loss_pct)

        # ======================================================
        # REGISTRAR POSICIÓN ACTIVA
        # ======================================================

        try:
            self.active_trades[symbol] = {
                "symbol": symbol,
                "entry_price": entry_price,
                "qty": qty,
                "usdt": usdt,
                "timestamp": datetime.utcnow().isoformat()
            }
            self._save_active_trades()
        except Exception:
            log.exception("Failed registering active trade")

        return OrderResult(
            status="completed",
            symbol=symbol,
            entry_price=entry_price,
            average_price=entry_price,
            amount_executed=qty,
            stop_loss_price=stop,
            dca_levels=[],
            timestamp=str(datetime.utcnow()),
            raw=raw
        )

    # ======================================================
    # -------------------- DCA -----------------------------
    # ======================================================

    def execute_dca(self, symbol: str, initial_amount: float, levels: int = 3,
                    factor: float = 1.3, username: Optional[str] = None) -> OrderResult:
        self.reset_cancel()

        # --- NEW: validar límite con el monto inicial ---
        self._check_amount_limit(username, initial_amount, symbol)

        # Primera compra
        entry, qty, order = self._market_buy(symbol, initial_amount)
        accumulated_qty = qty
        total_cost = entry * qty
        dca_levels = [{"price": entry, "qty": qty, "usdt": initial_amount}]
        last_price = entry

        # Siguientes niveles
        for i in range(levels - 1):
            self._check_cancel()
            time.sleep(2)

            current_price = float(self.client.get_symbol_price(symbol))
            if current_price < last_price:
                usdt = initial_amount * (factor ** (i + 1))

                # --- NEW: validar límite por nivel DCA ---
                self._check_amount_limit(username, usdt, symbol)

                entry2, qty2, order2 = self._market_buy(symbol, usdt)
                accumulated_qty += qty2
                total_cost += entry2 * qty2
                dca_levels.append({"price": entry2, "qty": qty2, "usdt": usdt})
                last_price = entry2

        avg = total_cost / accumulated_qty
        stop = avg * (1 - self.stop_loss_pct)

        return OrderResult(
            status="completed",
            symbol=symbol,
            entry_price=entry,
            average_price=avg,
            amount_executed=accumulated_qty,
            stop_loss_price=stop,
            dca_levels=dca_levels,
            timestamp=str(datetime.utcnow()),
            raw={"dca": dca_levels}
        )

    # ======================================================
    # ----------- COMPUESTO (AI + DCA) ---------------------
    # ======================================================

    def execute_compound_order(
        self,
        symbol: str,
        usdt_amount: float = 10,
        dca_levels: int = 3,
        dca_factor: float = 1.25,
        ai_confidence: float = 0.7,
        username: Optional[str] = None,
        atr: Optional[float] = None,
        risk_pct: float = 2.0,
    ) -> OrderResult:

        if not symbol:
            raise OrderManagerError("Symbol required")

        if usdt_amount <= 0:
            raise OrderManagerError("Invalid USDT amount")

        if not self.client:
            raise OrderManagerError("Client not configured")

        self.reset_cancel()

        # --- validar límite ---
        self._check_amount_limit(username, usdt_amount, symbol)

        # ============================
        # EJECUCIÓN DCA BASE
        # ============================
        result = self.execute_dca(
            symbol=symbol,
            initial_amount=usdt_amount,
            levels=dca_levels,
            factor=dca_factor,
            username=username
        )

        entry_price = result.average_price

        # ============================
        # SL / TP PRO
        # ============================
        stop_loss_price = None
        tp_levels = {}

        if atr:
            stop_loss_price, tp_levels = compute_sl_tp_structural(
                direction="LONG",  # tu sistema actual es long-only
                entry_price=entry_price,
                atr=atr
            )

        # fallback si ATR no existe
        if not stop_loss_price:
            stop_loss_price = entry_price * (1 - self.stop_loss_pct)

        # ============================
        # AUDITORÍA FINAL
        # ============================
        if not isinstance(result.raw, dict):
            result.raw = {}

        result.raw.update({
            "ai_confidence": ai_confidence,
            "risk_pct": risk_pct,
            "atr": atr,
            "tp_levels": tp_levels,
            "position_size_usdt": usdt_amount,
            "user": username,
        })

        # sobrescribimos stop loss REAL
        result.stop_loss_price = stop_loss_price

        # ======================================================
        # REGISTRAR POSICIÓN COMPUESTA
        # ======================================================

        try:
            self.active_trades[symbol] = {
                "symbol": symbol,
                "entry_price": entry_price,
                "qty": result.amount_executed,
                "usdt": usdt_amount,
                "atr": atr,
                "confidence": ai_confidence,
                "timestamp": datetime.utcnow().isoformat()
            }
            self._save_active_trades()
        except Exception:
            log.exception("Failed registering compound trade")

        return result

    # ======================================================
    # ----------- CIERRES PRO (PASO 8) --------------------
    # ======================================================

    def market_sell_all(
        self,
        symbol: str,
        qty: float,
        reduce_only: bool = False,
        reason: str = "manual_close"
    ):
        """
        Cierre total de posición
        """
        self._check_cancel()

        try:
            if hasattr(self.client, "market_sell"):
                order = self.client.market_sell(symbol, qty)
            else:
                raise OrderManagerError("Cliente no soporta market_sell")

            log.warning(
                "Cierre TOTAL ejecutado",
                extra={
                    "symbol": symbol,
                    "qty": qty,
                    "reduce_only": reduce_only,
                    "reason": reason
                }
            )

            return order

        except Exception as e:
            log.exception("Error en cierre total")
            raise OrderManagerError(str(e))

    def market_sell_pct(
        self,
        symbol: str,
        qty_total: float,
        pct: float,
        reduce_only: bool = True,
        reason: str = "partial_tp"
    ):
        """
        Cierre parcial (% de la posición)
        """
        if pct <= 0 or pct > 100:
            raise OrderManagerError("Porcentaje inválido")

        qty = round(qty_total * (pct / 100.0), 6)

        return self.market_sell_all(
            symbol=symbol,
            qty=qty,
            reduce_only=reduce_only,
            reason=reason
        )

    # ======================================================
    # ----------- POSITION CONTROL INSTITUTIONAL -----------
    # ======================================================
    def close_position(self, symbol: str, reason: str = "manual_close"):
        if symbol not in self.active_trades:
            log.warning("Position not found: %s", symbol)
            return None
        trade = self.active_trades[symbol]
        qty = trade["qty"]
        try:
            order = self.market_sell_all(
                symbol=symbol,
                qty=qty,
                reduce_only=True,
                reason=reason
            )
            del self.active_trades[symbol]
            self._save_active_trades()
            log.warning(
                "Position closed",
                extra={
                    "symbol": symbol,
                    "qty": qty,
                    "reason": reason
                }
            )
            return order
        except Exception:
            log.exception("Failed closing position")
            raise

    # =======================================================
    # REDUCE POSITION
    # =======================================================
    def reduce_position(self, symbol: str, reduce_pct: float, reason: str = "partial_close"):
        if symbol not in self.active_trades:
            return None
        trade = self.active_trades[symbol]
        qty_total = trade["qty"]
        qty_reduce = qty_total * reduce_pct
        try:
            order = self.market_sell_all(
                symbol=symbol,
                qty=qty_reduce,
                reduce_only=True,
                reason=reason
            )
            trade["qty"] = qty_total - qty_reduce
            self._save_active_trades()
            return order
        except Exception:
            log.exception("Failed reducing position")
            raise

