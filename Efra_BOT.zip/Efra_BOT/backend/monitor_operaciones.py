# ============================================================
# backend/monitor_operaciones.py
# ============================================================
"""
Monitor en tiempo real de operaciones abiertas:
 - Supervisa las posiciones activas (DEMO o REAL).
 - Aplica control de riesgo dinámico (stop-loss configurable).
 - Envía alertas a Telegram al cierre automático (por pérdida o toma de ganancia).
 - Compatible con simulaciones y entorno real Binance.
"""
import os
import time
import pandas as pd
import numpy as np
import datetime
from backend.binance_client import obtener_datos_ohlcv, ejecutar_orden_simulada
from backend.telegram_notifier import enviar_mensaje
from utils.logger import log_info, log_error

# ============================================================
# CONFIGURACIÓN GLOBAL
# ============================================================
STOP_LOSS_PCT = 0.02     # 2% de riesgo por operación
CHECK_INTERVAL = 30      # segundos entre revisiones
TAKE_PROFIT_PCT = 0.03   # 3% de ganancia opcional

# ============================================================
# FUNCIÓN PRINCIPAL
# ============================================================
def monitor_operaciones_abiertas(operaciones: list, modo: str = "DEMO"):
    """
    Supervisa en tiempo real las operaciones abiertas.
    Si el precio cae > STOP_LOSS_PCT o sube > TAKE_PROFIT_PCT, cierra y notifica.
    Cada elemento en `operaciones` debe tener:
        { "symbol": str, "side": "BUY"/"SELL", "entry_price": float, "qty": float, "timestamp": str }
    """
    try:
        enviar_mensaje("🛰️ Iniciando monitor de operaciones abiertas...")
        while True:
            for op in operaciones:
                try:
                    symbol = op["symbol"]
                    side = op["side"]
                    qty = op["qty"]
                    entry = float(op["entry_price"])
                    df = obtener_datos_ohlcv(symbol, market="binance", periodo="1m", limite=10)

                    if df is None or df.empty:
                        continue

                    last_price = float(df["close"].iloc[-1])
                    diff_pct = (last_price - entry) / entry * (1 if side == "BUY" else -1)

                    # 🚨 Stop-loss
                    if diff_pct <= -STOP_LOSS_PCT:
                        msg = f"""
                        ⚠️ <b>Stop-Loss Activado</b>
                        • Activo: {symbol}
                        • Entrada: ${entry:.2f}
                        • Precio actual: ${last_price:.2f}
                        • Variación: {diff_pct*100:.2f}%
                        • Resultado: <b>PÉRDIDA CONTROLADA</b> 😔
                        • Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                        """
                        enviar_mensaje(msg)
                        cerrar_operacion(op, last_price, resultado="StopLoss", modo=modo)
                        operaciones.remove(op)
                        continue

                    # 🟢 Take-profit
                    if diff_pct >= TAKE_PROFIT_PCT:
                        msg = f"""
                        🟢 <b>Take Profit Alcanzado</b>
                        • Activo: {symbol}
                        • Entrada: ${entry:.2f}
                        • Precio actual: ${last_price:.2f}
                        • Variación: {diff_pct*100:.2f}%
                        • Resultado: <b>GANANCIA ASEGURADA</b> 💰
                        • Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                        """
                        enviar_mensaje(msg)
                        cerrar_operacion(op, last_price, resultado="TakeProfit", modo=modo)
                        operaciones.remove(op)
                        continue

                except Exception as e:
                    log_error(e, archivo="monitor_operaciones.py", funcion="monitor_loop_symbol")
                    continue

            if not operaciones:
                enviar_mensaje("✅ Todas las operaciones han sido cerradas o alcanzaron su objetivo.")
                break

            time.sleep(CHECK_INTERVAL)

    except Exception as e:
        log_error(e, archivo="monitor_operaciones.py", funcion="monitor_operaciones_abiertas")
        enviar_mensaje(f"❌ Error en monitor: {e}")


# ============================================================
# FUNCIÓN DE CIERRE DE OPERACIÓN
# ============================================================
def cerrar_operacion(op: dict, price_cierre: float, resultado: str, modo: str = "DEMO"):
    """
    Cierra la operación (simulada o real) y registra el resultado.
    """
    try:
        symbol = op["symbol"]
        side = "SELL" if op["side"] == "BUY" else "BUY"
        qty = op["qty"]

        if modo.upper() == "DEMO":
            res = ejecutar_orden_simulada(symbol, side, price_cierre * qty, modo)
            log_info(f"Cierre DEMO completado: {symbol} {resultado}")
        else:
            from backend.binance_client import place_market_order_with_stop
            res = place_market_order_with_stop(
                os.getenv("BINANCE_API_KEY"),
                os.getenv("BINANCE_API_SECRET"),
                symbol,
                side,
                price_cierre * qty,
                stop_loss_pct=STOP_LOSS_PCT,
                testnet=False
            )
            log_info(f"Cierre REAL completado: {symbol} {resultado}")

        # Telegram resumen de cierre
        enviar_mensaje(
            f"📉 <b>Operación cerrada ({resultado})</b>\n"
            f"• Activo: {symbol}\n"
            f"• Lado: {side}\n"
            f"• Precio cierre: ${price_cierre:.2f}\n"
            f"• Modo: {modo}\n"
            f"• Estado: ✅ Finalizada"
        )

        return res
    except Exception as e:
        log_error(e, archivo="monitor_operaciones.py", funcion="cerrar_operacion")
        enviar_mensaje(f"❌ Error al cerrar operación {op.get('symbol')}: {e}")
        return None
