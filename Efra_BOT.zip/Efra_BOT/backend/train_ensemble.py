# backend/train_ensemble.py
import os
import argparse
import json
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
import joblib

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def main(args):
    models_dir = args.models_dir
    ensure_dir(models_dir)

    df = pd.read_csv(args.data)
    # expected columns: features... and 'label' (0/1)
    if 'label' not in df.columns:
        raise ValueError("CSV must contain 'label' column (0/1).")

    # feature order: if provided by user else use all except timestamp/label
    skip = set(['timestamp', 'time', 'label'])
    feature_order = [c for c in df.columns if c not in skip]

    X = df[feature_order].fillna(0.0).values
    y = df['label'].astype(int).values

    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # ---------- LightGBM ----------
    try:
        import lightgbm as lgb
        dtrain = lgb.Dataset(X_train, label=y_train)
        params = {
            "objective": "binary",
            "metric": "auc",
            "verbosity": -1,
            "boosting": "gbdt",
            "num_leaves": 31,
            "learning_rate": 0.05,
            "feature_fraction": 0.9
        }
        lgbm = lgb.train(params, dtrain, num_boost_round=200)
        lgb_path = os.path.join(models_dir, "model_lgbm.txt")
        lgbm.save_model(lgb_path)
        print("Saved LightGBM ->", lgb_path)
        lgb_preds = lgbm.predict(X_val)
        lgb_auc = roc_auc_score(y_val, lgb_preds)
    except Exception as e:
        print("LightGBM training failed:", e)
        lgbm = None
        lgb_auc = 0.0

    # ---------- XGBoost ----------
    try:
        import xgboost as xgb
        dtrain_x = xgb.DMatrix(X_train, label=y_train)
        dval_x = xgb.DMatrix(X_val, label=y_val)
        params_x = {"objective": "binary:logistic", "eval_metric": "auc", "verbosity": 0}
        xgbm = xgb.train(params_x, dtrain_x, num_boost_round=200, evals=[(dval_x, "val")], early_stopping_rounds=20, verbose_eval=False)
        xgb_path = os.path.join(models_dir, "model_xgb.json")
        xgbm.save_model(xgb_path)
        print("Saved XGBoost ->", xgb_path)
        xgb_preds = xgbm.predict(dval_x)
        xgb_auc = roc_auc_score(y_val, xgb_preds)
    except Exception as e:
        print("XGBoost training failed:", e)
        xgbm = None
        xgb_auc = 0.0

    # ---------- MLP (sklearn) ----------
    try:
        scaler = StandardScaler()
        Xs_train = scaler.fit_transform(X_train)
        Xs_val = scaler.transform(X_val)
        mlp = MLPClassifier(hidden_layer_sizes=(64,32), max_iter=300, random_state=42)
        mlp.fit(Xs_train, y_train)
        mlp_path = os.path.join(models_dir, "model_mlp.joblib")
        joblib.dump({"model": mlp, "scaler": scaler}, mlp_path)
        print("Saved MLP ->", mlp_path)
        mlp_preds = mlp.predict_proba(Xs_val)[:,1]
        mlp_auc = roc_auc_score(y_val, mlp_preds)
    except Exception as e:
        print("MLP training failed:", e)
        mlp = None
        mlp_auc = 0.0

    # Compute weights proportional to AUC (if all 0 -> equal weights)
    aucs = {"lgb": float(lgb_auc), "xgb": float(xgb_auc), "mlp": float(mlp_auc)}
    total = sum([max(0.0, v) for v in aucs.values()])
    if total <= 0:
        weights = {"lgb": 1.0, "xgb": 1.0, "mlp": 1.0}
    else:
        weights = {k: max(0.01, v) / total for k, v in aucs.items()}

    meta = {
        "feature_order": feature_order,
        "weights": weights,
        "aucs": aucs
    }
    meta_path = os.path.join(models_dir, "meta.json")
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)
    print("Saved meta ->", meta_path)
    print("AUCs:", aucs)
    print("Weights:", weights)

    # Optional threshold calibration (use weighted avg proba)
    if args.calibrate:
        # build validation probs combined
        probs = []
        if lgbm:
            probs.append((lgb_preds, weights.get("lgb",1.0)))
        if xgbm:
            probs.append((xgb_preds, weights.get("xgb",1.0)))
        if mlp:
            probs.append((mlp_preds, weights.get("mlp",1.0)))
        if probs:
            num = sum(p * w for p, w in probs)
            den = sum(w for _, w in probs)
            y_proba = num / (den + 1e-12)
            from sklearn.metrics import precision_score, f1_score
            # simple threshold search maximizing f1
            best_th = 0.5
            best_f1 = -1
            for th in np.linspace(0.01, 0.99, 99):
                y_pred = (y_proba >= th).astype(int)
                f1 = f1_score(y_val, y_pred, zero_division=0)
                if f1 > best_f1:
                    best_f1 = f1
                    best_th = th
            th_path = os.path.join(models_dir, "threshold.json")
            with open(th_path, "w") as f:
                json.dump({"threshold": float(best_th)}, f)
            print("Calibrated threshold ->", best_th)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="CSV with features + label column")
    p.add_argument("--models_dir", default="models")
    p.add_argument("--calibrate", action="store_true")
    args = p.parse_args()
    main(args)
