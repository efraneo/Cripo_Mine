# ============================================================
# backend/telegram_core.py — Envío de mensajes y fotos a Telegram
# ============================================================
import os
import requests
from utils.logger import log_error, log_info

# -----------------------------------------------------------------
# Configuración base (debes tener tu token y chat_id en variables .env)
# -----------------------------------------------------------------
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# -----------------------------------------------------------------
# Función genérica: enviar texto
# -----------------------------------------------------------------
def enviar_mensaje(texto: str, parse_mode: str = "HTML"):
    """
    Envía un mensaje a Telegram. Requiere TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID en .env
    """
    try:
        if not BOT_TOKEN or not CHAT_ID:
            raise ValueError("Faltan credenciales de Telegram (BOT_TOKEN o CHAT_ID)")

        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
        payload = {"chat_id": CHAT_ID, "text": texto, "parse_mode": parse_mode}
        r = requests.post(url, data=payload, timeout=10)
        if r.status_code != 200:
            raise Exception(f"Error enviando mensaje Telegram: {r.text}")
        log_info("Mensaje enviado correctamente a Telegram.")
        return True
    except Exception as e:
        log_error(e, archivo="telegram_core.py", funcion="enviar_mensaje")
        return False

# -----------------------------------------------------------------
# Función: enviar imagen / sticker / bytes
# -----------------------------------------------------------------
def enviar_photo_bytes(photo_bytes: bytes, caption: str = None):
    """
    Envía una imagen (bytes) al chat de Telegram.
    """
    try:
        if not BOT_TOKEN or not CHAT_ID:
            raise ValueError("Faltan credenciales de Telegram (BOT_TOKEN o CHAT_ID)")

        url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"
        files = {"photo": ("avatar.png", photo_bytes)}
        data = {"chat_id": CHAT_ID, "caption": caption or ""}
        r = requests.post(url, files=files, data=data, timeout=15)
        if r.status_code != 200:
            raise Exception(f"Error enviando foto a Telegram: {r.text}")
        log_info("📸 Imagen enviada correctamente a Telegram.")
        return True
    except Exception as e:
        log_error(e, archivo="telegram_core.py", funcion="enviar_photo_bytes")
        return False
