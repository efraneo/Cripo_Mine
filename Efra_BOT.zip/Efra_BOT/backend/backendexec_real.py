# backend/exec_real.py
"""
Funciones seguras para ejecutar compra REAL (mainnet/testnet)
con gestión de riesgo básica y chequeos previos.
"""

import logging
import math
from typing import Dict, Any, Optional
from datetime import datetime

logger = logging.getLogger("exec_real")
if not logger.handlers:
    fh = logging.FileHandler("exec_real.log")
    fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(fh)
logger.setLevel(logging.INFO)

# Import your binance client wrappers (assumes backend/binance_client.py exists)
from backend.binance_client import obtener_balance, ejecutar_orden_compuesta, obtener_datos_ohlcv

# Helper: compute stop loss using ATR
def compute_stop_loss_from_atr(df, atr_multiplier=1.5):
    try:
        # df must contain 'close' and 'high'/'low' to compute ATR if not present
        if "atr" in df.columns:
            last_atr = float(df["atr"].iloc[-1])
        else:
            # basic fallback using high-low
            last_atr = float((df["high"] - df["low"]).rolling(14, min_periods=1).mean().iloc[-1])
        last_close = float(df["close"].iloc[-1])
        stop = max(0.0, last_close - atr_multiplier * last_atr)
        return float(stop)
    except Exception as e:
        logger.exception("compute_stop_loss_from_atr: %s", e)
        return None

def size_from_usdt_amount(usdt_amount: float, price: float, precision: int = 8) -> float:
    if price <= 0:
        return 0.0
    qty = usdt_amount / price
    # round to precision
    fmt = "{:0." + str(precision) + "f}"
    return float(fmt.format(qty))

def check_balance_and_execute(symbol: str,
                              buy_usdt: float,
                              modo: str = "REAL",
                              min_usdt_required: float = 10.0,
                              risk_pct_stop: float = 0.02,
                              atr_mult: float = 1.5,
                              user: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:
    """
    - Comprueba balance USDT disponible
    - Descarga precio reciente
    - Calcula qty y stop (ATR)
    - Ejecuta usando ejecutar_orden_compuesta (wrapper)
    """
    try:
        # 1. balance
        bal = obtener_balance("USDT")
        if bal is None:
            logger.error("Cannot read balance (None). Aborting.")
            return {"status":"error", "reason":"no_balance"}

        # if obtener_balance returns dict or float
        usdt_available = None
        if isinstance(bal, dict):
            usdt_available = float(bal.get("USDT", 0.0))
        else:
            usdt_available = float(bal)

        logger.info("USDT available: %s", usdt_available)

        if modo.upper() == "REAL" and usdt_available < min_usdt_required:
            return {"status":"rejected", "reason":"insufficient_balance", "available": usdt_available}

        if buy_usdt <= 0:
            return {"status":"error", "reason":"invalid_amount"}

        # 2. price (try local OHLCV)
        df = obtener_datos_ohlcv(symbol=symbol, interval="1h", limit=20)
        price = None
        if df is not None and not df.empty:
            price = float(df["close"].iloc[-1])
        else:
            # fallback to public price
            try:
                import requests
                r = requests.get("https://api.binance.com/api/v3/ticker/price", params={"symbol": symbol}, timeout=5)
                price = float(r.json().get("price", 0))
            except Exception as e:
                logger.exception("price fallback failed: %s", e)
                price = None

        if not price or price <= 0:
            return {"status":"error", "reason":"no_price"}

        # 3. compute qty and stop
        qty = size_from_usdt_amount(buy_usdt, price)
        stop_price = None
        if df is not None and not df.empty:
            stop_price = compute_stop_loss_from_atr(df, atr_multiplier=atr_mult)
        else:
            stop_price = round(price * (1.0 - risk_pct_stop), 8)

        if stop_price is None:
            stop_price = round(price * (1.0 - risk_pct_stop), 8)

        # sanity clamp
        if qty <= 0:
            return {"status":"error", "reason":"zero_qty"}

        # 4. execute (paper or real)
        if modo.upper() == "DEMO" or modo.upper() == "PAPER":
            # simulate
            logger.info("SIMULATED buy %s USDT of %s at price %s qty %s", buy_usdt, symbol, price, qty)
            return {
                "status":"simulated",
                "symbol": symbol,
                "price": price,
                "qty": qty,
                "stop_price": stop_price,
                "amount_usdt": buy_usdt
            }

        # REAL execution: use ejecutar_orden_compuesta wrapper (which will try to use client instance)
        res = ejecutar_orden_compuesta(symbol=symbol, side="BUY", qty=qty, stop_price=stop_price, modo="REAL")
        logger.info("REAL execution result: %s", res)
        return {"status":"sent", "symbol": symbol, "qty": qty, "price": price, "stop_price": stop_price, "res": res}

    except Exception as e:
        logger.exception("check_balance_and_execute failed: %s", e)
        return {"status":"error", "error": str(e)}
