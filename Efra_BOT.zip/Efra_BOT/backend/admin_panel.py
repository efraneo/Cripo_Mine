# backend/admin_panel.py
"""
ADMIN PANEL PRO
 - Panel completo para gestionar usuarios
 - Compatible con UserManager PRO, IPManager, auth_utils
 - Roles, estado, permisos extendidos
 - Auditoría rápida
"""

import streamlit as st
import pandas as pd
from datetime import datetime
from backend.user_manager import UserManager
from backend.ip_manager import IPManager
from backend import auth_utils

def render_admin_panel(user_m: UserManager, ip_m: IPManager):
    st.title("⚙️ Panel de Administración PRO")

    # ======================================================
    # Sección 1 — Usuarios completos
    # ======================================================
    st.subheader("👥 Usuarios Registrados")

    users = user_m.list_users()
    if not users:
        st.info("No hay usuarios registrados.")
        return

    df_users = pd.DataFrame(users)
    st.dataframe(df_users)

    st.markdown("---")
    st.header("➕ Crear Usuario")

    with st.form("create_user_form"):
        new_user = st.text_input("Usuario (ID o nickname)")
        new_pass = st.text_input("Contraseña", type="password")
        new_email = st.text_input("Correo")
        new_admin = st.checkbox("Es administrador?", value=False)
        new_enabled = st.checkbox("Usuario activo", value=True)
        new_ip = st.text_input("IP asociada (opcional)")

        submitted = st.form_submit_button("Crear Usuario")

        if submitted:
            if not new_user or not new_pass:
                st.error("Usuario y contraseña son requeridos.")
            else:
                try:
                    user_m.create_user_secure(
                        username=new_user,
                        password=new_pass,
                        email=new_email,
                        is_admin=new_admin,
                        enabled=new_enabled
                    )
                    if new_ip:
                        ip_m.approve_ip(new_user, new_ip)

                    st.success(f"Usuario {new_user} creado correctamente.")
                except Exception as e:
                    st.error(f"Error: {e}")

    # ======================================================
    # Edición de usuarios
    # ======================================================
    st.markdown("---")
    st.header("✏️ Editar Usuario Existente")

    target_user = st.selectbox("Seleccione usuario", [u["username"] for u in users])

    if target_user:
        urec = user_m.get_user_by_username(target_user)
        st.write("### Datos actuales")
        st.json(urec)

        new_email = st.text_input("Nuevo correo", value=urec["email"] or "")
        new_is_admin = st.checkbox("Administrador", value=urec.get("is_admin", False))
        new_enabled = st.checkbox("Activo", value=urec.get("enabled", True))

        if st.button("Aplicar cambios"):
            try:
                user_m.update_user_by_username(target_user, {
                    "email": new_email,
                    "is_admin": new_is_admin,
                    "enabled": new_enabled
                })
                st.success("Datos actualizados con éxito.")
            except Exception as e:
                st.error(f"Error: {e}")

        st.markdown("### 🔐 Resetear contraseña")

        newpass = st.text_input("Nueva contraseña", type="password")
        if st.button("Resetear contraseña"):
            try:
                user_m.set_password(target_user, newpass)
                st.success("Contraseña actualizada.")
            except Exception as e:
                st.error(f"Error: {e}")

        st.markdown("### 🗑 Eliminar usuario")
        if st.button("Eliminar DEFINITIVAMENTE"):
            try:
                user_m.delete_user_by_username(target_user)
                st.success("Usuario eliminado.")
            except Exception as e:
                st.error(f"Error: {e}")

    # ======================================================
    # IP Manager
    # ======================================================
    st.markdown("---")
    st.header("🌐 Control de IP")

    allowed_ips = ip_m.list_allowed()
    st.write("### IPs Aprobadas")
    if allowed_ips:
        st.dataframe(pd.DataFrame(allowed_ips))
    else:
        st.info("No hay IPs aprobadas todavía.")

    st.write("### Aprobar nueva IP")
    with st.form("approve_ip"):
        ip_user = st.selectbox("Usuario", [u["username"] for u in users])
        ip_addr = st.text_input("IP")
        ok = st.form_submit_button("Aprobar")
        if ok:
            try:
                ip_m.approve_ip(ip_user, ip_addr)
                st.success("IP aprobada.")
            except Exception as e:
                st.error(f"Error: {e}")

    # ======================================================
    # Auditoría rápida
    # ======================================================
    st.markdown("---")
    st.header("📊 Auditoría Rápida")

    try:
        conn = user_m._conn()
        fails = pd.read_sql_query("SELECT * FROM failed_logins ORDER BY ts DESC LIMIT 50", conn)
        locks = pd.read_sql_query("SELECT * FROM lockouts", conn)
        conn.close()

        st.markdown("### ❌ Intentos fallidos recientes")
        st.dataframe(fails)

        st.markdown("### 🔒 Usuarios bloqueados")
        st.dataframe(locks)

    except Exception as e:
        st.error(f"No se pudo cargar auditoría: {e}")
