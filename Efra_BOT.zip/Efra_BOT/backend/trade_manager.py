from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional

from backend.log_manager import get_logger

log = get_logger("trade_manager")


# ==================================================
# ESTADO DEL TRADE
# ==================================================
@dataclass
class TradeState:
    symbol: str
    entry_price: float
    qty: float
    atr: float
    direction: str  # LONG / SHORT
    stop_loss: float
    tp_levels: Dict[str, float]

    tp_hit: Dict[str, bool] = field(default_factory=dict)
    breakeven_applied: bool = False
    trailing_active: bool = False
    opened_at: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    closed: bool = False


# ==================================================
# TRADE MANAGER PRO
# ==================================================
class TradeManager:
    """
    Gestión viva del trade (post entrada).
    Decide QUÉ hacer, NO ejecuta órdenes.
    """

    def __init__(self):
        self.trades: Dict[str, TradeState] = {}
        self.history: list = []

    def record_history(self, record: dict):
        self.history.append(record)

    def get_trade_history(self, limit: int = 200):
        return self.history[-limit:]

    # --------------------------------------------------
    # REGISTRO INICIAL
    # --------------------------------------------------
    def register_trade(
        self,
        symbol: str,
        entry_price: float,
        qty: float,
        atr: float,
        direction: str,
        stop_loss: float,
        tp_levels: Dict[str, float],
    ):
        self.trades[symbol] = TradeState(
            symbol=symbol,
            entry_price=entry_price,
            qty=qty,
            atr=atr,
            direction=direction.upper(),
            stop_loss=stop_loss,
            tp_levels=tp_levels,
            tp_hit={k: False for k in tp_levels},
        )

        log.info(
            "Trade registrado",
            extra={
                "symbol": symbol,
                "direction": direction,
                "entry": entry_price,
                "sl": stop_loss,
            },
        )

    # --------------------------------------------------
    # UPDATE CENTRAL
    # --------------------------------------------------
    def update(
        self,
        symbol: str,
        price: float,
        ia_score: float,
        atr: Optional[float] = None,
    ):
        if symbol not in self.trades:
            return None

        trade = self.trades[symbol]
        if trade.closed:
            return None

        atr_val = atr or trade.atr

        # ==================================================
        # 1) TAKE PROFITS
        # ==================================================
        for tp, level in trade.tp_levels.items():
            if trade.tp_hit.get(tp):
                continue

            hit = (
                price >= level if trade.direction == "LONG"
                else price <= level
            )

            if hit:
                trade.tp_hit[tp] = True
                log.info(f"{tp} alcanzado", extra={"symbol": symbol})

                if tp == "TP1" and not trade.breakeven_applied:
                    trade.stop_loss = trade.entry_price
                    trade.breakeven_applied = True
                    log.info("Break-even aplicado", extra={"symbol": symbol})

                if tp == "TP2":
                    trade.trailing_active = True
                    log.info("Trailing activado", extra={"symbol": symbol})

                return {
                    "action": "PARTIAL_CLOSE",
                    "tp": tp,
                    "symbol": symbol,
                }

        # ==================================================
        # 2) TRAILING STOP
        # ==================================================
        if trade.trailing_active:
            if trade.direction == "LONG":
                new_sl = price - atr_val * 1.2
                if new_sl > trade.stop_loss:
                    trade.stop_loss = new_sl
            else:
                new_sl = price + atr_val * 1.2
                if new_sl < trade.stop_loss:
                    trade.stop_loss = new_sl

        # ==================================================
        # 3) STOP LOSS
        # ==================================================
        sl_hit = (
            price <= trade.stop_loss if trade.direction == "LONG"
            else price >= trade.stop_loss
        )

        if sl_hit:
            trade.closed = True
            log.warning("Stop Loss ejecutado", extra={"symbol": symbol})
            return {
                "action": "CLOSE_ALL",
                "reason": "STOP_LOSS",
                "symbol": symbol,
            }

        # ==================================================
        # 4) CIERRE DEFENSIVO POR IA
        # ==================================================
        if ia_score < 65:
            trade.closed = True
            log.warning(
                "Trade cerrado por degradación IA",
                extra={"symbol": symbol, "ia_score": ia_score},
            )
            return {
                "action": "CLOSE_ALL",
                "reason": "IA_DEGRADATION",
                "symbol": symbol,
            }

        # ==================================================
        # 5) HOLD
        # ==================================================
        return {
            "action": "HOLD",
            "symbol": symbol,
            "stop_loss": trade.stop_loss,
            "tp_hit": trade.tp_hit,
            "breakeven": trade.breakeven_applied,
            "trailing": trade.trailing_active,
        }

    def compute_metrics(self):
        if not self.history:
            return {}

        df = pd.DataFrame(self.history)

        pnl = df.get("pnl", pd.Series(dtype=float))

        metrics = {
            "total_trades": len(df),
            "win_rate": float((pnl > 0).mean()) if not pnl.empty else 0.0,
            "avg_pnl": float(pnl.mean()) if not pnl.empty else 0.0,
            "max_drawdown": float(pnl.cumsum().min()) if not pnl.empty else 0.0,
            "expectancy": float(pnl.mean()) if not pnl.empty else 0.0,
        }

        return metrics
