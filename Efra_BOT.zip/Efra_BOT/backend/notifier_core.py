# ================================================================
# backend/notifier_core.py — Núcleo de Notificación PRO (2025)
# ================================================================

from __future__ import annotations
import time
import traceback
from typing import Optional, Dict, Any, List, Callable

try:
    from backend.log_manager import get_logger
    log = get_logger("notifier_core")
except Exception:
    import logging
    log = logging.getLogger("notifier_core")
    if not log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        log.addHandler(h)
    log.setLevel(logging.DEBUG)


# ================================================================
# Clase base para 1 canal de notificación
# ================================================================
class BaseNotifier:
    channel_name = "base"

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.last_error: Optional[str] = None

    def send_message(self, message: str, **kwargs) -> bool:
        if not self.enabled:
            log.debug(f"[{self.channel_name}] deshabilitado.")
            return False
        try:
            ok = self.send_message_impl(message, **kwargs)
            if not ok:
                raise Exception("send_message_impl returned False")
            return True
        except Exception as e:
            self.last_error = str(e)
            log.error(
                f"[{self.channel_name}] error: {e}\n{traceback.format_exc()}"
            )
            return False

    def send_message_impl(self, message: str, **kwargs) -> bool:
        raise NotImplementedError


# ================================================================
# Multiplexor PRO
# ================================================================
class NotifierMux:

    def __init__(self):
        self.channels: Dict[str, BaseNotifier] = {}
        self.queue_enabled = False
        self._msg_queue: List[Dict[str, Any]] = []
        self.on_message_callback: Optional[Callable[[str], None]] = None

    def register(self, name: str, notifier: BaseNotifier):
        self.channels[name] = notifier
        log.info(f"Canal registrado: {name}")

    def set_ui_callback(self, cb: Callable[[str], None]):
        self.on_message_callback = cb

    def broadcast(self, message: str):
        if self.queue_enabled:
            self._msg_queue.append({"msg": message, "ts": time.time()})
            return True

        success_any = False
        for name, ch in self.channels.items():
            success_any = ch.send_message(message) or success_any

        if self.on_message_callback:
            try:
                self.on_message_callback(message)
            except Exception:
                log.error("UI callback failed")

        return success_any

    def enable_queue(self):
        self.queue_enabled = True

    def disable_queue(self):
        self.queue_enabled = False
        self.flush_queue()

    def flush_queue(self):
        for item in list(self._msg_queue):
            self.broadcast(item["msg"])
        self._msg_queue.clear()

    # Semánticos
    def send_trade(self, msg: str):
        return self.broadcast(f"💹 Trade: {msg}")

    def send_error(self, msg: str):
        return self.broadcast(f"❌ Error: {msg}")

    def send_alert(self, msg: str):
        return self.broadcast(f"⚠️ Alerta: {msg}")

    def send_system(self, msg: str):
        return self.broadcast(f"🖥️ Sistema: {msg}")


# ================================================================
# Instancia GLOBAL
# ================================================================
DEFAULT_NOTIFIER = NotifierMux()


# ================================================================
# 🧩 API FUNCIONAL (COMPATIBILIDAD LEGACY)
# ================================================================
# ⚠️ NO eliminar — usada por módulos antiguos
# ================================================================

def send(*args):
    """
    Compatibilidad:
    - send("mensaje")
    - send(chat_id, "mensaje") → chat_id se ignora (mux decide)
    """
    message = args[-1] if args else ""
    return DEFAULT_NOTIFIER.broadcast(str(message))


def send_markdown(*args):
    message = args[-1] if args else ""
    return DEFAULT_NOTIFIER.broadcast(str(message))


def send_error(*args):
    message = args[-1] if args else ""
    return DEFAULT_NOTIFIER.send_error(str(message))
