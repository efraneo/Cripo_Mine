# backend/utils.py
"""
Utilidades internas del backend: carga de .env, lectura CSV segura, formateo
"""
import os
from dotenv import load_dotenv
import pandas as pd

def cargar_entornos():
    """
    Carga archivos .env presentes en la carpeta env/
    """
    base = os.path.join(os.getcwd(), "env")
    if not os.path.exists(base):
        return
    for f in os.listdir(base):
        if f.endswith(".env"):
            path = os.path.join(base, f)
            try:
                load_dotenv(path)
            except Exception:
                pass

def leer_csv_seguro(ruta):
    """
    Lee un CSV y retorna DataFrame; en error devuelve df vacío.
    """
    try:
        if not os.path.exists(ruta):
            return pd.DataFrame()
        return pd.read_csv(ruta)
    except Exception as e:
        print(f"[leer_csv_seguro] Error leyendo {ruta}: {e}")
        return pd.DataFrame()

def safe_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default
