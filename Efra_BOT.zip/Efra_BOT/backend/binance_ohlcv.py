# backend/binance_ohlcv.py
"""
binance_ohlcv.py

Refactor del BLOQUE A2 del archivo original.
Contiene TODA la lógica relacionada con obtención de datos OHLCV:

 - get_ohlcv()                       → Función general
 - obtener_datos_ohlcv_binance()    → Binance real / Testnet
 - obtener_datos_ohlcv_yf()         → Fallback con yfinance
 - obtener_datos_ohlcv_sim()        → Simulador sintético
 - normalización de DataFrame
 - validación de intervalos
 - conversión de timestamps
 - integración con binance_core (safe_float, _simular_ohlcv)

Este módulo **no toca órdenes**, no toca monitor, no toca funciones de usuario,
solamente datos de mercado.

Es compatible con:
 - backtesting
 - tu módulo IA
 - tus señales
 - tu monitor de órdenes
"""

from __future__ import annotations
import os
import time
import pandas as pd
import numpy as np
import datetime
from typing import Optional, Dict, Any, Tuple, List

# Importamos utilidades del módulo 1
from backend.binance_core import (
    safe_float,
    _simular_ohlcv
)

# Intento cargar python-binance
try:
    from binance.client import Client as _BinanceClient
    from binance.exceptions import BinanceAPIException
    _BINANCE_AVAILABLE = True
except Exception:
    _BINANCE_AVAILABLE = False

# Carga de yfinance
try:
    import yfinance as yf
    _YF_AVAILABLE = True
except Exception:
    _YF_AVAILABLE = False


# ============================================================
# 🚀 1. MAPEOS DE INTERVALOS
# ============================================================

_BINANCE_INTERVAL_MAP = {
    "1m": _BinanceClient.KLINE_INTERVAL_1MINUTE if _BINANCE_AVAILABLE else "1m",
    "3m": _BinanceClient.KLINE_INTERVAL_3MINUTE if _BINANCE_AVAILABLE else "3m",
    "5m": _BinanceClient.KLINE_INTERVAL_5MINUTE if _BINANCE_AVAILABLE else "5m",
    "15m": _BinanceClient.KLINE_INTERVAL_15MINUTE if _BINANCE_AVAILABLE else "15m",
    "30m": _BinanceClient.KLINE_INTERVAL_30MINUTE if _BINANCE_AVAILABLE else "30m",
    "1h": _BinanceClient.KLINE_INTERVAL_1HOUR if _BINANCE_AVAILABLE else "1h",
    "2h": _BinanceClient.KLINE_INTERVAL_2HOUR if _BINANCE_AVAILABLE else "2h",
    "4h": _BinanceClient.KLINE_INTERVAL_4HOUR if _BINANCE_AVAILABLE else "4h",
    "1d": _BinanceClient.KLINE_INTERVAL_1DAY if _BINANCE_AVAILABLE else "1d",
    "1w": _BinanceClient.KLINE_INTERVAL_1WEEK if _BINANCE_AVAILABLE else "1w",
}


_YF_INTERVAL_MAP = {
    "1m": "1m",
    "2m": "2m",
    "5m": "5m",
    "15m": "15m",
    "30m": "30m",
    "60m": "60m",
    "90m": "90m",
    "1h": "1h",
    "1d": "1d",
    "5d": "5d",
    "1wk": "1wk",
    "1mo": "1mo",
}


# ============================================================
# 🚀 2. VALIDACIÓN
# ============================================================

def _validar_intervalo(intervalo: str) -> str:
    """
    Normaliza y valida intervalo. Lanza excepción si inválido.
    """
    intervalo = intervalo.lower().strip()

    if intervalo in _BINANCE_INTERVAL_MAP:
        return intervalo

    # Intento YF
    if intervalo in _YF_INTERVAL_MAP:
        return intervalo

    raise ValueError(
        f"Intervalo no soportado: {intervalo}. "
        f"Binance soporta: {list(_BINANCE_INTERVAL_MAP.keys())}, "
        f"YF soporta: {list(_YF_INTERVAL_MAP.keys())}"
    )


# ============================================================
# 🚀 3. LIMPIEZA / FORMATEO DE OHLCV
# ============================================================

def _df_from_klines(klines: List[List[Any]]) -> pd.DataFrame:
    """
    Convierte un array de klines de Binance a DataFrame limpio.
    """
    rows = []
    for k in klines:
        rows.append({
            "time": datetime.datetime.utcfromtimestamp(k[0] / 1000),
            "open": safe_float(k[1]),
            "high": safe_float(k[2]),
            "low": safe_float(k[3]),
            "close": safe_float(k[4]),
            "volume": safe_float(k[5]),
        })
    df = pd.DataFrame(rows)
    return df


# ============================================================
# 🚀 4. FUENTE: BINANCE REAL / TESTNET
# ============================================================

def obtener_datos_ohlcv_binance(
    client: _BinanceClient,
    symbol: str,
    intervalo: str,
    limit: int = 500
) -> Optional[pd.DataFrame]:
    """
    Obtiene datos OHLCV usando el cliente Binance real/testnet.
    Retorna DataFrame o None si falla.
    """
    try:
        if not _BINANCE_AVAILABLE:
            return None

        intervalo_api = _BINANCE_INTERVAL_MAP.get(intervalo)
        if not intervalo_api:
            return None

        kl = client.get_klines(
            symbol=symbol,
            interval=intervalo_api,
            limit=limit
        )

        if not kl:
            return None

        return _df_from_klines(kl)

    except BinanceAPIException as e:
        print(f"[Binance] Error API OHLCV: {e}")
        return None
    except Exception as e:
        print(f"[Binance] Error inesperado: {e}")
        return None


# ============================================================
# 🚀 5. FUENTE: YFINANCE
# ============================================================

def obtener_datos_ohlcv_yf(
    symbol: str,
    intervalo: str,
    limit: int = 500
) -> Optional[pd.DataFrame]:
    """
    Descarga datos OHLCV vía yfinance.
    """
    try:
        if not _YF_AVAILABLE:
            return None

        intervalo_yf = _YF_INTERVAL_MAP.get(intervalo)
        if not intervalo_yf:
            return None

        pair = symbol.replace("/", "").upper()

        df = yf.download(
            tickers=pair,
            period="7d",
            interval=intervalo_yf,
            progress=False
        )

        if df is None or df.empty:
            return None

        df = df.reset_index()
        df.rename(columns={
            "Datetime": "time",
            "Open": "open",
            "High": "high",
            "Low": "low",
            "Close": "close",
            "Volume": "volume",
        }, inplace=True)

        df = df[["time", "open", "high", "low", "close", "volume"]]

        # Dejar los últimos `limit`
        if len(df) > limit:
            df = df.iloc[-limit:]

        return df

    except Exception as e:
        print(f"[YF] Error obteniendo OHLCV: {e}")
        return None


# ============================================================
# 🚀 6. FUENTE: SIMULADOR OHLCV
# ============================================================

def obtener_datos_ohlcv_sim(limit: int = 500) -> pd.DataFrame:
    """
    Devuelve datos simulados (función ya implementada en módulo core).
    """
    return _simular_ohlcv(limite=limit)


# ============================================================
# 🚀 7. FUNCIÓN PRINCIPAL UNIVERSAL
# ============================================================

def get_ohlcv(
    symbol: str,
    intervalo: str,
    limit: int = 500,
    client_dict: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    """
    Función universal para obtener OHLCV de:
     - Binance real/testnet → prioridad
     - yfinance → fallback
     - simulador → última opción
    
    Uso:
        df = get_ohlcv("BTCUSDT", "1m", 500, client_user)

    Donde client_user es dict retornado por get_binance_client_for_user()
    """
    intervalo = _validar_intervalo(intervalo)

    # 1) BINANCE REAL O TESTNET
    if _BINANCE_AVAILABLE and client_dict:
        client = client_dict.get("client")
        if client:
            df = obtener_datos_ohlcv_binance(client, symbol, intervalo, limit)
            if df is not None:
                return df

    # 2) YFINANCE
    df = obtener_datos_ohlcv_yf(symbol, intervalo, limit)
    if df is not None:
        return df

    # 3) SIMULACIÓN
    return obtener_datos_ohlcv_sim(limit)


# ============================================================
# EXPORTS
# ============================================================

__all__ = [
    "get_ohlcv",
    "obtener_datos_ohlcv_binance",
    "obtener_datos_ohlcv_yf",
    "obtener_datos_ohlcv_sim",
]
