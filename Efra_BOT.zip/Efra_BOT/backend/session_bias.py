# backend/session_bias.py
from datetime import datetime, time

# ============================
# SESSION DETECTION (UTC)
# ============================

def get_session(now_utc=None):
    if not now_utc:
        now_utc = datetime.utcnow().time()

    if time(23, 0) <= now_utc or now_utc < time(7, 0):
        return "ASIA"
    if time(7, 0) <= now_utc < time(13, 0):
        return "LONDON"
    if time(13, 0) <= now_utc < time(21, 0):
        return "NEW_YORK"
    return "DEAD"


# ============================
# SESSION BIAS (RULE-BASED)
# ============================

def apply_session_bias(
    score: float,
    direction: str,
    signal_type: str,  # "BREAKOUT" | "CONTINUATION" | "REVERSAL"
):
    session = get_session()
    reasons = []
    delta = 0
    blocked = False

    # ========================
    # ASIA
    # ========================
    if session == "ASIA":
        if signal_type == "BREAKOUT":
            delta -= 20
            reasons.append("Asia session: breakout de baja fiabilidad")
        if score < 90:
            blocked = True
            reasons.append("Asia session: score insuficiente")

    # ========================
    # LONDON
    # ========================
    elif session == "LONDON":
        if signal_type == "BREAKOUT":
            delta += 10
            reasons.append("London session: ruptura institucional")
        if signal_type == "CONTINUATION":
            delta += 5
            reasons.append("London: continuación con liquidez")

    # ========================
    # NEW YORK
    # ========================
    elif session == "NEW_YORK":
        if signal_type == "CONTINUATION":
            delta += 5
            reasons.append("New York: continuación válida")
        if signal_type == "REVERSAL":
            delta -= 10
            reasons.append("New York: reversión tardía")

    # ========================
    # DEAD ZONE
    # ========================
    else:
        blocked = True
        reasons.append("Dead zone: liquidez insuficiente")

    final_score = max(score + delta, 0)

    return {
        "session": session,
        "adjusted_score": round(final_score, 2),
        "delta": delta,
        "blocked": blocked,
        "reasons": reasons,
    }
