# backend/binance_manager.py — PRO (reemplazar archivo completo)
"""
BinanceManager PRO (2025)

- Robust wrapper around backend.binance_client (if present)
- Requests-based ping
- Caching (in-memory) for symbols/ticker/klines
- Throttling (naive) for safe calls
- Normalization of klines to list[dict] and optional pandas.DataFrame
- Async wrappers for blocking calls
- Compatible with the UI cached helpers and TradingEngine
"""
from __future__ import annotations

import time
import threading
from typing import Any, Dict, List, Optional, Tuple, Union
import requests

# Logger (prefer backend.log_manager if available)
try:
    from backend.log_manager import get_logger

    log = get_logger("binance_manager")
except Exception:
    import logging

    log = logging.getLogger("binance_manager")
    if not log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        log.addHandler(h)
    log.setLevel(logging.INFO)

# Try import real client (optional)
try:
    from backend.binance_client import BinanceClient, BinanceTimeSyncError
except Exception:
    BinanceClient = None

    class BinanceTimeSyncError(Exception):
        pass

KlinesType = List[Dict[str, Any]]


class BinanceManager:
    def __init__(
        self,
        api_key: str = "",
        api_secret: str = "",
        base_url: str = "https://api.binance.com",
        cache_ttl: float = 3.0,
        klines_ttl: float = 5.0,
        cooldown_between_calls: float = 0.12,
    ):
        self.api_key = api_key or ""
        self.api_secret = api_secret or ""
        self.base_url = base_url.rstrip("/")

        # Client (optional)
        self.client = None
        if BinanceClient and self.api_key and self.api_secret:
            try:
                self.client = BinanceClient(self.api_key, self.api_secret, base_url=self.base_url)
            except Exception as e:
                log.exception("No se pudo iniciar BinanceClient: %s", e)
                self.client = None
        else:
            log.warning("BinanceClient no disponible o sin API keys (modo solo lectura / fallback).")

        # caches
        self._ticker_cache: Dict[str, Tuple[float, float]] = {}  # symbol -> (ts, price)
        self._klines_cache: Dict[Tuple[str, str, int], Tuple[float, Union[KlinesType, "pandas.DataFrame"]]] = {}
        self._symbols_cache: Tuple[float, List[str]] = (0.0, [])

        self.cache_ttl = float(cache_ttl)
        self.klines_ttl = float(klines_ttl)

        # naive throttling
        self._last_call_ts = 0.0
        self.cooldown = float(cooldown_between_calls)
        self._call_lock = threading.Lock()

    # -----------------------
    # ping (requests)
    # -----------------------
    def ping(self) -> Dict[str, Any]:
        """
        Simple ping to Binance REST API /api/v3/ping
        Returns dict: {"ok": True, "latency_ms": n} or {"ok": False, "error": "..."}
        """
        url = f"{self.base_url}/api/v3/ping"
        try:
            t0 = time.time()
            r = requests.get(url, timeout=5)
            latency = (time.time() - t0) * 1000.0
            if r.status_code == 200:
                return {"ok": True, "latency_ms": round(latency, 2)}
            return {"ok": False, "status": r.status_code, "response": r.text}
        except Exception as e:
            log.exception("ping failed: %s", e)
            return {"ok": False, "error": str(e)}

    # -----------------------
    # internal throttle / safe call
    # -----------------------
    def _throttle(self) -> None:
        with self._call_lock:
            now = time.time()
            diff = now - self._last_call_ts
            if diff < self.cooldown:
                time.sleep(self.cooldown - diff)
            self._last_call_ts = time.time()

    def _safe_call(self, fn, *args, **kwargs):
        """
        Call wrapper for client methods:
         - throttles calls
         - tries a client time sync on BinanceTimeSyncError
        Raises underlying exception so callers can catch/log.
        """
        try:
            self._throttle()
            if not self.client:
                raise RuntimeError("BinanceClient not available")
            return fn(*args, **kwargs)
        except BinanceTimeSyncError:
            log.warning("BinanceTimeSyncError detected, attempting client._sync_time()")
            try:
                if hasattr(self.client, "_sync_time"):
                    self.client._sync_time()
            except Exception:
                log.exception("client._sync_time() failed")
            # retry once
            return fn(*args, **kwargs)
        except Exception:
            # let caller handle exception; also log here
            log.exception("Safe call failed for %s", getattr(fn, "__name__", str(fn)))
            raise

    # -----------------------
    # ORDER EXECUTION HELPERS
    # -----------------------
    def market_sell(self, symbol: str, qty: float, reduce_only: bool = False):
        """
        Wrapper seguro para market sell
        """
        if not self.client:
            raise RuntimeError("BinanceClient no inicializado")

        if hasattr(self.client, "order_market_sell"):
            return self._safe_call(
                self.client.order_market_sell,
                symbol=symbol,
                quantity=qty
            )

        if hasattr(self.client, "market_sell"):
            return self._safe_call(self.client.market_sell, symbol, qty)

        raise RuntimeError("Cliente no soporta market sell")

    def market_buy(self, symbol: str, qty: float):
        """
        Wrapper seguro para market buy
        """
        if not self.client:
            raise RuntimeError("BinanceClient no inicializado")

        if hasattr(self.client, "order_market_buy"):
            return self._safe_call(
                self.client.order_market_buy,
                symbol=symbol,
                quantity=qty
            )

        if hasattr(self.client, "market_buy"):
            return self._safe_call(self.client.market_buy, symbol, qty)

        raise RuntimeError("Cliente no soporta market buy")


    # -----------------------
    # SYMBOLS / exchange info
    # -----------------------
    def get_symbols(self, refresh: bool = False) -> List[str]:
        """
        Returns normalized list of symbols (uppercase). Caches for short period.
        """
        now = time.time()
        ts, cached = self._symbols_cache
        if not refresh and cached and (now - ts) < max(self.cache_ttl, 10.0):
            return cached

        symbols: List[str] = []
        try:
            if self.client and hasattr(self.client, "get_exchange_info"):
                info = self._safe_call(self.client.get_exchange_info)
                symbols = [s["symbol"] for s in info.get("symbols", []) if "symbol" in s]
            elif self.client and hasattr(self.client, "get_all_tickers"):
                res = self._safe_call(self.client.get_all_tickers)
                if isinstance(res, list):
                    symbols = [r["symbol"] for r in res if isinstance(r, dict) and "symbol" in r]
            else:
                # Try public REST via requests as fallback to get symbol list from ticker endpoint
                try:
                    url = f"{self.base_url}/api/v3/ticker/price"
                    r = requests.get(url, timeout=5)
                    if r.status_code == 200:
                        data = r.json()
                        if isinstance(data, list):
                            symbols = [it.get("symbol") for it in data if "symbol" in it]
                except Exception:
                    log.debug("requests fallback for symbols failed", exc_info=True)
        except Exception:
            log.exception("get_symbols failed")

        if not symbols:
            symbols = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

        cleaned = sorted({str(s).upper() for s in symbols if s})
        self._symbols_cache = (time.time(), cleaned)
        return cleaned

    # alias expected by UI
    def get_all_symbols(self) -> List[str]:
        return self.get_symbols()

    # small helper
    def symbol_exists(self, symbol: str) -> bool:
        return str(symbol).upper() in self.get_symbols()

    # -----------------------
    # TICKER / price helpers
    # -----------------------
    def get_all_tickers(self) -> Optional[List[Dict[str, Any]]]:
        try:
            if self.client and hasattr(self.client, "get_all_tickers"):
                return self._safe_call(self.client.get_all_tickers)
            # fallback to REST
            r = requests.get(f"{self.base_url}/api/v3/ticker/price", timeout=5)
            if r.status_code == 200:
                return r.json()
        except Exception:
            log.exception("get_all_tickers failed")
        return None

    def get_symbol_ticker(self, symbol: str) -> Optional[Dict[str, Any]]:
        try:
            if self.client and hasattr(self.client, "get_symbol_ticker"):
                return self._safe_call(self.client.get_symbol_ticker, symbol)
            # fallback REST
            r = requests.get(f"{self.base_url}/api/v3/ticker/price", params={"symbol": symbol}, timeout=5)
            if r.status_code == 200:
                return r.json()
        except Exception:
            log.exception("get_symbol_ticker failed for %s", symbol)
        return None

    def get_price(self, symbol: str) -> Optional[float]:
        return self.get_ticker_price(symbol)

    def get_ticker_price(self, symbol: str, use_cache: bool = True) -> Optional[float]:
        """
        Returns float price or None.
        """
        s = str(symbol).upper()
        now = time.time()
        if use_cache:
            cached = self._ticker_cache.get(s)
            if cached and (now - cached[0]) < self.cache_ttl:
                return float(cached[1])

        try:
            t = self.get_symbol_ticker(s)
            if not t:
                return None
            # python-binance style dict or simple dict {'symbol':..., 'price': '123.45'}
            if isinstance(t, dict):
                price = t.get("price") or t.get("lastPrice") or t.get("close") or None
                if price is None:
                    # some clients return numeric directly
                    try:
                        return float(t)
                    except Exception:
                        return None
                price_f = float(price)
                self._ticker_cache[s] = (time.time(), price_f)
                return price_f
            # fallback: if t is string/number
            try:
                p = float(t)
                self._ticker_cache[s] = (time.time(), p)
                return p
            except Exception:
                return None
        except Exception:
            log.exception("get_ticker_price failed for %s", s)
            return None

    # -----------------------
    # KLINES (normalized)
    # -----------------------
    def get_klines(self, symbol: str, interval: str = "1m", limit: int = 500, use_cache: bool = True) -> Optional[Union[KlinesType, "pandas.DataFrame"]]:
        """
        Returns normalized klines as list[dict] (time,open,high,low,close,volume),
        or pandas.DataFrame if pandas is installed AND caller uses get_klines_df.
        """
        key = (str(symbol).upper(), str(interval), int(limit))
        now = time.time()
        if use_cache:
            cached = self._klines_cache.get(key)
            if cached and (now - cached[0]) < self.klines_ttl:
                return cached[1]

        raw = None
        try:
            # Prefer client method if present
            if self.client and hasattr(self.client, "get_klines"):
                raw = self._safe_call(self.client.get_klines, symbol=key[0], interval=interval, limit=limit)
            elif self.client and hasattr(self.client, "get_klines_agg"):
                raw = self._safe_call(self.client.get_klines_agg, symbol=key[0], interval=interval, limit=limit)
            else:
                # Try public REST (klines endpoint)
                url = f"{self.base_url}/api/v3/klines"
                params = {"symbol": key[0], "interval": interval, "limit": int(limit)}
                r = requests.get(url, params=params, timeout=10)
                if r.status_code == 200:
                    raw = r.json()
                else:
                    log.warning("REST klines returned status %s", r.status_code)
        except Exception:
            log.exception("get_klines failed for %s %s", symbol, interval)
            raw = None

        if raw is None:
            return None

        normalized = self._normalize_klines(raw)

        # cache normalized
        self._klines_cache[key] = (time.time(), normalized)
        return normalized

    def _normalize_klines(self, raw) -> KlinesType:
        """
        Normalize various kline formats into:
        [ {"time": <int|datetime>, "open":float, "high":float, "low":float, "close":float, "volume":float}, ... ]
        Supports:
         - python-binance list of lists
         - list of dicts with common keys
         - pandas.DataFrame
        """
        out: KlinesType = []

        # pandas DataFrame
        try:
            import pandas as pd  # type: ignore

            if isinstance(raw, pd.DataFrame):
                df = raw.copy()
                # normalize column names (case-insensitive)
                col_map = {c.lower(): c for c in df.columns}
                def getcol(n):
                    return df[col_map[n]] if n in col_map else None

                # attempt conversions
                for c in ("open", "high", "low", "close", "volume"):
                    if c in col_map:
                        df[c] = pd.to_numeric(getcol(c), errors="coerce")
                    elif c.capitalize() in df.columns:
                        df[c] = pd.to_numeric(df[c.capitalize()], errors="coerce")

                if "time" in col_map:
                    try:
                        df["time"] = pd.to_datetime(getcol("time"), unit="ms", errors="ignore")
                    except Exception:
                        df["time"] = pd.to_datetime(getcol("time"), errors="ignore")
                else:
                    try:
                        df.index = pd.to_datetime(df.index)
                        df["time"] = df.index
                    except Exception:
                        pass

                for _, row in df.iterrows():
                    out.append({
                        "time": row.get("time"),
                        "open": float(row.get("open") or 0.0),
                        "high": float(row.get("high") or 0.0),
                        "low": float(row.get("low") or 0.0),
                        "close": float(row.get("close") or 0.0),
                        "volume": float(row.get("volume") or 0.0),
                    })
                return out
        except Exception:
            # pandas not available or not a DataFrame
            pass

        # python-binance style: list of lists
        if isinstance(raw, list) and raw and isinstance(raw[0], (list, tuple)):
            for item in raw:
                try:
                    ts = item[0]
                    o = float(item[1])
                    h = float(item[2])
                    l = float(item[3])
                    c = float(item[4])
                    v = float(item[5])
                    out.append({"time": ts, "open": o, "high": h, "low": l, "close": c, "volume": v})
                except Exception:
                    continue
            return out

        # list of dicts (common API shapes)
        if isinstance(raw, list) and raw and isinstance(raw[0], dict):
            for d in raw:
                try:
                    t = d.get("time") or d.get("open_time") or d.get("timestamp") or d.get("t")
                    o = d.get("open") or d.get("o")
                    h = d.get("high") or d.get("h")
                    l = d.get("low") or d.get("l")
                    c = d.get("close") or d.get("c")
                    v = d.get("volume") or d.get("v") or d.get("q") or 0.0
                    out.append({
                        "time": t,
                        "open": float(o or 0.0),
                        "high": float(h or 0.0),
                        "low": float(l or 0.0),
                        "close": float(c or 0.0),
                        "volume": float(v or 0.0)
                    })
                except Exception:
                    continue
            return out

        # otherwise return empty list
        return out

    # -----------------------
    # BALANCE helpers
    # -----------------------
    def get_balance(self, asset: str = "USDT") -> Optional[float]:
        """
        Generic balance accessor (float free amount) – keeps backward compatibility.
        """
        try:
            # 1) client.get_asset_balance
            if self.client and hasattr(self.client, "get_asset_balance"):
                bal = self._safe_call(self.client.get_asset_balance, asset)
                if isinstance(bal, dict):
                    free = bal.get("free") or bal.get("balance") or 0.0
                    try:
                        return float(free)
                    except Exception:
                        return None
                if isinstance(bal, (int, float, str)):
                    try:
                        return float(bal)
                    except Exception:
                        return None

            # 2) client.get_account -> balances list
            if self.client and hasattr(self.client, "get_account"):
                acc = self._safe_call(self.client.get_account)
                if acc and isinstance(acc, dict):
                    for b in acc.get("balances", []) or []:
                        if b.get("asset") == asset:
                            try:
                                return float(b.get("free") or 0.0)
                            except Exception:
                                return None

            # 3) fallback: no client -> None
            log.debug("get_balance fallback: client not available or methods missing")
            return None
        except Exception:
            log.exception("get_balance failed")
            return None

    def get_spot_balance(self, asset: str = "USDT") -> Optional[float]:
        """
        Returns the free spot balance (float) for compatibility with cached_get_balance usage.
        """
        try:
            # Try get_asset_balance or get_account logic
            b = self.get_balance(asset)
            return float(b) if b is not None else None
        except Exception:
            log.exception("get_spot_balance failed")
            return None

    def get_spot_balance_full(self, asset: str = "USDT") -> Dict[str, Any]:
        """
        Returns dict with detailed balances: {"ok": True, "free": ..., "locked": ..., "total": ...}
        Use this if you need full info.
        """
        try:
            if not self.client:
                return {"ok": False, "error": "client not initialized"}

            if hasattr(self.client, "get_account"):
                acc = self._safe_call(self.client.get_account)
                for b in acc.get("balances", []) or []:
                    if b.get("asset") == asset:
                        free = float(b.get("free") or 0.0)
                        locked = float(b.get("locked") or 0.0)
                        return {"ok": True, "asset": asset, "free": free, "locked": locked, "total": free + locked}
            # fallback to get_asset_balance
            if hasattr(self.client, "get_asset_balance"):
                bal = self._safe_call(self.client.get_asset_balance, asset)
                if isinstance(bal, dict):
                    free = float(bal.get("free") or bal.get("balance") or 0.0)
                    locked = float(bal.get("locked") or 0.0)
                    return {"ok": True, "asset": asset, "free": free, "locked": locked, "total": free + locked}

            return {"ok": False, "error": "no balance info"}
        except Exception as e:
            log.exception("get_spot_balance_full failed")
            return {"ok": False, "error": str(e)}

    # -----------------------
    # Async wrappers (run blocking methods in executor)
    # -----------------------
    async def get_klines_async(self, symbol: str, interval: str = "1m", limit: int = 500, use_cache: bool = True):
        import asyncio

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.get_klines(symbol, interval, limit, use_cache))

    async def get_symbol_ticker_async(self, symbol: str):
        import asyncio

        loop = asyncio.get_event_loop()

        def _call():
            try:
                return self.get_symbol_ticker(symbol)
            except Exception:
                return None

        return await loop.run_in_executor(None, _call)


# -----------------------
# singleton convenience
# -----------------------
_manager_singleton: Optional[BinanceManager] = None


def get_binance_manager(api_key: str = "", api_secret: str = "", **kwargs) -> BinanceManager:
    global _manager_singleton
    if _manager_singleton is None:
        _manager_singleton = BinanceManager(api_key=api_key, api_secret=api_secret, **kwargs)
    return _manager_singleton
