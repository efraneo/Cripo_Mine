# backend/trading_engine.py

import logging

from core.portfolio.hedge_fund_engine import HedgeFundEngine
from core.risk.hedge_fund_controller import HedgeFundController

from backend.trade_manager import TradeManager
from backend.equity_tracker import EquityTracker
from backend.circuit_breaker import CircuitBreaker
from backend.global_risk_controller import GlobalRiskController
from backend.security_engine import SecurityEngine

from backend.binance_manager import BinanceManager
from backend.risk_manager import RiskManager
from backend.order_manager import OrderManager

from core.execution.execution_engine import ExecutionEngine
from core.broker.binance_broker import BinanceBroker

from core.market_scanner import MarketScanner
from core.portfolio_engine import PortfolioEngine
from core.portfolio.multi_asset_engine import MultiAssetEngine

from core.ia_pro_orchestrator import compute_ia_pro_decision

from core.risk.risk_engine import (
    dynamic_risk,
    detect_session
)

# MIXINS
from backend.engine.engine_market import MarketMixin
from backend.engine.engine_execution import ExecutionMixin
from backend.engine.engine_monitor import MonitorMixin
from backend.engine.engine_history import HistoryMixin
from backend.engine.engine_multi_asset import MultiAssetMixin
from backend.engine.engine_backtesting import BacktestingMixin
from backend.engine.engine_context import ContextMixin
from backend.engine.engine_cycle import CycleMixin

# AUTO TRADER REAL
from core.trading.auto_trader import AutoTrader

log = logging.getLogger("trading_engine")


class TradingEngine(
    MarketMixin,
    ExecutionMixin,
    MonitorMixin,
    HistoryMixin,
    MultiAssetMixin,
    BacktestingMixin,
    ContextMixin,
    CycleMixin
):

    def __init__(
        self,
        binance: BinanceManager,
        order_manager: OrderManager,
        risk_manager: RiskManager,
        predictor=None,
        feature_builder=None,
        mode: str = "DEMO",
    ):

        self.log = log

        self.binance = binance
        self.order_manager = order_manager
        self.risk = risk_manager

        self.mode = mode.upper()

        self.predictor = predictor
        self.feature_builder = feature_builder

        self.trade_manager = TradeManager()

        self.equity_tracker = EquityTracker()

        self.circuit_breaker = CircuitBreaker()

        self.global_risk = GlobalRiskController()

        # ======================================
        # BROKER
        # ======================================
        self.broker = BinanceBroker()

        # ======================================
        # EXECUTION ENGINE
        # ======================================
        self.execution_engine = ExecutionEngine(
            self.broker
        )

        # ======================================
        # SECURITY ENGINE
        # ======================================
        self.security_engine = SecurityEngine()

        # ======================================
        # SCANNER
        # ======================================
        self.scanner = MarketScanner(
            self,
            compute_ia_pro_decision
        )

        # ======================================
        # PORTFOLIO
        # ======================================

        self.portfolio = PortfolioEngine(self)

        self.multi_asset_engine = MultiAssetEngine(
            self
        )

        # ======================================
        # HEDGE FUND ENGINE
        # ======================================

        self.hedge_engine = HedgeFundEngine(
            self
        )

        self.hedge_controller = HedgeFundController()

        # ======================================
        # AUTO TRADER
        # ======================================

        self.auto_trader = AutoTrader(
            self
        )

        self.force_ia_pro = True

        # ======================================
        # CONTEXTO INSTITUCIONAL
        # ======================================

        self.market_context = self.get_market_context()

        # ======
        self.log.info(
            "TradingEngine inicializado",
            extra={
                "mode": self.mode
            }
        )
