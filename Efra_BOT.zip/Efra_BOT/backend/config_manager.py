"""
config_manager.py — Configuración PRO (2025)
-------------------------------------------
✔ Carga automática desde .env o environment_manager.py
✔ Fallback seguro con valores mínimos
✔ Perfiles: DEV / PROD
✔ Recarga dinámica sin reinicio del BOT
✔ Modo seguro: valida API keys, riesgos y parámetros
✔ Persistencia interna + Cache
"""

import os
import json
import time
from typing import Dict, Any, Optional
from pathlib import Path

from backend.environment_manager import EnvironmentManager
from backend.log_manager import get_logger

log = get_logger("config_manager")


class InvalidConfig(Exception):
    pass


class ConfigManager:
    """
    PRO CONFIG MANAGER 2025
    ------------------------
    - Provee acceso global seguro
    - Sincroniza con environment_manager.py
    - Permite actualización dinámica desde Streamlit
    """

    CONFIG_FILE = Path("config_runtime.json")
    CACHE_TTL = 5  # segundos

    def __init__(self):
        self.env = EnvironmentManager()
        self._cache_expire = 0
        self._cache: Dict[str, Any] = {}
        self._loaded_runtime = False

        # Cargar env + runtime config
        self._load()

    # -----------------------------------------------------------
    #  CARGA PRINCIPAL
    # -----------------------------------------------------------

    def _load(self):
        base = self._load_env_defaults()

        runtime = self._load_runtime_file()

        # Fusionar (runtime tiene prioridad)
        base.update(runtime)

        # Validar resultado final
        self._validate(base)

        self._cache = base
        self._cache_expire = time.time() + self.CACHE_TTL

        log.info("✔ Configuración cargada correctamente.")

    # -----------------------------------------------------------
    #  CARGA DE VARIABLES ENV .env O SISTEMA
    # -----------------------------------------------------------

    def _load_env_defaults(self) -> Dict[str, Any]:
        """
        Usa environment_manager.py para obtener las claves
        y aplica defaults PRO.
        """

        return {
            # -------------------------------------------------
            # Binance
            # -------------------------------------------------
            "BINANCE_API_KEY": self.env.get("BINANCE_API_KEY", required=True),
            "BINANCE_API_SECRET": self.env.get("BINANCE_API_SECRET", required=True),
            "BINANCE_BASE_URL": self.env.get("BINANCE_BASE_URL", "https://api.binance.com"),

            # -------------------------------------------------
            # Telegram
            # -------------------------------------------------
            "TELEGRAM_TOKEN": self.env.get("TELEGRAM_TOKEN", required=True),
            "TELEGRAM_CHAT_ID": self.env.get("TELEGRAM_CHAT_ID", required=True),

            # -------------------------------------------------
            # Risk Manager
            # -------------------------------------------------
            "DEFAULT_STOP_LOSS_PERCENT": float(self.env.get("DEFAULT_STOP_LOSS_PERCENT", 2.0)),
            "MAX_RISK_USD": float(self.env.get("MAX_RISK_USD", 200)),
            "DCA_SEGMENTS": int(self.env.get("DCA_SEGMENTS", 3)),

            # -------------------------------------------------
            # IA & Features
            # -------------------------------------------------
            "IA_MODEL_PATH": self.env.get("IA_MODEL_PATH", "models/model_pro.bin"),
            "FEATURE_COUNT": int(self.env.get("FEATURE_COUNT", 150)),

            # -------------------------------------------------
            # Perfil
            # -------------------------------------------------
            "MODE": self.env.get("ENV_MODE", "PROD").upper(),
        }

    # -----------------------------------------------------------
    #  ARCHIVO RUNTIME (CONFIGURACIÓN MODIFICADA EN TIEMPO REAL)
    # -----------------------------------------------------------

    def _load_runtime_file(self) -> Dict[str, Any]:
        if not self.CONFIG_FILE.exists():
            return {}

        try:
            with open(self.CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._loaded_runtime = True
                return data
        except Exception as e:
            log.error(f"❌ Error leyendo config_runtime.json: {e}")
            return {}

    # -----------------------------------------------------------
    #  VALIDACIÓN PROFESIONAL
    # -----------------------------------------------------------

    def _validate(self, cfg: Dict[str, Any]):
        if not cfg["BINANCE_API_KEY"] or not cfg["BINANCE_API_SECRET"]:
            raise InvalidConfig("API Key de Binance faltante.")

        if cfg["DEFAULT_STOP_LOSS_PERCENT"] < 0.5 or cfg["DEFAULT_STOP_LOSS_PERCENT"] > 10:
            raise InvalidConfig("Stop Loss fuera de rango permitido (0.5%–10%).")

        if cfg["FEATURE_COUNT"] < 50:
            raise InvalidConfig("FEATURE_COUNT mínimo es 50.")

        if cfg["MODE"] not in ["DEV", "PROD"]:
            raise InvalidConfig("ENV_MODE debe ser DEV o PROD.")

        # Config segura validada
        return True

    # -----------------------------------------------------------
    #  ACCESO PÚBLICO (CON CACHE)
    # -----------------------------------------------------------

    def get(self, key: str, default=None):
        if time.time() > self._cache_expire:
            self._load()

        return self._cache.get(key, default)

    def all(self) -> Dict[str, Any]:
        if time.time() > self._cache_expire:
            self._load()
        return dict(self._cache)

    # -----------------------------------------------------------
    #  ACTUALIZACIÓN DINÁMICA PRO (Streamlit)
    # -----------------------------------------------------------

    def update(self, new_values: Dict[str, Any]):
        """
        Streamlit puede usar esto para actualizar config en vivo.
        """

        # Fusionar valores sobre el cache actual
        merged = {**self._cache, **new_values}

        # Validar antes de grabar
        self._validate(merged)

        # Actualizar archivo runtime
        try:
            with open(self.CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(merged, f, indent=4, ensure_ascii=False)
        except Exception as e:
            log.error(f"❌ Error guardando config_runtime.json: {e}")
            raise

        # Actualizar memoria
        self._cache = merged
        self._cache_expire = time.time() + self.CACHE_TTL

        log.info("✔ Config actualizado dinámicamente.")

    # -----------------------------------------------------------
    #  INDICADORES DE PERFIL
    # -----------------------------------------------------------

    def is_dev(self) -> bool:
        return self.get("MODE") == "DEV"

    def is_prod(self) -> bool:
        return self.get("MODE") == "PROD"

