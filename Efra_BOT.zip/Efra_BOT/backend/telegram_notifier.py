# ================================================================
# backend/telegram_notifier.py — Telegram PRO (2025)
# ================================================================

import requests
from backend.notifier_core import BaseNotifier
from backend.notifier_core import DEFAULT_NOTIFIER

# funciones legacy que ya usas
# from backend.notifier_core import DEFAULT_NOTIFIER as _MUX


class TelegramNotifier(BaseNotifier):
    channel_name = "telegram"

    def __init__(self, env):
        super().__init__(enabled=True)
        self.chat_id = env.get("TELEGRAM_CHAT_ID")
        self.bot_token = env.get("TELEGRAM_BOT_TOKEN")

        if not self.chat_id or not self.bot_token:
            self.enabled = False

    # 🔑 MÉTODO CLAVE PARA notifier_core
    def send_message_impl(self, message: str, **kwargs) -> bool:
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": message,
                "parse_mode": kwargs.get("parse_mode"),
            }
            r = requests.post(url, json=payload, timeout=10)
            return r.status_code == 200
        except Exception:
            return False

    # ------------------------------------------------------------
    # Métodos legacy (NO romper)
    # ------------------------------------------------------------
    def ping(self, txt: str):
        return send(txt)

    def markdown(self, txt: str):
        return send_markdown(txt)

    def send_error(self, err):
        return send_error(str(err))

    # ------------------------------------------------------------
    # Métodos PRO semánticos
    # ------------------------------------------------------------
    def notify_operation(self, symbol, side, amount, price, mode):
        msg = (
            f"🟢 *Operación ejecutada*\n"
            f"• Símbolo: `{symbol}`\n"
            f"• Lado: *{side}*\n"
            f"• Monto: `{amount}`\n"
            f"• Precio: `{price}`\n"
            f"• Modo: `{mode}`"
        )
        return self.send_message(msg, parse_mode="Markdown")


# ================================================================
# Registro automático en el MUX
# ================================================================
from backend.notifier_core import DEFAULT_NOTIFIER

def register_telegram_notifier(env):
    """
    Registra el canal de Telegram en el multiplexor central.
    """
    token = env.get("TELEGRAM_BOT_TOKEN")
    chat_id = env.get("TELEGRAM_CHAT_ID")

    if not token or not chat_id:
        raise ValueError("Faltan credenciales de Telegram")

    def send(msg: str):
        return send_telegram_message(msg)

    DEFAULT_NOTIFIER.register("telegram", send)

# ================================================================
# WRAPPERS FUNCIONALES (compatibilidad legacy / seguridad)
# ================================================================

from backend.notifier_core import DEFAULT_NOTIFIER


import requests

def send_telegram_message(message: str):
    import os

    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message
    }
    return requests.post(url, json=payload)

def notify_security_event(
    event: str,
    username: str = "unknown",
    ip: str = "N/A",
    extra: str = ""
) -> bool:
    """
    Notificación PRO de eventos de seguridad.
    """
    msg = (
        "🚨 *Evento de Seguridad Detectado*\n"
        f"• Evento: `{event}`\n"
        f"• Usuario: `{username}`\n"
        f"• IP: `{ip}`\n"
        f"• Extra: `{extra}`"
    )

    try:
        return DEFAULT_NOTIFIER.broadcast(msg)
    except Exception:
        return False
