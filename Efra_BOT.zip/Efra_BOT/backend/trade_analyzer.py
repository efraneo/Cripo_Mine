# backend/trade_analyzer.py
"""
TradeAnalyzer PRO (2025)
------------------------
Funciones y clase central para:
 - Generación de señales técnicas (multiescala)
 - Integración con IAPredictor (ensemble)
 - Backtesting sencillo por ventana
 - Resumen y métricas (precision/recall, pnl estimado)
 - Detección de patrones (breakout, pullback, divergence)
 - Interfaz limpia para TradingEngine / BotManager

Diseñado para integrarse con:
 - utils.feature_builder_pro.build_feature_set(df)
 - backend.ia_predictor.IAPredictor
 - backend.log_manager.get_logger
"""

from __future__ import annotations

import time
import math
import json
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass, asdict

import numpy as np
import pandas as pd

# logging
try:
    from backend.log_manager import get_logger
    log = get_logger("trade_analyzer")
except Exception:
    import logging
    log = logging.getLogger("trade_analyzer")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)

# optional imports
try:
    from backend.ia_predictor import IAPredictor
except Exception:
    IAPredictor = None

try:
    from utils.feature_builder_pro import build_feature_set as build_feature_set_pro
except Exception:
    build_feature_set_pro = None

# -------------------------
# Data classes
# -------------------------
@dataclass
class Signal:
    ts: str
    symbol: str
    signal: str  # "BUY" / "SELL" / "HOLD"
    confidence: float
    price: float
    reason: str
    meta: Dict[str, Any]

    def to_dict(self):
        return asdict(self)

# -------------------------
# Helpers
# -------------------------
def _safe_float(x, default=0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default

def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

# -------------------------
# Technical primitives
# -------------------------
def rolling_zscore(series: pd.Series, window: int = 20) -> pd.Series:
    return (series - series.rolling(window).mean()) / (series.rolling(window).std().replace(0, np.nan))

def sma(series: pd.Series, window: int) -> pd.Series:
    return series.rolling(window).mean()

def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high_low = df["high"] - df["low"]
    high_close = (df["high"] - df["close"].shift()).abs()
    low_close = (df["low"] - df["close"].shift()).abs()
    tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
    return tr.rolling(period, min_periods=1).mean()

# -------------------------
# Pattern detectors
# -------------------------
def detect_pullback(df: pd.DataFrame, lookback: int = 5, thresh_pct: float = 0.02) -> pd.Series:
    """
    Devuelve boolean series indicando pullback en las últimas 'lookback' velas
    comparando diferencia relativa con el precio.
    """
    cs = df["close"]
    pb = cs.pct_change(periods=lookback)
    return (pb <= -abs(thresh_pct))

def detect_breakout(df: pd.DataFrame, window: int = 20) -> pd.Series:
    """
    Breakout si close supera el max de high en 'window' (excluyendo la vela actual).
    """
    highs = df["high"].rolling(window, min_periods=1).max().shift(1)
    return df["close"] > highs

def detect_divergence(df: pd.DataFrame, rsi_window: int = 14) -> pd.Series:
    """
    Señala divergencia simple RSI vs precio: precio hace nuevos mínimos y RSI no.
    Retorna serie booleana.
    """
    rsi = None
    try:
        delta = df["close"].diff()
        up = delta.clip(lower=0)
        down = (-delta).clip(lower=0)
        ma_up = up.rolling(rsi_window).mean()
        ma_down = down.rolling(rsi_window).mean()
        rs = ma_up / (ma_down.replace(0, 1e-9))
        rsi = 100 - (100 / (1 + rs))
    except Exception:
        rsi = pd.Series([50] * len(df))
    # new lows in price (compared to prior window) but RSI not making new lows
    low_look = df["low"].rolling(10, min_periods=1).min().shift(1)
    price_new_low = df["low"] < low_look
    rsi_low_look = rsi.rolling(10, min_periods=1).min().shift(1)
    rsi_not_new_low = rsi > rsi_low_look
    return price_new_low & rsi_not_new_low

# -------------------------
# TradeAnalyzer core
# -------------------------
class TradeAnalyzer:
    """
    Clase principal que expone:
     - generate_signals(df, symbol)
     - score_signal(sample)
     - backtest_signals(df, signals)
     - summarize_signals(signals)
    """

    def __init__(self, ia_predictor: Optional[IAPredictor] = None, feature_builder=build_feature_set_pro):
        self.ia = ia_predictor or (IAPredictor() if IAPredictor else None)
        self.feature_builder = feature_builder
        log.info("TradeAnalyzer inicializado (IA=%s, feature_builder=%s)", bool(self.ia), bool(self.feature_builder))

    # -------------------------
    # Build sample for IA from last row + computed indicators
    # -------------------------
    def _build_sample_from_df(self, df: pd.DataFrame) -> Dict[str, Any]:
        last = df.iloc[-1]
        indicators = {}
        try:
            indicators["ema_fast"] = float(df["close"].ewm(span=12, adjust=False).mean().iloc[-1])
            indicators["ema_slow"] = float(df["close"].ewm(span=26, adjust=False).mean().iloc[-1])
            indicators["rsi"] = float(((df["close"].diff().clip(lower=0).rolling(14).mean()) /
                                       (df["close"].diff().abs().rolling(14).mean()).replace(0, 1e-9) * 100).iloc[-1])
            indicators["atr"] = float(atr(df).iloc[-1])
        except Exception:
            indicators["ema_fast"] = indicators["ema_slow"] = indicators["rsi"] = indicators["atr"] = 0.0

        sample = {
            "open": _safe_float(last.get("open")),
            "high": _safe_float(last.get("high")),
            "low": _safe_float(last.get("low")),
            "close": _safe_float(last.get("close")),
            "volume": _safe_float(last.get("volume")),
            **indicators
        }

        # Expand using feature_builder if available (best-effort)
        try:
            if self.feature_builder and isinstance(df, pd.DataFrame):
                full = self.feature_builder(df.copy())
                if not full.empty:
                    latest = full.iloc[-1].to_dict()
                    # merge without overwriting base
                    for k, v in latest.items():
                        if k not in sample:
                            try:
                                sample[k] = float(v)
                            except Exception:
                                sample[k] = v
        except Exception:
            log.debug("feature_builder expansion failed")

        return sample

    # -------------------------
    # Generate signals from dataframe
    # -------------------------
    def generate_signals(self, df: pd.DataFrame, symbol: str, min_confidence: float = 0.70) -> List[Signal]:
        """
        Escanea el dataframe y emite señales puntuales (última vela).
        Estrategia:
          - Detecta breakout / pullback / divergence
          - Consulta IAPredictor -> probabilidad
          - Empaqueta Signal con razón y metadata
        """
        out: List[Signal] = []
        try:
            if df is None or df.empty:
                return out

            # compute quick indicators
            pb = detect_pullback(df)
            bo = detect_breakout(df)
            div = detect_divergence(df)

            sample = self._build_sample_from_df(df)
            price = sample.get("close", 0.0)

            # IA confidence (if available)
            if self.ia:
                try:
                    prob = float(self.ia.predict_proba(sample))
                except Exception as e:
                    log.debug("IA predict_proba error: %s", e)
                    prob = 0.5
            else:
                # fallback heuristic
                prob = 0.5
                if sample.get("ema_fast", 0) > sample.get("ema_slow", 0):
                    prob += 0.12
                if sample.get("rsi", 50) < 40:
                    prob += 0.06
                prob = max(0.01, min(0.99, prob))

            # Reasoning rules
            reason_parts = []
            if bo.iloc[-1]:
                reason_parts.append("breakout")
            if pb.iloc[-1]:
                reason_parts.append("pullback")
            if div.iloc[-1]:
                reason_parts.append("divergence")

            # Default action
            action = "HOLD"
            if prob >= min_confidence and ("breakout" in reason_parts or "divergence" in reason_parts):
                action = "BUY"
            elif prob <= (1.0 - min_confidence):
                action = "SELL"
            elif "pullback" in reason_parts and prob >= 0.55:
                action = "BUY"

            sig = Signal(
                ts=_now_iso(),
                symbol=symbol,
                signal=action,
                confidence=float(prob),
                price=float(price),
                reason=",".join(reason_parts) or "heuristic",
                meta={
                    "features_sample": {k: sample.get(k) for k in ["ema_fast","ema_slow","rsi","atr"] if k in sample},
                    "raw_reasons": reason_parts
                }
            )
            out.append(sig)
            return out
        except Exception as e:
            log.exception("generate_signals error: %s", e)
            return out

    # -------------------------
    # Score a single sample (exposed)
    # -------------------------
    def score_sample(self, sample: Dict[str, Any]) -> float:
        """
        Devuelve probabilidad 0..1 usando IA o heurística.
        """
        try:
            if self.ia:
                return float(self.ia.predict_proba(sample))
        except Exception as e:
            log.debug("IA score_sample failed: %s", e)

        # fallback heuristic
        score = 0.5
        if sample.get("ema_fast", 0) > sample.get("ema_slow", 0):
            score += 0.12
        if sample.get("rsi", 50) < 40:
            score += 0.06
        return float(max(0.0, min(1.0, score)))

    # -------------------------
    # Backtest simple PRO (walk-forward extendido)
    # -------------------------
    def backtest_signals(
        self,
        df: pd.DataFrame,
        signals: List[Signal],
        tp_pct: float = 0.02,
        sl_pct: float = 0.02,
        fee_pct: float = 0.0004  # fee aproximado por operación
    ) -> Dict[str, Any]:
        """
        Backtest PRO:
        - Usa próxima vela como entry
        - TP/SL porcentual
        - Fee maker/taker (fee_pct)
        - Equity curve
        - Sharpe Ratio
        - Max Drawdown
        - Resultados detallados
        """
        results = []
        wins = 0
        losses = 0
        total_pnl = 0.0
        equity = [1.0]  # curva de equity inicial

        try:
            for s in signals:
                if s.signal != "BUY":
                    continue

                # -------------------------------------------
                # Localización PRO del índice por timestamp
                # -------------------------------------------
                try:
                    # Buscar filas cuyo timestamp contenga la fecha de la señal
                    idx = df.index[df["time"].astype(str).str.contains(s.ts[:10])].tolist()
                    if idx:
                        i = idx[-1] + 1
                    else:
                        i = len(df) - 1
                except Exception:
                    i = len(df) - 1

                if i >= len(df):
                    continue

                # -------------------------------------------
                # Entry, TP, SL y Fees
                # -------------------------------------------
                entry_price = float(df["close"].iloc[i])
                tp = entry_price * (1 + tp_pct)
                sl = entry_price * (1 - sl_pct)
                fee_cost = entry_price * fee_pct

                # -------------------------------------------
                # Simulación de salida (horizonte 10 velas)
                # -------------------------------------------
                exit_price = entry_price
                hit = "none"
                for j in range(i, min(len(df), i + 10)):
                    high = float(df["high"].iloc[j])
                    low = float(df["low"].iloc[j])

                    if high >= tp:
                        exit_price = tp
                        hit = "tp"
                        break
                    if low <= sl:
                        exit_price = sl
                        hit = "sl"
                        break

                # -------------------------------------------
                # PnL considerando fee
                # -------------------------------------------
                pnl = (exit_price - entry_price) - fee_cost
                total_pnl += pnl

                if pnl > 0:
                    wins += 1
                else:
                    losses += 1

                equity.append(equity[-1] + pnl)

                # -------------------------------------------
                # Registro completo de la operación
                # -------------------------------------------
                results.append({
                    "signal": s.to_dict(),
                    "entry_price": entry_price,
                    "exit_price": exit_price,
                    "pnl": pnl,
                    "hit": hit,
                    "fee": fee_cost
                })

            # -------------------------------------------
            # Métricas finales
            # -------------------------------------------
            trades = len(results)
            win_rate = (wins / trades) if trades else 0.0
            avg_pnl = (total_pnl / trades) if trades else 0.0

            # Sharpe Ratio
            try:
                pnl_series = pd.Series([r["pnl"] for r in results])
                sharpe = (
                    pnl_series.mean() / (pnl_series.std() + 1e-9)
                    if trades > 1 else 0.0
                )
            except Exception:
                sharpe = 0.0

            # Max Drawdown
            try:
                equity_series = pd.Series(equity)
                peak = equity_series.cummax()
                dd = equity_series - peak
                max_dd = float(dd.min())
            except Exception:
                max_dd = 0.0

            summary = {
                "trades": trades,
                "wins": wins,
                "losses": losses,
                "win_rate": win_rate,
                "total_pnl": total_pnl,
                "avg_pnl": avg_pnl,
                "sharpe_ratio": float(sharpe),
                "max_drawdown": max_dd,
                "equity_curve": equity,
                "results": results
            }
            return summary

        except Exception as e:
            log.exception("backtest_signals error: %s", e)
            return {"error": str(e)}

    # -------------------------
    # Summaries / diagnostics
    # -------------------------
    def summarize_signals(self, signals: List[Signal]) -> Dict[str, Any]:
        try:
            total = len(signals)
            by_type = {}
            for s in signals:
                by_type.setdefault(s.signal, 0)
                by_type[s.signal] += 1
            avg_conf = float(np.mean([s.confidence for s in signals])) if signals else 0.0
            return {"total": total, "by_type": by_type, "avg_confidence": avg_conf}
        except Exception as e:
            log.exception("summarize_signals error: %s", e)
            return {"error": str(e)}

    # -------------------------
    # Utilities
    # -------------------------
    def detect_opportunities_bulk(self, df_dict: Dict[str, pd.DataFrame], min_confidence: float = 0.7) -> Dict[str, Any]:
        """
        Acepta dict symbol -> df, retorna map symbol -> signals (list)
        """
        out = {}
        for sym, df in df_dict.items():
            try:
                out[sym] = [s.to_dict() for s in self.generate_signals(df, sym, min_confidence=min_confidence)]
            except Exception:
                out[sym] = []
        return out

# -------------------------
# Module-level helper: simple signal emitter
# -------------------------
def emit_signal_for_symbol(df: pd.DataFrame, symbol: str, ia_predictor: Optional[IAPredictor] = None) -> Optional[Dict[str, Any]]:
    analyzer = TradeAnalyzer(ia_predictor=ia_predictor)
    sigs = analyzer.generate_signals(df, symbol)
    if not sigs:
        return None
    return sigs[0].to_dict()

# -------------------------
# If executed as script -> demo
# -------------------------
if __name__ == "__main__":
    log.info("TradeAnalyzer demo: cargar sample.csv si existe")
    try:
        df = pd.read_csv("sample_klines.csv")
        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"])
        ta = TradeAnalyzer()
        sigs = ta.generate_signals(df, "SAMPLE")
        print("Signals:", [s.to_dict() for s in sigs])
    except Exception as e:
        log.error("Demo failed: %s", e)
