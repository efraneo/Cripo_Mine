# backend/mailer.py
"""
Mailer PRO
- Primary: SMTP (TLS) with username/password (app password recommended)
- Optional: Gmail OAuth2 via refresh token (auto-refresh + XOAUTH2)
- send_mail(...) usage for 2FA, password reset, alerts, etc.
"""

from __future__ import annotations
import os
import smtplib
import ssl
import time
import base64
import json
from typing import Optional, List, Dict, Any
from email.message import EmailMessage
from email.utils import formataddr
import requests

# optional structured logger from your project
try:
    from backend.log_manager import get_logger
    log = get_logger("mailer")
except Exception:
    import logging
    log = logging.getLogger("mailer")
    if not log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s mailer: %(message)s"))
        log.addHandler(h)
    log.setLevel(logging.INFO)

# Environment config (use your .env)
SMTP_HOST = os.getenv("SERVIDOR_SMTP", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("PUERTO_SMTP", "587"))
SMTP_USER = os.getenv("CORREO_ORIGEN")
SMTP_PASS = os.getenv("CLAVE_CORREO")  # app password recommended

# Optional Gmail OAuth2 (if provided, used in priority over plain SMTP auth)
GMAIL_OAUTH2_CLIENT_ID = os.getenv("GMAIL_OAUTH2_CLIENT_ID")
GMAIL_OAUTH2_CLIENT_SECRET = os.getenv("GMAIL_OAUTH2_CLIENT_SECRET")
GMAIL_OAUTH2_REFRESH_TOKEN = os.getenv("GMAIL_OAUTH2_REFRESH_TOKEN")

# Token endpoint
GOOGLE_OAUTH2_TOKEN_URL = "https://oauth2.googleapis.com/token"


def _get_access_token_from_refresh_token() -> Optional[str]:
    """Exchange refresh token for access token (Google)."""
    if not (GMAIL_OAUTH2_CLIENT_ID and GMAIL_OAUTH2_CLIENT_SECRET and GMAIL_OAUTH2_REFRESH_TOKEN):
        return None
    try:
        data = {
            "client_id": GMAIL_OAUTH2_CLIENT_ID,
            "client_secret": GMAIL_OAUTH2_CLIENT_SECRET,
            "refresh_token": GMAIL_OAUTH2_REFRESH_TOKEN,
            "grant_type": "refresh_token",
        }
        r = requests.post(GOOGLE_OAUTH2_TOKEN_URL, data=data, timeout=10)
        r.raise_for_status()
        payload = r.json()
        access_token = payload.get("access_token")
        if not access_token:
            log.error("OAuth2 token response missing access_token: %s", payload)
            return None
        return access_token
    except Exception as e:
        log.exception("Error fetching access token from refresh token: %s", e)
        return None


def _smtp_auth_xoauth2(smtp: smtplib.SMTP, user: str, access_token: str) -> bool:
    """
    Perform AUTH XOAUTH2 (smtp -> 'AUTH XOAUTH2 <base64(...)>')
    Returns True if server accepts, False otherwise.
    """
    try:
        auth_string = f"user={user}\x01auth=Bearer {access_token}\x01\x01"
        auth_b64 = base64.b64encode(auth_string.encode("utf-8")).decode("utf-8")
        # Send AUTH XOAUTH2 command
        code, resp = smtp.docmd("AUTH", "XOAUTH2 " + auth_b64)
        # success codes are 235
        if 200 <= code < 400:
            # many servers require 235 specifically
            return code in (235, 250)
        return False
    except Exception as e:
        log.debug("XOAUTH2 auth failed: %s", e)
        return False


def _connect_and_send(msg: EmailMessage, to_addrs: List[str], retries: int = 2, timeout: int = 10) -> Dict[str, Any]:
    """
    Tries OAuth2 SMTP first (if configured), then falls back to LOGIN with user/pass.
    """
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            context = ssl.create_default_context()
            smtp = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=timeout)
            smtp.ehlo()
            if SMTP_PORT in (587, 25):
                smtp.starttls(context=context)
                smtp.ehlo()

            # Try OAuth2 if available
            if GMAIL_OAUTH2_REFRESH_TOKEN:
                access_token = _get_access_token_from_refresh_token()
                if access_token:
                    try:
                        ok = _smtp_auth_xoauth2(smtp, SMTP_USER, access_token)
                        if ok:
                            smtp.send_message(msg, from_addr=msg["From"], to_addrs=to_addrs)
                            smtp.quit()
                            return {"ok": True}
                        else:
                            log.info("XOAUTH2 attempt failed; will try LOGIN fallback.")
                    except Exception as e:
                        log.debug("XOAUTH2 flow exception: %s", e)

            # Fallback to user/pass login if available
            if SMTP_USER and SMTP_PASS:
                smtp.login(SMTP_USER, SMTP_PASS)
                smtp.send_message(msg, from_addr=msg["From"], to_addrs=to_addrs)
                smtp.quit()
                return {"ok": True}
            else:
                smtp.quit()
                return {"ok": False, "error": "No SMTP credentials configured."}

        except Exception as e:
            last_err = e
            log.warning("SMTP send attempt %d/%d failed: %s", attempt, retries, e)
            time.sleep(min(2 * attempt, 10))

    return {"ok": False, "error": str(last_err)}


def send_mail(
    to: str,
    subject: str,
    body: str,
    html: Optional[str] = None,
    cc: Optional[List[str]] = None,
    bcc: Optional[List[str]] = None,
    attachments: Optional[List[str]] = None,
    from_name: Optional[str] = None,
    retries: int = 2,
    timeout: int = 10
) -> Dict[str, Any]:
    """
    Send an email.
    - to: single recipient email (string) or comma-separated list
    - subject, body: plain text body
    - html: optional html body
    - attachments: list of file paths to attach
    Returns dict: {"ok": True} or {"ok": False, "error": "..."}
    """
    try:
        if not SMTP_USER:
            log.warning("SMTP_USER not configured (CORREO_ORIGEN). Attempting to continue, but mail may fail.")

        # create message
        msg = EmailMessage()
        display_from = SMTP_USER
        if from_name:
            msg["From"] = formataddr((from_name, SMTP_USER))
        else:
            msg["From"] = SMTP_USER
        to_addrs = [a.strip() for a in (to.split(",") if isinstance(to, str) and "," in to else ([to] if isinstance(to, str) else to))]
        msg["To"] = ", ".join(to_addrs)
        if cc:
            msg["Cc"] = ", ".join(cc)
        if bcc is None:
            bcc = []
        all_recipients = to_addrs + (cc or []) + (bcc or [])

        msg["Subject"] = subject
        msg.set_content(body)
        if html:
            msg.add_alternative(html, subtype="html")

        # attachments
        if attachments:
            for file_path in attachments:
                try:
                    with open(file_path, "rb") as fh:
                        data = fh.read()
                        maintype = "application"
                        subtype = "octet-stream"
                        # try guess by extension (light)
                        if file_path.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
                            maintype = "image"
                            subtype = file_path.rsplit(".", 1)[-1]
                        filename = os.path.basename(file_path)
                        msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=filename)
                except Exception:
                    log.exception("Attachment %s failed to attach", file_path)

        # send via SMTP
        res = _connect_and_send(msg, all_recipients, retries=retries, timeout=timeout)
        if not res.get("ok"):
            log.error("send_mail failed: %s", res.get("error"))
            return res

        log.info("Email sent to %s subject=%s", to_addrs, subject)
        return {"ok": True}

    except Exception as e:
        log.exception("send_mail unexpected error: %s", e)
        return {"ok": False, "error": str(e)}


# -----------------------------
# Quick CLI / test helper
# -----------------------------
if __name__ == "__main__":
    # small manual test
    tgt = os.getenv("TEST_MAIL_TO")
    if not tgt:
        print("Set TEST_MAIL_TO env var to run quick test.")
    else:
        r = send_mail(
            to=tgt,
            subject="EFRA BOT — Test mail",
            body="Este es un correo de prueba enviado por backend/mailer.py",
            html="<b>Prueba desde EFRA BOT</b>"
        )
        print(r)
