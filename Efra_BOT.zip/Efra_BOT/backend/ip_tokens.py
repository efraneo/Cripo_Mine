# backend/ip_tokens.py
"""
IP Tokens PRO
- Tokens HMAC firmados para aprobación de IP
- Expiración segura
- Compatible con sidebar / admin / API
"""

import os
import hmac
import hashlib
import base64
from datetime import datetime, timedelta

# ============================================================
# Configuración segura
# ============================================================

SECRET_KEY = (
    os.getenv("HMAC_INTEGRITY_KEY")
    or os.getenv("DB_MASTER_KEY")
    or os.getenv("IP_TOKEN_SECRET")
    or "DEV_SECRET_CHANGE_ME"
).encode("utf-8")

TTL_SECONDS = 900  # 15 minutos


# ============================================================
# Generar token
# ============================================================

def generate_ip_token(username: str, ip: str, ttl: int = TTL_SECONDS) -> str:
    """
    Genera un token firmado para aprobar una IP.
    """
    exp = int((datetime.utcnow() + timedelta(seconds=ttl)).timestamp())
    payload = f"{username}|{ip}|{exp}"

    sig = hmac.new(
        SECRET_KEY,
        payload.encode("utf-8"),
        hashlib.sha256
    ).digest()

    raw = payload.encode("utf-8") + b"." + sig
    return base64.urlsafe_b64encode(raw).decode("utf-8")


# ============================================================
# Validar token
# ============================================================

def validate_ip_token(token: str):
    """
    Valida token IP.
    Retorna (username, ip) o None si inválido / expirado.
    """
    try:
        raw = base64.urlsafe_b64decode(token.encode("utf-8"))
        payload_raw, sig = raw.rsplit(b".", 1)

        expected_sig = hmac.new(
            SECRET_KEY,
            payload_raw,
            hashlib.sha256
        ).digest()

        if not hmac.compare_digest(sig, expected_sig):
            return None

        payload = payload_raw.decode("utf-8")
        username, ip, exp = payload.split("|")

        if datetime.utcnow().timestamp() > int(exp):
            return None

        from backend.telegram_notifier import notify_security_event
        from core.utils.time_utils import now_colombia

        notify_security_event(
            event="IP_APPROVED",
            username=username,
            ip=ip,
            extra=f"Hora COL: {now_colombia()}"
        )

        return username, ip

    except Exception:
        return None
