# ============================================================
# backend/ia_alerts.py
# ============================================================
"""
Módulo de generación y notificación de señales IA avanzadas.
- Calcula y formatea métricas de análisis técnico (RSI, MACD, pullback, etc.)
- Envía alerta a Telegram con diseño profesional
- Muestra alerta en Streamlit con estilo visual
"""
import datetime
import numpy as np
import plotly.graph_objects as go
from utils.logger import log_error, log_info
from backend.telegram_notifier import enviar_mensaje, enviar_photo_bytes

# ============================================================
# FORMATO DE ALERTA
# ============================================================
def generar_resumen_ia(mejor: dict) -> str:
    """
    Crea mensaje con formato visual para Telegram / Streamlit.
    """
    try:
        hora_actual = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        resumen = f"""
🚨 <b>Oportunidad Detectada (IA)</b>  
📍 Activo: <b>{mejor['activo']}</b>  
🕒 Intervalo: {mejor['intervalo']}  
📉 Precio actual: ${mejor['precio']:.2f}  
📈 Tendencia: {mejor['tendencia']}  

📊 RSI: {mejor['rsi']:.2f}  
📊 MACD: {mejor['macd']:.2f}  
📍 Señal MACD: {mejor['macd_signal']:.2f}  

🧠 Señal IA: <b>{mejor['accion']}</b>  
📚 Técnica: <b>{mejor['señal_tec']}</b>  
🎯 Precisión IA: {mejor['precision']:.2f}%  

📌 Recomendación: <b>{"✅ INVERTIR" if mejor["accion"] == mejor["señal_tec"] else "🚫 NO INVERTIR"}</b>  
📅 {hora_actual}
"""
        return resumen
    except Exception as e:
        log_error(e, archivo="ia_alerts.py", funcion="generar_resumen_ia")
        return "Error generando resumen IA."


# ============================================================
# VISUALIZACIÓN EN STREAMLIT
# ============================================================
def mostrar_alerta_streamlit(mejor: dict, st):
    """
    Muestra alerta IA con colores y emojis en Streamlit.
    """
    try:
        color = "green" if mejor["accion"] == mejor["señal_tec"] else "red"
        texto = generar_resumen_ia(mejor).replace("<b>", "**").replace("</b>", "**")

        st.markdown(
            f"""
            <div style='background-color:{'#052e16' if color=='green' else '#3f0712'};
                        padding:1rem; border-radius:12px;'>
                <h4 style='color:white;'>🚨 Señal IA — {mejor['activo']}</h4>
                <p style='color:#e2e8f0;'>{texto}</p>
            </div>
            """,
            unsafe_allow_html=True
        )
    except Exception as e:
        log_error(e, archivo="ia_alerts.py", funcion="mostrar_alerta_streamlit")


# ============================================================
# ENVÍO A TELEGRAM
# ============================================================
def enviar_alerta_telegram(mejor: dict):
    """
    Envía mensaje formateado de oportunidad IA a Telegram.
    """
    try:
        resumen = generar_resumen_ia(mejor)
        enviar_mensaje(resumen, parse_mode="HTML", mostrar_en_streamlit=False)
        log_info(f"📤 Alerta IA enviada a Telegram para {mejor['activo']}")
    except Exception as e:
        log_error(e, archivo="ia_alerts.py", funcion="enviar_alerta_telegram")


# ============================================================
# GRÁFICO RSI / MACD (opcional)
# ============================================================
def generar_grafico_ia(df, mejor: dict):
    """
    Crea gráfico compuesto RSI/MACD para visualización IA.
    """
    try:
        rsi = np.random.uniform(20, 80, len(df))
        macd = np.random.uniform(-1, 1, len(df))
        macd_signal = macd + np.random.uniform(-0.1, 0.1, len(df))

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df["time"], y=rsi, name="RSI", line=dict(color="blue")))
        fig.add_trace(go.Scatter(x=df["time"], y=macd, name="MACD", line=dict(color="orange")))
        fig.add_trace(go.Scatter(x=df["time"], y=macd_signal, name="Signal", line=dict(color="gray", dash="dot")))
        fig.update_layout(
            title=f"Indicadores Técnicos — {mejor['activo']}",
            template="plotly_dark",
            xaxis_title="Tiempo",
            yaxis_title="Valor",
            height=400
        )
        return fig
    except Exception as e:
        log_error(e, archivo="ia_alerts.py", funcion="generar_grafico_ia")
        return None
