# backend/backtrader_integration.py
"""
Integración con Backtrader.

Incluye:
 - Strategy que consulta tu IA predictor por barra y ejecuta entradas con stoploss/takeprofit.
 - Hooks para registrar señales IA en cerebro (para análisis posterior).
 - Ejemplo de uso en main() para correr un backtest rápido.

Requisitos:
    pip install backtrader pandas numpy

Cómo usar (PowerShell):
    python -c "from backend.backtrader_integration import run_demo; run_demo('data/BTC_1m.csv')"

Notas:
 - Asume que 'ia_predictor' expone un método predecir_probabilidad(row_dict) que devuelve {'prob':..., 'label':...}
 - Si tu predictor está en otra forma, adapta la llamada en Strategy.next()
"""

from __future__ import annotations
import os
import datetime
import backtrader as bt
import pandas as pd
import numpy as np

# Intentar importar tu predictor IA
IA = None
try:
    # opción: ia_predictor.ia_predictor.predecir_probabilidad(...)
    from backend.ia_predictor import ia_predictor as IA
except Exception:
    try:
        from backend.ia_predictor import IAPredictor
        IA = IAPredictor()
    except Exception:
        IA = None

# ---------------------------
# Strategy
# ---------------------------
class IAConfirmedStrategy(bt.Strategy):
    params = dict(
        min_confidence=0.80,
        stake_pct=0.05,        # fracción del capital a usar por trade
        stop_atr_mult=1.0,
        tp_atr_mult=1.5,
        atr_period=14
    )

    def __init__(self):
        # indicadores básicos
        self.dataclose = self.datas[0].close
        self.datahigh = self.datas[0].high
        self.datalow = self.datas[0].low
        self.volume = self.datas[0].volume

        # ATR
        self.atr = bt.indicators.ATR(self.data, period=self.p.atr_period)

        # para guardar órdenes y trazas
        self.order = None
        self.last_trade_info = None

    def next(self):
        # crear row dict con valores necesarios para el predictor
        row = {
            "open": float(self.data.open[0]),
            "high": float(self.data.high[0]),
            "low": float(self.data.low[0]),
            "close": float(self.data.close[0]),
            "volume": float(self.data.volume[0]),
            "atr": float(self.atr[0]) if len(self.atr) > 0 else 0.0
        }

        # fallback si no hay predictor
        prob = 0.5
        label = 0
        if IA is not None:
            try:
                # IA puede ser instancia global o clase; adaptamos llamadas comunes
                if hasattr(IA, "predecir_probabilidad"):
                    r = IA.predecir_probabilidad(row)
                elif hasattr(IA, "predecir"):
                    r = IA.predecir(row)
                else:
                    # si IA es un objeto con método predict_proba directamente (sk-learn pipeline)
                    # convertir row a DataFrame y llamar predict_proba
                    import pandas as _pd
                    df = _pd.DataFrame([row])
                    proba = float(IA.pipeline.predict_proba(df)[0][1])
                    lab = int(IA.pipeline.predict(df)[0])
                    r = {"prob": proba, "label": lab}
                prob = float(r.get("prob", 0.5))
                label = int(r.get("label", 0))
            except Exception as e:
                # no romper si predictor falla
                prob = 0.5
                label = 0

        # Guardar prob en cerebro (anotar)
        self.log(f"IA prob={prob:.4f} label={label}")

        # Si ya hay posición abierta, no abrir nueva
        if self.position:
            return

        # Si prob suficiente -> abrir trade
        if prob >= self.p.min_confidence:
            # calcular size por stake_pct del capital
            cash = self.broker.getcash()
            size_notional = cash * self.p.stake_pct
            price = float(self.dataclose[0])
            size = size_notional / price if price > 0 else 0

            # Calcular SL/TP por ATR
            atr_val = float(self.atr[0]) if len(self.atr) > 0 else 0.0
            sl = price - self.p.stop_atr_mult * atr_val
            tp = price + self.p.tp_atr_mult * atr_val

            # Enviar orden de mercado (Backtrader no tiene take-profit/stop nativo en orden simple;
            # se puede usar bracket orders)
            try:
                self.order = self.buy(size=size)
                # registrar targets en last_trade_info para gestion luego
                self.last_trade_info = dict(price=price, size=size, sl=sl, tp=tp, prob=prob)
                self.log(f"BUY order placed size={size:.6f} price={price:.2f} sl={sl:.2f} tp={tp:.2f}")
            except Exception as e:
                self.log(f"Order send error: {e}")

    def notify_order(self, order):
        if order.status in [order.Submitted, order.Accepted]:
            return
        if order.status in [order.Completed]:
            if order.isbuy():
                self.log(f"BUY EXECUTED price={order.executed.price:.2f}, size={order.executed.size:.6f}")
            elif order.issell():
                self.log("SELL EXECUTED")
        elif order.status in [order.Canceled, order.Margin, order.Rejected]:
            self.log("Order Canceled/Rejected/Margin")

        self.order = None

    def notify_trade(self, trade):
        if not trade.isclosed:
            return
        self.log(f"Trade closed PnL Gross {trade.pnl:.6f}")

    def log(self, txt, dt=None):
        dt = dt or self.datas[0].datetime.datetime(0)
        print(f"[{dt.isoformat()}] {txt}")


# ---------------------------
# Helper para correr demo
# ---------------------------
def run_demo(csv_path: str,
             start_cash: float = 1000.0,
             timeframe=bt.TimeFrame.Minutes,
             compression=1):
    """
    Ejecuta backtest demo con archivo CSV OHLCV (debe contener Date/Time/Open/High/Low/Close/Volume)
    """
    cerebro = bt.Cerebro()
    cerebro.broker.setcash(start_cash)

    # cargar datos CSV
    data = bt.feeds.GenericCSVData(
        dataname=csv_path,
        dtformat=('%Y-%m-%d %H:%M:%S'),
        datetime=0,
        time=-1,
        open=1,
        high=2,
        low=3,
        close=4,
        volume=5,
        timeframe=timeframe,
        compression=compression,
        header=0,
        fromdate=None,
        todate=None
    )
    cerebro.adddata(data)
    cerebro.addstrategy(IAConfirmedStrategy)
    cerebro.addsizer(bt.sizers.FixedSize, stake=1)

    print("Starting Portfolio Value:", cerebro.broker.getvalue())
    res = cerebro.run(maxcpus=1)
    print("Final Portfolio Value:", cerebro.broker.getvalue())
    return res


# ---------------------------
# Ejecución desde script
# ---------------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("csv", help="CSV OHLCV path")
    parser.add_argument("--cash", type=float, default=1000.0)
    args = parser.parse_args()

    run_demo(args.csv, start_cash=args.cash)
