# backend/activity_logger.py

from datetime import datetime
from backend.telegram_notifier import send_telegram_message
from backend.user_activity_db import save_activity

def log_user_activity(
    username,
    role,
    ip,
    action,
    symbol=None,
    extra=None
):

    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    msg = (
        "🧠 EL BOT DE EFRA — ACTIVIDAD DE USUARIO\n\n"
        f"👤 Usuario: {username}\n"
        f"🛡️ Rol: {role}\n"
        f"🌐 IP: {ip}\n"
        f"⚡ Acción: {action}\n"
        f"📈 Activo: {symbol or 'N/A'}\n"
        f"🕒 Fecha: {ts}\n"
        f"📋 Extra: {extra or 'N/A'}"
    )

    try:
        save_activity(
            username=username,
            role=role,
            ip=ip,
            action=action,
            symbol=symbol,
            extra=extra
        )
        send_telegram_message(msg)
    except Exception:
        pass
