# utils/model_auto_trainer.py
# ============================================================
# AutoML Trainer PRO – LightGBM + evaluación + rollback
# ============================================================

import os
import json
import time
import joblib
import numpy as np
import pandas as pd
from datetime import datetime
import lightgbm as lgb

from backend.log_manager import get_logger
log = get_logger("automl")

try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except:
    telegram_send = None


class AutoMLTrainer:
    def __init__(self, model_path="models/model_lgb.pkl"):
        self.model_path = model_path
        os.makedirs("models", exist_ok=True)

    # -----------------------------
    # Cargar datos OHLCV
    # -----------------------------
    def load_data(self, csv_path):
        df = pd.read_csv(csv_path)
        df = df.dropna()
        return df

    # -----------------------------
    # Feature Engineering PRO
    # -----------------------------
    def build_features(self, df):
        df["ret"] = df["close"].pct_change()
        df["ema_fast"] = df["close"].ewm(span=9).mean()
        df["ema_slow"] = df["close"].ewm(span=21).mean()
        df["rsi"] = self._rsi(df["close"])
        df["atr"] = self._atr(df)
        df["target"] = (df["close"].shift(-1) > df["close"]).astype(int)
        df = df.dropna()
        return df

    def _rsi(self, series, period=14):
        delta = series.diff()
        gain = delta.clip(lower=0).rolling(period).mean()
        loss = -delta.clip(upper=0).rolling(period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    def _atr(self, df, period=14):
        tr = np.maximum(df["high"] - df["low"],
                        np.maximum(abs(df["high"] - df["close"].shift()),
                                   abs(df["low"] - df["close"].shift())))
        return tr.rolling(period).mean()

    # -----------------------------
    # Train + evaluate + rollback
    # -----------------------------
    def train(self, df):
        X = df[["ret", "ema_fast", "ema_slow", "rsi", "atr"]]
        y = df["target"]

        split = int(len(df) * 0.8)
        X_train, X_val = X[:split], X[split:]
        y_train, y_val = y[:split], y[split:]

        train_data = lgb.Dataset(X_train, label=y_train)
        val_data = lgb.Dataset(X_val, label=y_val)

        params = {
            "objective": "binary",
            "metric": "auc",
            "learning_rate": 0.01,
            "num_leaves": 16,
            "feature_fraction": 0.8
        }

        log.info("Entrenando LightGBM…")
        model = lgb.train(params, train_data, valid_sets=[val_data], num_boost_round=500, verbose_eval=False)

        preds = model.predict(X_val)
        auc = self._compute_auc(y_val.values, preds)

        log.info("AUC nuevo modelo: %s", auc)

        old_auc = self._load_old_auc()

        if auc > old_auc:
            joblib.dump(model, self.model_path)
            self._save_auc(auc)
            msg = f"✔ Nuevo modelo LightGBM activado — AUC {auc:.4f}"
        else:
            msg = f"❌ Nuevo modelo peor — rollback automático (AUC {auc:.4f} < {old_auc:.4f})"

        log.info(msg)
        if telegram_send:
            telegram_send(msg)

        return auc

    def _compute_auc(self, y, preds):
        from sklearn.metrics import roc_auc_score
        return roc_auc_score(y, preds)

    def _load_old_auc(self):
        path = os.path.join("models", "auc.json")
        if not os.path.exists(path):
            return 0
        return json.load(open(path))["auc"]

    def _save_auc(self, auc):
        json.dump({"auc": auc}, open(os.path.join("models", "auc.json"), "w"))
