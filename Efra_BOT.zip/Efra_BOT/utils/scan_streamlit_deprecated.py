import os

TARGET = "use_container_width"

def scan_file(path):
    results = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for num, line in enumerate(f, start=1):
            if TARGET in line:
                results.append((num, line.strip()))
    return results


def scan_project(root="."):
    print("\n🔍 Escaneando proyecto en busca de `use_container_width`...\n")

    for dirpath, _, filenames in os.walk(root):
        for name in filenames:
            if name.endswith(".py"):
                full_path = os.path.join(dirpath, name)
                matches = scan_file(full_path)
                if matches:
                    print(f"\n📌 Archivo: {full_path}")
                    for num, line in matches:
                        print(f"   Línea {num}: {line}")

    print("\n🔚 Escaneo finalizado.")
    print("Si quieres que genere el script corrector automático, me dices.")


if __name__ == "__main__":
    scan_project(".")
