# utils/dashboard_utils.py
# ============================================================
# Dashboard Utils PRO — Gráficos, métricas y análisis completo
# ============================================================

import os
import json
import pandas as pd
import numpy as np
from datetime import datetime
import plotly.graph_objects as go
import plotly.express as px

from backend.log_manager import get_logger
log = get_logger("dashboard")

# Directorio de datos
DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)


# ============================================================
# 1) CARGA DE ARCHIVOS JSONL
# ============================================================

def load_jsonl(path: str) -> pd.DataFrame:
    """
    Carga un JSONL como DataFrame.
    Retorna DataFrame vacío si no existe.
    """
    if not os.path.exists(path):
        return pd.DataFrame()

    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except:
                continue

    return pd.DataFrame(rows)


def load_signals():
    return load_jsonl(os.path.join(DATA_DIR, "signals_log.jsonl"))


def load_executions():
    return load_jsonl(os.path.join(DATA_DIR, "executions_log.jsonl"))


def load_audit_orders():
    return load_jsonl(os.path.join(DATA_DIR, "orders_audit.jsonl"))


# ============================================================
# 2) MÉTRICAS DE TRADING PROFESIONALES
# ============================================================

def compute_metrics(df_exec: pd.DataFrame) -> dict:
    """
    Calcula métricas clave basado en DF de ejecuciones.
    Debe contener 'result' o 'pnl' o 'profit'.
    """
    if df_exec.empty:
        return {
            "total_trades": 0,
            "winrate": 0,
            "avg_win": 0,
            "avg_loss": 0,
            "profit_factor": 0,
            "expectancy": 0,
            "net_profit": 0
        }

    # PNL: los modelos tuyos tienen diferentes estructuras.
    # Intentamos extraer la ganancia
    def extract_pnl(row):
        if isinstance(row.get("result"), dict):
            return row["result"].get("pnl", 0)
        if "pnl" in row:
            return row["pnl"]
        if "profit" in row:
            return row["profit"]
        return 0

    df_exec["pnl"] = df_exec.apply(extract_pnl, axis=1)
    pnl = df_exec["pnl"]

    wins = pnl[pnl > 0]
    losses = pnl[pnl <= 0]

    total_trades = len(pnl)
    winrate = len(wins) / total_trades if total_trades else 0
    avg_win = wins.mean() if not wins.empty else 0
    avg_loss = losses.mean() if not losses.empty else 0

    profit_factor = abs(wins.sum() / losses.sum()) if losses.sum() != 0 else np.inf
    expectancy = pnl.mean()  # promedio por trade
    net_profit = pnl.sum()

    return {
        "total_trades": total_trades,
        "winrate": round(winrate * 100, 2),
        "avg_win": round(avg_win, 4),
        "avg_loss": round(avg_loss, 4),
        "profit_factor": round(profit_factor, 4),
        "expectancy": round(expectancy, 4),
        "net_profit": round(net_profit, 4)
    }


# ============================================================
# 3) EQUITY CURVE (Curve de crecimiento de capital)
# ============================================================

def build_equity_curve(df_exec: pd.DataFrame):
    """
    Construye una equity curve acumulada basada en pnl
    """
    if df_exec.empty:
        return pd.DataFrame()

    # Convert ts to datetime
    if "ts" in df_exec:
        df_exec["datetime"] = df_exec["ts"].apply(lambda x: datetime.utcfromtimestamp(x))
    elif "time" in df_exec:
        df_exec["datetime"] = df_exec["time"].apply(lambda x: datetime.utcfromtimestamp(x))
    else:
        df_exec["datetime"] = pd.date_range(start="2024-01-01", periods=len(df_exec))

    # Extract PNL
    def extract_pnl(row):
        if isinstance(row.get("result"), dict):
            return row["result"].get("pnl", 0)
        if "pnl" in row:
            return row["pnl"]
        if "profit" in row:
            return row["profit"]
        return 0

    df_exec["pnl"] = df_exec.apply(extract_pnl, axis=1)

    df_exec = df_exec.sort_values("datetime")
    df_exec["equity"] = df_exec["pnl"].cumsum()

    return df_exec


def plot_equity_curve(df_equity: pd.DataFrame, title="Equity Curve"):
    """
    Gráfico PRO de equity curve
    """
    if df_equity.empty:
        fig = go.Figure()
        fig.update_layout(title="No hay datos de ejecuciones", template="plotly_dark")
        return fig

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df_equity["datetime"],
        y=df_equity["equity"],
        mode="lines",
        line=dict(width=3),
        name="Equity"
    ))

    fig.update_layout(
        title=title,
        template="plotly_dark",
        height=450,
        xaxis_title="Tiempo",
        yaxis_title="Equity (USDT)",
    )

    return fig


# ============================================================
# 4) HEATMAP — CORRELACIÓN DE FEATURES DEL MODELO
# ============================================================

def plot_feature_heatmap(df: pd.DataFrame, title="Feature Correlation"):
    if df.empty:
        return go.Figure()

    corr = df.corr()

    fig = px.imshow(
        corr,
        color_continuous_scale="Viridis",
        title=title
    )
    fig.update_layout(template="plotly_dark", height=500)
    return fig


# ============================================================
# 5) HISTOGRAMA DE PNL
# ============================================================

def plot_pnl_histogram(df_exec):
    if df_exec.empty:
        return go.Figure()

    if "pnl" not in df_exec:
        return go.Figure()

    fig = px.histogram(
        df_exec,
        x="pnl",
        nbins=40,
        title="Distribución del PnL",
        template="plotly_dark"
    )
    fig.update_layout(height=400)
    return fig


# ============================================================
# 6) FUNCIÓN PRINCIPAL PARA STREAMLIT
# ============================================================

def load_dashboard_data():
    """
    Carga TODO para el dashboard
    """
    signals = load_signals()
    execs = load_executions()
    orders = load_audit_orders()

    metrics = compute_metrics(execs)
    equity_df = build_equity_curve(execs)

    return {
        "signals": signals,
        "executions": execs,
        "orders": orders,
        "metrics": metrics,
        "equity_df": equity_df
    }

# utils/dashboard_utils.py
"""
Dashboard helpers: equity, drawdown, pnl dist, per-user cumulative curves.
"""

import plotly.graph_objects as go
import pandas as pd
from typing import Optional

def equity_figure(equity_df: pd.DataFrame, title="Equity Curve"):
    fig = go.Figure()
    if equity_df is None or equity_df.empty:
        fig.update_layout(title="No equity data", template="plotly_dark")
        return fig
    fig.add_trace(go.Scatter(x=equity_df["time"], y=equity_df["equity"], mode="lines", name="Equity"))
    fig.update_layout(title=title, template="plotly_dark", xaxis_title="Time", yaxis_title="Equity (USD)", height=420)
    return fig

def drawdown_figure(equity_df: pd.DataFrame, title="Drawdown"):
    if equity_df is None or equity_df.empty:
        return go.Figure()
    eq = equity_df.sort_values("time")
    vals = eq["equity"].astype(float).values
    peak = -1e18; dd=[]
    for v in vals:
        peak = max(peak, v)
        dd.append((peak - v)/(peak + 1e-9))
    fig = go.Figure(); fig.add_trace(go.Scatter(x=eq["time"], y=dd, mode="lines", name="Drawdown"))
    fig.update_layout(title=title, template="plotly_dark", height=300)
    return fig

def pnl_histogram(trades_df: pd.DataFrame, title="PnL distribution"):
    fig = go.Figure()
    if trades_df is None or trades_df.empty:
        fig.update_layout(title="No trades", template="plotly_dark")
        return fig
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=trades_df["pnl"], nbinsx=50))
    fig.update_layout(title=title, template="plotly_dark", xaxis_title="PnL (USD)", yaxis_title="Count", height=300)
    return fig

def per_user_equity_curve(all_trades_df: pd.DataFrame, user_col: str = "username"):
    """
    all_trades_df must contain: username, ts_close (timestamp), pnl
    Returns DataFrame per user cumulative equity and figure
    """
    if all_trades_df is None or all_trades_df.empty:
        return None, go.Figure()
    df = all_trades_df.copy()
    df["ts"] = pd.to_datetime(df["ts_close"], unit="s", errors="coerce")
    df = df.sort_values(["username","ts"])
    df["cume"] = df.groupby("username")["pnl"].cumsum()
    fig = go.Figure()
    for user, g in df.groupby("username"):
        fig.add_trace(go.Scatter(x=g["ts"], y=g["cume"], mode="lines", name=str(user)))
    fig.update_layout(title="Per-user equity", template="plotly_dark", xaxis_title="Time", yaxis_title="Cumulative PnL", height=420)
    return df, fig
