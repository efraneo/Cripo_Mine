import pandas as pd

FILE = "utils/datasets/signals_2025_12.parquet"

df = pd.read_parquet(FILE)
print("Columnas:", df.columns.tolist())
print("Registros:", len(df))

print("\nTIPOS DETECTADOS:")
print(df.dtypes)

print("\nBuscando filas corruptas...")

bad_rows = []

for i, row in df.iterrows():
    if not isinstance(row['open'], (int, float)):
        bad_rows.append(i)
    if not isinstance(row['high'], (int, float)):
        bad_rows.append(i)
    if not isinstance(row['low'], (int, float)):
        bad_rows.append(i)
    if not isinstance(row['close'], (int, float)):
        bad_rows.append(i)
    if isinstance(row['target'], str):
        bad_rows.append(i)

print("\nFilas corruptas detectadas:", len(set(bad_rows)))
print("Índices:", list(set(bad_rows))[:20])
