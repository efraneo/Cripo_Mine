import os
import time
import json
import math
import requests
import numpy as np
import pandas as pd
from datetime import datetime
from ta.volatility import AverageTrueRange
from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator, SMAIndicator, MACD

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

BINANCE_KLINES = "https://api.binance.com/api/v3/klines"


# ---------------------------------------------------------
# 🔥 Descarga OHLCV reales desde Binance
# ---------------------------------------------------------
def download_klines(symbol: str, interval: str, limit: int = 50000):
    print(f"📥 Descargando {symbol} {interval} ... ")

    df_all = []
    step = 1000  # límite real de Binance por request
    end_time = int(time.time() * 1000)

    for _ in range(limit // step):
        params = {
            "symbol": symbol.upper(),
            "interval": interval,
            "endTime": end_time,
            "limit": step
        }
        r = requests.get(BINANCE_KLINES, params=params)
        data = r.json()

        if not isinstance(data, list):
            print("❌ Error Binance:", data)
            break

        df = pd.DataFrame(data, columns=[
            "open_time", "open", "high", "low", "close", "volume",
            "close_time", "qav", "trades", "taker_base", "taker_quote", "ignore"
        ])
        df_all.append(df)

        # siguiente bloque hacia atrás
        end_time = int(df["open_time"].iloc[0])
        time.sleep(0.45)  # para evitar rate-limit

    df = pd.concat(df_all).sort_values("open_time").reset_index(drop=True)

    # convertir datos
    df["open"] = df["open"].astype(float)
    df["high"] = df["high"].astype(float)
    df["low"] = df["low"].astype(float)
    df["close"] = df["close"].astype(float)
    df["volume"] = df["volume"].astype(float)

    print(f"✅ {symbol} {interval}: {len(df)} velas descargadas")
    return df


# ---------------------------------------------------------
# 🧠 Construcción de Features PRO
# ---------------------------------------------------------
def build_features(df: pd.DataFrame):
    print("⚙️ Construyendo features...")

    # ATR
    df["atr"] = AverageTrueRange(
        high=df["high"], low=df["low"], close=df["close"], window=14
    ).average_true_range()

    # RSI
    df["rsi"] = RSIIndicator(close=df["close"], window=14).rsi()

    # EMA/SMA
    df["ema_9"] = EMAIndicator(close=df["close"], window=9).ema_indicator()
    df["ema_50"] = EMAIndicator(close=df["close"], window=50).ema_indicator()
    df["sma_20"] = SMAIndicator(close=df["close"], window=20).sma_indicator()

    # MACD
    macd = MACD(close=df["close"])
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_hist"] = macd.macd_diff()

    # log returns
    df["log_return"] = np.log(df["close"] / df["close"].shift(1))

    # volatility
    df["volatility"] = df["log_return"].rolling(20).std()

    # candle features
    df["body"] = df["close"] - df["open"]
    df["upper_wick"] = df["high"] - df[["close", "open"]].max(axis=1)
    df["lower_wick"] = df[["close", "open"]].min(axis=1) - df["low"]

    # variation
    df["return_pct"] = df["close"].pct_change()

    return df


# ---------------------------------------------------------
# 🎯 Target ML: retorno futuro (horizon configurable)
# ---------------------------------------------------------
def add_future_target(df: pd.DataFrame, horizon: int = 5):
    print(f"🎯 Calculando retorno futuro (h={horizon}) ...")

    df["future_return"] = df["close"].shift(-horizon) / df["close"] - 1

    # target binario BUY/SELL
    df["target"] = (df["future_return"] > 0).astype(int)
    return df


# ---------------------------------------------------------
# 📤 Guardado en JSONL y CSV
# ---------------------------------------------------------
def export_dataset(symbol, interval, df):
    base = f"{DATA_DIR}/{symbol}_{interval}"
    df.to_csv(base + ".csv", index=False)

    jsonl_path = base + ".jsonl"
    with open(jsonl_path, "w") as f:
        for _, row in df.iterrows():
            f.write(json.dumps(row.to_dict()) + "\n")

    print("📁 Dataset guardado en:")
    print("   →", base + ".csv")
    print("   →", base + ".jsonl")


# ---------------------------------------------------------
# 🚀 MAIN
# ---------------------------------------------------------
def build(symbols=None, intervals=None, horizon=5):
    symbols = symbols or ["BTCUSDT", "ETHUSDT"]
    intervals = intervals or ["1m", "5m"]

    for symbol in symbols:
        for interval in intervals:
            df = download_klines(symbol, interval)
            df = build_features(df)
            df = add_future_target(df, horizon=horizon)
            export_dataset(symbol, interval, df)


if __name__ == "__main__":
    build()
