# utils/train_model_pro.py
# ======================================================================
# Entrena un modelo profesional LightGBM para señales
# Genera:
#   models/best_model.pkl
#   models/scaler.pkl
#
# Entrada:
#   data/signals_log.jsonl (de SignalsEngine)
#
# Requiere:
#   pip install lightgbm scikit-learn joblib pandas numpy
# ======================================================================

import os
import json
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from lightgbm import LGBMRegressor


DATASET_PATH = "data/signals_log.jsonl"
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)


# ------------------------------------------------------------------
# CARGAR DATASET
# ------------------------------------------------------------------
def load_dataset(path=DATASET_PATH):
    rows = []

    if not os.path.exists(path):
        raise FileNotFoundError(f"No existe dataset: {path}")

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                obj = json.loads(line)
                y = obj.get("future_return_y")
                feats = obj.get("features")

                if y is None or feats is None:
                    continue

                rows.append({**feats, "y": y})
            except:
                pass

    df = pd.DataFrame(rows)
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    return df


# ------------------------------------------------------------------
# ENTRENAMIENTO PRO
# ------------------------------------------------------------------
def train_model():
    print("📥 Cargando dataset...")
    df = load_dataset()

    y = df["y"].values
    X = df.drop(columns=["y"]).values
    feature_names = df.drop(columns=["y"]).columns.tolist()

    # Normalizar
    print("📦 Normalizando...")
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    # Train/test
    X_train, X_test, y_train, y_test = train_test_split(
        Xs, y, test_size=0.2, random_state=42
    )

    # Modelo LightGBM
    print("🚀 Entrenando LightGBM...")
    model = LGBMRegressor(
        n_estimators=350,
        learning_rate=0.03,
        max_depth=7,
        num_leaves=64,
        subsample=0.85,
        colsample_bytree=0.85,
        reg_lambda=1.2,
        reg_alpha=0.6,
        objective="regression"
    )

    model.fit(X_train, y_train)

    # Validación ROC–AUC sobre signo(+/-)
    pred = model.predict(X_test)
    pred_bin = (pred > 0).astype(int)
    y_bin = (y_test > 0).astype(int)

    auc_score = roc_auc_score(y_bin, pred_bin)
    print(f"🎯 ROC–AUC: {auc_score:.4f}")

    # Guardar
    joblib.dump(model, f"{MODEL_DIR}/best_model.pkl")
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.pkl")

    print("✅ ENTRENAMIENTO COMPLETO")
    print("📁 Guardado en:")
    print("   → models/best_model.pkl")
    print("   → models/scaler.pkl")

    return auc_score


if __name__ == "__main__":
    train_model()
