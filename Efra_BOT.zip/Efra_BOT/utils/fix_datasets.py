import os
import pandas as pd

# Ruta correcta según tu estructura:
DATASET_DIR = "utils/datasets"

def fix_csv(path):
    print(f"🔍 Revisando: {path}")

    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    header = lines[0].strip().split(",")
    expected_cols = len(header)

    fixed_lines = [lines[0]]  # mantener header
    removed = 0

    for i, line in enumerate(lines[1:], start=2):
        parts = line.strip().split(",")

        if len(parts) != expected_cols:
            print(f"⚠ Línea {i} corrupta → eliminada (cols={len(parts)}, esperado={expected_cols})")
            removed += 1
        else:
            fixed_lines.append(line)

    with open(path, "w", encoding="utf-8") as f:
        f.writelines(fixed_lines)

    print(f"✅ Reparado: {path}  | Líneas removidas: {removed}\n")


def main():
    print("=== Reparando datasets ===\n")

    if not os.path.exists(DATASET_DIR):
        print(f"❌ ERROR: No existe la carpeta {DATASET_DIR}")
        return

    for file in os.listdir(DATASET_DIR):
        if file.endswith(".csv"):
            fix_csv(os.path.join(DATASET_DIR, file))

    print("✔ TODOS LOS DATASETS REPARADOS ✔")


if __name__ == "__main__":
    main()
