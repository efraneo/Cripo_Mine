# utils/automl_trainer_pro_2.py
# ============================================================
# AutoML PRO 2.0 – compatible con Feature Builder PRO
# ============================================================

import os
import json
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split

import lightgbm as lgb
import xgboost as xgb
import shap
import matplotlib.pyplot as plt


FEATURE_PARQUET = "utils/datasets/features/features_2025_12.parquet"
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)


# ------------------------------------------------------------
# 1. Cargar dataset PRO con 40–60 features
# ------------------------------------------------------------
def load_feature_dataset():
    print(f"📥 Cargando FEATURE DATASET PRO: {FEATURE_PARQUET}")
    df = pd.read_parquet(FEATURE_PARQUET)
    print("📊 Shape:", df.shape)
    return df


# ------------------------------------------------------------
# 2. Split train/test
# ------------------------------------------------------------
def make_train_test(df):
    X = df.drop("target", axis=1)
    y = df["target"]

    return train_test_split(X, y, test_size=0.2, shuffle=True, random_state=42)


# ------------------------------------------------------------
# 3. Entrenar modelos
# ------------------------------------------------------------
def train_lightgbm(X_train, X_test, y_train, y_test):
    model = lgb.LGBMClassifier(
        n_estimators=500,
        learning_rate=0.01,
        num_leaves=64,
        subsample=0.8,
        colsample_bytree=0.8
    )

    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]

    metrics = evaluate_model(y_test, pred, prob)
    return model, metrics


def train_xgboost(X_train, X_test, y_train, y_test):
    model = xgb.XGBClassifier(
        n_estimators=500,
        eta=0.01,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8,
        eval_metric="logloss"
    )

    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]

    metrics = evaluate_model(y_test, pred, prob)
    return model, metrics


# ------------------------------------------------------------
# 4. Métricas completas
# ------------------------------------------------------------
def evaluate_model(y_true, y_pred, prob):
    metrics = {
        "auc": roc_auc_score(y_true, prob),
        "acc": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "confusion": confusion_matrix(y_true, y_pred).tolist()
    }
    return metrics


# ------------------------------------------------------------
# 5. SHAP VALUES
# ------------------------------------------------------------
def save_shap(model, X_train):
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_train[:500])

    plt.figure(figsize=(10, 6))
    shap.summary_plot(shap_values, X_train[:500], show=False)
    plt.tight_layout()
    plt.savefig("models/shap_summary.png")
    plt.close()


# ------------------------------------------------------------
# 6. Curvas ROC, PR, Equidad
# ------------------------------------------------------------
def plot_curves(y_true, prob, name="model"):
    from sklearn.metrics import roc_curve, precision_recall_curve

    # ROC
    fpr, tpr, _ = roc_curve(y_true, prob)
    plt.figure()
    plt.plot(fpr, tpr)
    plt.title("ROC Curve")
    plt.savefig(f"models/{name}_roc.png")
    plt.close()

    # PR
    prec, rec, _ = precision_recall_curve(y_true, prob)
    plt.figure()
    plt.plot(rec, prec)
    plt.title("Precision-Recall Curve")
    plt.savefig(f"models/{name}_pr.png")
    plt.close()

    # Equity curve
    plt.figure()
    equity = np.cumsum(prob - 0.5)
    plt.plot(equity)
    plt.title("Equity Curve")
    plt.savefig(f"models/{name}_equity.png")
    plt.close()


# ------------------------------------------------------------
# 7. Guardado del mejor modelo
# ------------------------------------------------------------
def save_best(model, metrics, feature_list):

    import pickle
    pickle.dump(model, open("models/best_model.pkl", "wb"))

    with open("models/metrics.json", "w") as f:
        json.dump(metrics, f, indent=4)

    with open("models/feature_list.json", "w") as f:
        json.dump(feature_list, f, indent=4)

    print("\n💾 Guardado modelo final: models/best_model.pkl")
    print("📊 Métricas guardadas en models/metrics.json")
    print("🧩 Features guardados en models/feature_list.json\n")


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
def main():
    df = load_feature_dataset()
    X_train, X_test, y_train, y_test = make_train_test(df)

    print("⚡ Entrenando LightGBM...")
    lgb_model, lgb_metrics = train_lightgbm(X_train, X_test, y_train, y_test)

    print("⚡ Entrenando XGBoost...")
    xgb_model, xgb_metrics = train_xgboost(X_train, X_test, y_train, y_test)

    print("\n📊 MÉTRICAS LightGBM:", lgb_metrics)
    print("📊 MÉTRICAS XGBoost:", xgb_metrics)

    # Elegir ganador
    best_model = xgb_model if xgb_metrics["auc"] > lgb_metrics["auc"] else lgb_model
    best_metrics = xgb_metrics if xgb_metrics["auc"] > lgb_metrics["auc"] else lgb_metrics

    print(f"\n🏆 MEJOR MODELO: {'XGBOOST' if best_model == xgb_model else 'LIGHTGBM'} (AUC={best_metrics['auc']:.4f})")

    # SHAP y curvas
    print("📈 Generando curvas y SHAP...")
    prob_best = best_model.predict_proba(X_test)[:, 1]

    plot_curves(y_test, prob_best, name="best")
    save_shap(best_model, X_train)

    save_best(best_model, best_metrics, list(X_train.columns))

    print("\n🎉 AutoML PRO 2.0 COMPLETO 🎉")


if __name__ == "__main__":
    main()
