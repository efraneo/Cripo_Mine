# utils/execution_queue.py
"""
Execution Queue (simple) - enqueue orders from SignalsEngine and let a worker process them.
- API: enqueue_order(payload: dict)
- start_worker(order_executor_fn) -> launches a background thread that consumes the queue
- order_executor_fn should be a callable(payload) that performs order (sync) and returns result dict
"""

import threading, queue, time
from typing import Callable, Dict, Any, Optional

try:
    from backend.log_manager import get_logger
    log = get_logger("exec_queue")
except Exception:
    import logging
    log = logging.getLogger("exec_queue")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s exec_queue: %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)

_EXEC_Q: queue.Queue = queue.Queue()
_worker_thread: Optional[threading.Thread] = None
_worker_stop = threading.Event()

def enqueue_order(payload: Dict[str, Any]):
    """Push an order payload into the queue."""
    _EXEC_Q.put(payload)
    log.debug("Enqueued order: %s", {k:v for k,v in payload.items() if k!="features"})

def _worker_loop(order_executor_fn: Callable[[Dict[str, Any]], Dict[str, Any]], sleep_on_empty: float = 0.5):
    log.info("Execution queue worker started.")
    while not _worker_stop.is_set():
        try:
            payload = _EXEC_Q.get(timeout=1.0)
        except Exception:
            time.sleep(sleep_on_empty)
            continue
        try:
            log.info("Processing queued order: %s", {k:v for k,v in payload.items() if k not in ("features","full_df")})
            res = order_executor_fn(payload)
            log.info("Order executed (queue) result: %s", str(res)[:200])
        except Exception as e:
            log.exception("Order executor failed: %s", e)
        finally:
            _EXEC_Q.task_done()
    log.info("Execution queue worker stopped.")

def start_worker(order_executor_fn: Callable[[Dict[str, Any]], Dict[str, Any]], daemon: bool=True):
    """Start the background worker that will call order_executor_fn(payload)."""
    global _worker_thread, _worker_stop
    if _worker_thread and _worker_thread.is_alive():
        log.info("Execution worker already running.")
        return
    _worker_stop.clear()
    _worker_thread = threading.Thread(target=_worker_loop, args=(order_executor_fn,), daemon=daemon, name="exec-queue-worker")
    _worker_thread.start()

def stop_worker():
    global _worker_stop
    _worker_stop.set()
