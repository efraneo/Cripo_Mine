import pandas as pd
import os

SRC = "utils/datasets/signals_2025_12.parquet"
DST = "utils/datasets/"

COLS = ["open", "high", "low", "close", "target"]

def main():
    print(f"📥 Cargando parquet {SRC}")
    df = pd.read_parquet(SRC)

    # Forzar columnas correctas
    df = df[COLS]

    # Convertir todo a float excepto target
    df["open"] = df["open"].astype(float)
    df["high"] = df["high"].astype(float)
    df["low"] = df["low"].astype(float)
    df["close"] = df["close"].astype(float)

    # Target debe ser int (0/1)
    df["target"] = df["target"].astype(int)

    df = df.dropna()

    print("📊 Registros finales:", len(df))

    # Guardar datasets de entrenamiento y prueba
    train = df.iloc[: int(len(df) * 0.8)]
    test = df.iloc[int(len(df) * 0.8):]

    train.to_csv(os.path.join(DST, "dataset_train.csv"), index=False)
    test.to_csv(os.path.join(DST, "dataset_test.csv"), index=False)

    # Subdatasets pequeños para AutoML
    train.iloc[:2000].to_csv(os.path.join(DST, "dataset_1.csv"), index=False)
    train.iloc[2000:4000].to_csv(os.path.join(DST, "dataset_2.csv"), index=False)
    train.iloc[4000:6000].to_csv(os.path.join(DST, "dataset_3.csv"), index=False)

    df.to_csv(os.path.join(DST, "dataset_full.csv"), index=False)

    print("\n🎉 REGENERACIÓN COMPLETA — 0% ERRORES POSIBLES")
    print("   → dataset_train.csv")
    print("   → dataset_test.csv")
    print("   → dataset_1.csv")
    print("   → dataset_2.csv")
    print("   → dataset_3.csv")
    print("   → dataset_full.csv")


if __name__ == "__main__":
    main()
