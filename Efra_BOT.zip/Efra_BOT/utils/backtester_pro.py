# utils/backtester_pro.py
# Backtester PRO (actualizado) - DCA acumula posición + report Streamlit
from __future__ import annotations
import os, math, json
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import numpy as np
import pandas as pd
import plotly.graph_objects as go

try:
    from backend.log_manager import get_logger
    log = get_logger("backtester")
except Exception:
    import logging
    log = logging.getLogger("backtester")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s backtester: %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(os.path.join(DATA_DIR, "backtests"), exist_ok=True)

@dataclass
class TradeRecord:
    ts_open: float
    ts_close: Optional[float]
    symbol: str
    side: str
    entry_price: float
    exit_price: Optional[float]
    qty: float
    amount_usd: float
    pnl: Optional[float]
    fees: float
    slippage: float
    status: str = "OPEN"
    notes: str = ""

    def to_dict(self):
        return {k: (v.isoformat() if isinstance(v, datetime) else v) for k,v in self.__dict__.items()}

class BacktesterPRO:
    def __init__(self,
                 initial_capital: float = 1000.0,
                 fee_pct: float = 0.00075,
                 slippage_pct: float = 0.0005,
                 min_trade_usd: float = 10.0,
                 results_dir: str = os.path.join(DATA_DIR, "backtests")):
        self.initial_capital = float(initial_capital)
        self.fee_pct = float(fee_pct)
        self.slippage_pct = float(slippage_pct)
        self.min_trade_usd = float(min_trade_usd)
        self.results_dir = results_dir
        os.makedirs(self.results_dir, exist_ok=True)

        self.reset_state()
        log.info("BacktesterPRO initialized with capital=%s", self.initial_capital)

    def reset_state(self):
        self.cash = float(self.initial_capital)
        self.open_positions: Dict[str, TradeRecord] = {}  # key -> position (accumulated)
        self.closed_trades: List[TradeRecord] = []
        self.equity_ts: List[float] = []
        self.equity_vals: List[float] = []

    @staticmethod
    def _ts_to_dt(ts):
        if isinstance(ts, (int,float)):
            return pd.to_datetime(ts, unit="s")
        return pd.to_datetime(ts)

    # -------------------------
    # run_from_signals: additive DCA (each signal opens/adds to the same position per symbol/side)
    # -------------------------
    def run_from_signals(self,
                         candles: pd.DataFrame,
                         signals: List[Dict[str, Any]],
                         dca_steps: int = 1,
                         stop_loss_pct: Optional[float] = None,
                         take_profit_pct: Optional[float] = None,
                         size_mode: str = "fixed",
                         size_value: float = 25.0,
                         verbose: bool = False) -> Dict[str, Any]:
        """
        - DCA behavior: successive steps for same signal accumulate into open position per (symbol,side).
        - Positions remain open until TP/SL hit (searches forward). If no TP/SL, closes at last available close.
        """

        df = candles.copy().reset_index(drop=True)
        if "time" not in df.columns:
            raise ValueError("candles must include 'time' column (datetime-like)")
        df["time"] = pd.to_datetime(df["time"])
        df = df.sort_values("time").reset_index(drop=True)

        # reset run state
        self.reset_state()

        signals_sorted = sorted(signals, key=lambda s: float(pd.to_datetime(s.get("ts", s.get("time", datetime.utcnow()))).timestamp()))
        log.info("Backtest run_from_signals on %d signals", len(signals_sorted))

        for sig in signals_sorted:
            try:
                sig_ts = float(pd.to_datetime(sig.get("ts", sig.get("time", datetime.utcnow()))).timestamp())
                sig_dt = pd.to_datetime(sig_ts, unit="s")
                symbol = sig.get("symbol", "UNKNOWN")
                side = (sig.get("side", "BUY") or "BUY").upper()
                # find entry index
                idx_candidates = df.index[df["time"] >= sig_dt]
                if len(idx_candidates) == 0:
                    if verbose: log.debug("Signal beyond last candle - skip")
                    continue
                idx = int(idx_candidates[0])
                entry_price = float(df.loc[idx, "close"])

                # sizing
                if size_mode == "fixed":
                    total_amount = float(sig.get("amount_usd", size_value))
                else:
                    pct = float(sig.get("pct", size_value))
                    total_amount = max(self.min_trade_usd, self.cash * pct)

                if total_amount < self.min_trade_usd:
                    if verbose: log.debug("Amount < min; skipping")
                    continue

                per_step = total_amount / max(1, int(dca_steps))
                for step in range(int(dca_steps)):
                    # compute slippage and effective price
                    slippage = entry_price * self.slippage_pct
                    eff_price = entry_price + (slippage if side=="BUY" else -slippage)
                    qty = per_step / eff_price
                    fees = per_step * self.fee_pct

                    # deduct cash (we simulate opening position by converting USD to asset)
                    self.cash -= (per_step + fees)
                    key = f"{symbol}__{side}"

                    # accumulate into open position
                    if key in self.open_positions:
                        pos = self.open_positions[key]
                        # weighted average entry price
                        new_qty = pos.qty + qty
                        new_entry = (pos.entry_price * pos.qty + eff_price * qty) / new_qty if new_qty>0 else eff_price
                        pos.qty = new_qty
                        pos.entry_price = new_entry
                        pos.amount_usd += per_step
                        pos.fees += fees
                        pos.slippage += abs(slippage * qty)
                        pos.notes = "DCA_added"
                    else:
                        pos = TradeRecord(
                            ts_open=sig_ts,
                            ts_close=None,
                            symbol=symbol,
                            side=side,
                            entry_price=eff_price,
                            exit_price=None,
                            qty=qty,
                            amount_usd=per_step,
                            pnl=None,
                            fees=fees,
                            slippage=abs(slippage * qty),
                            status="OPEN",
                            notes="DCA_start"
                        )
                        self.open_positions[key] = pos

                # after adding, attempt to resolve TP/SL by scanning forward
                self._attempt_close_positions(df, idx, stop_loss_pct, take_profit_pct, symbol, verbose=verbose)

                # snapshot equity
                self._record_equity(sig_ts)

            except Exception as e:
                log.exception("Error processing signal %s: %s", sig, e)

        # at end, close remaining open positions at last close
        last_ts = float(df["time"].iloc[-1].timestamp())
        for key,pos in list(self.open_positions.items()):
            # find last close price
            last_price = float(df["close"].iloc[-1])
            self._close_position_force(key, last_price, float(df["time"].iloc[-1].timestamp()), note="end_of_data")

        self._record_equity(datetime.utcnow().timestamp())

        trades_df = pd.DataFrame([t.to_dict() for t in self.closed_trades])
        equity_df = pd.DataFrame({"time": pd.to_datetime(self.equity_ts, unit="s"), "equity": self.equity_vals}).sort_values("time")
        metrics = self.compute_metrics(trades_df, equity_df)
        return {"trades_df": trades_df, "equity_df": equity_df, "metrics": metrics}

    def _attempt_close_positions(self, df: pd.DataFrame, start_idx: int,
                                 stop_loss_pct: Optional[float], take_profit_pct: Optional[float],
                                 symbol_filter: Optional[str] = None, verbose: bool=False):
        # scan forward from start_idx+1 to detect TP/SL for any open positions
        for j in range(start_idx+1, len(df)):
            r = df.loc[j]
            high, low = float(r["high"]), float(r["low"])
            ts = float(r["time"].timestamp())
            for key,pos in list(self.open_positions.items()):
                if symbol_filter and not key.startswith(symbol_filter):
                    continue
                side = pos.side
                entry = pos.entry_price
                closed = False
                if take_profit_pct is not None:
                    if side=="BUY":
                        tp = entry*(1+take_profit_pct)
                        if high >= tp:
                            self._close_position_force(key, tp, ts, note="tp_hit")
                            closed = True
                    else:
                        tp = entry*(1-take_profit_pct)
                        if low <= tp:
                            self._close_position_force(key, tp, ts, note="tp_hit")
                            closed = True
                if closed:
                    continue
                if stop_loss_pct is not None:
                    if side=="BUY":
                        sl = entry*(1-stop_loss_pct)
                        if low <= sl:
                            self._close_position_force(key, sl, ts, note="sl_hit")
                    else:
                        sl = entry*(1+stop_loss_pct)
                        if high >= sl:
                            self._close_position_force(key, sl, ts, note="sl_hit")

    def _close_position_force(self, key: str, exit_price: float, ts_close: float, note: str="forced_close"):
        pos = self.open_positions.pop(key, None)
        if not pos:
            return
        exit_fees = abs(exit_price*pos.qty) * self.fee_pct
        gross = (exit_price - pos.entry_price) * pos.qty if pos.side=="BUY" else (pos.entry_price - exit_price) * pos.qty
        pnl = gross - (pos.fees + exit_fees)
        # return USD to cash from asset sale
        self.cash += (exit_price * pos.qty) - exit_fees
        pos.exit_price = exit_price
        pos.ts_close = ts_close
        pos.pnl = pnl
        pos.fees += exit_fees
        pos.status = "CLOSED"
        pos.notes = note
        self.closed_trades.append(pos)

    def _record_equity(self, ts: float):
        # equity = cash + mark-to-market of open positions (approx using entry price -> conservative)
        mtm = 0.0
        for pos in self.open_positions.values():
            mtm += pos.qty * pos.entry_price
        equity = float(self.cash + mtm)
        self.equity_ts.append(float(ts))
        self.equity_vals.append(float(equity))

    @staticmethod
    def compute_metrics(trades_df: pd.DataFrame, equity_df: pd.DataFrame) -> Dict[str, Any]:
        if trades_df is None or trades_df.empty:
            return {"total_trades": 0, "net_profit": 0.0, "winrate": 0.0, "cagr":0.0, "sharpe":0.0, "max_drawdown":0.0}
        pnl = trades_df["pnl"].astype(float)
        wins = pnl[pnl>0]; losses = pnl[pnl<=0]
        total = len(pnl)
        net = pnl.sum()
        winrate = len(wins)/total if total else 0.0
        avg_win = wins.mean() if not wins.empty else 0.0
        avg_loss = losses.mean() if not losses.empty else 0.0
        pf = abs(wins.sum()/losses.sum()) if losses.sum()!=0 else float("inf")
        expectancy = pnl.mean()
        # equity metrics (simple)
        if equity_df is None or equity_df.empty:
            return {"total_trades":total, "net_profit":float(net), "winrate":float(winrate*100), "avg_win":avg_win, "avg_loss":avg_loss, "profit_factor":pf, "expectancy":expectancy, "cagr":0.0, "sharpe":0.0, "max_drawdown":0.0}
        eq = equity_df.sort_values("time").reset_index(drop=True)
        vals = eq["equity"].astype(float).values
        returns = np.diff(vals) / (vals[:-1] + 1e-9) if len(vals)>1 else np.array([0.0])
        sharpe = (np.mean(returns) / (np.std(returns)+1e-9)) * math.sqrt(252) if len(returns)>1 else 0.0
        t0 = pd.to_datetime(eq.loc[0,"time"]); t1 = pd.to_datetime(eq.loc[len(eq)-1,"time"])
        years = max(1e-9, (t1 - t0).total_seconds()/(365.25*24*3600))
        start = float(eq.loc[0,"equity"]); end = float(eq.loc[len(eq)-1,"equity"])
        cagr = (end/start)**(1.0/years)-1.0 if start>0 else 0.0
        # max drawdown
        peak = -1e18; maxdd=0.0
        for v in vals:
            peak = max(peak, v)
            dd = (peak - v) / (peak + 1e-9)
            maxdd = max(maxdd, dd)
        return {"total_trades":int(total),"net_profit":float(round(net,6)),"winrate":float(round(winrate*100,2)),"avg_win":float(round(avg_win,6)),"avg_loss":float(round(avg_loss,6)),"profit_factor":float(round(pf,4) if np.isfinite(pf) else float("inf")),"expectancy":float(round(expectancy,6)),"cagr":float(round(cagr,6)),"sharpe":float(round(sharpe,6)),"max_drawdown":float(round(maxdd,6))}

    # -------------------------
    # Streamlit helper: plot equity & drawdown (plotly)
    # -------------------------
    def plot_equity(self, equity_df: pd.DataFrame, title="Equity Curve"):
        import plotly.graph_objects as go
        if equity_df is None or equity_df.empty:
            fig = go.Figure(); fig.update_layout(title="No Equity Data", template="plotly_dark"); return fig
        fig = go.Figure(); fig.add_trace(go.Scatter(x=equity_df["time"], y=equity_df["equity"], name="Equity", mode="lines"))
        fig.update_layout(title=title, template="plotly_dark", xaxis_title="Time", yaxis_title="Equity (USD)", height=420)
        return fig

    def plot_drawdown(self, equity_df: pd.DataFrame, title="Drawdown"):
        import plotly.graph_objects as go
        if equity_df is None or equity_df.empty:
            return go.Figure()
        eq = equity_df.sort_values("time").reset_index(drop=True)
        vals = eq["equity"].astype(float).values
        peak=-1e18; dd=[]
        for v in vals:
            peak = max(peak, v); dd.append((peak-v)/(peak+1e-9))
        fig=go.Figure(); fig.add_trace(go.Scatter(x=eq["time"], y=dd, name="Drawdown", mode="lines")); fig.update_layout(title=title, template="plotly_dark", height=300); return fig

    # optional: save result file
    def save_report(self, trades_df: pd.DataFrame, equity_df: pd.DataFrame, prefix="backtest"):
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        fname = os.path.join(self.results_dir, f"{prefix}_{ts}.json")
        payload = {"ts": datetime.utcnow().isoformat(), "metrics": self.compute_metrics(trades_df, equity_df), "trades": trades_df.to_dict(orient="records"), "equity": equity_df.to_dict(orient="records")}
        try:
            with open(fname, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2, default=str)
            log.info("Saved backtest report %s", fname)
            return fname
        except Exception:
            log.exception("Failed to save backtest report")
            return None
