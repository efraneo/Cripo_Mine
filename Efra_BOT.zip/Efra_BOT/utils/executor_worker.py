# utils/executor_worker.py
# ===============================================================
# Worker que consume ORDER_QUEUE y ejecuta órdenes.
# Con backoff, retries, logs y alertas.
# ===============================================================

import threading
import time
import traceback

from utils.execution_queue import ORDER_QUEUE
from backend.log_manager import get_logger

try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except:
    telegram_send = None

try:
    from backend.trading_engine import get_engine_singleton
    ENGINE = get_engine_singleton()()
except:
    ENGINE = None

log = get_logger("executor")

class ExecutorWorker(threading.Thread):
    def __init__(self, daemon=True, retry_wait=3, max_retries=5):
        super().__init__(daemon=daemon)
        self.retry_wait = retry_wait
        self.max_retries = max_retries
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        log.info("ExecutorWorker iniciado…")

        while not self._stop:
            try:
                order = ORDER_QUEUE.get(timeout=1)
            except:
                continue

            self._execute(order)

    def _execute(self, order):
        symbol = order["symbol"]
        side = order["side"]
        amount = order["amount"]
        user = order["usuario"]

        for attempt in range(1, self.max_retries+1):
            try:
                log.info("Ejecutando → %s %s $%.2f (try %s)", symbol, side, amount, attempt)

                if ENGINE and hasattr(ENGINE, "ejecutar_compound_order"):

                    result = ENGINE.ejecutar_compound_order(
                        usuario=user,
                        symbol=symbol,
                        side=side,
                        total_amount_usdt=amount,
                        steps=1,
                        modo="REAL"
                    )

                    log.info("Orden ejecutada %s -> %s", symbol, str(result)[:150])

                    if telegram_send:
                        telegram_send(f"✔ Orden ejecutada\n{symbol} {side}\n$ {amount}\n{str(result)[:150]}")

                    return result

                else:
                    raise Exception("ENGINE no disponible")

            except Exception as e:
                log.error("Error ejecutando orden: %s", e)
                time.sleep(self.retry_wait)

        # Si llegó aquí → falló todo
        log.error("FATAL: No se pudo ejecutar orden %s después de retries.", symbol)

        if telegram_send:
            telegram_send(f"❌ FATAL: No se pudo ejecutar orden {symbol} (worker agoto retries)")

        return None
