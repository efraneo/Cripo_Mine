# utils/dataset_builder.py
"""
Dataset Builder for AutoML
--------------------------
Lee data/signals_log.jsonl (o cualquier JSONL con estructura parecida)
y genera datasets listos para entrenar (parquet) en utils/datasets/.

Principio de etiquetado (label):
 - Para cada fila (por símbolo), buscamos el primer registro posterior
   con timestamp >= ts + horizon_minutes.
 - Si future_close >= close*(1 + min_return) => label=1 (ganancia)
   else label=0.
 - Esto crea una tarea binaria simple que tu AutoML puede usar.

Funciones principales:
 - build_datasets_from_signals(...)
 - build_single_dataset(...)
 - concat_all_datasets(...)
 - quick_preview(...)

Uso:
  python -m utils.dataset_builder    # ejecuta main() (configurable)
  >>> from utils.dataset_builder import build_datasets_from_signals
  >>> build_datasets_from_signals("data/signals_log.jsonl", horizon_minutes=10)

Requisitos:
  pandas, pyarrow (para parquet)
"""

from __future__ import annotations
import os
import json
import time
import math
from typing import List, Dict, Any, Optional, Tuple

import pandas as pd
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASETS_DIR = os.path.join(BASE_DIR, "datasets")
os.makedirs(DATASETS_DIR, exist_ok=True)

# Default paths (tu SignalsEngine escribe aquí)
DEFAULT_SIGNALS_JSONL = os.path.join(os.getcwd(), "data", "signals_log.jsonl")

# -------------------------
# Helpers
# -------------------------
def _read_jsonl(path: str) -> List[Dict[str, Any]]:
    rows = []
    if not os.path.exists(path):
        return rows
    with open(path, "r", encoding="utf-8") as fh:
        for ln in fh:
            ln = ln.strip()
            if not ln:
                continue
            try:
                rows.append(json.loads(ln))
            except Exception:
                # skip corrupt lines silently (or log externally)
                continue
    return rows

def _ensure_numeric_series(d: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convierte valores a float cuando sea posible, evita NaNs.
    Mantiene campos no numéricos en su lugar.
    """
    out = {}
    for k, v in d.items():
        if v is None:
            out[k] = 0.0
            continue
        if isinstance(v, (int, float, bool)):
            out[k] = float(v)
            continue
        # try parse numeric strings
        try:
            out[k] = float(v)
            continue
        except Exception:
            out[k] = v
    return out

# -------------------------
# Core: construir dataset a partir de signals_jsonl
# -------------------------
def build_single_dataset(
    signals_jsonl: str = DEFAULT_SIGNALS_JSONL,
    symbol: Optional[str] = None,
    horizon_minutes: int = 10,
    min_return: float = 0.001,
    drop_na_features: bool = True
) -> pd.DataFrame:
    """
    Construye un DataFrame etiquetado a partir de signals_log.jsonl

    Args:
      signals_jsonl: ruta al jsonl con señales
      symbol: si se especifica, filtra por símbolo (e.g. 'BTCUSDT')
      horizon_minutes: horizonte para evaluar el precio futuro (minutos)
      min_return: retorno mínimo relativo para considerar label=1 (ej. 0.001 = 0.1%)
      drop_na_features: si True elimina filas sin features

    Returns:
      DataFrame listo para entrenamiento con columna 'target' (0/1) y 'symbol', 'ts', 'close'
    """
    rows = _read_jsonl(signals_jsonl)
    if not rows:
        raise FileNotFoundError(f"No signals found at {signals_jsonl}")

    # normalizar y transformar a DF
    recs = []
    for r in rows:
        # cada r típicamente tiene: ts, symbol, close, features (dict), prob, actions...
        try:
            rec = {
                "ts": float(r.get("ts", time.time())),
                "symbol": r.get("symbol", None),
                "close": float(r.get("close", 0.0)),
                "prob": float(r.get("prob", 0.0))
            }
            # extraer features si existen
            feats = r.get("features") or r.get("features_used") or {}
            # ensure numeric conversion where possible
            feats = _ensure_numeric_series(feats)
            # flatten features into top-level keys with prefix "f_"
            for fk, fv in feats.items():
                # avoid name collisions
                key = fk if fk not in rec else f"f_{fk}"
                rec[key] = fv
            recs.append(rec)
        except Exception:
            continue

    df = pd.DataFrame(recs)
    if df.empty:
        raise ValueError("No usable rows extracted from signals jsonl")

    # optional symbol filter
    if symbol:
        df = df[df["symbol"] == symbol.upper()].copy()
        if df.empty:
            raise ValueError(f"No rows for symbol {symbol}")

    # sort by time per symbol
    df["ts"] = pd.to_numeric(df["ts"]).astype(float)
    df = df.sort_values(["symbol", "ts"]).reset_index(drop=True)

    # Build quick index per symbol for fast future lookup
    all_dfs = []
    for sym, grp in df.groupby("symbol"):
        grp = grp.reset_index(drop=True)
        times = grp["ts"].values  # float seconds
        closes = grp["close"].values
        # compute target index for horizon
        # for each i, find j = first index with times[j] >= times[i] + horizon_seconds
        horizon_s = horizon_minutes * 60
        future_close = np.full(len(grp), np.nan)
        for i, t in enumerate(times):
            target_t = t + horizon_s
            # find earliest j with times[j] >= target_t
            j = np.searchsorted(times, target_t, side="left")
            if j < len(times):
                future_close[i] = closes[j]
            else:
                # no future available -> leave NaN (will be dropped)
                future_close[i] = np.nan

        grp["future_close"] = future_close
        # compute relative return
        grp["future_return"] = (grp["future_close"] / grp["close"]) - 1.0
        # label
        grp["target"] = (grp["future_return"] >= float(min_return)).astype(int)
        all_dfs.append(grp)

    df_labeled = pd.concat(all_dfs, ignore_index=True)
    # drop rows without future (can't label)
    df_labeled = df_labeled.dropna(subset=["future_close"])

    # drop feature columns that are non-numeric if requested
    if drop_na_features:
        numcols = [c for c in df_labeled.columns if df_labeled[c].dtype.kind in "fi"]
        # keep target, ts, symbol, close also
        keep = set(numcols) | {"target", "ts", "symbol", "close", "prob", "future_return"}
        df_labeled = df_labeled[[c for c in df_labeled.columns if c in keep]]

    # reset index
    df_labeled = df_labeled.reset_index(drop=True)
    return df_labeled

# -------------------------
# Guardar dataset en parquet (por mes o por fecha)
# -------------------------
def save_dataset(df: pd.DataFrame, prefix: str = "data", monthly: bool = True) -> str:
    """
    Guarda df como parquet en utils/datasets/
    Si monthly=True: archivo utils/datasets/<prefix>_YYYY_MM.parquet
    else: utils/datasets/<prefix>_YYYYMMDD_HHMM.parquet
    Devuelve path escrito.
    """
    if df.empty:
        raise ValueError("Empty dataframe; nothing to save")

    now = pd.Timestamp.utcnow()
    if monthly:
        fname = f"{prefix}_{now.year}_{now.month:02d}.parquet"
    else:
        fname = f"{prefix}_{now.strftime('%Y%m%d_%H%M%S')}.parquet"

    path = os.path.join(DATASETS_DIR, fname)
    # If file exists, append by reading existing and concat (safer)
    if os.path.exists(path):
        try:
            existing = pd.read_parquet(path)
            combined = pd.concat([existing, df], ignore_index=True)
            combined.to_parquet(path, index=False)
            return path
        except Exception:
            # fallback overwrite
            df.to_parquet(path, index=False)
            return path
    else:
        df.to_parquet(path, index=False)
        return path

# -------------------------
# Utility: concatar todos los datasets en uno (para training)
# -------------------------
def concat_all_datasets() -> pd.DataFrame:
    files = [os.path.join(DATASETS_DIR, f) for f in os.listdir(DATASETS_DIR) if f.endswith(".parquet")]
    if not files:
        return pd.DataFrame()
    dfs = []
    for f in files:
        try:
            dfs.append(pd.read_parquet(f))
        except Exception:
            continue
    if not dfs:
        return pd.DataFrame()
    return pd.concat(dfs, ignore_index=True)

# -------------------------
# Quick preview helper
# -------------------------
def quick_preview(signals_jsonl: str = DEFAULT_SIGNALS_JSONL, n=10):
    rows = _read_jsonl(signals_jsonl)
    print(f"Total lines read: {len(rows)}")
    if not rows:
        return
    sample = rows[-n:]
    for s in sample:
        print(json.dumps(s, ensure_ascii=False, indent=2))

# -------------------------
# Top-level builder
# -------------------------
def build_datasets_from_signals(
    signals_jsonl: str = DEFAULT_SIGNALS_JSONL,
    horizon_minutes: int = 10,
    min_return: float = 0.001,
    monthly: bool = True,
    symbol: Optional[str] = None,
    drop_na_features: bool = True
) -> str:
    """
    Conveniencia: construye dataset etiquetado y lo guarda (parquet).
    Retorna path del archivo creado.
    """
    df = build_single_dataset(signals_jsonl=signals_jsonl,
                              symbol=symbol,
                              horizon_minutes=horizon_minutes,
                              min_return=min_return,
                              drop_na_features=drop_na_features)
    path = save_dataset(df, prefix="signals", monthly=monthly)
    return path

# -------------------------
# Script entry (CLI)
# -------------------------
def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--signals", default=DEFAULT_SIGNALS_JSONL)
    p.add_argument("--horizon", type=int, default=10)
    p.add_argument("--min_return", type=float, default=0.001)
    p.add_argument("--monthly", action="store_true", default=True)
    p.add_argument("--symbol", default=None)
    args = p.parse_args()

    print("Building dataset from", args.signals)
    out = build_datasets_from_signals(signals_jsonl=args.signals,
                                      horizon_minutes=args.horizon,
                                      min_return=args.min_return,
                                      monthly=args.monthly,
                                      symbol=args.symbol)
    print("Saved dataset: ", out)

if __name__ == "__main__":
    main()
