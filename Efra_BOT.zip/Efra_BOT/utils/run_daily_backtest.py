# utils/run_daily_backtest.py
"""
Run daily backtests reading data/signals_log.jsonl
Intended to be called from cron or systemd timer.
"""

import os, json, time
import pandas as pd
from utils.backtester_pro import BacktesterPRO

SIGNALS = "data/signals_log.jsonl"
CANDLES_CACHE = "data/candles_cache_last.csv"  # optional: if you have pre-downloaded candles
OUT_DIR = "data/backtests"

def load_signals(path=SIGNALS):
    if not os.path.exists(path):
        return []
    sigs=[]
    with open(path,"r",encoding="utf-8") as fh:
        for line in fh:
            try:
                sigs.append(json.loads(line))
            except:
                continue
    return sigs

def load_candles():
    # try cache, else abort (you should provide a candles df)
    if os.path.exists(CANDLES_CACHE):
        df = pd.read_csv(CANDLES_CACHE)
        df["time"] = pd.to_datetime(df["time"])
        return df
    else:
        raise RuntimeError("Candles cache not found: " + CANDLES_CACHE)

def main():
    sigs = load_signals()
    if not sigs:
        print("No signals found.")
        return
    candles = load_candles()
    bt = BacktesterPRO(initial_capital=1000.0)
    out = bt.run_from_signals(candles, sigs, dca_steps=1, stop_loss_pct=0.02, take_profit_pct=0.03)
    trades_df = out["trades_df"]; equity_df = out["equity_df"]; metrics = out["metrics"]
    fname = bt.save_report(trades_df, equity_df, prefix="daily_backtest")
    print("Saved", fname, "metrics:", metrics)

if __name__ == "__main__":
    main()
