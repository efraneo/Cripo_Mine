# utils/build_features_from_parquet.py
# ============================================================
# Generador MASTER de features desde parquet
# ============================================================

import pandas as pd
import os
from feature_builder_pro import build_feature_set


PARQUET_IN = "utils/datasets/signals_2025_12.parquet"
OUT_DIR = "utils/datasets/features/"


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    print(f"📥 Cargando parquet: {PARQUET_IN}")
    df = pd.read_parquet(PARQUET_IN)

    print("⚙️ Generando FEATURE SET PRO (40+ features)...")
    feat = build_feature_set(df)

    print("📊 Shape final:", feat.shape)

    out_parquet = os.path.join(OUT_DIR, "features_2025_12.parquet")
    feat.to_parquet(out_parquet)

    out_csv = os.path.join(OUT_DIR, "features_2025_12.csv")
    feat.to_csv(out_csv, index=False)

    print(f"✔ Saved parquet → {out_parquet}")
    print(f"✔ Saved csv → {out_csv}")

    print("\n🎉 FEATURE SET PRO listo para AutoML PRO 🎉")


if __name__ == "__main__":
    main()
