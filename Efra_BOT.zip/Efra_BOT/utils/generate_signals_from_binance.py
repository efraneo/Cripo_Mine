# utils/generate_signals_from_binance.py
# ===============================================================
# Genera 5.000 señales realistas usando datos OHLCV reales
# de Binance (REST Klines) y las guarda como signals_log.jsonl
#
# Formato 100% compatible con tu SignalsEngine y dataset_builder.
# ===============================================================

import requests
import time
import json
import os
import numpy as np
import pandas as pd

OUT_FILE = os.path.join("data", "signals_log.jsonl")
os.makedirs("data", exist_ok=True)

# ---------------------------------------------------------------
# Binance API REST (pública)
# ---------------------------------------------------------------
def get_klines(symbol="BTCUSDT", interval="1m", limit=1000):
    url = (
        f"https://api.binance.com/api/v3/klines?"
        f"symbol={symbol}&interval={interval}&limit={limit}"
    )
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    data = r.json()
    rows = []
    for k in data:
        rows.append({
            "open_time": k[0],
            "open": float(k[1]),
            "high": float(k[2]),
            "low": float(k[3]),
            "close": float(k[4]),
            "volume": float(k[5]),
            "close_time": k[6]
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------
# ATR (simple)
# ---------------------------------------------------------------
def compute_atr(df, period=14):
    df = df.copy()
    df["h-l"] = df["high"] - df["low"]
    df["h-pc"] = np.abs(df["high"] - df["close"].shift())
    df["l-pc"] = np.abs(df["low"] - df["close"].shift())
    df["tr"] = df[["h-l", "h-pc", "l-pc"]].max(axis=1)
    df["atr"] = df["tr"].rolling(period).mean()
    return df["atr"]


# ---------------------------------------------------------------
# Generar señal sintética realista
# ---------------------------------------------------------------
def generate_signal(row):
    close = row["close"]
    open_ = row["open"]

    # probabilidad IA sintética (realista)
    direction = close - open_
    base = np.clip(abs(direction) / (close * 0.002), 0, 1)
    prob = 0.5 + (base * 0.5 * np.sign(direction))

    action = None
    if prob >= 0.80:
        action = ("IA_BUY", f"prob={prob:.3f}")
    elif prob <= 0.20:
        action = ("IA_SELL", f"prob={prob:.3f}")
    else:
        action = None

    return prob, action


# ---------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------
def main():
    print("📌 Descargando datos desde Binance...")
    df = get_klines("BTCUSDT", "1m", 1000)

    # duplicamos hasta 5000 señales
    df = pd.concat([df] * 5, ignore_index=True).head(5000)

    df["atr"] = compute_atr(df)
    df["atr_rel"] = df["atr"] / df["close"]

    print("📌 Generando señales realistas...")
    with open(OUT_FILE, "w", encoding="utf-8") as f:
        for _, row in df.iterrows():
            prob, ia_action = generate_signal(row)

            payload = {
                "ts": row["close_time"] / 1000.0,
                "symbol": "BTCUSDT",
                "interval": "1m",
                "close": row["close"],
                "atr": float(row["atr"]) if not pd.isna(row["atr"]) else 0.0,
                "atr_rel": float(row["atr_rel"]) if not pd.isna(row["atr_rel"]) else 0.0,
                "prob": float(prob),
                "actions": [ia_action] if ia_action else [],
                "features": {
                    "open": row["open"],
                    "high": row["high"],
                    "low": row["low"],
                    "close": row["close"],
                    "volume": row["volume"]
                }
            }

            f.write(json.dumps(payload, ensure_ascii=False) + "\n")

    print(f"✔ Archivo generado: {OUT_FILE}")
    print("✔ Total señales:", len(df))


if __name__ == "__main__":
    main()
