import json
import pickle
import numpy as np
import pandas as pd
import lightgbm as lgb
import xgboost as xgb
import os

MODEL_PATH = "models/best_model.pkl"
FEATURES_PATH = "models/feature_list.json"


class MLModel:
    def __init__(self):
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError("No se encontró models/best_model.pkl")

        if not os.path.exists(FEATURES_PATH):
            raise FileNotFoundError("No se encontró models/feature_list.json")

        with open(MODEL_PATH, "rb") as f:
            self.model = pickle.load(f)

        with open(FEATURES_PATH, "r") as f:
            self.features = json.load(f)

        self.is_lgb = isinstance(self.model, lgb.Booster)
        self.is_xgb = isinstance(self.model, xgb.Booster)

    def predict_proba(self, feature_dict: dict) -> float:
        """Recibe tu vector de features crudos y devuelve probabilidad real."""

        row = [feature_dict.get(f, np.nan) for f in self.features]
        X = pd.DataFrame([row], columns=self.features)

        if self.is_lgb:
            p = self.model.predict(X)[0]
        elif self.is_xgb:
            d = xgb.DMatrix(X)
            p = float(self.model.predict(d)[0])
        else:
            raise Exception("Modelo no reconocido")

        return float(p)
