# utils/health_monitor.py
"""
Health Monitor PRO — chequeos periódicos + AutoML automático.
Ejecuta en background, NOTIFICA via telegram_notifier.enviar_mensaje
y nunca ejecuta nada al importarse.

Incluye:
- Chequeo NTP
- Chequeo latencia Binance
- Chequeo tamaños de logs
- Chequeo de motor
- ENTRENAMIENTO AUTOMÁTICO de modelos cada X ciclos
"""

import threading
import time
import os
from datetime import datetime

# Logger PRO
try:
    from backend.log_manager import get_logger
    log = get_logger("health")
except Exception:
    import logging
    log = logging.getLogger("health")
    if not log.handlers:
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s health: %(message)s"))
        log.addHandler(ch)
    log.setLevel(logging.INFO)

# Telegram
try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

# NTP
try:
    import ntplib
except Exception:
    ntplib = None

# AutoML (tu sistema personalizado)
from utils.automl_manager import automl_train


class HealthMonitor(threading.Thread):
    """
    Hilo que corre cada interval_sec segundos.
    Incluye:
    - chequeos constantes
    - entrenamiento AutoML cada N ciclos
    """

    def __init__(
        self,
        engine=None,
        interval_sec: int = 600,  # 600s = 10 minutos
        log_dir: str = "logs",
        max_log_mb: float = 200.0,
        train_every: int = 12     # 12 ciclos × 600s = 7200s = 2 horas
    ):
        """
        train_every=12 → cada 12 ciclos (si cada ciclo = 10 minutos → entrena cada 2h)
        Puedes ajustar libremente.
        """
        super().__init__(daemon=True)
        self.engine = engine
        self.interval = interval_sec
        self.log_dir = log_dir
        self.max_log_mb = max_log_mb
        self.train_every = train_every
        self._stop = threading.Event()

        # Contador para entrenamiento
        self.counter = 0

    def stop(self):
        self._stop.set()

    # -------------------------
    # HILO PRINCIPAL
    # -------------------------
    def run(self):
        log.info("HealthMonitor PRO iniciado (interval=%ss, entrenamiento cada %d ciclos)",
                 self.interval, self.train_every)

        if telegram_send:
            telegram_send("🟢 HealthMonitor PRO iniciado")

        while not self._stop.is_set():
            try:
                self._run_cycle()
            except Exception as e:
                log.exception("Error en ciclo HealthMonitor")
                if telegram_send:
                    telegram_send("f⚠️ Error HealthMonitor: {e}")
            time.sleep(self.interval)

        log.info("HealthMonitor detenido.")
        if telegram_send:
            telegram_send("🔴 HealthMonitor detenido")

    # -------------------------
    # CICLO COMPLETO
    # -------------------------
    def _run_cycle(self):
        self.counter += 1
        log.info("HealthMonitor ciclo #%d", self.counter)

        self.check_ntp()
        self.check_binance_latency()
        self.check_log_sizes()
        self.check_engine()

        # Entrenamiento automático
        if self.counter % self.train_every == 0:
            self.run_automl_training()

    # -------------------------
    # CHEQUEOS
    # -------------------------
    def check_ntp(self):
        if ntplib is None:
            log.debug("NTP no disponible")
            return

        try:
            c = ntplib.NTPClient()
            r = c.request("time.google.com", version=3)
            offset = r.tx_time - time.time()

            if abs(offset) > 1.0:
                msg = f"NTP offset alto: {offset:.3f}s"
                log.warning(msg)
                if telegram_send:
                    telegram_send(f"⚠️ {msg}")

        except Exception:
            log.debug("Fallo chequeo NTP")

    def check_binance_latency(self):
        try:
            if self.engine and hasattr(self.engine, "data_client") and self.engine.data_client:
                t0 = time.time()
                self.engine.data_client.get_server_time()
                latency = time.time() - t0

                if latency > 1.5:
                    msg = f"Binance latency alta: {latency:.3f}s"
                    log.warning(msg)
                    if telegram_send:
                        telegram_send(f"⚠️ {msg}")

        except Exception:
            log.debug("Fallo chequeo de latencia Binance")

    def check_log_sizes(self):
        try:
            if not os.path.isdir(self.log_dir):
                return
            for fname in os.listdir(self.log_dir):
                fpath = os.path.join(self.log_dir, fname)
                if os.path.isfile(fpath):
                    size_mb = os.path.getsize(fpath) / (1024 * 1024)
                    if size_mb > self.max_log_mb:
                        msg = f"Log {fname} excede tamaño: {size_mb:.1f}MB"
                        log.warning(msg)
                        if telegram_send:
                            telegram_send(f"⚠️ {msg}")
        except Exception:
            log.debug("Fallo chequeo tamaño logs")

    def check_engine(self):
        try:
            if self.engine and hasattr(self.engine, "get_ticker_price"):
                p = self.engine.get_ticker_price("BTCUSDT")
                if p is None:
                    msg = "Engine get_ticker_price devolvió None"
                    log.warning(msg)
        except Exception:
            log.debug("Engine health check failed")

    # -------------------------
    # ENTRENAMIENTO AUTOMÁTICO PRO
    # -------------------------
    def run_automl_training(self):
        log.info("Ejecutando entrenamiento AutoML...")
        if telegram_send:
            telegram_send("🤖 Entrenando nuevo modelo IA (AutoML)...")

        try:
            result = automl_train()

            version = result.get("version", "???")
            auc = result.get("auc", 0.0)

            msg = (
                f"🤖 Nuevo modelo entrenado:\n"
                f"🆕 Versión: {version}\n"
                f"📈 AUC: {auc:.4f}\n"
                f"🕒 {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}"
            )

            log.info(msg)
            if telegram_send:
                telegram_send(msg)

        except Exception as e:
            log.exception("Error entrenando modelo")
            if telegram_send:
                telegram_send(f"❌ Error entrenando modelo: {e}")
