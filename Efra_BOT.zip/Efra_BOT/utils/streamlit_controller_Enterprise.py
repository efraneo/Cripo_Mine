# utils/streamlit_controller_Enterprise.py
"""
Streamlit Controller — Enterprise Modular (2025)
------------------------------------------------
Ubicación sugerida: utils/streamlit_controller_Enterprise.py

Características principales:
- Arquitectura modular (EventBus, Connector, WebSocket/SSE server opcional)
- Integración con BotManager (enqueue_execute with on_finish)
- Integración con TelegramNotifier (clase orientada a objetos)
- Cache inteligente y prevención de recálculo (in-memory + TTL)
- Rate limiting / debounce / backpressure
- Session-aware: integra SessionManager si se inyecta
- Hooks para UI (register_ui_hook, push_update)
- Async-safe: usa threads para background polling y ejecución
- Opcional: arranca un servidor ASGI (FastAPI + uvicorn) para WebSockets/SSE
- Diseñado para integrarse con Streamlit front-end (o cualquier frontend)
- No fuerza dependencias; las opcionales son importadas bajo demanda.

USO BÁSICO (Streamlit):
    from utils.streamlit_controller_Enterprise import StreamlitControllerEnterprise
    ctrl = StreamlitControllerEnterprise(bot_manager=BOT, notifier=NOTIFIER, session_manager=SM)
    ctrl.register_ui_hook(my_ui_callback)
    ctrl.start_background_polling()
    # En la UI: ctrl.get_state() / ctrl.execute_trade(...)

NOTA: Este módulo intenta no lanzar un servidor ASGI por defecto. Para habilitar WebSocket/SSE,
pasa enable_asgi=True y asegúrate de tener fastapi & uvicorn instalados en el entorno.

Autor: Assistant (GPT-5 Thinking mini) — versión Enterprise (2025)
"""

from __future__ import annotations

import threading
import time
import json
import uuid
import functools
import queue
import logging
from dataclasses import dataclass, field
from typing import Optional, Callable, Any, Dict, List, Tuple
from datetime import datetime, timedelta

# Optional dependencies (import bajo demanda)
_FASTAPI_AVAIL = False
_UVICORN_AVAIL = False
try:
    import fastapi  # type: ignore
    import uvicorn  # type: ignore
    from fastapi import FastAPI, WebSocket, Request
    from fastapi.responses import StreamingResponse
    _FASTAPI_AVAIL = True
    _UVICORN_AVAIL = True
except Exception:
    _FASTAPI_AVAIL = False

# Logger (si tu repo tiene uno preferido inyecta el logger)
logger = logging.getLogger("st_enterprise")
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
    logger.addHandler(ch)
logger.setLevel(logging.INFO)


# ---------------------------
# Helpers / utilidades
# ---------------------------
def now_iso():
    return datetime.utcnow().isoformat() + "Z"


def ttl_cache(ttl_seconds: int = 5):
    """
    Decorator simple para cache con TTL (in-memory). Útil para evitar recálculos repetidos.
    """
    def deco(fn):
        cache = {}
        lock = threading.Lock()

        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            key = (fn.__name__, args, tuple(sorted(kwargs.items())))
            with lock:
                entry = cache.get(key)
                if entry:
                    ts, val = entry
                    if (time.time() - ts) < ttl_seconds:
                        return val
                val = fn(*args, **kwargs)
                cache[key] = (time.time(), val)
                return val

        def invalidate(*a, **k):
            with lock:
                cache.clear()

        wrapped.invalidate = invalidate  # type: ignore
        return wrapped
    return deco


def debounce(wait_s: float = 0.3):
    """
    Decorator para debouncing simple de llamadas (última llamada pasa).
    """
    def deco(fn):
        lock = threading.Lock()
        last_call = {"timer": None, "args": None, "kwargs": None}

        @functools.wraps(fn)
        def wrapped(*args, **kwargs):
            def _run():
                with lock:
                    a = last_call["args"] or ()
                    k = last_call["kwargs"] or {}
                    last_call["timer"] = None
                    last_call["args"] = None
                    last_call["kwargs"] = None
                try:
                    fn(*a, **k)
                except Exception:
                    logger.exception("Debounced function failed")

            with lock:
                last_call["args"] = args
                last_call["kwargs"] = kwargs
                if last_call["timer"] and last_call["timer"].is_alive():
                    # timer exists -> cancel by just replacing args
                    pass
                else:
                    t = threading.Timer(wait_s, _run)
                    last_call["timer"] = t
                    t.daemon = True
                    t.start()

        return wrapped
    return deco


# ---------------------------
# EventBus (in-process)
# ---------------------------
class EventBus:
    """
    Pub/Sub simple en memoria.
    UI / Workers pueden suscribirse a eventos nombrados.
    """

    def __init__(self):
        self._subs: Dict[str, List[Callable[[Dict[str, Any]], None]]] = {}
        self._lock = threading.Lock()

    def subscribe(self, topic: str, cb: Callable[[Dict[str, Any]], None]):
        with self._lock:
            self._subs.setdefault(topic, []).append(cb)
        logger.debug("Subscribed to %s", topic)

    def unsubscribe(self, topic: str, cb: Callable[[Dict[str, Any]], None]):
        with self._lock:
            if topic in self._subs:
                try:
                    self._subs[topic].remove(cb)
                except ValueError:
                    pass

    def publish(self, topic: str, payload: Dict[str, Any]):
        with self._lock:
            cbs = list(self._subs.get(topic, []))
        logger.debug("Publishing event %s -> %d listeners", topic, len(cbs))
        for cb in cbs:
            try:
                cb(payload)
            except Exception:
                logger.exception("Event handler for %s failed", topic)


# ---------------------------
# ASGI Server (optional)
# ---------------------------
class ASGIServer:
    """
    Encapsula un FastAPI server con endpoints SSE / WebSocket para emitir eventos.
    No se inicia por defecto; usar enable_asgi=True en el controller si quieres.
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 8001, event_bus: Optional[EventBus] = None):
        if not _FASTAPI_AVAIL:
            raise RuntimeError("FastAPI/uvicorn no disponibles in environment.")
        self.host = host
        self.port = port
        self.app = FastAPI()
        self.event_bus = event_bus or EventBus()
        self._ws_clients: List[WebSocket] = []
        self._sse_queues: List[queue.Queue] = []

        @self.app.get("/health")
        async def _health():
            return {"status": "ok", "ts": now_iso()}

        @self.app.websocket("/ws")
        async def _ws_endpoint(ws: WebSocket):
            await ws.accept()
            self._ws_clients.append(ws)
            logger.info("WS client connected")
            try:
                while True:
                    data = await ws.receive_text()
                    # Echo or interpret simple commands if needed
                    await ws.send_text(json.dumps({"echo": data, "ts": now_iso()}))
            except Exception:
                logger.info("WS client disconnected")
            finally:
                try:
                    self._ws_clients.remove(ws)
                except Exception:
                    pass

        @self.app.get("/sse")
        async def _sse(request: Request):
            q = queue.Queue()
            self._sse_queues.append(q)

            def event_stream():
                try:
                    while True:
                        # if client disconnected, break
                        if await_client_disconnected(request):
                            break
                        item = q.get()
                        yield f"data: {json.dumps(item)}\n\n"
                except GeneratorExit:
                    pass
                finally:
                    try:
                        self._sse_queues.remove(q)
                    except Exception:
                        pass

            return StreamingResponse(event_stream(), media_type="text/event-stream")

        # Hook event_bus -> ws/sse
        def _forward(payload):
            # Broadcast to WS & SSE
            js = payload
            # WS (async send is required but we call sync; best-effort)
            for ws in list(self._ws_clients):
                try:
                    # schedule async send
                    import asyncio
                    asyncio.ensure_future(ws.send_text(json.dumps(js)))
                except Exception:
                    logger.debug("WS broadcast failed")
            # SSE
            for q in list(self._sse_queues):
                try:
                    q.put(js, block=False)
                except Exception:
                    pass

        self.event_bus.subscribe("broadcast", _forward)

    def run(self, log_level: str = "info", reload: bool = False):
        if not _UVICORN_AVAIL:
            raise RuntimeError("uvicorn not installed")
        logger.info("Starting ASGI server %s:%d", self.host, self.port)
        uvicorn.run(self.app, host=self.host, port=self.port, log_level=log_level, reload=reload)


async def await_client_disconnected(request):
    """
    Helper para detectar desconexión de cliente SSE.
    Implementación muy simple (fastapi specifics).
    """
    try:
        await request.is_disconnected()
        return True
    except Exception:
        return False


# ---------------------------
# Core Controller
# ---------------------------
@dataclass
class StreamlitControllerEnterprise:
    """
    Controlador Enterprise — inyecta dependencias y expone API para la UI.
    """
    bot_manager: Any  # BotManager (preferible instancia)
    notifier: Any     # TelegramNotifier (clase orientada a objetos)
    session_manager: Optional[Any] = None  # SessionManager opcional
    risk_manager: Optional[Any] = None
    results_manager: Optional[Any] = None
    polling_interval: float = 1.0  # segundos
    enable_asgi: bool = False
    asgi_host: str = "127.0.0.1"
    asgi_port: int = 8001

    # internals
    event_bus: EventBus = field(default_factory=EventBus)
    _state_lock: threading.Lock = field(default_factory=threading.Lock)
    _state: Dict[str, Any] = field(default_factory=dict)
    _background_thread: Optional[threading.Thread] = None
    _stop_event: threading.Event = field(default_factory=threading.Event)
    _asgi_server: Optional[ASGIServer] = None

    def __post_init__(self):
        # state defaults
        self._state.update({
            "last_seen": now_iso(),
            "queue_size": 0,
            "workers": getattr(self.bot_manager, "worker_count", 1) if self.bot_manager else 0,
            "recent_events": []
        })
        # setup asgi if requested and available
        if self.enable_asgi:
            if not _FASTAPI_AVAIL:
                logger.warning("ASGI requested but FastAPI not available. Skipping ASGI.")
            else:
                self._asgi_server = ASGIServer(host=self.asgi_host, port=self.asgi_port, event_bus=self.event_bus)

    # -----------------------
    # State management
    # -----------------------
    def get_state(self) -> Dict[str, Any]:
        with self._state_lock:
            s = dict(self._state)
        s["ts"] = now_iso()
        return s

    def update_state(self, key: str, value: Any):
        with self._state_lock:
            self._state[key] = value
        # publish to bus
        self.event_bus.publish("state_update", {"key": key, "value": value, "ts": now_iso()})

    def push_event(self, topic: str, payload: Dict[str, Any]):
        payload = dict(payload)
        payload["ts"] = now_iso()
        self.event_bus.publish(topic, payload)
        # also keep small history
        with self._state_lock:
            lst = self._state.setdefault("recent_events", [])
            lst.insert(0, {"topic": topic, **payload})
            # cap history
            self._state["recent_events"] = lst[:50]

    # -----------------------
    # UI hooks
    # -----------------------
    def register_ui_hook(self, topic: str, callback: Callable[[Dict[str, Any]], None]):
        """
        Registra una función que será llamada cuando se publique en `topic`.
        Ideal para Streamlit: pasar una función que haga st.session_state updates.
        """
        self.event_bus.subscribe(topic, callback)

    def unregister_ui_hook(self, topic: str, callback: Callable[[Dict[str, Any]], None]):
        self.event_bus.unsubscribe(topic, callback)

    # -----------------------
    # Background polling / bridge to BotManager
    # -----------------------
    def start_background_polling(self):
        if self._background_thread and self._background_thread.is_alive():
            logger.info("Background polling already running")
            return
        self._stop_event.clear()
        t = threading.Thread(target=self._bg_loop, daemon=True, name="st_enterprise_bg")
        t.start()
        self._background_thread = t
        logger.info("Background polling started")

        # start ASGI server in separate thread if configured
        if self._asgi_server:
            thr = threading.Thread(target=self._asgi_server.run, kwargs={"log_level": "info"}, daemon=True, name="st_enterprise_asgi")
            thr.start()
            logger.info("ASGI server started on %s:%d", self.asgi_host, self.asgi_port)

    def stop_background_polling(self):
        self._stop_event.set()
        if self._background_thread:
            self._background_thread.join(timeout=2.0)
        logger.info("Background polling stopped")

    def _bg_loop(self):
        """
        Loop que consulta estado del BotManager y publica eventos útiles para UI.
        """
        while not self._stop_event.is_set():
            try:
                # queue size
                qsize = getattr(self.bot_manager, "_queue", None)
                if qsize is not None:
                    try:
                        q = getattr(self.bot_manager, "_queue")
                        qlen = q.qsize() if hasattr(q, "qsize") else 0
                    except Exception:
                        qlen = 0
                else:
                    qlen = 0
                self.update_state("queue_size", qlen)

                # workers alive
                try:
                    alive = sum(1 for t in getattr(self.bot_manager, "_workers", []) if t.is_alive())
                except Exception:
                    alive = getattr(self.bot_manager, "worker_count", 0)
                self.update_state("workers_alive", alive)

                # publish heartbeat
                self.push_event("heartbeat", {"queue_size": qlen, "workers_alive": alive})

                # emit occasional summary to Telegram (throttled)
                last_queue = self._state.get("_last_telegram_queue_alert_at")
                if qlen > 10 and (not last_queue or (time.time() - last_queue) > 300):
                    try:
                        self.notifier.send_trading_start("SYSTEM", {"info": f"High queue: {qlen}"})
                        self._state["_last_telegram_queue_alert_at"] = time.time()
                    except Exception:
                        logger.debug("Notifier send failed")

            except Exception:
                logger.exception("Background loop unexpected error")
            # sleep
            time.sleep(max(0.2, self.polling_interval))

    # -----------------------
    # Execute trade (UI helper)
    # -----------------------
    def execute_trade(
        self,
        user_id: str,
        asset: str,
        amount_usdt: float,
        steps: int = 1,
        stop_loss_pct: float = 0.02,
        mode: str = "DEMO",
        metadata: Optional[Dict[str, Any]] = None,
        on_finish: Optional[Callable[[Dict[str, Any]], None]] = None
    ) -> Dict[str, Any]:
        """
        Helper conveniente para la UI. Encola la ejecución en BotManager.
        Permite pasar on_finish callback (se almacenará y ejecutará desde BotManager worker).
        Retorna: job_id (local) y estado inicial.
        """
        # Basic validation
        if amount_usdt <= 0:
            return {"error": "amount_usdt must be > 0"}

        job_id = uuid.uuid4().hex
        payload = {
            "job_id": job_id,
            "asset": asset,
            "user_id": user_id,
            "amount_usdt": amount_usdt,
            "steps": steps,
            "stop_loss_pct": stop_loss_pct,
            "mode": mode,
            "metadata": metadata or {},
            "created_at": now_iso()
        }

        # keep mapping to call back after execution via event bus
        def _local_on_finish(result: Dict[str, Any]):
            # push to event bus
            self.push_event("execution_result", {"job_id": job_id, "result": result})
            # call user callback if provided
            try:
                if callable(on_finish):
                    on_finish(result)
            except Exception:
                logger.exception("on_finish callback failed")

        # enqueue into BotManager — try modern signature first
        try:
            # Newer BotManager in your repo accepts enqueue_execute with named args including on_finish
            try:
                self.bot_manager.enqueue_execute(
                    symbol=asset,
                    session_id=str(user_id),
                    usuario={"usuario": user_id},
                    amount_usdt=float(amount_usdt),
                    steps=int(steps),
                    stop_loss_pct=float(stop_loss_pct),
                    mode=mode,
                    metadata=payload.get("metadata"),
                )
                # we can't directly attach on_finish to external bot if it doesn't support it.
                # So we register local listener on "execution_complete" events to match job by asset+user
            except TypeError:
                # fallback to older signature (asset, session_id, usuario, amount...)
                self.bot_manager.enqueue_execute(asset, str(user_id), {"usuario": user_id}, amount_usdt, steps)
        except Exception as e:
            logger.exception("Failed to enqueue execution")
            return {"error": str(e)}

        # Register temporary listener for matching execution result (best-effort)
        def _match_and_forward(payload_event: Dict[str, Any]):
            try:
                res = payload_event.get("result") or payload_event
                # try to heuristically match job -> by asset & user
                if isinstance(res, dict):
                    # If engine returns structured result include asset
                    if res.get("execution") and res["execution"].get("symbol") == asset:
                        _local_on_finish(res)
                    elif res.get("symbol") == asset:
                        _local_on_finish(res)
            except Exception:
                logger.exception("Matching callback failed")

        # Subscribe once; will remain but only forwards matching results (lightweight)
        self.register_ui_hook("execution_complete", _match_and_forward)

        # emit initial event
        self.push_event("execution_enqueued", payload)
        return {"status": "enqueued", "job_id": job_id, "asset": asset}

    # -----------------------
    # Utilities
    # -----------------------
    def force_stop_all(self):
        """
        Pide parada inmediata a BotManager (si expone método).
        """
        try:
            if hasattr(self.bot_manager, "shutdown"):
                self.bot_manager.shutdown(wait=False)
            if hasattr(self.bot_manager, "stop"):
                self.bot_manager.stop()
            # also stop our polling
            self.stop_background_polling()
            self.push_event("system", {"action": "force_stop"})
            return True
        except Exception:
            logger.exception("force_stop_all failed")
            return False

    # -----------------------
    # Clean shutdown
    # -----------------------
    def shutdown(self):
        try:
            self.stop_background_polling()
            if self._asgi_server:
                # no clean stop implemented for uvicorn here; leaving to deployment orchestration
                logger.info("ASGI server left running; stop it externally if needed.")
            logger.info("Controller shutdown complete")
        except Exception:
            logger.exception("shutdown error")
