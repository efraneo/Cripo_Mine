import os
import json
import joblib
import warnings
import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    roc_auc_score, accuracy_score, precision_score,
    recall_score, f1_score, confusion_matrix
)

warnings.filterwarnings("ignore")

PARQUET_PATH = "utils/datasets/signals_2025_12.parquet"
MODEL_DIR = "models"
FEATURE_LIST_FILE = f"{MODEL_DIR}/feature_list.json"
BEST_MODEL_FILE = f"{MODEL_DIR}/best_model.pkl"

os.makedirs(MODEL_DIR, exist_ok=True)


def load_clean_dataset():
    print("📥 Cargando dataset desde parquet...")
    df = pd.read_parquet(PARQUET_PATH)

    features = ["open", "high", "low", "close"]
    target = "target"

    df = df[features + [target]]
    df = df.dropna()

    print("📊 Dataset final:", df.shape)
    return df, features


def save_feature_list(features):
    with open(FEATURE_LIST_FILE, "w") as f:
        json.dump(features, f, indent=4)
    print(f"📄 Guardado feature_list.json ({len(features)} features)")


def train_models(df, features):
    X = df[features]
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, shuffle=False
    )

    print("\n⚡ Entrenando modelos...")

    models = {
        "lightgbm": LGBMClassifier(
            n_estimators=400,
            learning_rate=0.03,
            max_depth=6
        ),
        "xgboost": XGBClassifier(
            n_estimators=400,
            learning_rate=0.03,
            max_depth=6,
            eval_metric="logloss"
        )
    }

    best_model_name = None
    best_auc = -1
    best_model = None

    results = {}

    for name, model in models.items():
        print(f"➡️ Entrenando {name}...")
        model.fit(X_train, y_train)
        preds_proba = model.predict_proba(X_test)[:, 1]
        preds = (preds_proba > 0.5).astype(int)

        auc = roc_auc_score(y_test, preds_proba)

        results[name] = {
            "auc": auc,
            "acc": accuracy_score(y_test, preds),
            "precision": precision_score(y_test, preds),
            "recall": recall_score(y_test, preds),
            "f1": f1_score(y_test, preds),
            "confusion": confusion_matrix(y_test, preds).tolist()
        }

        print(f"   🟩 AUC = {auc:.4f}")

        if auc > best_auc:
            best_auc = auc
            best_model_name = name
            best_model = model

    print(f"\n🏆 Mejor modelo: {best_model_name} (AUC={best_auc:.4f})")
    return best_model, results


def save_best_model(model):
    joblib.dump(model, BEST_MODEL_FILE)
    print(f"💾 Guardado modelo final: {BEST_MODEL_FILE}")


def train_automl():
    df, features = load_clean_dataset()

    save_feature_list(features)

    best_model, metrics = train_models(df, features)

    save_best_model(best_model)

    print("\n📊 Métricas finales:")
    print(json.dumps(metrics, indent=4))


if __name__ == "__main__":
    train_automl()
