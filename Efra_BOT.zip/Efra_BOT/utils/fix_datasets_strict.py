import os
import csv

DATASET_DIR = "utils/datasets"

def fix_file_strict(path):
    print(f"🔍 Analizando: {path}")

    with open(path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        rows = list(reader)

    if len(rows) == 0:
        print("⚠ Archivo vacío, saltando\n")
        return

    header = rows[0]
    expected = len(header)

    cleaned = [header]
    removed = 0

    for i, row in enumerate(rows[1:], start=2):
        if len(row) != expected:
            print(f"❌ Línea {i} descartada (cols={len(row)}, esperado={expected})")
            removed += 1
            continue

        cleaned.append(row)

    # Reescribir limpio
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(cleaned)

    print(f"✅ Archivo limpio → {path} | Líneas eliminadas: {removed}\n")


def main():
    print("=== Reparación estricta de datasets ===\n")

    if not os.path.exists(DATASET_DIR):
        print(f"❌ ERROR: No existe carpeta {DATASET_DIR}")
        return

    for file in os.listdir(DATASET_DIR):
        if file.endswith(".csv"):
            fix_file_strict(os.path.join(DATASET_DIR, file))

    print("✔ TODOS LOS DATASETS REPARADOS ✔")


if __name__ == "__main__":
    main()
