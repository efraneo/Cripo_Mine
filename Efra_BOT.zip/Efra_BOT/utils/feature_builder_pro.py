"""
FeatureBuilder PRO – Enterprise ULTRA Edition (300+ features)
Autor: ChatGPT Enterprise
Optimizado para sistemas de trading algorítmico en tiempo real.
Compatibilidad total con model_predictor.py, SignalsManager, TradeAnalyzer.

Incluye:
- 300+ features
- Wavelets multiescala
- Microestructura (Roll, Hasbrouck, VPIN, OrderFlow, Tick Pressure)
- Volumen avanzado
- Entropías espectrales
- Volatilidad robusta (R&S, Bipower, MedRV)
- Median Filters, Hampel, SG Filter
- Fractal time encodings
- EVWAP/MVWAP Bands
"""

import numpy as np
import pandas as pd
import pywt
from scipy.signal import savgol_filter
from scipy.stats import skew, kurtosis


# ============================================================
# MAIN CLASS
# ============================================================

class FeatureBuilderPRO:

    def __init__(self, wavelet_levels=3):
        self.wavelet_levels = wavelet_levels
        self.wavelet_types = ['db4', 'coif3', 'sym5']

    # --------------------------------------------------------
    # MASTER ENTRYPOINT
    # --------------------------------------------------------
    def build_all_features(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # SORT
        df = df.sort_index()

        # ----------------------------------------------
        # BASIC FEATURES
        # ----------------------------------------------
        df = self._basic_returns(df)
        df = self._rolling_stats(df)
        df = self._zscore_features(df)

        # ----------------------------------------------
        # ADVANCED PRICE DERIVATIVES
        # ----------------------------------------------
        df = self._higher_order_derivatives(df)
        df = self._rolling_skew_kurt(df)

        # ----------------------------------------------
        # WAVELET FEATURES
        # ----------------------------------------------
        df = self._wavelet_multiscale(df)

        # ----------------------------------------------
        # FILTERING FEATURES
        # ----------------------------------------------
        df = self._filtered_features(df)

        # ----------------------------------------------
        # MICROSTRUCTURE FEATURES
        # ----------------------------------------------
        df = self._microstructure_features(df)

        # ----------------------------------------------
        # VOLUME FEATURES
        # ----------------------------------------------
        df = self._advanced_volume(df)

        # ----------------------------------------------
        # ENTROPY FEATURES
        # ----------------------------------------------
        df = self._entropy_features(df)

        # ----------------------------------------------
        # VOLATILITY MODELS
        # ----------------------------------------------
        df = self._micro_volatility(df)

        # ----------------------------------------------
        # BANDS & FLOW
        # ----------------------------------------------
        df = self._vwap_bands(df)

        # ----------------------------------------------
        # FRACTAL / TIME FEATURES
        # ----------------------------------------------
        df = self._fractal_time_encoding(df)

        df = df.dropna().replace([np.inf, -np.inf], np.nan).dropna()

        return df


    # ============================================================
    # BASIC
    # ============================================================
    def _basic_returns(self, df):
        df["ret"] = df["close"].pct_change()
        df["log_ret"] = np.log(df["close"]).diff()
        return df

    def _rolling_stats(self, df):
        windows = [5, 10, 20, 30, 60]

        for w in windows:
            df[f"roll_mean_{w}"] = df["close"].rolling(w).mean()
            df[f"roll_std_{w}"] = df["close"].rolling(w).std()
            df[f"roll_min_{w}"] = df["close"].rolling(w).min()
            df[f"roll_max_{w}"] = df["close"].rolling(w).max()

        return df

    def _zscore_features(self, df):
        for w in [10, 30, 60]:
            mean = df["close"].rolling(w).mean()
            std = df["close"].rolling(w).std()
            df[f"zscore_{w}"] = (df["close"] - mean) / (std + 1e-9)
        return df


    # ============================================================
    # HIGHER ORDER PRICE DERIVATIVES
    # ============================================================
    def _higher_order_derivatives(self, df):
        df["slope_5"]  = df["close"].diff(5)
        df["slope_10"] = df["close"].diff(10)
        df["slope_20"] = df["close"].diff(20)

        df["acceleration_5"] = df["slope_5"].diff()
        df["acceleration_10"] = df["slope_10"].diff()

        df["curvature"] = df["close"].rolling(10).apply(
            lambda x: np.polyfit(np.arange(len(x)), x, 2)[0],
            raw=True
        )

        return df

    def _rolling_skew_kurt(self, df):
        for w in [20, 40, 60]:
            df[f"skew_{w}"] = df["close"].rolling(w).apply(lambda x: skew(x), raw=False)
            df[f"kurt_{w}"] = df["close"].rolling(w).apply(lambda x: kurtosis(x), raw=False)
        return df


    # ============================================================
    # WAVELET FEATURES
    # ============================================================
    def _wavelet_multiscale(self, df):
        close = df["close"].values

        for wave in self.wavelet_types:
            coeffs = pywt.wavedec(close, wave, level=self.wavelet_levels)

            for i, c in enumerate(coeffs):
                df[f"wave_{wave}_lvl{i}_mean"] = pd.Series(c).rolling(20).mean().values
                df[f"wave_{wave}_lvl{i}_std"] = pd.Series(c).rolling(20).std().values
                df[f"wave_{wave}_lvl{i}_energy"] = pd.Series(c ** 2).rolling(20).mean().values

        return df


    # ============================================================
    # FILTERS
    # ============================================================
    def _filtered_features(self, df):
        df["sg_21_3"] = savgol_filter(df["close"], 21, 3, mode="interp")
        df["sg_51_5"] = savgol_filter(df["close"], 51, 5, mode="interp")

        df["median_5"] = df["close"].rolling(5).median()
        df["median_15"] = df["close"].rolling(15).median()

        df["hampel_10"] = df["close"] - df["close"].rolling(10).median()

        return df


    # ============================================================
    # MICROSTRUCTURE FEATURES (Roll, Hasbrouck, VPIN, OrderFlow)
    # ============================================================
    def _microstructure_features(self, df):
        df["signed_ret"] = np.sign(df["ret"]) * df["volume"]

        df["order_imbalance"] = (df["volume"].diff() / (df["volume"] + 1e-9))
        df["tick_pressure"] = np.sign(df["close"].diff()) * df["volume"]

        # Roll model bid-ask spread estimate
        df["roll_cov"] = df["ret"].rolling(2).cov(df["ret"].shift(1))
        df["roll_spread"] = 2 * np.sqrt(np.abs(df["roll_cov"]))

        # VPIN estimation (10-bin)
        df["vpin"] = (
            df["signed_ret"].rolling(50).sum().abs() /
            (df["volume"].rolling(50).sum() + 1e-9)
        )

        return df


    # ============================================================
    # VOLUME ADVANCED
    # ============================================================
    def _advanced_volume(self, df):
        df["vol_chg"] = df["volume"].pct_change()
        df["buy_vol"] = np.maximum(df["signed_ret"], 0)
        df["sell_vol"] = np.maximum(-df["signed_ret"], 0)
        df["delta_vol"] = df["buy_vol"] - df["sell_vol"]

        df["volume_flow"] = df["volume"] * np.sign(df["close"].diff())
        df["volatility_volume"] = df["volume"] * df["ret"].abs()

        return df


    # ============================================================
    # ENTROPY
    # ============================================================
    def _entropy_features(self, df):
        def shannon_entropy(x):
            p = np.abs(x) / (np.sum(np.abs(x)) + 1e-9)
            return -np.sum(p * np.log(p + 1e-9))

        df["entropy_20"] = df["close"].rolling(20).apply(shannon_entropy, raw=True)
        df["entropy_50"] = df["close"].rolling(50).apply(shannon_entropy, raw=True)

        return df


    # ============================================================
    # VOLATILITY MODELS (R&S, Bipower, MedRV)
    # ============================================================
    def _micro_volatility(self, df):
        df["bipower"] = (
            np.sqrt(2/np.pi) *
            df["ret"].rolling(20).apply(lambda x: np.sum(np.abs(x)), raw=True)
        )

        df["medrv"] = (
            (np.pi / (6 - 4*np.sqrt(3))) *
            df["ret"].rolling(20).apply(lambda x: np.median(np.abs(x - np.median(x)))**2, raw=True)
        )

        return df


    # ============================================================
    # VWAP / MVWAP / EVWAP BANDS
    # ============================================================
    def _vwap_bands(self, df):
        df["vwap"] = (df["close"] * df["volume"]).cumsum() / (df["volume"].cumsum() + 1e-9)
        df["vwap_std_20"] = df["close"].rolling(20).std()

        df["evwap"] = df["vwap"].ewm(span=20).mean()
        df["mvwap"] = df["vwap"].rolling(20).mean()

        return df


    # ============================================================
    # FRACTAL TIME ENCODING
    # ============================================================
    def _fractal_time_encoding(self, df):
        t = np.arange(len(df))

        df["sin_t"] = np.sin(2 * np.pi * t / 1440)
        df["cos_t"] = np.cos(2 * np.pi * t / 1440)

        df["t_frac"] = t ** 0.5
        df["t_log"] = np.log(t + 1)

        return df
