# utils/logger.py
# ============================================================
# 🧾 Sistema de registro de logs centralizado (compatibilidad total)
# ============================================================

import os
import datetime

LOG_DIR = os.path.join(os.path.dirname(__file__), "..", "logs")
os.makedirs(LOG_DIR, exist_ok=True)
DEFAULT_LOG_FILE = os.path.join(LOG_DIR, "app.log")


def _write_log(mensaje: str, archivo: str = None):
    """
    Escribe logs en archivo (si no se da, usa app.log)
    """
    log_path = os.path.join(LOG_DIR, archivo) if archivo else DEFAULT_LOG_FILE
    with open(log_path, "a", encoding="utf-8") as f:
        f.write(mensaje)


def log_error(e, archivo="app.log", funcion="desconocida"):
    """
    Registra errores. Permite archivo personalizado.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mensaje = f"[{timestamp}] ❌ Error en {archivo}::{funcion} -> {str(e)}\n"
    _write_log(mensaje, archivo)
    print(mensaje)


def log_info(msg, archivo="app.log"):
    """
    Registra eventos informativos. Permite archivo personalizado.
    """
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mensaje = f"[{timestamp}] ℹ️ {msg}\n"
    _write_log(mensaje, archivo)
    print(mensaje)
