# utils/generate_datasets_from_parquet.py
# ==========================================================
# Conversión robusta de parquet → CSV para AutoML PRO
# Mantiene únicamente columnas numéricas permitidas:
#   open, high, low, close, target
# Ignora columnas extra, strings, arrays o estructuras anidadas.
# ==========================================================

import pandas as pd
import os
from sklearn.model_selection import train_test_split

PARQUET_PATH = "utils/datasets/signals_2025_12.parquet"
OUT_DIR = "utils/datasets"

os.makedirs(OUT_DIR, exist_ok=True)

KEEP_COLS = ["open", "high", "low", "close", "target"]

def main():
    print("📥 Leyendo parquet:", PARQUET_PATH)

    if not os.path.exists(PARQUET_PATH):
        print("❌ ERROR: No existe el parquet")
        return

    df = pd.read_parquet(PARQUET_PATH)

    print("🔎 Columnas detectadas:", list(df.columns))

    # ============================================
    # LIMPIEZA: nos quedamos SOLO con columnas válidas
    # ============================================
    clean = pd.DataFrame()

    for col in KEEP_COLS:
        if col not in df.columns:
            print(f"⚠ '{col}' no existe → creando columna dummy...")
            clean[col] = 0.0
        else:
            clean[col] = pd.to_numeric(df[col], errors="coerce")

    # Eliminar filas problemáticas
    clean = clean.dropna().reset_index(drop=True)

    print("📊 Registros finales:", len(clean))
    print("📄 Columnas finales:", list(clean.columns))

    # ==========================================================
    # 1) dataset_full.csv
    # ==========================================================
    clean.to_csv(os.path.join(OUT_DIR, "dataset_full.csv"), index=False)
    print("✔ dataset_full.csv creado")

    # ==========================================================
    # 2) train / test
    # ==========================================================
    train, test = train_test_split(clean, test_size=0.2, shuffle=True, random_state=42)

    train.to_csv(os.path.join(OUT_DIR, "dataset_train.csv"), index=False)
    test.to_csv(os.path.join(OUT_DIR, "dataset_test.csv"), index=False)

    print("✔ dataset_train.csv creado")
    print("✔ dataset_test.csv creado")

    # ==========================================================
    # 3) mini datasets (1,2,3)
    # ==========================================================
    mini1 = clean.head(300)
    mini2 = clean.head(800)
    mini3 = clean.sample(400, random_state=1)

    mini1.to_csv(os.path.join(OUT_DIR, "dataset_1.csv"), index=False)
    mini2.to_csv(os.path.join(OUT_DIR, "dataset_2.csv"), index=False)
    mini3.to_csv(os.path.join(OUT_DIR, "dataset_3.csv"), index=False)

    print("✔ dataset_1.csv creado")
    print("✔ dataset_2.csv creado")
    print("✔ dataset_3.csv creado")

    print("\n🎉 LISTO — datasets 100% compatibles con AutoML PRO 🎉")


if __name__ == "__main__":
    main()
