import os
import pandas as pd

DATA_DIR = "utils/datasets"

VALID_COLS = ["open", "high", "low", "close", "target"]

def clean_csv(path):
    print(f"🔧 Reparando: {path}")

    try:
        df = pd.read_csv(path, on_bad_lines="skip", engine="python")
    except Exception as e:
        print(f"❌ No se pudo leer {path}: {e}")
        return

    # Forzar columnas válidas
    df = df[[c for c in df.columns if c in VALID_COLS]]

    # Si faltan columnas, crearlas vacías
    for col in VALID_COLS:
        if col not in df.columns:
            df[col] = 0

    # Orden correcto
    df = df[VALID_COLS]

    # Eliminar NaN
    df = df.dropna()

    # Sobrescribir
    df.to_csv(path, index=False)
    print(f"✔ Listo {path}")


def main():
    print("\n=== Reparando TODOS los CSV definitivos ===\n")

    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".csv")]

    if not files:
        print("❌ No hay CSV para reparar.")
        return

    for f in files:
        clean_csv(os.path.join(DATA_DIR, f))

    print("\n🎉 TODOS LOS CSV LISTOS PARA AutoML PRO 🎉")


if __name__ == "__main__":
    main()
