# utils/generate_signals_dataset_pro.py
# ==================================================================
# DATASET PRO — SEÑALES SINTÉTICAS AVANZADAS 100% REALISTAS
#
# Incluye:
#  - tendencias bull/bear largas
#  - consolidación
#  - reversión mean-reversion
#  - shocks de volatilidad
#  - gaps sintéticos
#  - ruido microestructural
#  - ATR dinámico
#  - señales IA_BUY / IA_SELL realistas
#  - label futuro para ML (y = retorno futuro)
#
# Genera 15.000 señales en data/signals_log.jsonl (formato idóneo)
# ==================================================================

import os
import json
import numpy as np
import pandas as pd
import time
from tqdm import tqdm

OUT_FILE = "data/signals_log.jsonl"
os.makedirs("data", exist_ok=True)

N = 15000  # número de señales PRO a generar

# ----------------------------------------------------------------------
#   1) Generador de precios PRO
# ----------------------------------------------------------------------
def generate_price_series(n=15000):
    """
    Price generator estilo institucional:
    mezcla tendencias, consolidación y shocks.
    """
    prices = [68000.0]  # precio inicial BTC sintético

    for i in range(1, n):
        mode = np.random.choice(
            ["trend_up", "trend_down", "consolidation", "shock", "reversal"],
            p=[0.30, 0.25, 0.30, 0.05, 0.10]
        )

        last = prices[-1]

        if mode == "trend_up":
            step = np.random.normal(last * 0.0006, last * 0.0010)
        elif mode == "trend_down":
            step = np.random.normal(-last * 0.0006, last * 0.0010)
        elif mode == "consolidation":
            step = np.random.normal(0, last * 0.0002)
        elif mode == "reversal":
            step = np.random.normal(-np.sign(np.random.rand() - 0.5) * last * 0.0015, last * 0.0012)
        else:  # shock
            step = np.random.normal(last * 0.02, last * 0.005)

        new_price = max(1000, last + step)
        prices.append(new_price)

    return np.array(prices)

# ----------------------------------------------------------------------
#   2) Construcción OHLCV sintético PRO
# ----------------------------------------------------------------------
def generate_ohlcv(prices):
    o = prices[:-1]
    c = prices[1:]
    high = np.maximum(o, c) + np.random.uniform(0, 5, len(c))
    low = np.minimum(o, c) - np.random.uniform(0, 5, len(c))
    vol = np.random.uniform(10, 300, len(c))

    df = pd.DataFrame({
        "open": o,
        "high": high,
        "low": low,
        "close": c,
        "volume": vol
    })
    return df

# ----------------------------------------------------------------------
#   3) ATR realista
# ----------------------------------------------------------------------
def compute_atr(df, period=14):
    df = df.copy()
    df["h-l"] = df["high"] - df["low"]
    df["h-pc"] = np.abs(df["high"] - df["close"].shift())
    df["l-pc"] = np.abs(df["low"] - df["close"].shift())
    df["tr"] = df[["h-l", "h-pc", "l-pc"]].max(axis=1)
    df["atr"] = df["tr"].rolling(period).mean().fillna(df["tr"].expanding().mean())
    return df["atr"]

# ----------------------------------------------------------------------
#   4) Probabilidad IA sintética PRO
# ----------------------------------------------------------------------
def generate_ai_probability(row):
    """
    La probabilidad está influenciada por:
    - direccionalidad (open-close)
    - volatilidad (atr_rel)
    - ruido
    """
    direction = row["close"] - row["open"]
    base = np.clip(abs(direction) / (row["close"] * 0.002), 0, 1)

    prob = 0.5 + (base * 0.5 * np.sign(direction))
    prob += np.random.normal(0, 0.05)
    return float(np.clip(prob, 0.01, 0.99))

# ----------------------------------------------------------------------
#   5) Label futuro (y)
# ----------------------------------------------------------------------
def compute_future_return(df, horizon=10):
    future = df["close"].shift(-horizon)
    y = (future - df["close"]) / df["close"]
    return y.fillna(0)

# ----------------------------------------------------------------------
#   MAIN
# ----------------------------------------------------------------------
def main():
    print("🔥 Generando dataset PRO (15.000 señales)…")

    prices = generate_price_series(N)
    df = generate_ohlcv(prices)
    df["atr"] = compute_atr(df)
    df["atr_rel"] = df["atr"] / df["close"]

    df["y"] = compute_future_return(df)

    # Crear archivo JSONL
    with open(OUT_FILE, "w", encoding="utf-8") as f:

        for idx, row in tqdm(df.iterrows(), total=len(df)):

            prob = generate_ai_probability(row)

            if prob >= 0.80:
                actions = [("IA_BUY", f"prob={prob:.3f}")]
            elif prob <= 0.20:
                actions = [("IA_SELL", f"prob={prob:.3f}")]
            else:
                actions = []

            payload = {
                "ts": time.time() + idx,
                "symbol": "BTCUSDT",
                "interval": "1m",
                "close": float(row["close"]),
                "atr": float(row["atr"]),
                "atr_rel": float(row["atr_rel"]),
                "prob": prob,
                "actions": actions,
                "features": {
                    "open": float(row["open"]),
                    "high": float(row["high"]),
                    "low": float(row["low"]),
                    "close": float(row["close"]),
                    "volume": float(row["volume"]),
                    "atr": float(row["atr"]),
                    "atr_rel": float(row["atr_rel"])
                },
                "future_return_y": float(row["y"])
            }

            f.write(json.dumps(payload, ensure_ascii=False) + "\n")

    print(f"✔ Dataset PRO generado en {OUT_FILE}")
    print("✔ Listo para AutoML (LightGBM / XGBoost)")
    print("✔ Cantidad de señales:", len(df))


if __name__ == "__main__":
    main()
