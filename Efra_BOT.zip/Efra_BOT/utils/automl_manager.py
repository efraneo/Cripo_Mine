# utils/automl_manager.py
"""
AutoML Manager PRO — Entrenamiento, evaluación, versionado y rollback
Integrado con LightGBM + sklearn.

Genera:
 - modelos versionados en utils/model_registry/
 - gráfico de métricas en utils/model_registry/metrics/
 - archivo model_current.pkl (modelo activo)
 
Se integra con SignalsEngine, TradingEngine y Dashboard Streamlit.
"""

from __future__ import annotations
import os
import time
import json
import joblib
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from lightgbm import LGBMClassifier

# -------------------------------------------------------------
# Carpetas
# -------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_DIR = os.path.join(BASE_DIR, "model_registry")
METRICS_DIR = os.path.join(MODEL_DIR, "metrics")
DATASETS_DIR = os.path.join(BASE_DIR, "datasets")

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(METRICS_DIR, exist_ok=True)
os.makedirs(DATASETS_DIR, exist_ok=True)

CURRENT_MODEL = os.path.join(MODEL_DIR, "model_current.pkl")


# =============================================================
#        UTILIDADES
# =============================================================
def list_datasets():
    """Lista todos los datasets parquet dentro de utils/datasets."""
    return [
        os.path.join(DATASETS_DIR, f)
        for f in os.listdir(DATASETS_DIR)
        if f.endswith(".parquet")
    ]


def load_all_datasets():
    """Concatena todos los datasets del directorio."""
    files = list_datasets()
    if not files:
        raise ValueError("No hay datasets en utils/datasets. Genera datos primero.")

    dfs = []
    for f in files:
        try:
            dfs.append(pd.read_parquet(f))
        except Exception:
            pass

    if not dfs:
        raise ValueError("Datasets corruptos o vacíos.")

    df = pd.concat(dfs, ignore_index=True)
    return df


# =============================================================
#        AUTO ML MANAGER
# =============================================================
class AutoMLManager:
    def __init__(self):
        self.version = int(time.time())

    # ---------------------------------------------------------
    def prepare_data(self, df: pd.DataFrame):
        """
        Prepara los datos para LightGBM.
        Requiere columnas:
            close, open, high, low, volume, atr, prob, ...
        Y una etiqueta "target"
        """

        if "target" not in df.columns:
            raise ValueError("Falta columna target en el dataset.")

        # Variables numéricas válidas
        feature_cols = [
            c for c in df.columns
            if c not in ["target", "timestamp", "ts", "symbol"]
            and df[c].dtype != object
        ]

        X = df[feature_cols].astype(float)
        y = df["target"].astype(int)

        return X, y, feature_cols

    # ---------------------------------------------------------
    def train_model(self, df: pd.DataFrame):
        """Entrena modelo LightGBM y retorna dict con métricas + path."""

        X, y, features = self.prepare_data(df)

        Xtr, Xte, ytr, yte = train_test_split(
            X, y, test_size=0.25, shuffle=True, random_state=42
        )

        model = LGBMClassifier(
            n_estimators=300,
            learning_rate=0.03,
            max_depth=-1,
            subsample=0.9,
            colsample_bytree=0.9
        )

        model.fit(Xtr, ytr)

        pred = model.predict(Xte)
        prob = model.predict_proba(Xte)[:, 1]

        acc = accuracy_score(yte, pred)
        f1 = f1_score(yte, pred)
        auc = roc_auc_score(yte, prob)

        # Guardar versión
        version_path = os.path.join(MODEL_DIR, f"model_{self.version}.pkl")
        joblib.dump({
            "model": model,
            "features": features,
            "version": self.version,
            "metrics": {"acc": acc, "f1": f1, "auc": auc}
        }, version_path)

        # Guardar como modelo actual
        joblib.dump(model, CURRENT_MODEL)

        # Guardar métricas
        metrics_path = os.path.join(METRICS_DIR, f"metrics_{self.version}.json")
        with open(metrics_path, "w", encoding="utf-8") as fh:
            json.dump({
                "version": self.version,
                "acc": acc,
                "f1": f1,
                "auc": auc,
                "features": features
            }, fh, indent=4)

        return {
            "version": self.version,
            "acc": acc,
            "f1": f1,
            "auc": auc,
            "version_path": version_path,
            "metrics_path": metrics_path
        }

    # ---------------------------------------------------------
    def rollback(self):
        """Vuelve al modelo anterior más reciente."""
        models = [
            f for f in os.listdir(MODEL_DIR)
            if f.startswith("model_") and f.endswith(".pkl")
        ]
        if len(models) < 2:
            raise ValueError("No hay modelos previos para rollback.")

        models = sorted(models, reverse=True)
        # El más reciente es models[0], rollback a models[1]
        rollback_file = os.path.join(MODEL_DIR, models[1])

        bundle = joblib.load(rollback_file)
        joblib.dump(bundle["model"], CURRENT_MODEL)

        return {
            "rollback_to": rollback_file,
            "version": bundle.get("version"),
            "metrics": bundle.get("metrics")
        }


# =============================================================
#        FUNCIÓN DIRECTA
# =============================================================
def automl_train():
    """Carga datasets y entrena un modelo nuevo."""
    df = load_all_datasets()
    automl = AutoMLManager()
    return automl.train_model(df)


def automl_rollback():
    """Rollback directo."""
    automl = AutoMLManager()
    return automl.rollback()
