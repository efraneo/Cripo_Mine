# ============================================================
# pages/2_📸_Gestor_de_Avatares.py
# ============================================================
import os
import datetime
import streamlit as st
from backend.telegram_notifier import generar_avatar
from utils.logger import log_info, log_error

# ------------------------------------------------------------
# CONFIGURACIÓN INICIAL
# ------------------------------------------------------------
AVATAR_DIR = os.path.join("data", "avatars")
os.makedirs(AVATAR_DIR, exist_ok=True)

st.set_page_config(page_title="Gestor de Avatares IA", page_icon="📸", layout="wide")

# ------------------------------------------------------------
# 🔐 VERIFICAR LOGIN Y ROL ADMIN
# ------------------------------------------------------------
if "usuario_actual" not in st.session_state:
    st.error("🚫 Acceso denegado. Debes iniciar sesión antes de usar esta página.")
    st.stop()

usuario = st.session_state["usuario_actual"]
IS_ADMIN = bool(usuario.get("es_admin"))

if not IS_ADMIN:
    st.error("⛔ Solo los administradores pueden acceder al Gestor de Avatares.")
    st.stop()

# ------------------------------------------------------------
# UI PRINCIPAL
# ------------------------------------------------------------
st.title("📸 Gestor de Avatares IA")
st.caption("Administra, regenera o elimina los avatares personalizados generados por el sistema.")

# Mostrar lista de archivos
archivos = [f for f in os.listdir(AVATAR_DIR) if f.lower().endswith((".png", ".gif"))]

if not archivos:
    st.info("⚠️ No hay avatares generados todavía.")
else:
    cols = st.columns(3)
    for i, f in enumerate(archivos):
        path = os.path.join(AVATAR_DIR, f)
        try:
            size_kb = round(os.path.getsize(path) / 1024, 2)
            fecha = datetime.datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M")
            with open(path, "rb") as imgf:
                img_bytes = imgf.read()
            with cols[i % 3]:
                st.image(img_bytes, width=180, caption=f"{f}\n{size_kb} KB — {fecha}")
                c1, c2 = st.columns(2)
                if c1.button("🌀 Regenerar", key=f"regen_{f}"):
                    nombre = os.path.splitext(f)[0]
                    usuario_mock = {"usuario": nombre, "nombre": nombre.title()}
                    try:
                        png, gif = generar_avatar(usuario_mock, size=512, animado=True)
                        if png:
                            with open(os.path.join(AVATAR_DIR, f"{nombre}.png"), "wb") as out:
                                out.write(png)
                        if gif:
                            with open(os.path.join(AVATAR_DIR, f"{nombre}.gif"), "wb") as out:
                                out.write(gif)
                        st.success(f"✅ Avatar de {nombre} regenerado con éxito.")
                        log_info(f"Avatar de {nombre} regenerado manualmente.")
                        st.rerun()
                    except Exception as e:
                        log_error(e, archivo="Gestor_de_Avatares.py", funcion="regenerar")
                        st.error(f"Error al regenerar avatar: {e}")
                if c2.button("🗑️ Eliminar", key=f"del_{f}"):
                    os.remove(path)
                    st.warning(f"Avatar {f} eliminado.")
                    log_info(f"Avatar {f} eliminado manualmente.")
                    st.rerun()
        except Exception as e:
            log_error(e, archivo="Gestor_de_Avatares.py", funcion="mostrar_imagen")
            st.error(f"Error mostrando {f}: {e}")

st.markdown("---")
st.caption("_Gestor IA Avatares v1.0 — Efra Bot_")
