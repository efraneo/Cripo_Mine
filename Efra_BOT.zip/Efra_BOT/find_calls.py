# find_calls.py

import os

KEYWORDS = [
    "run_cycle(",
    "auto_trader",
    "execute_trade(",
    "scan_market(",
    "while True",
]

BASE_DIR = "."  # raíz del proyecto

for root, dirs, files in os.walk(BASE_DIR):
    for file in files:
        if file.endswith(".py"):
            path = os.path.join(root, file)

            try:
                with open(path, "r", encoding="utf-8") as f:
                    lines = f.readlines()

                for i, line in enumerate(lines):
                    for kw in KEYWORDS:
                        if kw in line:
                            print(f"\n📂 {path}:{i+1}")
                            print(f"👉 {line.strip()}")

            except:
                pass

