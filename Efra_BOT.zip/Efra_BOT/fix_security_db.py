# fix_security_db.py

import sqlite3

DB="data/security.db"

conn=sqlite3.connect(DB)

cur=conn.cursor()

cur.execute("""

CREATE TABLE IF NOT EXISTS
security_events(

id INTEGER PRIMARY KEY,

username TEXT,

ip TEXT,

event TEXT,

risk_score REAL DEFAULT 0,

created_at TIMESTAMP
DEFAULT CURRENT_TIMESTAMP

)

""")

cur.execute(
"""
PRAGMA table_info(
security_events
)
"""
)

cols=[r[1] for r in cur.fetchall()]

if "risk_score" not in cols:

    cur.execute(
    """
    ALTER TABLE
    security_events

    ADD COLUMN
    risk_score REAL
    DEFAULT 0
    """
    )

    print(
        "risk_score agregada"
    )

else:

    print(
        "risk_score ya existe"
    )

conn.commit()

conn.close()

print(
"DB reparada"
)
