"""
Dashboard PRO — Streamlit (dashboard/dashboard_pro.py)

Versión hardening y fixes (muestra figuras vía buffer, límites en tablas,
manejo defensivo de SHAP y datasets grandes).
"""

from __future__ import annotations

import os
import json
import time
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import io

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# evitamos forzar colores ni estilos desde matplotlib según las reglas

# Optional imports
try:
    import joblib
except Exception:
    joblib = None

try:
    import shap
except Exception:
    shap = None

try:
    import lightgbm as lgb
except Exception:
    lgb = None

try:
    import xgboost as xgb
except Exception:
    xgb = None

# Paths
BASE = Path(os.getenv("PROJECT_BASE", "."))
MODEL_PATH = BASE / "models" / "best_model.pkl"
SCALER_PATH = BASE / "models" / "scaler.pkl"
FEATURE_LIST_PATH = BASE / "models" / "feature_list.json"
METRICS_PATH = BASE / "models" / "metrics.json"
DATASETS_DIR = BASE / "utils" / "datasets"
FEATURES_DIR = BASE / "utils" / "datasets" / "features"
PARQUET_FEATURE = None
SIGNALS_JSONL = BASE / "data" / "signals_log.jsonl"
EXEC_JSONL = BASE / "data" / "executions_log.jsonl"
LOGS_DIR = BASE / "logs"

# config
st.set_page_config(page_title="Dashboard PRO - Efra Bot", layout="wide")

# -----------------------------
# Helpers
# -----------------------------

def load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def safe_joblib_load(path: Path):
    if joblib is None:
        return None
    try:
        return joblib.load(str(path))
    except Exception:
        return None


@st.cache_data(ttl=30)
def load_model_and_scaler() -> Tuple[Optional[Any], Optional[Any]]:
    model = safe_joblib_load(MODEL_PATH) if MODEL_PATH.exists() else None
    scaler = safe_joblib_load(SCALER_PATH) if SCALER_PATH.exists() else None
    return model, scaler


@st.cache_data(ttl=30)
def load_feature_list() -> Optional[list]:
    d = load_json(FEATURE_LIST_PATH)
    if not d:
        return None
    # feature_list.json may be either list or dict
    if isinstance(d, dict) and "features" in d:
        return d.get("features")
    if isinstance(d, list):
        return d
    return None


@st.cache_data(ttl=30)
def load_metrics() -> Optional[Dict[str, Any]]:
    return load_json(METRICS_PATH)


@st.cache_data(ttl=10)
def load_signals_tail(n: int = 200) -> pd.DataFrame:
    # read jsonl safely
    if not SIGNALS_JSONL.exists():
        return pd.DataFrame()
    rows = []
    try:
        with open(SIGNALS_JSONL, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return pd.DataFrame()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    return df.tail(n)


@st.cache_data(ttl=10)
def load_executions_tail(n: int = 200) -> pd.DataFrame:
    if not EXEC_JSONL.exists():
        return pd.DataFrame()
    rows = []
    try:
        with open(EXEC_JSONL, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return pd.DataFrame()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    return df.tail(n)


def plot_roc_curve(ax, fpr, tpr, auc):
    ax.plot(fpr, tpr)
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=0.7)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title(f"ROC curve (AUC={auc:.4f})")


def plot_pr_curve(ax, precision, recall, ap):
    ax.plot(recall, precision)
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title(f"Precision-Recall (AP={ap:.4f})")


def confusion_matrix_plot(ax, conf: list):
    try:
        import seaborn as sns  # optional
    except Exception:
        sns = None
    if sns is not None:
        sns.heatmap(np.array(conf), annot=True, fmt="d", cmap="Blues", ax=ax)
    else:
        # fallback simple table in ax
        arr = np.array(conf)
        ax.table(cellText=arr, loc="center")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix")


def display_fig(fig, clamp_width: int = 1200):
    """
    Render matplotlib figure to Streamlit in a robust way:
    - Save to PNG buffer and show via st.image to reduce frontend issues.
    """
    try:
        buf = io.BytesIO()
        fig.tight_layout()
        fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
        buf.seek(0)
        st.image(buf, width="content") # o width="stretch" si quieres ocupar el ancho completo
        plt.close(fig)
    except Exception:
        # fallback: try st.pyplot (last resort)
        try:
            st.pyplot(fig)
            plt.close(fig)
        except Exception as e:
            st.error(f"Plot display failed: {e}")


# -----------------------------
# Main UI
# -----------------------------

st.title("📈 Dashboard PRO — Efra Bot")

# Top controls
col1, col2, col3 = st.columns([2, 2, 1])

with col1:
    st.markdown("**Model & Data**")
    model, scaler = load_model_and_scaler()
    st.write("Model:", MODEL_PATH.name if MODEL_PATH.exists() else "(no encontrado)")
    st.write("Scaler:", SCALER_PATH.name if SCALER_PATH.exists() else "(no encontrado)")
    if st.button("Recargar modelo"):
        load_model_and_scaler.clear()
        st.rerun()

with col2:
    st.markdown("**Datasets & Features**")
    feat_list = load_feature_list()
    st.write("Features:", len(feat_list) if feat_list else "(no encontrado)")
    if st.button("Regenerar lista features (clear cache)"):
        load_feature_list.clear()
        st.rerun()

with col3:
    st.markdown("**Quick actions**")
    if st.button("Abrir carpeta logs"):
        # solo intento abrir con explorer (win), si no, mostrar path
        try:
            os.startfile(str(LOGS_DIR.resolve()))
        except Exception:
            st.write(LOGS_DIR)

st.markdown("---")

# Metrics + Model selection
metrics = load_metrics() or {}

st.header("🏷️ Model summary & selection")
col_a, col_b = st.columns([2, 3])
with col_a:
    st.subheader("Available models")
    # show current model file and metrics
    st.write("Current model:", MODEL_PATH.name if MODEL_PATH.exists() else "-(none)-")
    # pretty print metrics limited to reasonable size
    try:
        st.json(metrics)
    except Exception:
        st.write("Metrics JSON present but cannot render as JSON (too large?)")

with col_b:
    st.subheader("Feature importance & SHAP (if available)")
    if MODEL_PATH.exists() and feat_list:
        # attempt to show feature importance for lgb/xgb/sklearn
        m = model
        fig, ax = plt.subplots(figsize=(6, 4))
        shown = False
        try:
            if m is not None and hasattr(m, "feature_importances_"):
                fi = np.array(getattr(m, "feature_importances_"))
                # safe length
                top_n = min(20, len(fi), len(feat_list))
                idx = np.argsort(fi)[::-1][:top_n]
                names = [feat_list[i] for i in idx if i < len(feat_list)]
                ax.barh(range(len(names))[::-1], fi[idx[:len(names)]])
                ax.set_yticks(range(len(names)))
                ax.set_yticklabels(names[::-1])
                ax.set_title("Feature importance (top)")
                display_fig(fig)
                shown = True
        except Exception as e:
            shown = False
        if not shown:
            st.info("No feature importance available for this model type")
    else:
        st.info("Model or feature list missing; cannot show importance")

# Curvas ROC / PR / Confusion
st.header("📊 Performance & Curves")

auc_val = None
best = None
if metrics and isinstance(metrics, dict):
    # try to pick best model metrics
    for k, v in metrics.items():
        if isinstance(v, dict) and "auc" in v:
            if best is None or v.get("auc", 0) > (best.get("auc", 0) if isinstance(best, dict) else 0):
                best = v
    if best:
        auc_val = best.get("auc")

col1, col2, col3 = st.columns(3)
with col1:
    st.subheader("ROC")
    fig1, ax1 = plt.subplots()
    # If metrics store fpr/tpr, use them; otherwise placeholder
    try:
        if metrics and "roc" in metrics:
            r = metrics["roc"]
            plot_roc_curve(ax1, r.get("fpr", []), r.get("tpr", []), r.get("auc", 0.0))
        elif best and best.get("auc") is not None:
            ax1.text(0.2, 0.5, f"AUC: {best.get('auc'):.4f}", fontsize=12)
        else:
            ax1.text(0.3, 0.5, "ROC not available in metrics.json", fontsize=12)
        display_fig(fig1)
    except Exception as e:
        st.error(f"ROC plotting failed: {e}")

with col2:
    st.subheader("Precision-Recall")
    fig2, ax2 = plt.subplots()
    try:
        if metrics and "pr" in metrics:
            p = metrics["pr"]
            plot_pr_curve(ax2, p.get("precision", []), p.get("recall", []), p.get("ap", 0.0))
        else:
            ax2.text(0.3, 0.5, "PR not available in metrics.json", fontsize=12)
        display_fig(fig2)
    except Exception as e:
        st.error(f"PR plotting failed: {e}")

with col3:
    st.subheader("Confusion Matrix")
    fig3, ax3 = plt.subplots()
    try:
        if best and best.get("confusion"):
            confusion_matrix_plot(ax3, best.get("confusion"))
        else:
            ax3.text(0.3, 0.5, "Confusion not available", fontsize=12)
        display_fig(fig3)
    except Exception as e:
        st.error(f"Confusion plotting failed: {e}")

st.markdown("---")

# SHAP panel
st.header("🧠 SHAP Explainers (if available)")
if shap is None:
    st.info("shap library not installed — install shap to enable SHAP plots")
else:
    try:
        with st.expander("Compute SHAP summary (may be slow)"):
            if st.button("Run SHAP (approx)"):
                # load a small feature sample
                sample_df = None
                if FEATURES_DIR.exists():
                    try:
                        files = list(FEATURES_DIR.glob("*.parquet"))
                        if files:
                            pf = sorted(files, key=lambda p: p.stat().st_mtime)[-1]
                            sample_df = pd.read_parquet(pf)
                    except Exception:
                        sample_df = None

                if sample_df is None or sample_df.shape[0] == 0:
                    st.warning("No features parquet found (utils/datasets/features/*.parquet) or file unreadable")
                else:
                    # sample safely
                    sample = sample_df.sample(min(500, len(sample_df)))
                    st.write("Sample shape:", sample.shape)
                    try:
                        if model is None:
                            st.warning("Model not loaded; SHAP requires a trained model")
                        else:
                            explainer = None
                            try:
                                # Prefer tree explainer for tree models
                                if hasattr(model, "predict_proba") or hasattr(model, "predict"):
                                    explainer = shap.TreeExplainer(model)
                                else:
                                    explainer = shap.Explainer(model)
                            except Exception as e:
                                st.warning(f"Could not create SHAP explainer: {e}")
                                explainer = None

                            if explainer is not None:
                                # compute shap values, but guard memory and time
                                try:
                                    X = sample.iloc[:, :len(feat_list)] if feat_list else sample.select_dtypes(include=[np.number]).iloc[:, :50]
                                    shap_values = explainer.shap_values(X)
                                    # SHAP summary plot -> matplotlib via savefig
                                    fig_sh = plt.figure(figsize=(8, 6))
                                    try:
                                        shap.summary_plot(shap_values, X, show=False)
                                    except Exception:
                                        # shap may produce its own matplotlib; attempt to capture
                                        pass
                                    display_fig(plt.gcf())
                                    st.success("SHAP summary plotted")
                                except Exception as e:
                                    st.error(f"SHAP computation failed: {e}")
                    except Exception as e:
                        st.error(f"SHAP plotting error: {e}")
    except Exception as e:
        st.exception(e)

st.markdown("---")

# Equity curve simulation
st.header("📈 Equity curve (simulated from signals)")

sim_col1, sim_col2 = st.columns([1, 2])
with sim_col1:
    look_back = st.number_input("Signals to simulate (tail)", min_value=10, max_value=2000, value=500, step=10)
    starting_cap = st.number_input("Starting capital (USD)", min_value=1.0, value=1000.0)
    per_trade = st.number_input("USD per trade (fixed)", min_value=1.0, value=10.0)

with sim_col2:
    st.markdown("_Simulation assumptions_: each IA_BUY -> entry at close, TP=1×ATR, SL=2% fixed, no fees, position sizing fixed")

signals_df = load_signals_tail(int(look_back))
if signals_df.empty:
    st.info("No signals_log.jsonl found or empty — run SignalsEngine to generate signals")
else:
    st.write("Signals loaded (tail):", len(signals_df))
    # build a simple equity simulation
    def simulate_equity(signals: pd.DataFrame, start_cap: float, per_trade_usd: float):
        cap = float(start_cap)
        history = [cap]
        times = []
        # iterate tail-to-head (old->new)
        for _, r in signals.iterrows():
            act = None
            try:
                acts = r.get("actions") or []
                for a in acts:
                    if isinstance(a, (list, tuple)) and isinstance(a[0], str) and a[0].startswith("IA_"):
                        act = a[0]
                        break
            except Exception:
                act = None
            if act == "IA_BUY":
                ret = float(r.get("features", {}).get("future_return", 0.0) or 0.0)
                pnl = per_trade_usd * ret
                cap += pnl
            elif act == "IA_SELL":
                ret = float(r.get("features", {}).get("future_return", 0.0) or 0.0)
                pnl = -per_trade_usd * ret
                cap += pnl
            history.append(cap)
            times.append(r.get("ts", time.time()))
        return np.array(history), np.array(times)

    # ensure not too heavy
    try:
        eq, times = simulate_equity(signals_df[::-1], float(starting_cap), float(per_trade))
        fig_eq, ax_eq = plt.subplots(figsize=(8, 4))
        ax_eq.plot(eq)
        ax_eq.set_title("Equity curve (simulated)")
        ax_eq.set_xlabel("Trades")
        ax_eq.set_ylabel("USD")
        display_fig(fig_eq)
    except Exception as e:
        st.error(f"Equity simulation failed: {e}")

st.markdown("---")

# Live signals viewer
st.header("🔔 Live Signals & Executions")
view_col1, view_col2 = st.columns(2)
with view_col1:
    s_tbl = load_signals_tail(200)
    if s_tbl.empty:
        st.info("No signals to show")
    else:
        # Limit columns and rows to avoid overloading frontend
        try:
            # keep top useful columns if exist
            cols_to_show = ["ts", "symbol", "close", "prob", "atr", "actions"]
            exist_cols = [c for c in cols_to_show if c in s_tbl.columns]
            st.dataframe(s_tbl[exist_cols].sort_values(by="ts", ascending=False).head(200))
        except Exception:
            st.dataframe(s_tbl.head(200))

with view_col2:
    e_tbl = load_executions_tail(200)
    if e_tbl.empty:
        st.info("No executions logged yet")
    else:
        try:
            cols_show = ["ts", "symbol", "side", "amount", "mode"]
            exist_cols = [c for c in cols_show if c in e_tbl.columns]
            st.dataframe(e_tbl[exist_cols].sort_values(by="ts", ascending=False).head(200))
        except Exception:
            st.dataframe(e_tbl.head(200))

st.markdown("---")

# Health check
st.header("🔎 Health Check & Diagnostics")
hc_col1, hc_col2, hc_col3 = st.columns(3)
with hc_col1:
    st.write("Model exists:", MODEL_PATH.exists())
    st.write("Scaler exists:", SCALER_PATH.exists())
    st.write("Feature list exists:", FEATURE_LIST_PATH.exists())

with hc_col2:
    st.write("Signals file:", SIGNALS_JSONL.exists())
    st.write("Executions file:", EXEC_JSONL.exists())
    st.write("Datasets dir:", DATASETS_DIR.exists())

with hc_col3:
    st.write("SHAP installed:", shap is not None)
    st.write("LightGBM installed:", lgb is not None)
    st.write("XGBoost installed:", xgb is not None)

st.markdown("---")

st.caption("Dashboard PRO — no cambios en ejecución real. Usa este panel para monitorizar y auditar.")

# EOF
