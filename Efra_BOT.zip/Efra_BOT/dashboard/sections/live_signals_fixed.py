import streamlit as st
import pandas as pd
import json
import os
from datetime import datetime

SIGNALS_FILE = "data/signals_log.jsonl"
EXEC_FILE = "data/executions_log.jsonl"


def load_jsonl(path):
    if not os.path.exists(path):
        return pd.DataFrame()
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except:
                pass
    return pd.DataFrame(rows)


def format_ts(ts):
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except:
        return ts


def draw_live_signals():
    st.title("📡 Live Signals & Executions — FIXED")

    col1, col2 = st.columns(2)

    # ==========================
    #   LOAD SIGNALS
    # ==========================
    with col1:
        st.subheader("📥 Señales Recientes")
        df_signals = load_jsonl(SIGNALS_FILE)

        if len(df_signals) == 0:
            st.warning("No hay señales registradas aún.")
        else:
            if "timestamp" in df_signals.columns:
                df_signals["timestamp"] = df_signals["timestamp"].apply(format_ts)

            st.dataframe(
                df_signals.tail(20).sort_values(by="timestamp", ascending=False),
                width="stretch",
            )

    # ==========================
    #   LOAD EXECUTIONS
    # ==========================
    with col2:
        st.subheader("🔧 Ejecuciones del Bot")
        df_exec = load_jsonl(EXEC_FILE)

        if len(df_exec) == 0:
            st.info("Aún no hay ejecuciones registradas.")
        else:
            if "timestamp" in df_exec.columns:
                df_exec["timestamp"] = df_exec["timestamp"].apply(format_ts)

            st.dataframe(
                df_exec.tail(20).sort_values(by="timestamp", ascending=False),
                width="stretch",
            )

    # ==========================
    # NO DYNAMIC IMPORTS
    # ==========================
    st.success("Live view funcionando sin módulos dinámicos 🚀")
