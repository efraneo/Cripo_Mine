# dashboard/model_dashboard.py
# =====================================================================
# Dashboard PRO de desempeño del modelo (Streamlit)
#
# Gráficos:
#   ✔ ROC curve
#   ✔ Precision–Recall curve
#   ✔ Confusion Matrix
#   ✔ Feature Importance
#   ✔ Equity Curve (backtesting simple)
#
# Carga:
#   models/best_model.pkl
#   models/scaler.pkl
#   data/signals_log.jsonl
# =====================================================================

import os
import json
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.metrics import (
    roc_curve, auc,
    precision_recall_curve,
    confusion_matrix
)

# -------------------------------------------------------------------
# UTIL PARA CARGAR DATASET
# -------------------------------------------------------------------
def load_dataset(path="data/signals_log.jsonl"):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                obj = json.loads(line)
                y = obj.get("future_return_y")
                feats = obj.get("features", {})
                if y is None:
                    continue
                rows.append({**feats, "y": y})
            except:
                continue

    df = pd.DataFrame(rows)
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    return df


# -------------------------------------------------------------------
# EQUITY CURVE — backtest simple sobre señales
# -------------------------------------------------------------------
def build_equity_curve(y_true, y_pred, threshold=0.5):
    """
    Regla simple:
    - pred > threshold → BUY → retorno = y_true
    - pred < (1 - threshold) → SELL → retorno = -y_true
    - neutro → 0
    """
    equity = []
    balance = 1.0

    for yt, yp in zip(y_true, y_pred):
        if yp > threshold:
            balance *= (1 + yt)
        elif yp < (1 - threshold):
            balance *= (1 - yt)
        # neutra => no trade
        equity.append(balance)

    return equity


# -------------------------------------------------------------------
# DASHBOARD — STREAMLIT
# -------------------------------------------------------------------
def main():
    st.set_page_config(page_title="Modelo ML — Dashboard PRO", layout="wide")
    st.title("📈 Dashboard PRO — Modelo AutoML (LightGBM / XGBoost)")

    # ----------------------------------------------------------------
    # CARGA MODELO
    # ----------------------------------------------------------------
    model_path = "models/best_model.pkl"
    scaler_path = "models/scaler.pkl"

    if not os.path.exists(model_path):
        st.error("❌ No se encontró models/best_model.pkl — entrena el modelo primero.")
        return

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)

    st.success("Modelo cargado correctamente ✔")

    # ----------------------------------------------------------------
    # DATASET
    # ----------------------------------------------------------------
    df = load_dataset()
    st.write(f"Dataset cargado: **{df.shape}**")

    y = df["y"].values
    X = df.drop(columns=["y"]).values

    # aplicar scaler
    Xs = scaler.transform(X)

    # predicciones
    preds = model.predict(Xs)

    # ----------------------------------------------------------------
    # GRÁFICO ROC CURVE
    # ----------------------------------------------------------------
    st.subheader("📉 ROC Curve")

    fpr, tpr, _ = roc_curve((y > 0).astype(int), preds)
    roc_auc = auc(fpr, tpr)

    fig, ax = plt.subplots()
    ax.plot(fpr, tpr, label=f"AUC = {roc_auc:.3f}")
    ax.plot([0, 1], [0, 1], linestyle="--")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve")
    ax.legend()
    st.pyplot(fig)

    # ----------------------------------------------------------------
    # PRECISION–RECALL CURVE
    # ----------------------------------------------------------------
    st.subheader("🎯 Precision–Recall Curve")

    precision, recall, _ = precision_recall_curve((y > 0).astype(int), preds)

    fig, ax = plt.subplots()
    ax.plot(recall, precision)
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("Precision–Recall Curve")
    st.pyplot(fig)

    # ----------------------------------------------------------------
    # CONFUSION MATRIX
    # ----------------------------------------------------------------
    st.subheader("🧩 Confusion Matrix")

    threshold = st.slider("Threshold (BUY vs SELL)", 0.1, 0.9, 0.5)

    y_bin = (y > 0).astype(int)
    p_bin = (preds > threshold).astype(int)

    cm = confusion_matrix(y_bin, p_bin)

    fig, ax = plt.subplots()
    im = ax.imshow(cm, cmap="Blues")
    plt.colorbar(im)

    for i in range(2):
        for j in range(2):
            ax.text(j, i, cm[i, j], ha="center", va="center")

    ax.set_xticks([0, 1])
    ax.set_yticks([0, 1])
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Confusion Matrix")
    st.pyplot(fig)

    # ----------------------------------------------------------------
    # FEATURE IMPORTANCE (solo si existe atributo)
    # ----------------------------------------------------------------
    st.subheader("⭐ Feature Importance")

    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_

        fig, ax = plt.subplots(figsize=(8, 6))
        idx = np.argsort(importances)
        ax.barh(range(len(importances)), importances[idx])
        ax.set_yticks(range(len(importances)))
        ax.set_yticklabels(df.drop(columns=["y"]).columns[idx])
        ax.set_title("Feature Importance")
        st.pyplot(fig)
    else:
        st.warning("Este modelo no provee feature_importances_")

    # ----------------------------------------------------------------
    # EQUITY CURVE
    # ----------------------------------------------------------------
    st.subheader("💰 Equity Curve")

    eq = build_equity_curve(y, preds, threshold=threshold)

    fig, ax = plt.subplots()
    ax.plot(eq)
    ax.set_title("Backtest — Equity Curve")
    ax.set_ylabel("Balance")
    st.pyplot(fig)


if __name__ == "__main__":
    main()
