# repair_ip_risk.py

import sqlite3

DB="data/usuarios.db"

conn=sqlite3.connect(DB)

cur=conn.cursor()

print("\nVerificando tabla ip_risk...\n")

cur.execute(
"""
PRAGMA table_info(ip_risk)
"""
)

cols=[r[1] for r in cur.fetchall()]

print("Columnas actuales:")
print(cols)

# ==================================
# AGREGAR risk_score SI FALTA
# ==================================

if "risk_score" not in cols:

    print(
        "\nAgregando risk_score..."
    )

    cur.execute(
    """
    ALTER TABLE ip_risk

    ADD COLUMN risk_score
    INTEGER DEFAULT 0
    """
    )

    print(
        "OK"
    )

else:

    print(
        "\nrisk_score ya existe"
    )

conn.commit()

conn.close()

print(
"\nDB reparada correctamente"
)
