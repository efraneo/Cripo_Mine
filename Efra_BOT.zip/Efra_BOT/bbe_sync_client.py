# ============================================================
# bbe_sync_client.py — Cliente sincronizador cifrado BBE
# ============================================================
"""
CLI seguro para sincronizar los archivos de claves Binance (BBE_<usuario>.csv)
entre el dispositivo del usuario y el servidor autorizado del administrador.

Funciones:
- Genera y almacena clave AES única por usuario (derivada de MASTER_KEY)
- Solicita token JWT al servidor para autenticación
- Sube o descarga el archivo cifrado desde el servidor
- Puede ejecutarse como script o desde otros módulos (import bbe_sync_client)
"""

import os
import sys
import json
import time
import base64
import hmac
import hashlib
import requests
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from typing import Optional

# ------------------------------
# CONFIGURACIÓN LOCAL
# ------------------------------
SERVER_URL = os.getenv("BBE_SYNC_SERVER", "http://localhost:8000")
MASTER_KEY_HEX = os.getenv("MASTER_KEY_HEX", None)
MASTER_KEY = bytes.fromhex(MASTER_KEY_HEX) if MASTER_KEY_HEX else hashlib.sha256(b"default_master_key").digest()

USUARIO = os.getenv("BBE_USER", None)
CLAVE = os.getenv("BBE_PASS", None)
LOCAL_FILE = os.getenv("BBE_FILE", f"./BBE_{USUARIO or 'user'}.csv")

# ------------------------------
# CIFRADO AES-GCM LOCAL
# ------------------------------
def derive_user_key(usuario: str) -> bytes:
    if not isinstance(usuario, bytes):
        usuario = usuario.encode()
    return hmac.new(MASTER_KEY, usuario, hashlib.sha256).digest()

def aes_encrypt_for_user(usuario: str, data: bytes) -> bytes:
    key = derive_user_key(usuario)
    nonce = os.urandom(12)
    aes = AESGCM(key)
    ct = aes.encrypt(nonce, data, associated_data=None)
    return base64.b64encode(nonce + ct)

def aes_decrypt_for_user(usuario: str, b64data: bytes) -> bytes:
    key = derive_user_key(usuario)
    payload = base64.b64decode(b64data)
    nonce, ct = payload[:12], payload[12:]
    aes = AESGCM(key)
    return aes.decrypt(nonce, ct, associated_data=None)

# ------------------------------
# TOKEN HANDLER
# ------------------------------
def request_token(usuario: str, clave: str) -> Optional[str]:
    try:
        resp = requests.post(f"{SERVER_URL}/token", json={"usuario": usuario, "clave": clave}, timeout=10)
        if resp.status_code == 200:
            return resp.json().get("access_token")
        else:
            print(f"[!] Error token: {resp.status_code} {resp.text}")
            return None
    except Exception as e:
        print(f"[!] Error conectando al servidor: {e}")
        return None

# ------------------------------
# SUBIR / DESCARGAR ARCHIVOS
# ------------------------------
def upload_bbe(usuario: str, clave: str, path: str):
    if not os.path.exists(path):
        print(f"[!] No existe el archivo local {path}")
        return
    token = request_token(usuario, clave)
    if not token:
        print("[!] No se pudo obtener token JWT.")
        return

    try:
        with open(path, "rb") as f:
            data = f.read()
        enc_data = aes_encrypt_for_user(usuario, data)
        files = {"file": ("BBE.csv", base64.b64decode(enc_data))}
        data_payload = {"usuario": usuario}
        headers = {"Authorization": f"Bearer {token}"}
        r = requests.post(f"{SERVER_URL}/sync/upload", files=files, data=data_payload, headers=headers)
        if r.status_code == 200:
            print("[✓] Archivo subido correctamente al servidor.")
        else:
            print(f"[!] Error en subida: {r.status_code} {r.text}")
    except Exception as e:
        print(f"[!] Error subiendo archivo: {e}")

def download_bbe(usuario: str, clave: str, dest: str):
    token = request_token(usuario, clave)
    if not token:
        print("[!] No se pudo obtener token JWT.")
        return
    headers = {"Authorization": f"Bearer {token}"}
    params = {"usuario": usuario}
    r = requests.get(f"{SERVER_URL}/sync/download", headers=headers, params=params)
    if r.status_code != 200:
        print(f"[!] Error descarga: {r.status_code} {r.text}")
        return
    js = r.json()
    b64data = js.get("file_b64")
    if not b64data:
        print("[!] No hay archivo remoto.")
        return
    try:
        dec = aes_decrypt_for_user(usuario, b64data.encode("utf-8"))
        with open(dest, "wb") as f:
            f.write(dec)
        print(f"[✓] Archivo descargado y descifrado en {dest}")
    except Exception as e:
        print(f"[!] Error descifrando: {e}")

# ------------------------------
# CLI
# ------------------------------
def main():
    if len(sys.argv) < 2:
        print("Uso: python bbe_sync_client.py [upload|download]")
        sys.exit(1)
    accion = sys.argv[1].lower()
    usuario = USUARIO or input("Usuario: ")
    clave = CLAVE or input("Clave: ")
    if accion == "upload":
        upload_bbe(usuario, clave, LOCAL_FILE)
    elif accion == "download":
        download_bbe(usuario, clave, LOCAL_FILE)
    else:
        print("Acción no reconocida (usa upload o download)")

if __name__ == "__main__":
    main()
