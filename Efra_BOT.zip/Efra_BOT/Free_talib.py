import talib
import numpy as np

print(np.__version__)
print(len(talib.get_functions()))
