import sqlite3

conn = sqlite3.connect("data/usuarios.db")
c = conn.cursor()

# Añadir columna IP a sesiones
c.execute("ALTER TABLE sessions ADD COLUMN ip TEXT")

conn.commit()
conn.close()

print("✅ Migración completada: columna ip añadida a sessions")
