import sqlite3
import os

DB = os.path.join("data", "usuarios.db")

schema = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    username TEXT,
    created_at INTEGER,
    last_touch INTEGER,
    expires_at INTEGER
);
"""

print("📌 Conectando a la base de datos:", DB)

conn = sqlite3.connect(DB)
c = conn.cursor()

print("📌 Creando tabla 'sessions' con schema PRO...")

c.execute(schema)
conn.commit()

print("📌 Verificando estructura final...")

columns = c.execute("PRAGMA table_info(sessions)").fetchall()

print("\n📋 Columnas encontradas en 'sessions':")
for col in columns:
    cid, name, coltype, *_ = col
    print(f" - {cid}: {name} ({coltype})")

print("\n✅ DONE: La tabla fue creada y verificada correctamente.")
conn.close()
