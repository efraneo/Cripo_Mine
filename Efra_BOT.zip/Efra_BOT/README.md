# 🤖 Efra_BOT

Sistema de análisis de activos y trading automático con IA.

## 🚀 Instalación

```bash
git clone ...
cd Efra_BOT
pip install -r requirements.txt
streamlit run el_bot_de_efra.py
```

## ▶️ Entrada principal actual

- App principal: `el_bot_de_efra.py`
- API secundaria: `infra/api/main.py`

## 🧭 Nota operativa

El flujo más estable del proyecto hoy es la app Streamlit. Los scripts de migración, utilidades sueltas y rutas auxiliares deben tratarse como soporte/legacy hasta que se consoliden.
