import streamlit as st

st.set_page_config(page_title="TEST MOTOR", layout="wide")
st.header("TEST MOTOR")

engine = st.session_state.get("trading_engine")

if engine is None:
    st.error("❌ ENGINE NO EXISTE EN SESSION_STATE")
    st.info(
        "Este test debe ejecutarse DESPUÉS de que el bot principal "
        "haya inicializado el TradingEngine."
    )
    st.stop()

st.success("✅ ENGINE ENCONTRADO")

# ----------------------------------------
# TEST REAL
# ----------------------------------------
try:
    df = engine.get_klines_df("BTCUSDT", "5m", 10)

    st.success("get_klines_df ejecutado correctamente")
    st.write("Tipo devuelto:", type(df))
    st.dataframe(df)

except Exception as e:
    st.error("❌ Error usando el engine")
    st.exception(e)
