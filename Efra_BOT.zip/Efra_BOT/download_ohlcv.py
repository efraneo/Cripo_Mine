import argparse
import pandas as pd
from datetime import datetime, timedelta
from binance.client import Client
from env_loader import load_binance_keys

# ----------------------------------------------------
# CARGAR CLAVES DESDE /env/binance.env
# ----------------------------------------------------
API_KEY, API_SECRET, MODO_DEMO = load_binance_keys()

# ----------------------------------------------------
# FUNCIÓN PARA DESCARGAR OHLCV
# ----------------------------------------------------
def descargar_ohlcv(symbol, interval, days):
    print(f"🔐 Claves cargadas. MODO_DEMO = {MODO_DEMO}")
    client = Client(API_KEY, API_SECRET)

    end_time = datetime.utcnow()
    start_time = end_time - timedelta(days=days)

    print(f"📥 Descargando {days} días de velas para {symbol} en {interval}...")

    klines = client.get_historical_klines(
        symbol,
        interval,
        start_time.strftime("%d %b %Y %H:%M:%S"),
        end_time.strftime("%d %b %Y %H:%M:%S")
    )

    columnas = [
        "timestamp", "open", "high", "low", "close", "volume",
        "close_time", "quote_asset_volume", "number_of_trades",
        "taker_buy_base", "taker_buy_quote", "ignore"
    ]

    df = pd.DataFrame(klines, columns=columnas)

    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    df = df[["timestamp", "open", "high", "low", "close", "volume"]]

    filename = f"{symbol}_{interval}_{days}d.csv"
    df.to_csv(filename, index=False)

    print(f"✅ Archivo generado exitosamente: {filename}")

# ----------------------------------------------------
# MAIN
# ----------------------------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--symbol", type=str, required=True)
    parser.add_argument("--interval", type=str, default="1m")
    parser.add_argument("--days", type=int, default=30)

    args = parser.parse_args()
    descargar_ohlcv(args.symbol, args.interval, args.days)
