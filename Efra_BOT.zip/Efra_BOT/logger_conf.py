# logger_conf.py
"""
Logger configuration with rotating file handlers.
Provides get_logger(name) -> logging.Logger

Logs:
 - Console: INFO
 - File: DEBUG (rotating)
 - Sensitive values are not written by default.
"""
import logging
from logging.handlers import RotatingFileHandler
import os

LOG_DIR = os.getenv("BOT_LOG_DIR", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

def get_logger(name: str = "bot") -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    fmt = logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")

    # Console handler (INFO)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(fmt)
    logger.addHandler(console)

    # Rotating file handler (DEBUG)
    file_handler = RotatingFileHandler(
        os.path.join(LOG_DIR, f"{name}.log"),
        maxBytes=10_000_000,  # 10 MB
        backupCount=10,
        encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    # Avoid propagation to root handlers duplicate
    logger.propagate = False
    return logger
