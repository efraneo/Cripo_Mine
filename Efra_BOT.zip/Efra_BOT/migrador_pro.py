import sqlite3
import os
import re

DB = os.path.join("data", "usuarios.db")
SCHEMA_FILE = os.path.join("sql", "schema_pro.sql")

print("📌 Leyendo schema PRO desde:", SCHEMA_FILE)

with open(SCHEMA_FILE, "r", encoding="utf-8") as f:
    schema_sql = f.read()

# Extraer definiciones CREATE TABLE
table_defs = re.findall(
    r"CREATE TABLE IF NOT EXISTS ([a-zA-Z0-9_]+)\s*\((.*?)\);",
    schema_sql,
    flags=re.DOTALL
)

conn = sqlite3.connect(DB)
c = conn.cursor()

def parse_columns(block):
    cols = []
    for line in block.split(","):
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        # obtener nombre y tipo
        parts = line.split()
        name = parts[0]
        coltype = parts[1] if len(parts) > 1 else "TEXT"
        cols.append((name, coltype))
    return cols

print("📌 Iniciando migración...\n")

for table_name, cols_block in table_defs:

    print(f"🔍 Revisando tabla: {table_name}")

    # parse columnas del schema
    required_cols = parse_columns(cols_block)

    # Obtener columnas reales de la BD
    existing = c.execute(f"PRAGMA table_info({table_name})").fetchall()

    if not existing:
        print(f"  ➤ Tabla '{table_name}' NO existe. Creándola...")
        c.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({cols_block})")
        conn.commit()
        print("  ✔ Tabla creada\n")
        continue

    existing_names = {col[1]: col[2] for col in existing}

    # Revisar columnas faltantes
    for col_name, col_type in required_cols:
        if col_name not in existing_names:
            print(f"  ➤ Columna faltante: {col_name} ({col_type}). Agregando...")
            try:
                c.execute(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}")
                conn.commit()
                print("    ✔ Columna agregada")
            except Exception as e:
                print("    ❌ Error al agregar columna:", e)

    print("  ✔ Tabla OK\n")

print("🎉 MIGRACIÓN COMPLETADA EXITOSAMENTE 🎉\n")

print("📋 Estructura final de todas las tablas:\n")

for table_name, _ in table_defs:
    print(f"Tabla: {table_name}")
    columns = c.execute(f"PRAGMA table_info({table_name})").fetchall()
    for col in columns:
        print(f"  - {col[1]} ({col[2]})")
    print("")

conn.close()
print("✅ Listo. Base de datos actualizada correctamente.")
