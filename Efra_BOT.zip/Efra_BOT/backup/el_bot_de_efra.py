# ============================================================
# EL BOT DE EFRA PRO — BLOQUE CORREGIDO (REEMPLAZAR PARTE 1/2)
# - Evita reinicios de Streamlit causados por inicializaciones con side-effects.
# - Lazy init del engine + inicialización segura del session_state.
# - cached_get_* tolerantes a engine None.
# ============================================================

import os
import json
import time
import uuid
import logging
import sqlite3
import re
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

import streamlit as st

# ==========================================
# 1) CARGA DE VARIABLES DE ENTORNO (UNA VEZ)
# ==========================================
if "env_loaded" not in st.session_state:
    try:
        from backend.env_loader import load_all_envs
        load_all_envs("env", override=True)
    except Exception:
        pass
    st.session_state["env_loaded"] = True

# ==========================================
# 2) LOGGERS PRO UNIFICADOS
# ==========================================
try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
    security_log = get_logger("security")
    signals_log = get_logger("signals")
    trade_log = get_logger("trade")
except Exception:
    app_log = logging.getLogger("app")
    security_log = logging.getLogger("security")
    signals_log = logging.getLogger("signals")
    trade_log = logging.getLogger("trade")

    for lg in (app_log, security_log, signals_log, trade_log):
        if not lg.handlers:
            h = logging.StreamHandler()
            h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
            lg.addHandler(h)
        lg.setLevel(logging.INFO)

# ==========================================
# 3) IMPORTS DEL BACKEND (no side-effect heavy ops)
# ==========================================
from backend.user_manager import UserManager
from backend.ip_manager import IPManager
from backend.session_manager import SessionManager

# IMPORTS para engine/managers (no inicializamos aquí: lazy_init_engine() se encargará)
from backend.trading_engine import init_engine_singleton, get_engine_singleton
from backend.binance_manager import BinanceManager
from backend.order_manager import OrderManager
from backend.risk_manager import RiskManager
from backend.model_predictor import IAPredictor
from utils.feature_builder_pro import FeatureBuilderPRO

# Telegram notifier (best-effort)
try:
    from backend.telegram_notifier import enviar_mensaje as telegram_send
except Exception:
    telegram_send = None

# Auth Utils (Bloqueo, 2FA)
try:
    from backend import auth_utils
except Exception:
    auth_utils = None

# Results
try:
    from backend.results_manager import ResultsManager
except Exception:
    ResultsManager = None

# ==========================================
# 4) CONFIG PAGINA
# ==========================================
st.set_page_config(
    page_title="El BOT de EFRA",
    layout="wide",
    page_icon="⚡"
)

# ==========================================
# 5) DATABASE / MANAGERS (ligero, seguro)
# ==========================================
DB_PATH = os.path.join("data", "usuarios.db")
os.makedirs("data", exist_ok=True)

user_m = UserManager(DB_PATH)
ip_m = IPManager(DB_PATH)
session_m = SessionManager(DB_PATH)

# =================================================
# 6) INICIALIZACIÓN SEGURA DEL SESSION_STATE (UNA VEZ)
# =================================================
if "init_done" not in st.session_state:
    # claves seguras por defecto
    st.session_state["init_done"] = True
    st.session_state["session_id"] = None
    st.session_state["pending_2fa_user"] = None
    st.session_state["selected_asset"] = None
    st.session_state["analizando_activo"] = False
    st.session_state["authenticated_user"] = None
    st.session_state["username"] = None
    st.session_state["current_username"] = None
    st.session_state["current_user_display"] = None
    # engine guard (no inicializa aquí)
    st.session_state["engine"] = None
    st.session_state["engine_init_attempted"] = False  # evita reintentos continuos si falla
    app_log.info("🔧 Session state inicializado (una sola vez).")

# =================================================
# 7) FUNCIONES FALTANTES — IMPLEMENTACIÓN REAL
# =================================================

def safe_rerun(delay: float = 0.2):
    """Reintenta hacer rerun de Streamlit sin romper si el entorno no soporta rerun."""
    try:
        time.sleep(delay)
        st.rerun()
    except Exception:
        pass


def get_current_user_record():
    """
    Devuelve el registro (fila) completo del usuario autenticado actual.
    Maneja sesión expirada, sesión inválida y fallback seguro.
    """
    sid = st.session_state.get("session_id")
    if not sid:
        return None

    try:
        sess = session_m.get_session(sid)
    except Exception as e:
        app_log.exception("Error leyendo session_m.get_session: %s", e)
        sess = None

    if not sess:
        # sesión expirada o eliminada
        st.session_state["session_id"] = None
        return None

    # Touch session para renovar expiración
    try:
        session_m.touch_session(sid)
    except Exception:
        pass

    username = sess.get("username")
    if not username:
        return None

    # Obtener usuario desde DB
    try:
        rec = user_m.get_user_by_username(username)
        if not rec:
            return {"username": username}
        return rec
    except Exception as e:
        app_log.exception("Error en get_current_user_record(): %s", e)
        return {"username": username}


def _get_display_name_from_record(rec: dict | None):
    """
    Devuelve el nombre 'bonito' del usuario (display name) según múltiples campos.
    """
    if not rec:
        return None

    for k in ("display_name", "display", "nombre", "full_name", "fullname", "name"):
        v = rec.get(k)
        if v and isinstance(v, str) and v.strip():
            return v.strip()

    fn = rec.get("first_name") or rec.get("firstname")
    ln = rec.get("last_name") or rec.get("lastname") or rec.get("apellido")
    if fn or ln:
        parts = []
        if fn and isinstance(fn, str):
            parts.append(fn.strip())
        if ln and isinstance(ln, str):
            parts.append(ln.strip())
        if parts:
            return " ".join(parts)

    # email local-part
    email = rec.get("email")
    if email and isinstance(email, str) and "@" in email:
        return email.split("@", 1)[0].replace(".", " ").replace("_", " ").title()

    # username fallback
    u = rec.get("username")
    if isinstance(u, int) or (isinstance(u, str) and u.isdigit()):
        return f"User-{u}"
    if isinstance(u, str):
        return u

    return "Usuario"


# ====================================================
# 8) EMAIL EXTRACTOR
# ====================================================
_email_rx = re.compile(r"[^@]+@[^@]+\.[^@]+")

def _get_user_email(username: str) -> str | None:
    try:
        u = user_m.get_user_by_username(username)
        if not u:
            return None
        email = u.get("email")
        if email and isinstance(email, str) and _email_rx.match(email):
            return email
        return None
    except Exception:
        return None


# ============================================================
# 9) LATE / LAZY ENGINE INITIALIZATION — evitar side-effects
# ============================================================
def lazy_init_engine(force: bool = False):
    """
    Inicializa el engine SOLO cuando se necesita.
    Soporta MODO REAL/DEMO + confirm_callback 2FA para órdenes reales.
    """
    # Ya existe
    if st.session_state.get("engine") and not force:
        return st.session_state["engine"]

    # Ya intentado anteriormente
    if st.session_state.get("engine_init_attempted") and not force:
        app_log.info("lazy_init_engine: init previamente intentado; no reintentando.")
        return st.session_state.get("engine")

    st.session_state["engine_init_attempted"] = True

    try:
        # ----- Crear BinanceManager -----
        binance_mgr = BinanceManager(
            api_key=os.getenv("BINANCE_API_KEY", ""),
            api_secret=os.getenv("BINANCE_API_SECRET", ""),
            base_url=os.getenv("BINANCE_BASE_URL", "https://api.binance.com"),
        )

        # ----- Determinar modo REAL/DEMO -----
        selected_mode = st.session_state.get("bot_mode", "DEMO").upper()

        # ----- OrderManager con callback 2FA si REAL -----
        order_mgr = OrderManager(
            client=binance_mgr.client,
            mode=selected_mode,
            confirm_callback=auth_utils.validate_2fa_token if selected_mode == "REAL" else None
        )

        # ----- Engine -----
        engine_obj = init_engine_singleton(
            binance=binance_mgr,
            order_manager=order_mgr,
            risk_manager=RiskManager(),
            predictor=IAPredictor if IAPredictor is not None else None,
            feature_builder=FeatureBuilderPRO if FeatureBuilderPRO is not None else None,
            mode=selected_mode
        )

        try:
            engine_singleton = get_engine_singleton()
        except Exception:
            engine_singleton = engine_obj

        st.session_state["engine"] = engine_singleton

        app_log.info(f"Engine inicializado correctamente (lazy). MODO={selected_mode}")
        return engine_singleton

    except Exception as e:
        app_log.exception("lazy_init_engine failed: %s", e)
        st.session_state["engine"] = None
        return None


# ============================================================
# 10) CACHING PRO (symbols + balance) — tolerantes a engine None
#     (usa parámetros _engine optional para compatibilidad)
# ============================================================
@st.cache_data(ttl=300, show_spinner=False)
def cached_get_symbols(_engine=None):
    """
    Obtiene lista de símbolos (cacheada 5 min).
    Si _engine es None, intenta usar st.session_state["engine"] (lazy-init NO forzado).
    """
    try:
        engine_obj = _engine or st.session_state.get("engine")
        if engine_obj is None:
            # no forzamos init para evitar side-effects; devolvemos fallback
            app_log.info("cached_get_symbols: no engine disponible -> fallback symbols.")
            return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

        symbols_list = None

        # 1) prioridad a engine.binance si existe
        if getattr(engine_obj, "binance", None):
            b = engine_obj.binance
            if getattr(b, "get_all_symbols", None):
                symbols_list = b.get_all_symbols()
            elif getattr(b, "get_symbols", None):
                symbols_list = b.get_symbols()
            elif getattr(b, "get_all_tickers", None):
                symbols_list = [s["symbol"] for s in b.get_all_tickers()]

        # 2) helper en el engine
        if not symbols_list and getattr(engine_obj, "get_symbols", None):
            symbols_list = engine_obj.get_symbols()

        # 3) data_client helper
        if not symbols_list and getattr(engine_obj, "data_client", None):
            dc = engine_obj.data_client
            if getattr(dc, "get_all_symbols", None):
                symbols_list = dc.get_all_symbols()
            elif getattr(dc, "get_symbols", None):
                symbols_list = dc.get_symbols()
            elif getattr(dc, "get_all_tickers", None):
                symbols_list = [s["symbol"] for s in dc.get_all_tickers()]

        # safe fallback
        if not symbols_list:
            return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

        cleaned = []
        for s in symbols_list:
            if isinstance(s, dict) and "symbol" in s:
                cleaned.append(str(s["symbol"]).upper())
            else:
                cleaned.append(str(s).upper())

        cleaned = sorted(set(cleaned))
        usdt_pairs = [c for c in cleaned if c.endswith("USDT")]
        others = [c for c in cleaned if not c.endswith("USDT")]
        return usdt_pairs + others

    except Exception as e:
        app_log.exception("Error en cached_get_symbols: %s", e)
        return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]


@st.cache_data(ttl=120, show_spinner=False)
def cached_get_balance(_engine=None, asset="USDT"):
    """
    Obtiene balance (cache 2 min).
    Si _engine es None, intenta usar st.session_state["engine"] (NO forzamos init).
    """
    try:
        engine_obj = _engine or st.session_state.get("engine")
        if engine_obj is None:
            app_log.info("cached_get_balance: no engine disponible -> returning 0.0")
            return 0.0

        # 1) compat engine.binance
        if getattr(engine_obj, "binance", None):
            b = engine_obj.binance
            if getattr(b, "get_spot_balance", None):
                bal = b.get_spot_balance(asset)
                return float(bal) if bal not in (None, "None") else 0.0
            if getattr(b, "get_asset_balance", None):
                bal = b.get_asset_balance(asset)
                if isinstance(bal, dict):
                    free_val = bal.get("free") or bal.get("balance") or None
                    try:
                        return float(free_val) if free_val not in (None, "None") else 0.0
                    except:
                        return 0.0
                if isinstance(bal, (int, float, str)):
                    try:
                        return float(bal)
                    except:
                        return 0.0

        # 2) data_client.get_balance
        if getattr(engine_obj, "data_client", None) and getattr(engine_obj.data_client, "get_balance", None):
            bal = engine_obj.data_client.get_balance(asset)
            return float(bal) if bal not in (None, "None") else 0.0

        # 3) engine.get_balance
        if getattr(engine_obj, "get_balance", None):
            bal = engine_obj.get_balance(asset)
            return float(bal) if bal not in (None, "None") else 0.0

        # fallback
        app_log.warning(f"[cached_get_balance] No se pudo obtener balance para {asset}.")
        return 0.0

    except Exception as e:
        app_log.exception("Error en cached_get_balance: %s", e)
        return 0.0

# ============================================================
# FIN DEL BLOQUE CORREGIDO —
# - Usa lazy_init_engine() para crear el engine en el momento que quieras.
# - Ejemplo de uso recomendado: llamar lazy_init_engine() justo antes de leer balance/símbolos
#   (por ejemplo, en el sidebar cuando el usuario ya se autentificó).
# ============================================================

# ============================================================
# SIDEBAR PRO — Autenticación, 2FA, Engine Lazy, Balance Spot,
# Selector de activos, Modo (REAL/DEMO) y control de sesión
# ============================================================

st.sidebar.title("🔐 Acceso al Bot de Efra")

# ------------------------------
# HELPER: Inicialización diferida del engine (idempotente)
# ------------------------------
def lazy_init_engine(force: bool = False):
    """
    Inicializa el engine SOLO cuando se necesita.
    - Evita reinicios constantes y protege el flujo de login + 2FA.
    - Mantiene la instancia en st.session_state['engine'].
    """
    # devolver si ya existe y no forzamos
    if not force and st.session_state.get("engine") is not None:
        return st.session_state["engine"]

    try:
        binance_mgr = BinanceManager(
            api_key=os.getenv("BINANCE_API_KEY", ""),
            api_secret=os.getenv("BINANCE_API_SECRET", ""),
            base_url=os.getenv("BINANCE_BASE_URL", "https://api.binance.com"),
        )

        eng = init_engine_singleton(
            binance=binance_mgr,
            order_manager=OrderManager({"mode": os.getenv("BOT_MODE", "DEMO")}),
            risk_manager=RiskManager(),
            predictor=IAPredictor if IAPredictor is not None else None,
            feature_builder=FeatureBuilderPRO if FeatureBuilderPRO is not None else None,
        )

        st.session_state["engine"] = eng
        try:
            app_log.info("Engine inicializado por lazy_init_engine().")
        except Exception:
            pass
        return eng

    except Exception as e:
        try:
            app_log.exception("lazy_init_engine() → error: %s", e)
        except Exception:
            pass
        st.session_state["engine"] = None
        return None


# ------------------------------
# HELPER: Enviar correo 2FA (con logging)
# ------------------------------
def send_2fa_email(email: str, token: str) -> bool:
    """
    Envío seguro del código 2FA. Devuelve True si el envío fue confirmado.
    Usa backend/mailer.send_mail vía wrapper.
    """
    try:
        r = send_mail(
            to=email,
            subject="El BOT de Efra — Código de acceso",
            body=f"Tu código 2FA es: {token}\nVálido por 5 minutos."
        )
        if r.get("ok"):
            # feedback al usuario (sidebar)
            try:
                st.sidebar.success("Código 2FA enviado a tu correo.")
            except Exception:
                pass
            try:
                app_log.info("2FA enviado a %s", email)
            except Exception:
                pass
            return True
        else:
            try:
                st.sidebar.warning("No se pudo enviar correo 2FA (modo DEV activado).")
            except Exception:
                pass
            try:
                app_log.warning("send_2fa_email failed: %s", r.get("error"))
            except Exception:
                pass
            return False
    except Exception as e:
        try:
            app_log.exception("Error enviando correo 2FA: %s", e)
        except Exception:
            pass
        try:
            st.sidebar.warning("No se pudo enviar correo 2FA (modo DEV activado).")
        except Exception:
            pass
        return False


# ------------------------------
# Inicializar keys/session defaults si no están
# ------------------------------
if "engine" not in st.session_state:
    st.session_state["engine"] = None
if "bot_mode" not in st.session_state:
    st.session_state["bot_mode"] = os.getenv("BOT_MODE", "DEMO").upper() if os.getenv("BOT_MODE") else "DEMO"
if "analizando_activo" not in st.session_state:
    st.session_state["analizando_activo"] = False
if "selected_asset" not in st.session_state:
    st.session_state["selected_asset"] = None
if "pending_2fa_user" not in st.session_state:
    st.session_state["pending_2fa_user"] = None
if "session_id" not in st.session_state:
    st.session_state["session_id"] = None

# ------------------------------
# Selector de MODO (DEMO / REAL) — colocado en el sidebar arriba
# ------------------------------
st.sidebar.markdown("**Modo del Bot**")
st.session_state["bot_mode"] = st.sidebar.selectbox(
    "Selecciona modo",
    options=["REAL", "DEMO"],
    index=0 if st.session_state.get("bot_mode", "DEMO").upper() == "REAL" else 1,
    help="REAL → ejecuta órdenes reales. DEMO → simulación (seguro).",
    key="sidebar_bot_mode_select"
)

# ============================================================
#  ACTIVAR / CONFIRMAR MODO REAL con 2FA
# ============================================================

bot_mode = st.session_state.get("bot_mode", "DEMO").upper()

if bot_mode == "REAL":
    st.sidebar.warning("Modo REAL seleccionado. Se requiere autorización 2FA adicional.")

    # Campo para token 2FA
    token_real = st.sidebar.text_input(
        "Código 2FA para habilitar órdenes REALES",
        type="password",
        key="real_mode_2fa_input"
    )

    # Botón para confirmar MODO REAL
    if st.sidebar.button("Confirmar MODO REAL"):
        if not current_username:
            st.sidebar.error("Debe iniciar sesión.")
        else:
            # Engine debe existir antes
            eng = st.session_state.get("engine")
            if not eng:
                st.sidebar.error("Engine no inicializado aún. Analice un activo o recargue.")
            else:
                try:
                    om = eng.order_manager
                except:
                    om = None

                if om is None:
                    st.sidebar.error("OrderManager no disponible.")
                else:
                    ok = om.confirm_real_operation(token_real, current_username)

                    if ok:
                        st.sidebar.success("MODO REAL autorizado — válido por 5 minutos.")
                    else:
                        st.sidebar.error("Código 2FA inválido o expirado.")


# Propagar modo al engine/binance (si existe)
try:
    # lazy init only when needed — no forzar creación del engine al cambiar modo
    eng = st.session_state.get("engine")
    if eng is not None:
        try:
            setattr(eng, "mode", st.session_state["bot_mode"])
        except Exception:
            pass
        try:
            if getattr(eng, "binance", None):
                setattr(eng.binance, "mode", st.session_state["bot_mode"])
        except Exception:
            pass
except Exception:
    try:
        app_log.exception("No se pudo propagar bot_mode al engine/binance")
    except Exception:
        pass

# ------------------------------
# Obtener registro actual y display
# ------------------------------
logged_rec = get_current_user_record()
current_username = logged_rec.get("username") if logged_rec else None
current_user_display = _get_display_name_from_record(logged_rec) if logged_rec else None


# ============================================================
# SI YA ESTÁ LOGUEADO
# ============================================================
if current_username:

    st.sidebar.success(f"Conectado como: **{current_user_display or current_username}**")

    # ------------------------------------------------------------
    # Rol
    # ------------------------------------------------------------
    try:
        urec = user_m.get_user_by_username(current_username)
    except Exception:
        urec = None
    st.sidebar.info("Rol: ADMINISTRADOR" if (urec and urec.get("is_admin")) else "Rol: Usuario")

    # ------------------------------------------------------------
    # Inicializar ENGINE (lazy)
    # ------------------------------------------------------------
    engine = lazy_init_engine(force=False)

    # ------------------------------------------------------------
    # 1) Selector de MODO (REAL/DEMO)
    # ------------------------------------------------------------
    st.sidebar.markdown("### Modo del Bot")

    st.session_state["bot_mode"] = st.sidebar.selectbox(
        "Selecciona modo",
        options=["REAL", "DEMO"],
        index=0 if st.session_state.get("bot_mode", "DEMO") == "REAL" else 1,
        help="REAL → órdenes reales. DEMO → simulación (seguro)"
    )

    bot_mode = st.session_state["bot_mode"].upper()
    es_real = (bot_mode == "REAL")

    # Propagar al engine
    try:
        if engine:
            setattr(engine, "mode", bot_mode)
            if getattr(engine, "binance", None):
                setattr(engine.binance, "mode", bot_mode)
    except Exception:
        pass

    # ------------------------------------------------------------
    # 2) Mostrar balance (siempre seguro)
    # ------------------------------------------------------------
    try:
        balance_val = cached_get_balance(engine, "USDT") if engine else None
        bal_txt = f"{balance_val:,.2f} USDT" if isinstance(balance_val, (float, int)) else "N/D"
    except:
        bal_txt = "N/D"

    st.sidebar.caption(f"💰 Balance Spot: **{bal_txt}**")

    # ------------------------------------------------------------
    # 3) Lista de símbolos
    # ------------------------------------------------------------
    try:
        symbols_list = cached_get_symbols(engine) if engine else ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
    except:
        symbols_list = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

    st.sidebar.markdown("### Selección de activo")

    prev = st.session_state.get("selected_asset")
    default_index = symbols_list.index(prev) if prev in symbols_list else 0

    try:
        st.session_state["selected_asset"] = st.sidebar.selectbox(
            "Activo",
            options=symbols_list,
            index=default_index,
            key="sidebar_activo_select"
        )
    except Exception:
        st.session_state["selected_asset"] = st.sidebar.text_input(
            "Activo (ej: BTCUSDT)",
            value=st.session_state.get("selected_asset") or "BTCUSDT"
        )

    # ------------------------------------------------------------
    # 4) Protección MODO REAL (riesgo)
    # ------------------------------------------------------------
    if es_real:
        st.sidebar.markdown(
            """
            <div style="border:2px solid #600000; padding:10px; background:#330000;">
                <strong style="color:#ff4444; font-size:16px;">MODO REAL ACTIVADO</strong><br>
                Todas las operaciones posteriores serán REALES.<br>
                Requiere verificación adicional.
            </div>
            """,
            unsafe_allow_html=True,
        )

    # Estado interno doble confirmación
    if "real_analyze_confirm_pending" not in st.session_state:
        st.session_state.real_analyze_confirm_pending = False

    # ============================================================
    # 5) BOTÓN ANALIZAR – SOLO SI HAY ACTIVO SELECCIONADO
    # ============================================================
    if st.session_state.get("selected_asset"):

        # --------------------------------------------------------
        # SI NO SE ESTÁ ANALIZANDO AÚN
        # --------------------------------------------------------
        if not st.session_state.get("analizando_activo", False):

            # =====================================================
            # MODO DEMO — sin restricciones
            # =====================================================
            if not es_real:

                if st.sidebar.button("🔍 Analizar activo"):

                    st.session_state["analizando_activo"] = True
                    st.sidebar.success("Iniciando análisis…")

                    # Notificación Telegram
                    try:
                        ip = ip_m.get_client_ip() if hasattr(ip_m, "get_client_ip") else "N/D"
                        msg = (
                            "Acceso Bot EFRA PRO\n"
                            f"Usuario: {current_user_display or current_username}\n"
                            f"Modo: {bot_mode}\n"
                            f"Activo: {st.session_state.get('selected_asset')}\n"
                            f"IP: {ip}\n"
                            f"Fecha: {datetime.utcnow():%Y-%m-%d %H:%M:%S} UTC"
                        )
                        if telegram_send:
                            telegram_send(msg)
                    except:
                        pass

                    try:
                        st.rerun()
                    except:
                        safe_rerun()

            # =====================================================
            # MODO REAL — requiere 2FA + doble confirmación
            # =====================================================
            else:
                eng = lazy_init_engine()
                om = eng.order_manager if eng else None

                # Validar que el usuario confirmó el modo real con 2FA
                if not om or not om._is_real_confirmed():
                    st.sidebar.error("Debe confirmar MODO REAL con su código 2FA antes de continuar.")
                    st.stop()

                # ---- Paso 1 ----
                if not st.session_state.real_analyze_confirm_pending:
                    if st.sidebar.button("⚠ Confirmo que entiendo el MODO REAL"):
                        st.session_state.real_analyze_confirm_pending = True
                        st.sidebar.warning("Confirmación iniciada. Pulse el botón final para continuar.")
                        try:
                            st.rerun()
                        except:
                            safe_rerun()

                # ---- Paso 2 ----
                else:
                    st.sidebar.warning("Confirmación REAL pendiente: presione el botón final para continuar.")

                    if st.sidebar.button("🚀 Continuar en MODO REAL (Final)"):

                        st.session_state["analizando_activo"] = True
                        st.session_state.real_analyze_confirm_pending = False
                        st.sidebar.success("Confirmado. Ejecutando análisis REAL…")

                        try:
                            ip = ip_m.get_client_ip() if hasattr(ip_m, "get_client_ip") else "N/D"
                            msg = (
                                "Acceso Bot EFRA — MODO REAL\n"
                                f"Usuario: {current_user_display or current_username}\n"
                                f"Activo: {st.session_state.get('selected_asset')}\n"
                                f"IP: {ip}\n"
                                f"Fecha: {datetime.utcnow():%Y-%m-%d %H:%M:%S} UTC\n"
                                "⚠ Doble confirmación completada."
                            )
                            if telegram_send:
                                telegram_send(msg)
                        except:
                            pass

                        try:
                            st.rerun()
                        except:
                            safe_rerun()

        # --------------------------------------------------------
        # SI YA SE ESTÁ ANALIZANDO — botón cancelar
        # --------------------------------------------------------
        else:
            if st.sidebar.button("Cancelar análisis"):
                st.session_state["analizando_activo"] = False
                st.session_state.real_analyze_confirm_pending = False
                try:
                    st.rerun()
                except:
                    safe_rerun()

    # ------------------------------------------------------------
    # 6) Cerrar sesión
    # ------------------------------------------------------------
    if st.sidebar.button("Cerrar sesión"):
        try:
            session_m.delete_session(st.session_state.get("session_id"))
        except:
            pass

        for k in ("session_id", "pending_2fa_user", "selected_asset", "analizando_activo"):
            st.session_state.pop(k, None)

        st.sidebar.info("Sesión cerrada.")
        try:
            st.rerun()
        except:
            safe_rerun()

# ============================================================
# SI NO ESTÁ LOGUEADO → LOGIN + 2FA
# ============================================================
else:

    # --------------------------
    # ETAPA 1 — Usuario + Contraseña
    # --------------------------
    if st.session_state.get("pending_2fa_user") is None:

        login_user = st.sidebar.text_input("Usuario")
        login_pass = st.sidebar.text_input("Contraseña", type="password")

        if st.sidebar.button("Ingresar"):

            username = (login_user or "").strip()

            # Bloqueo
            locked = False
            try:
                locked = auth_utils.is_locked(username) if getattr(auth_utils, "is_locked", None) else False
            except Exception:
                locked = False

            if locked:
                try:
                    until = datetime.utcfromtimestamp(locked)
                    st.sidebar.error(f"Cuenta bloqueada hasta {until} UTC")
                except Exception:
                    st.sidebar.error("Cuenta bloqueada temporalmente.")
                st.stop()

            # Validar credenciales
            try:
                valid = user_m.validate_user(username, login_pass)
            except Exception as e:
                st.sidebar.error("Error interno en autenticación.")
                try:
                    app_log.exception("validate_user error: %s", e)
                except Exception:
                    pass
                st.stop()

            if not valid:
                try:
                    if getattr(auth_utils, "record_failed_attempt", None):
                        auth_utils.record_failed_attempt(username)
                except Exception:
                    pass
                st.sidebar.error("Credenciales inválidas.")
                st.stop()

            # Limpiar intentos si aplica
            try:
                if getattr(auth_utils, "clear_failed_attempts", None):
                    auth_utils.clear_failed_attempts(username)
            except Exception:
                pass

            # Generar token 2FA (si existe)
            try:
                token = auth_utils.make_2fa_token(username) if getattr(auth_utils, "make_2fa_token", None) else None
            except Exception:
                token = None

            # Obtener email del usuario
            email = _get_user_email(username)

            # Enviar correo 2FA (si es posible)
            ok_email = False
            if email and token:
                try:
                    ok_email = send_2fa_email(email, token)
                except Exception:
                    ok_email = False

            if not ok_email:
                # mostrar token en modo DEV si no pudo enviarse
                try:
                    st.sidebar.warning("Modo DEV - Token mostrado abajo:")
                    st.sidebar.info(f"Token: {token}")
                except Exception:
                    pass

            # Avanzar a verificación (siempre guardamos pending user para el siguiente paso)
            st.session_state["pending_2fa_user"] = username
            try:
                safe_rerun()
            except Exception:
                pass

    # --------------------------
    # ETAPA 2 — Validar CÓDIGO 2FA
    # --------------------------
    else:
        username = st.session_state.get("pending_2fa_user")
        st.sidebar.info(f"Usuario: **{username}**")

        code = st.sidebar.text_input("Código 2FA recibido en tu correo")

        if st.sidebar.button("Verificar 2FA"):

            valid = False
            try:
                valid = auth_utils.validate_2fa_token(username, code) if getattr(auth_utils, "validate_2fa_token", None) else False
            except Exception:
                valid = False

            if valid:
                try:
                    sid = session_m.create_session(username)
                    st.session_state["session_id"] = sid
                    st.session_state["pending_2fa_user"] = None
                except Exception:
                    st.sidebar.error("Error creando sesión.")
                    try:
                        app_log.exception("session_m.create_session error")
                    except Exception:
                        pass
                    st.stop()

                # Notificación (best-effort)
                try:
                    ip = ip_m.get_client_ip() if getattr(ip_m, "get_client_ip", None) else "N/D"
                except Exception:
                    ip = "N/D"

                try:
                    display_name = _get_display_name_from_record(user_m.get_user_by_username(username)) or username
                except Exception:
                    display_name = username

                try:
                    msg = (
                        "Acceso Bot EFRA PRO\n"
                        f"Usuario: {display_name}\n"
                        f"Modo: {st.session_state.get('bot_mode','DEMO')}\n"
                        f"IP: {ip}\n"
                        f"Fecha: {datetime.utcnow():%Y-%m-%d %H:%M:%S} UTC"
                    )
                    if telegram_send:
                        try:
                            telegram_send(msg)
                        except Exception:
                            pass
                except Exception:
                    pass

                try:
                    st.sidebar.success("Acceso concedido.")
                except Exception:
                    pass

                time.sleep(0.3)
                try:
                    safe_rerun()
                except Exception:
                    pass

            else:
                try:
                    st.sidebar.error("Código incorrecto o expirado.")
                except Exception:
                    pass

# ============================================================
# EL BOT DE EFRA PRO — PARTE 3/6 (Tabs: ANALIZAR) — REEMPLAZO PRO
# - Robustez: engine lazy, defensas para DataFrame/list, mensajes no-críticos
# - Mantiene comportamiento UI/IA/ejecución con múltiples fallbacks
# ============================================================

# Asegurar loggers (defensivo)
try:
    app_log = get_logger("app")
except Exception:
    app_log = logging.getLogger("app")
try:
    trade_log = get_logger("trade")
except Exception:
    trade_log = logging.getLogger("trade")
try:
    security_log = get_logger("security")
except Exception:
    security_log = logging.getLogger("security")

# Asegurar engine desde session_state o lazy_init (no forzamos init aquí,
# pero si nunca se inicializó, lazy_init_engine() lo hará cuando haga falta)
engine = st.session_state.get("engine") or None

# Si no estamos en modo "analizando_activo", mostramos instrucción y detenemos la ejecución de tabs
if not st.session_state.analizando_activo:
    st.title("EL BOT DE EFRA PRO")
    st.info("Selecciona un activo desde la barra lateral para ver análisis e IA.")
    st.stop()

# Creamos los tabs (seguros — ya hay selected_asset)
tabs = st.tabs(["analizar", "configuración", "entrenar", "ranking", "señales", "Auditoría"])

# -------------------------
# Helpers locales para el tab Analizar (PRO)
# -------------------------
def safe_get_klines_df(symbol: str, interval: str = "1h", limit: int = 500):
    """
    Envuelve engine.get_klines_df con defensas:
    - Inicializa engine si es necesario (lazy)
    - Si engine devuelve lista, intenta convertir a DataFrame
    - Retorna DataFrame, lista o None
    """
    # Lazy init engine only when necessary
    eng = st.session_state.get("engine") or engine
    if eng is None:
        try:
            eng = lazy_init_engine()
        except Exception:
            eng = None

    if eng is None:
        app_log.warning("safe_get_klines_df: engine is None")
        return None

    try:
        df = eng.get_klines_df(symbol, interval=interval, limit=limit)
        if df is None:
            return None

        # If DataFrame already, normalize types
        try:
            import pandas as pd  # type: ignore
            if isinstance(df, pd.DataFrame):
                for c in ("open","high","low","close","volume"):
                    if c in df.columns:
                        df[c] = pd.to_numeric(df[c], errors="coerce")
                if "time" in df.columns:
                    try:
                        df["time"] = pd.to_datetime(df["time"], unit="ms", errors="ignore")
                    except Exception:
                        df["time"] = pd.to_datetime(df["time"], errors="ignore")
                return df
            # If list of dicts -> try convert to DataFrame
            if isinstance(df, list):
                try:
                    df2 = pd.DataFrame(df)
                    if "time" in df2.columns:
                        try:
                            df2["time"] = pd.to_datetime(df2["time"], unit="ms", errors="ignore")
                        except Exception:
                            df2["time"] = pd.to_datetime(df2["time"], errors="ignore")
                    for c in ("open","high","low","close","volume"):
                        if c in df2.columns:
                            df2[c] = pd.to_numeric(df2[c], errors="coerce")
                    return df2
                except Exception:
                    # fallback: return original list
                    return df
        except Exception:
            # pandas not available or conversion failed -> return original df
            return df

    except Exception as e:
        app_log.exception("safe_get_klines_df error: %s", e)
        return None


def preview_engine_safe(symbol: str, amount: float, df):
    """
    Intenta usar engine.preview_order si existe, devuelve dict o {}
    """
    eng = st.session_state.get("engine") or engine
    if eng is None:
        try:
            eng = lazy_init_engine()
        except Exception:
            eng = None

    try:
        if eng and getattr(eng, "preview_order", None):
            return eng.preview_order(symbol, amount, df) or {}
    except Exception as e:
        app_log.exception("preview_engine_safe failed: %s", e)
    return {}


def try_generate_plot_image_safe(df, preview, symbol):
    try:
        return try_generate_plot_image(df, preview, symbol)
    except Exception:
        return None


# ------------- TAB: ANALIZAR -------------
with tabs[0]:
    st.header("Analizar")
    app_log.info("Ingreso al TAB Analizar", extra={"user": current_username or "N/D"})

    # Mostrar balance spot (cacheado ya mostrado en sidebar; aquí se vuelve a mostrar por claridad)
    engine = st.session_state.get("engine") or engine
    try:
        # init engine lazily if missing (no side-effects if already initialized)
        if engine is None:
            engine = lazy_init_engine()
        balance_val = cached_get_balance(engine, "USDT") if engine else None
    except Exception:
        balance_val = None

    st.subheader("Cuenta Spot")
    st.write(f"Balance USDT: **{balance_val if balance_val is not None else 'N/D'}**")

    # Cargar velas si hay activo seleccionado
    symbol = st.session_state.get("selected_asset")
    if not symbol:
        st.error("No se ha seleccionado activo.")
    else:
        # Interval selector PRO
        interval = st.selectbox("Intervalo de velas", ["1m","5m","15m","1h","4h","1d"], index=3, key="analizar_interval")
        limit = st.slider("Número de velas", min_value=50, max_value=2000, value=500, step=50, key="analizar_limit")

        df = safe_get_klines_df(symbol=symbol, interval=interval, limit=int(limit))

        if df is None or (hasattr(df, "empty") and df.empty) or (isinstance(df, list) and len(df) == 0):
            st.error("No se pudieron cargar velas para este símbolo.")
            app_log.error("No klines for symbol %s (engine may be misconfigured)", symbol)
        else:
            # Previsualización de la IA (engine.preview_order si disponible)
            preview = preview_engine_safe(symbol, 10.0, df)

            # ==== PANEL: Método de velas evaluado ====
            st.markdown("### 🕯️ Método de velas evaluado")
            candle_method = "desconocido"
            available_methods = None
            try:
                eng = st.session_state.get("engine") or engine
                if eng and getattr(eng, "predictor", None):
                    candle_method = getattr(eng.predictor, "candle_method", candle_method)
                    available_methods = getattr(eng.predictor, "available_methods", None)
            except Exception:
                pass

            with st.container():
                st.write("**Método actual de velas:**")
                st.success(f"🟢 {str(candle_method).upper()}")
                if available_methods:
                    try:
                        st.write("**Métodos disponibles:**")
                        st.info(", ".join([m.upper() for m in available_methods]))
                    except Exception:
                        st.info(str(available_methods))

            # Gráfico candlestick (plotly) — defensivo
            try:
                import plotly.graph_objects as go
                # Si df es lista de dicts, convertir a DataFrame para plotting si pandas está disponible
                if isinstance(df, list):
                    try:
                        import pandas as pd  # type: ignore
                        df = pd.DataFrame(df)
                    except Exception:
                        pass

                if hasattr(df, "loc") and ("time" in df.columns):
                    # asegurar tipo datetime
                    try:
                        df["time"] = pd.to_datetime(df["time"])
                    except Exception:
                        pass

                fig = go.Figure(data=[go.Candlestick(
                    x=df["time"], open=df["open"], high=df["high"], low=df["low"], close=df["close"], name=symbol
                )])
                # marcar predicción si existe
                if preview and "prediction_date" in preview:
                    try:
                        pred_dt = preview.get("prediction_date")
                        pred_time = preview.get("prediction_time")
                        if pred_time:
                            pred_dt_obj = pd.to_datetime(f"{pred_dt} {pred_time}")
                        else:
                            pred_dt_obj = pd.to_datetime(pred_dt)
                        fig.add_trace(go.Scatter(x=[pred_dt_obj],
                                                 y=[df["close"].iloc[-1]],
                                                 mode="markers+text",
                                                 text=[f"IA {preview.get('ia_confidence_pct',0):.1f}%"],
                                                 textposition="top center",
                                                 marker=dict(size=12)))
                    except Exception:
                        pass

                fig.update_xaxes(tickformat="%Y-%m-%d %H:%M", nticks=10)
                fig.update_layout(height=520, template="plotly_dark")
                try:
                    st.plotly_chart(fig, use_container_width=True)
                except Exception:
                    st.plotly_chart(fig)
            except Exception:
                st.text("Plot unavailable (plotly o pandas no instalados)")

            # Panel IA y acciones
            col1, col2 = st.columns([2,1])
            with col1:
                st.subheader("IA & Predicción")
                ia_conf = preview.get('ia_confidence_pct', 0) if isinstance(preview, dict) else 0
                try:
                    st.write(f"Confianza IA: **{ia_conf:.2f}%**")
                except Exception:
                    st.write(f"Confianza IA: **{ia_conf}**")
                st.write(f"Fecha predicha: **{preview.get('prediction_date','-')}**  Hora: **{preview.get('prediction_time','-')}**")
                st.write(f"Recomendación IA: **{str(preview.get('action','mantener')).upper()}**")

                st.markdown("### ¿Deseas invertir ahora?")
                invest_cols = st.columns([1,1,1])
                amount_input = st.number_input("Monto (USDT)", min_value=1.0, max_value=100000.0, value=10.0, step=1.0, key="invest_amount")
                steps_input = st.slider("Pasos DCA", 1, 10, 3, key="invest_steps")
                stop_pct_input = st.number_input("Stop loss (%)", min_value=0.1, max_value=50.0, value=2.0, step=0.1, key="invest_stop_pct")
                with invest_cols[0]:
                    do_invest = st.button("Invertir ahora", key="btn_invertir")
                with invest_cols[1]:
                    cancel_invest = st.button("Cancelar inversión", key="btn_cancelar_inversion")
                with invest_cols[2]:
                    preview_engine_btn = st.button("Previsualizar orden (engine)")

                if preview_engine_btn:
                    try:
                        pr = preview_engine_safe(symbol, amount_input, df)
                        st.json(pr)
                    except Exception as e:
                        st.error(f"Previsualización fallida: {e}")

                if do_invest:
                    try:
                        # Mensaje resumen
                        msg = (f"📈 Orden solicitada por *{current_user_display or current_username}* ({current_username})\n"
                               f"Activo: {symbol}\n"
                               f"Monto total: {amount_input} USDT\n"
                               f"Pasos (DCA): {steps_input}\n"
                               f"Stop loss: {stop_pct_input}%\n"
                               f"IA Confianza: {ia_conf:.2f}%\n"
                               f"Fecha/Hora predicción: {preview.get('prediction_date','-')} {preview.get('prediction_time','-')}")
                        if telegram_send:
                            try:
                                img = try_generate_plot_image_safe(df, preview, symbol)
                                if img:
                                    try:
                                        telegram_send(msg, image_path=img)
                                    except Exception:
                                        try:
                                            telegram_send(msg)
                                        except Exception:
                                            pass
                                else:
                                    try:
                                        telegram_send(msg)
                                    except Exception:
                                        pass
                            except Exception:
                                try:
                                    telegram_send(msg)
                                except Exception:
                                    pass

                        # Ejecutar orden en engine (best-effort): intentar con APIs modernas y fallback
                        usuario_dict = user_m.get_user_by_username(current_username) or {"username": current_username}
                        exec_res = {}
                        eng = st.session_state.get("engine") or engine
                        if eng is None:
                            eng = lazy_init_engine()

                        if eng:
                            try:
                                if getattr(eng, "ejecutar_compound_order", None):
                                    exec_res = eng.ejecutar_compound_order(
                                        usuario=usuario_dict,
                                        symbol=symbol,
                                        total_amount_usdt=float(amount_input),
                                        steps=int(steps_input),
                                        modo="REAL",
                                        stop_loss_pct=float(stop_pct_input),
                                        compound=True
                                    )
                                elif getattr(eng, "execute_trade", None):
                                    # if synchronous execute_trade exists, call it but warn (may be blocking)
                                    exec_res = eng.execute_trade(symbol, float(amount_input))
                                else:
                                    exec_res = {"error": "Engine no soporta ejecutar_compound_order/execute_trade"}
                            except TypeError:
                                # signature mismatch fallback
                                try:
                                    exec_res = eng.ejecutar_compound_order(
                                        usuario=usuario_dict,
                                        symbol=symbol,
                                        total_amount_usdt=float(amount_input),
                                        steps=int(steps_input),
                                        modo="REAL"
                                    )
                                except Exception as e:
                                    exec_res = {"error": str(e)}
                        else:
                            exec_res = {"error": "Engine no inicializado"}

                        st.success("Orden solicitada (ver resultado). Revisa logs/Telegram.")
                        st.json(exec_res)
                        trade_log.info("Orden solicitada desde UI", extra={"user": current_username, "symbol": symbol, "amount": amount_input, "steps": steps_input})
                    except Exception as e:
                        st.error(f"Error ejecutando orden: {e}")
                        app_log.exception("Error en inversión directa: %s", e)

                if cancel_invest:
                    st.info("Inversión cancelada por el usuario.")

            with col2:
                st.subheader("Detalle técnico")
                st.write("Última vela:")
                try:
                    if isinstance(df, list):
                        last_row = df[-1]
                    else:
                        last_row = df.iloc[-1].to_dict()
                    st.json(last_row)
                except Exception:
                    st.write("No hay datos de vela.")

            # Enviar reporte gráfico a telegram (no crítico)
            try:
                if telegram_send:
                    msg2 = (f"🔎 Resultado análisis — {symbol}\nUsuario: {current_user_display}\n"
                            f"IA Confianza: {ia_conf:.2f}%\nPredicción: {preview.get('prediction_date','-')} {preview.get('prediction_time','-')}\nRecomendación: {preview.get('action','mantener')}")
                    img2 = try_generate_plot_image_safe(df, preview, symbol)
                    try:
                        if img2:
                            telegram_send(msg2, image_path=img2)
                        else:
                            telegram_send(msg2)
                    except Exception:
                        try:
                            telegram_send(msg2)
                        except Exception:
                            pass
            except Exception:
                pass

# ============================================================
# FIN BLOQUE: TAB ANALIZAR (PARTE 3/6)
# ============================================================

# -------------------------
# TAB: CONFIGURACIÓN (ADMIN) — BLOQUE 4A
# -------------------------
with tabs[1]:
    st.header("Configuración (Administración)")

    # Obtener usuario actual desde la sesión (robusto)
    try:
        logged = get_current_user_record()
    except Exception:
        logged = None

    username_actual = logged.get("username") if logged else None
    urec = None
    try:
        if username_actual:
            urec = user_m.get_user_by_username(username_actual)
    except Exception:
        urec = None

    # Validación de sesión
    if not username_actual:
        st.warning("Accede como administrador desde el menú lateral.")
        st.stop()

    # Validación de rol admin
    if not urec or not urec.get("is_admin"):
        st.error("Acceso restringido: solo administrador.")
        st.stop()

    # CHANGES PRO: asegurar logger disponible
    try:
        security_log.info("Administrator access", extra={"user": username_actual})
    except Exception:
        pass

    # Renderizado del panel admin (encapsulado en try/except para evitar crash)
    try:
        from backend.admin_panel import render_admin_panel
        render_admin_panel(user_m, ip_m)
    except Exception as e:
        st.error("No se pudo cargar el panel de administración.")
        # CHANGES PRO: loguear excepción sin interrumpir UI
        try:
            app_log.exception("render_admin_panel error: %s", e)
        except Exception:
            pass

    # Información adicional (estado rápido)
    st.markdown("---")
    st.subheader("Estado rápido")
    col1, col2 = st.columns(2)
    with col1:
        st.write(f"- Usuario: **{_get_display_name_from_record(urec) or username_actual}**")
        st.write(f"- Rol: **{'ADMIN' if urec.get('is_admin') else 'USER'}**")
    with col2:
        try:
            engine_status = "OK" if engine else "NO_INICIALIZADO"
        except Exception:
            engine_status = "NO_INICIALIZADO"
        st.write(f"- Engine: **{engine_status}**")
        try:
            # mostrar balance (best-effort)
            if engine:
                balv = cached_get_balance(engine, "USDT")
                st.write(f"- Balance USDT (cached): **{balv:.2f}**")
            else:
                st.write("- Balance USDT (engine no inicializado)")
        except Exception:
            st.write("- Balance USDT: N/D")

    st.markdown("---")
    st.info("Panel de administración cargado. Usa las opciones para gestionar usuarios, IPs y configuraciones.")

# -------------------------
# TAB: ENTRENAR (Demo) — BLOQUE 4B
# -------------------------
with tabs[2]:
    st.header("Entrenar (Demo)")

    # Obtener usuario y display para mostrar en UI
    try:
        logged = get_current_user_record()
    except Exception:
        logged = None
    username_actual = logged.get("username") if logged else None
    display_name = get_display_name_for_current_user() or _get_display_name_from_record(logged) or username_actual

    st.write(f"Usuario conectado: **{display_name or username_actual or 'N/D'}**")
    st.info("Modo Demo — Las órdenes NO son reales.")

    # Selector de símbolos base (usar cached list si engine disponible)
    try:
        if engine:
            symbols_demo = cached_get_symbols(engine)
        else:
            symbols_demo = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
    except Exception:
        symbols_demo = ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

    demo_sym = st.selectbox("Par (DEMO)", symbols_demo, key="entrenar_sym")

    demo_monto = st.slider("Monto DEMO (USDT)", 10, 100, 25, key="entrenar_monto")
    demo_pasos = st.slider("Pasos (DCA)", 1, 5, 3, key="entrenar_pasos")

    if st.button("Ejecutar DEMO"):
        try:
            # Validaciones básicas
            if not username_actual:
                raise RuntimeError("Usuario no autenticado")

            usuario_dict = user_m.get_user_by_username(username_actual) or {"username": username_actual}

            if engine is None:
                raise RuntimeError("Engine no inicializado")

            # CHANGES PRO: intentar ejecutar con varias firmas posibles
            exec_res = None
            try:
                # preferir método moderno si existe
                if getattr(engine, "ejecutar_compound_order", None):
                    exec_res = engine.ejecutar_compound_order(
                        usuario=usuario_dict,
                        symbol=demo_sym,
                        total_amount_usdt=float(demo_monto),
                        steps=int(demo_pasos),
                        modo="DEMO"
                    )
                elif getattr(engine, "execute_trade", None):
                    # execute_trade es async en muchas impl; intentar fallback sync (best-effort)
                    maybe = engine.execute_trade(demo_sym, float(demo_monto))
                    exec_res = maybe
                else:
                    raise RuntimeError("Engine no expone método de ejecución reconocido")
            except TypeError:
                # signature mismatch -> intentar call más simple
                try:
                    exec_res = engine.ejecutar_compound_order(usuario=usuario_dict, symbol=demo_sym, total_amount_usdt=float(demo_monto), steps=int(demo_pasos), modo="DEMO")
                except Exception as e:
                    raise

            st.success("Demo ejecutada.")
            # Mostrar resultado de forma segura
            try:
                st.json(exec_res)
            except Exception:
                st.write(str(exec_res))

            # Registrar demo (si user_m lo soporta)
            try:
                if getattr(user_m, "record_investment", None):
                    user_m.record_investment(username_actual, demo_sym, demo_monto, "DEMO")
            except Exception:
                app_log.exception("record_investment failed (non-fatal)")

            trade_log.info("Ejecutado DEMO", extra={
                "user": username_actual,
                "symbol": demo_sym,
                "amount": demo_monto,
                "steps": demo_pasos
            })

        except Exception as e:
            st.error(f"No se pudo ejecutar la DEMO: {e}")
            try:
                app_log.exception("DEMO failed: %s", e)
            except Exception:
                pass

# -------------------------
# TAB: RANKING — BLOQUE 5A
# -------------------------
with tabs[3]:
    # CHANGES PRO: proteger variables y logs
    try:
        app_log.info("El usuario consultó Ranking", extra={"user": current_username})
    except Exception:
        pass

    st.header("🏆 Ranking de Ganancias Reales")

    # Selector periodo (UI)
    periodo = st.selectbox("Periodo", ["Día", "Semana", "Mes", "Todo"], index=2, key="ranking_periodo")
    period_map = {"Día": "day", "Semana": "week", "Mes": "month", "Todo": "all"}
    periodo_key = period_map.get(periodo, "month")

    # CHANGES PRO: uso seguro de ResultsManager si existe
    if ResultsManager is not None:
        try:
            rm = ResultsManager()
        except Exception as e:
            app_log.exception("ResultsManager init failed: %s", e)
            rm = None

        if rm is None:
            st.warning("ResultsManager no pudo inicializarse. Contacta al administrador.")
        else:
            try:
                r = rm.ranking(periodo_key)
                st.subheader(f"Ranking — {periodo}")
                if not r:
                    st.info("No hay datos aún.")
                else:
                    # Si r es lista/dict/df lo normalizamos para mostrar
                    try:
                        import pandas as pd  # type: ignore
                        if isinstance(r, list):
                            df_r = pd.DataFrame(r)
                        elif hasattr(r, "to_dict"):
                            df_r = pd.DataFrame(r)
                        else:
                            df_r = r
                        st.dataframe(df_r)
                    except Exception:
                        # fallback mostrar crudo
                        st.write(r)
            except Exception as e:
                st.error("Error cargando ranking. Revisa logs.")
                try:
                    app_log.exception("Ranking load failed: %s", e)
                except Exception:
                    pass
    else:
        st.info(
            "ResultsManager no disponible. "
            "Implementa backend/results_manager.py para ranking avanzado."
        )

    # CHANGES PRO: botón para forzar recalculo remoto (si RM lo soporta)
    try:
        if ResultsManager is not None and getattr(ResultsManager, "recalculate", None):
            if st.button("Recalcular ranking (forzar)"):
                try:
                    ResultsManager().recalculate()
                    st.success("Recalculo pedido. Refresca la página en breve.")
                except Exception as e:
                    st.error(f"Recalculo falló: {e}")
    except Exception:
        pass

# -------------------------
# TAB: SEÑALES — BLOQUE 5B
# -------------------------
with tabs[4]:
    st.header("📡 Señales en Tiempo Real — PRO")
    st.write("Control del *SignalsEngine*: señales IA → JSONL, SQLite y (opcional) ejecución automática.")

    # Controles básicos
    colA, colB, colC = st.columns([1, 1, 1])

    with colA:
        mode = st.selectbox(
            "Modo motor",
            ["SIMULATE", "AUTO_EXEC"],
            index=0,
            key="signals_mode_select"
        )

    with colB:
        start_btn = st.button("INICIAR Motor")
        stop_btn = st.button("DETENER Motor")

    with colC:
        refresh_btn = st.button("REFRESCAR Señales")

    # CHANGES PRO: paths definidos una sola vez
    SIGNALS_JSONL = os.path.join("data", "signals_log.jsonl")
    EXEC_JSONL    = os.path.join("data", "executions_log.jsonl")

    # Helper robusto: lectura JSONL
    def read_jsonl(path, limit=500):
        if not os.path.exists(path):
            return []
        rows = []
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    try:
                        rows.append(json.loads(line))
                    except Exception:
                        continue
        except Exception:
            try:
                signals_log.exception("read_jsonl couldn't open %s", path)
            except Exception:
                pass
            return []
        return rows[-limit:]

    # SignalsEngine stored in session_state
    sig_obj = st.session_state.get("signals_engine_obj")

    # ----------------------
    # START ENGINE
    # ----------------------
    if start_btn:
        try:
            if sig_obj is None:
                # CHANGES PRO: try to init with safe defaults
                try:
                    sig_obj = SignalsEngine(
                        symbols=cached_get_symbols(engine)[:10] if engine else ["BTCUSDT", "ETHUSDT"],
                        interval="1m",
                        mode=mode,
                        ia_threshold=float(os.getenv("MIN_CONFIDENCE", "0.8"))
                    )
                except Exception:
                    # fallback minimal init
                    sig_obj = SignalsEngine(symbols=["BTCUSDT", "ETHUSDT"], interval="1m", mode=mode)
                st.session_state["signals_engine_obj"] = sig_obj

                sig_obj.start()
                st.success("SignalsEngine iniciado.")
                try:
                    signals_log.info("SignalsEngine started (UI)", extra={"mode": mode})
                except Exception:
                    pass
            else:
                # Ya existe → ajustar modo y arrancar
                try:
                    sig_obj.mode = mode
                except Exception:
                    pass
                sig_obj.start()
                st.success("SignalsEngine reiniciado/ajustado.")
                try:
                    signals_log.info("SignalsEngine restarted", extra={"mode": mode})
                except Exception:
                    pass
        except Exception as e:
            st.error(f"No se pudo iniciar SignalsEngine: {e}")
            try:
                signals_log.exception("SignalsEngine start error: %s", e)
            except Exception:
                pass

    # ----------------------
    # STOP ENGINE
    # ----------------------
    if stop_btn:
        if sig_obj:
            try:
                sig_obj.stop()
                st.session_state["signals_engine_obj"] = None
                st.success("SignalsEngine detenido.")
                try:
                    signals_log.info("SignalsEngine STOP by UI")
                except Exception:
                    pass
            except Exception as e:
                st.error(f"Error deteniendo motor: {e}")
                try:
                    signals_log.exception("stop error: %s", e)
                except Exception:
                    pass
        else:
            st.info("SignalsEngine no estaba corriendo.")

    # ----------------------
    # Mostrar señales recientes (JSONL)
    # ----------------------
    st.markdown("### 📊 Señales recientes")
    try:
        signals_rows = read_jsonl(SIGNALS_JSONL, limit=500)
        if not signals_rows:
            st.info("No hay señales registradas aún.")
        else:
            # CHANGES PRO: mostrar en tabla truncada para rendimiento
            try:
                df_sig = pd.DataFrame(signals_rows[::-1])
                st.dataframe(df_sig.head(200))
            except Exception:
                st.write(signals_rows[-200:])
    except Exception as e:
        st.error("Error leyendo signals_log.jsonl")
        try:
            signals_log.exception("signals JSONL read error: %s", e)
        except Exception:
            pass

    # ----------------------
    # Mostrar ejecuciones (AUTO_EXEC)
    # ----------------------
    st.markdown("### ⚙️ Ejecuciones registradas")
    try:
        exec_rows = read_jsonl(EXEC_JSONL, limit=500)
        if not exec_rows:
            st.info("No hay ejecuciones registradas.")
        else:
            try:
                df_exec = pd.DataFrame(exec_rows[::-1])
                st.dataframe(df_exec.head(200))
            except Exception:
                st.write(exec_rows[-200:])
    except Exception as e:
        st.error("Error leyendo executions_log.jsonl")
        try:
            signals_log.exception("execution JSONL read error: %s", e)
        except Exception:
            pass

    # ----------------------
    # Botón refresh (fuerza rerun seguro)
    # ----------------------
    if refresh_btn:
        try:
            st.rerun()
        except Exception:
            safe_rerun()

# ============================================================
# EL BOT DE EFRA PRO — PARTE 6/6
# TAB: AUDITORÍA (Admin tools, export, HMAC verify, download)
# ============================================================

with tabs[5]:
    st.header("🔎 Auditoría & Export — Panel Administrador")

    # --------------------------------------------------------
    # LOGGERS SEGUROS (fallan → crean fallback sin handlers)
    # --------------------------------------------------------
    def _safe_get_logger(name):
        try:
            return get_logger(name)
        except Exception:
            lg = logging.getLogger(name)
            if not lg.handlers:
                h = logging.StreamHandler()
                h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
                lg.addHandler(h)
            lg.setLevel(logging.INFO)
            return lg

    audit_log = _safe_get_logger("audit")
    security_log = _safe_get_logger("security")

    # --------------------------------------------------------
    # RUTAS IMPORTANTES
    # --------------------------------------------------------
    SIGNALS_JSONL = os.path.join("data", "signals_log.jsonl")
    EXEC_JSONL    = os.path.join("data", "executions_log.jsonl")
    AUDIT_JSONL   = os.path.join("data", "orders_audit.jsonl")

    st.markdown("### 🗂 Estado de archivos del sistema")

    col1, col2, col3 = st.columns([1,1,1])
    for (label, path, col) in [
        ("Signals JSONL", SIGNALS_JSONL, col1),
        ("Executions JSONL", EXEC_JSONL, col2),
        ("Audit JSONL", AUDIT_JSONL, col3),
    ]:
        with col:
            st.write(f"- **{label}**: `{os.path.basename(path)}`")
            exists = os.path.exists(path)
            st.write(f"  - Existe: {'✅' if exists else '❌'}")
            if exists:
                try:
                    st.write(f"  - Tamaño: {os.path.getsize(path):,} bytes")
                except:
                    st.write("  - Tamaño: N/D")

    st.markdown("---")

    # --------------------------------------------------------
    # VERIFICAR ROL ADMIN
    # --------------------------------------------------------
    current_rec = get_current_user_record()
    username_actual = current_rec.get("username") if current_rec else None
    urec = user_m.get_user_by_username(username_actual) if username_actual else None
    is_admin = bool(urec and urec.get("is_admin"))

    if not username_actual:
        st.warning("No has iniciado sesión.")
        st.stop()

    if not is_admin:
        st.error("Acceso restringido — solo administradores pueden usar esta sección.")
        st.stop()

    st.success(f"Acceso administrador confirmado: **{username_actual}**")
    security_log.info("Admin audit access", extra={"user": username_actual})

    # --------------------------------------------------------
    # Helper: Leer JSONL robusto
    # --------------------------------------------------------
    def _read_jsonl_file(path, limit=1000):
        if not os.path.exists(path):
            return []
        rows = []
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for ln in fh:
                    try:
                        rows.append(json.loads(ln))
                    except:
                        continue
        except Exception as e:
            audit_log.exception("Cannot read %s: %s", path, e)
            return rows
        return rows[-limit:]

    # --------------------------------------------------------
    # VISTAS DE ARCHIVOS
    # --------------------------------------------------------
    st.markdown("### 👁️ Vistas rápidas (últimos 200 registros)")

    try:
        sig_rows = _read_jsonl_file(SIGNALS_JSONL, limit=500)
        exec_rows = _read_jsonl_file(EXEC_JSONL, limit=500)
        audit_rows = _read_jsonl_file(AUDIT_JSONL, limit=500)

        st.subheader("📡 Señales (Signals JSONL)")
        if sig_rows:
            st.dataframe(pd.DataFrame(sig_rows[::-1]).head(200))
        else:
            st.info("No hay señales registradas.")

        st.subheader("⚙️ Ejecuciones (Executions JSONL)")
        if exec_rows:
            st.dataframe(pd.DataFrame(exec_rows[::-1]).head(200))
        else:
            st.info("No hay ejecuciones registradas.")

        st.subheader("📝 Auditoría de órdenes (Audit JSONL)")
        if audit_rows:
            st.dataframe(pd.DataFrame(audit_rows[::-1]).head(200))
        else:
            st.info("No hay registros de auditoría.")
    except Exception as e:
        st.error("Error mostrando archivos de auditoría.")
        audit_log.exception("audit view error: %s", e)

    st.markdown("---")

    # --------------------------------------------------------
    # DESCARGA DE ARCHIVOS
    # --------------------------------------------------------
    st.markdown("### ⬇️ Descargar archivos JSONL")

    def _read_bytes(path):
        try:
            with open(path, "rb") as fh:
                return fh.read()
        except:
            return None

    for path, label in [
        (SIGNALS_JSONL, "Descargar Signals JSONL"),
        (EXEC_JSONL, "Descargar Executions JSONL"),
        (AUDIT_JSONL, "Descargar Audit JSONL"),
    ]:
        if os.path.exists(path):
            data_bytes = _read_bytes(path)
            if data_bytes:
                st.download_button(label, data=data_bytes, file_name=os.path.basename(path), mime="application/json")
        else:
            st.info(f"No existe `{os.path.basename(path)}` para descargar.")

    st.markdown("---")

    # --------------------------------------------------------
    # OPERACIONES ADMINISTRATIVAS: ARCHIVAR / TRUNCAR
    # --------------------------------------------------------
    st.markdown("### ⚠️ Operaciones administrativas (peligroso)")

    def archive_and_truncate(path, label):
        if not os.path.exists(path):
            st.warning(f"No existe `{label}` para archivar.")
            return
        try:
            os.makedirs("backups", exist_ok=True)
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            dest = os.path.join("backups", f"{label}_{ts}.jsonl")
            os.rename(path, dest)
            open(path, "w", encoding="utf-8").close()
            st.success(f"{label} archivado → `{dest}` y archivo reiniciado.")
            audit_log.info("File archived", extra={"file": label, "dest": dest, "user": username_actual})
        except Exception as e:
            st.error(f"Error archivando {label}: {e}")
            audit_log.exception("Archive error: %s", e)

    colA, colB = st.columns([1,1])

    with colA:
        if st.button("Archivar + limpiar Signals JSONL"):
            archive_and_truncate(SIGNALS_JSONL, "signals")

    with colB:
        if st.button("Archivar + limpiar Executions JSONL"):
            archive_and_truncate(EXEC_JSONL, "executions")

    if st.button("Archivar + limpiar Audit JSONL"):
        archive_and_truncate(AUDIT_JSONL, "audit")

    st.markdown("---")

    # --------------------------------------------------------
    # HMAC (Integridad del sistema)
    # --------------------------------------------------------
    st.markdown("### 🔐 Verificación HMAC (integridad de archivos)")

    try:
        from security.integrity import load_hash_db, verify_file_hmac

        try:
            db = load_hash_db()
            st.write("Hash DB cargada (preview 10 items):")
            st.json(dict(list(db.items())[:10]))
        except Exception as e:
            st.error(f"Error cargando hash DB: {e}")
            audit_log.exception("load_hash_db: %s", e)
            db = None

        if db:
            file_choice = st.selectbox(
                "Archivo a verificar",
                ["signals_log.jsonl", "executions_log.jsonl", "orders_audit.jsonl"]
            )

            path_map = {
                "signals_log.jsonl": SIGNALS_JSONL,
                "executions_log.jsonl": EXEC_JSONL,
                "orders_audit.jsonl": AUDIT_JSONL,
            }

            if st.button("Verificar HMAC"):
                p = path_map.get(file_choice)
                if not (p and os.path.exists(p)):
                    st.error("Archivo no encontrado.")
                else:
                    try:
                        ok, info = verify_file_hmac(p, db)
                        if ok:
                            st.success("✅ Verificación HMAC correcta.")
                            st.json(info)
                        else:
                            st.error("❌ Verificación HMAC fallida.")
                            st.json(info)
                            security_log.warning("HMAC failed", extra={"file": p, "user": username_actual})
                    except Exception as e:
                        st.error(f"Error verificando HMAC: {e}")
                        security_log.exception("HMAC error: %s", e)

    except Exception:
        st.warning("Módulo de integridad (security.integrity) no disponible. Instálalo si deseas HMAC.")

    st.markdown("---")
    st.info("Operaciones administrativas irreversibles. Úsalas sólo si sabes lo que haces.")
