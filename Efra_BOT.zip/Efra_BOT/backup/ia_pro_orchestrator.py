#core/ia_pro_orchestrator.py

from datetime import datetime

from core.ia_pro_score import compute_ia_pro_score
from core.ia_regime_detector import detect_regime
from core.ml.ml_predictor import IAProMLPredictor

from core.ia_agents.trend_agent import trend_agent
from core.ia_agents.risk_agent import risk_agent
from core.ia_agents.news_agent import news_agent
from core.ia_agents.ml_agent import ml_agent

from core.ia_audit_log import get_ia_audit_logger
from core.ia_entry_timing import compute_entry_timing

from core.market.market_regime_detection_engine import classify_market_regime

from core.smart_money import compute_smart_money_score

from core.learning.pnl_learning_engine import PnLLearningEngine

from core.strategy.institutional_strategy import (
    build_features,
    institutional_signal
)

from core.strategy.multi_tf_institutional import compute_multi_tf_signal
from core.strategy.quant_multi_tf import multi_tf_analysis

from core.quant.ensemble_brain import ensemble_decision
from core.quant.whale_detector import detect_whales
from core.quant.footprint_simulator import compute_footprint
from core.quant.liquidity_traps import detect_fake_breakout

from core.quant.order_clustering import detect_volume_clusters
from core.quant.rl_weights import RLWeightEngine
from core.quant.auto_retrainer import retrain_trigger
from core.quant.spoofing_detector import detect_spoofing

from core.orchestrators.microstructure_orchestrator import run_microstructure
from core.orchestrators.ensemble_orchestrator import run_ensemble
from core.orchestrators.execution_orchestrator import run_execution_layer
from core.orchestrators.meta_allocation_orchestrator import run_meta_allocation

# 🕯️ PATRONES DE VELAS
from backend.patrones_velas import detectar_patrones_velas

# 🛑 CAPITAL PRESERVATION
from core.risk.capital_preservation import capital_preservation_gate
from core.session_performance.session_tracker import get_session_stats

# ======================================================
# CONECTAR IA CON PNL ENGINE
# ======================================================
pnl_engine = PnLLearningEngine()

# ======================================================
# NORMALIZADOR DE RAZONES
# ======================================================
def _normalize_reasons(reasons):
    out = []

    for r in reasons or []:
        if not isinstance(r, dict):
            out.append({
                "rule": "UNKNOWN",
                "status": "FAIL",
                "details": str(r)
            })
            continue

        out.append({
            "rule": str(r.get("rule", "UNKNOWN")),
            "status": str(r.get("status", "FAIL")).upper(),
            "details": str(r.get("details", ""))
        })

    return out

# ======================================================
# ENTRY TIMING CORE
# ======================================================
def _compute_entry_timing(ia: dict) -> dict:

    direction = ia.get("direction")
    confidence = ia.get("confidence", 0)
    regime = ia.get("regime", "UNKNOWN")

    candle_ctx = ia.get("candlestick_context", {})
    patterns = candle_ctx.get("patterns", [])
    bias = candle_ctx.get("bias")

    ob_signal = ia.get("order_book", {}).get("signal")
    smc = ia.get("smart_money", {})
    smc_dir = smc.get("direction")

    timing = {
        "state": "NO_TRADE",
        "reason": "Condiciones insuficientes"
    }

    # ----------------------------------------
    # 1. Confianza mínima institucional
    # ----------------------------------------
    quant_conf = ia.get("quant", {}).get("confidence", 0)

    if confidence < 60 or quant_conf < 40:        
        timing["reason"] = "Confianza institucional insuficiente"
        return timing

    # ----------------------------------------
    # 2. Régimen inválido
    # ----------------------------------------
    if regime == "UNKNOWN":
        timing["state"] = "WAIT_CONFIRMATION"
        timing["reason"] = "Régimen no confirmado"
        return timing

    # ----------------------------------------
    # 3. Indecisión de vela
    # ----------------------------------------
    if any(p in patterns for p in ["Doji", "ShootingStar"]):
        timing["state"] = "WAIT_CANDLE_CLOSE"
        timing["reason"] = "Vela de indecisión"
        return timing

    # ----------------------------------------
    # 4. Confirmación institucional (SMC + OB)
    # ----------------------------------------
    aligned = True

    if smc_dir and direction and smc_dir != direction:
        aligned = False

    if ob_signal == "BUY_PRESSURE" and direction != "LONG":
        aligned = False

    if ob_signal == "SELL_PRESSURE" and direction != "SHORT":
        aligned = False

    if not aligned:
        timing["state"] = "WAIT_CONFIRMATION"
        timing["reason"] = "Desalineación institucional (SMC/OrderBook)"
        return timing

    # ----------------------------------------
    # 5. Confirmación de velas
    # ----------------------------------------
    if direction == "LONG" and bias != "bullish":
        timing["state"] = "WAIT_CONFIRMATION"
        timing["reason"] = "Velas no confirman LONG"
        return timing

    if direction == "SHORT" and bias != "bearish":
        timing["state"] = "WAIT_CONFIRMATION"
        timing["reason"] = "Velas no confirman SHORT"
        return timing

    # ----------------------------------------
    # ✅ TODO ALINEADO → ENTRAR
    # ----------------------------------------
    timing["state"] = "ENTER_NOW"
    timing["reason"] = "Confluencia institucional confirmada"

    return timing

# ======================================================
# XAI HUMANO
# ======================================================
def _build_trader_explanation(ia: dict) -> str:

    explanation = []

    explanation.append(
        f"Dirección: {ia.get('direction', 'N/A')}."
    )

    explanation.append(
        f"Régimen: {ia.get('regime', 'UNKNOWN')}."
    )

    explanation.append(
        f"Estrategia: {ia.get('strategy', 'DEFAULT')}."
    )

    smc = ia.get("smart_money", {})
    explanation.append(
        f"SMC: {smc.get('direction', 'N/A')} ({smc.get('confidence', 0):.1f}%)."
    )

    candle_ctx = ia.get("candlestick_context", {})
    if candle_ctx:
        explanation.append(
            f"Velas: {', '.join(candle_ctx.get('patterns', []))} "
            f"({candle_ctx.get('bias')})."
        )

    timing = ia.get("entry_timing", {})
    explanation.append(
        f"Timing: {timing.get('state')} — {timing.get('reason')}."
    )

    explanation.append(
        f"Confianza final: {ia.get('confidence', 0):.2f}%."
    )

    return " ".join(explanation)

# ======================================================
# ORQUESTADOR IA PRO
# ======================================================
def compute_ia_pro_decision(data_by_tf, symbol: str, order_book=None):

    from core.market_context.context_builder import build_market_context
    from backend.telegram_notifier import send_telegram_message

    audit = get_ia_audit_logger()

    # --------------------------------------------------
    # CONTEXTO
    # --------------------------------------------------
    market_context = build_market_context(symbol)

    df_by_tf = {
        tf: pack["df"]
        for tf, pack in data_by_tf.items()
        if isinstance(pack, dict) and "df" in pack
    }

    # ======================================================
    # 🔥 BASE IA
    # ======================================================
    ia = compute_ia_pro_score(df_by_tf, symbol)

    ia.setdefault("confidence", 0.0)
    ia.setdefault("reasons", [])
    ia.setdefault("actionable", True)
    ia.setdefault("risk_scales", [])

    def _clamp_conf(x):
        return max(0, min(100, x))

    # ======================================================
    # 🧠 QUANT MULTI-TIMEFRAME BRAIN
    # ======================================================
    try:
        quant = multi_tf_analysis(df_by_tf)

        ia["quant"] = quant

        # 🔥 FUSIÓN CON IA
        q_conf = quant.get("confidence", 0)
        q_dir = quant.get("direction")

        # Boost / penalización institucional
        if q_dir == ia.get("direction"):
            ia["confidence"] += q_conf * 0.15
        elif q_dir != "NEUTRAL":
            ia["confidence"] *= 0.85

        ia["reasons"].append({
            "rule": "QUANT_MULTI_TF",
            "status": "OK",
            "details": f"{q_dir} | conf {q_conf:.2f}"
        })

    except Exception:
        ia["quant"] = {"direction": "ERROR"}


    ia.setdefault("confidence", 0.0)
    ia.setdefault("reasons", [])
    ia.setdefault("actionable", True)
    ia.setdefault("risk_scales", [])

    # --------------------------------------------------
    # RÉGIMEN
    # --------------------------------------------------
    try:
        regime_data = classify_market_regime(df_by_tf.get("15m") or df_by_tf.get("5m"))

        ia["regime"] = regime_data["regime"]
        ia["regime_confidence"] = regime_data["confidence"]
        ia["regime_metrics"] = regime_data["metrics"]
    except Exception:
        ia["regime"] = "UNKNOWN"

    # Activacion automatica de estrategias
    # --------------------------------------------------
    # STRATEGY SELECTION
    # --------------------------------------------------

    regime = ia.get("regime", "UNKNOWN")

    # --------------------------------------------------
    # STRATEGY
    # --------------------------------------------------
    strategy_map = {
        "BULL": "TREND_FOLLOWING",
        "BEAR": "TREND_FOLLOWING",
        "TREND": "TREND_FOLLOWING",
        "SIDEWAYS": "MEAN_REVERSION",
        "RANGE": "MEAN_REVERSION",
        "VOLATILITY_SPIKE": "DEFENSIVE",
        "CRISIS": "DEFENSIVE",
    }
    ia["strategy"] = strategy_map.get(ia.get("regime"), "DEFENSIVE")

    # ======================================================
    # 🔥 PnL LEARNING ADAPTIVO
    # ======================================================
    strategy = ia.get("strategy", "DEFENSIVE")

    learning_score = pnl_engine.get_strategy_score(strategy)

    ia["confidence"] *= learning_score

    ia["reasons"].append({
        "rule": "PNL_LEARNING",
        "status": "INFO",
        "details": f"Score adaptativo: {learning_score:.2f}"
    })

    # --------------------------------------------------
    # CANDLESTICKS
    # --------------------------------------------------
    df_5m = df_by_tf.get("5m")
    candle_patterns, candle_bias = [], "neutral"

#    smc = compute_smart_money_score(df_5m)
    from core.smart_money_v3 import compute_smc_v3

    df_15m = df_by_tf.get("15m")
    df_1h = df_by_tf.get("1h")

    if df_5m is None or df_5m.empty:
        smc = {"confidence": 0, "direction": None}
    else:
        smc = compute_smc_v3(
            df_5m=df_5m,
            df_15m=df_15m,
            df_1h=df_1h
        )

    if df_5m is not None:
        raw = detectar_patrones_velas(df_5m)
        candle_patterns = [p for p in raw if p != "No pattern detected"]

        if any(p in {"Hammer", "EngulfingBull"} for p in candle_patterns):
            candle_bias = "bullish"
        elif any(p in {"ShootingStar", "EngulfingBear"} for p in candle_patterns):
            candle_bias = "bearish"

        ia["candlestick_context"] = {
            "patterns": candle_patterns,
            "bias": candle_bias
        }

        if candle_patterns:
            boost = min(15, 5 + len(candle_patterns) * 5)
            ia["confidence"] += boost
            ia["reasons"].append({
                "rule": "CANDLESTICK",
                "status": "OK",
                "details": f"{len(candle_patterns)} patrones → +{boost}%"
            })

    # ======================================================
    # 🧠 MICROSTRUCTURE INTELLIGENCE (WHALES + FOOTPRINT + TRAPS)
    # ======================================================
    try:
        whales = detect_whales(df_5m)
        footprint = compute_footprint(df_5m)
        traps = detect_fake_breakout(df_5m)

        ia["microstructure"] = {
            "whales": whales,
            "footprint": footprint,
            "traps": traps
        }

        clusters = detect_volume_clusters(df_5m)

        ia["microstructure"]["clusters"] = clusters

        if clusters.get("high_activity_zone"):
            ia["confidence"] += 2

            ia["reasons"].append({
                "rule": "VOLUME_CLUSTER",
                "status": "OK",
                "details": "High liquidity zone detected"
            })

        if clusters.get("absorption"):
            ia["confidence"] += 2

        # ----------------------------------------
        # 🐋 WHALE BOOST
        # ----------------------------------------
        if whales.get("active"):
            ia["confidence"] += min(5, whales.get("strength", 1) * 2)

            ia["reasons"].append({
                "rule": "WHALE_ACTIVITY",
                "status": "OK",
                "details": f"Strength {whales.get('strength'):.2f}"
            })

        # ----------------------------------------
        # ⚡ FOOTPRINT CONFIRMATION
        # ----------------------------------------
        fp_signal = footprint.get("signal")

        if fp_signal == "BUY_IMBALANCE" and ia.get("direction") == "LONG":
            ia["confidence"] += 3

            ia["reasons"].append({
                "rule": "FOOTPRINT",
                "status": "OK",
                "details": "Buy imbalance confirms LONG"
            })

        elif fp_signal == "SELL_IMBALANCE" and ia.get("direction") == "SHORT":
            ia["confidence"] += 3

            ia["reasons"].append({
                "rule": "FOOTPRINT",
                "status": "OK",
                "details": "Sell imbalance confirms SHORT"
            })

        # ----------------------------------------
        # 🪤 TRAP DEFENSE (CRÍTICO)
        # ----------------------------------------
        if traps.get("trap"):

            if traps["type"] == "BULL_TRAP" and ia.get("direction") == "LONG":
                ia["confidence"] *= 0.6
                ia["actionable"] = False

            elif traps["type"] == "BEAR_TRAP" and ia.get("direction") == "SHORT":
                ia["confidence"] *= 0.6
                ia["actionable"] = False

            ia["reasons"].append({
                "rule": "LIQUIDITY_TRAP",
                "status": "BLOCKED",
                "details": traps["type"]
            })

    except Exception as e:
        ia["microstructure"] = {"error": str(e)}

    # ======================================================
    # 🧠 QUANT LAYER (MESA INSTITUCIONAL)
    # ======================================================
    try:
        from core.quant.quant_orchestrator import compute_quant_layer

        quant = compute_quant_layer(df_5m)
        ia["quant"] = quant

        if quant["decision"] == "BUY" and ia.get("direction") == "LONG":
            ia["confidence"] += min(5, quant["strength"] * 1.5)

        elif quant["decision"] == "SELL" and ia.get("direction") == "SHORT":
            ia["confidence"] += min(5, quant["strength"] * 1.5)

        # MARKET MAKER DEFENSE
        if quant["market_maker"].get("active"):
            ia["confidence"] *= 0.85
            ia["reasons"].append({
                "rule": "MARKET_MAKER_DETECTED",
                "status": "WARNING",
                "details": quant["market_maker"].get("type")
            })

    except Exception as e:
        ia["quant"] = {"error": str(e)}

    # ======================================================
    # 🧠 INSTITUTIONAL STRATEGY (FILTRO PRO REAL)
    # ======================================================
    try:
        if df_5m is not None and not df_5m.empty:

            # 🔧 construir features (EMA, RSI, volumen, etc)
            df_features = build_features(df_5m.copy())

            from core.quant.feature_importance import compute_feature_importance

            fi = compute_feature_importance(df_features)
            ia["feature_importance"] = fi

            if fi.get("top_features"):
                ia["confidence"] += min(3, len(fi["top_features"]))

            # 🎯 señal institucional real
            inst_signal = institutional_signal(df_features)

            ia["institutional"] = inst_signal

            action = inst_signal.get("action")
            confidence_boost = inst_signal.get("confidence", 0) * 100

            # ----------------------------------------
            # 🎯 ALINEACIÓN CON IA
            # ----------------------------------------
            if action == "BUY":
                ia["direction"] = "LONG"
                ia["confidence"] += confidence_boost * 0.4

                ia["reasons"].append({
                    "rule": "INSTITUTIONAL_SIGNAL",
                    "status": "OK",
                    "details": f"BUY | conf {confidence_boost:.1f}%"
                })

            elif action == "SELL":
                ia["direction"] = "SHORT"
                ia["confidence"] += confidence_boost * 0.4

                ia["reasons"].append({
                    "rule": "INSTITUTIONAL_SIGNAL",
                    "status": "OK",
                    "details": f"SELL | conf {confidence_boost:.1f}%"
                })

            else:
                ia["reasons"].append({
                    "rule": "INSTITUTIONAL_SIGNAL",
                    "status": "INFO",
                    "details": "No actionable signal"
                })

            # ----------------------------------------
            # 🚫 FILTRO DURO (MUY IMPORTANTE)
            # ----------------------------------------
            if action == "HOLD":
                ia["confidence"] *= 0.7

            if inst_signal.get("confidence", 0) < 0.5:
                ia["confidence"] *= 0.8

    except Exception as e:
        ia["institutional"] = {
            "error": str(e)
        }

    # --------------------------------------------------
    # SMART MONEY BOOST (INSTITUCIONAL)
    # --------------------------------------------------
    smc_conf = smc.get("confidence", 0)

    # 🔥 FUSIÓN INSTITUCIONAL REAL
    smc_weight = 0.35
    ia["confidence"] = (
        ia["confidence"] * (1 - smc_weight)
        + smc_conf * smc_weight
    )

    ia["smart_money"] = smc

    # 🔥 INYECTAR ENTRY REAL
    if smc.get("entry", {}).get("valid"):
        ia["entry_price"] = smc["entry"]["entry"]
        ia["stop_loss"] = smc["entry"]["sl"]
        ia["take_profit"] = smc["entry"]["tp"]

    ia["reasons"].append({
        "rule": "SMART_MONEY_V3",
        "status": "OK" if smc_conf > 70 else "INFO",
        "details": f"SMC v3 confidence: {smc_conf:.2f}%"
    })

# ======================================================
# 🧠 ENSEMBLE MODELS (QUANT LAYER)
# ======================================================

models_outputs = []

# -----------------------------------
# 1. RULE-BASED (tu estrategia institucional)
# -----------------------------------
try:
    features_df = build_features(df_5m.copy())
    inst_signal = institutional_signal(features_df)

    models_outputs.append({
        "model": "INSTITUTIONAL_RULE",
        "direction": (
            "LONG" if inst_signal["action"] == "BUY"
            else "SHORT" if inst_signal["action"] == "SELL"
            else "HOLD"
        ),
        "confidence": inst_signal.get("confidence", 0) * 100
    })
except Exception:
    pass


# -----------------------------------
# 2. ML AGENT (ya lo tienes)
# -----------------------------------
try:
    ml_conf = ia.get("ml", {}).get("confidence", 0)

    models_outputs.append({
        "model": "ML_AGENT",
        "direction": ia.get("direction", "HOLD"),
        "confidence": ml_conf
    })
except Exception:
    pass


# -----------------------------------
# 3. SMART MONEY
# -----------------------------------
try:
    smc_dir = smc.get("direction")

    models_outputs.append({
        "model": "SMART_MONEY",
        "direction": smc_dir if smc_dir else "HOLD",
        "confidence": smc.get("confidence", 0)
    })
except Exception:
    pass


    # -----------------------------------
    # 🧠 FINAL ENSEMBLE + RL
    # -----------------------------------
    if models_outputs:
        ensemble = ensemble_decision(models_outputs)

        ia["ensemble"] = ensemble

        # 🔥 REEMPLAZO DE DIRECCIÓN
        ia["direction"] = ensemble["direction"]

        # 🔥 FUSIÓN DE CONFIANZA (NO reemplazo total)
        ia["confidence"] = (
            ia["confidence"] * 0.6 +
            ensemble["confidence"] * 0.4
        )

        ia["reasons"].append({
            "rule": "ENSEMBLE_BRAIN",
            "status": "OK",
            "details": f"Votes: {ensemble['votes']}"
        })

    # =========================================
    # 🧠 RL ADAPTIVE WEIGHTS
    # =========================================
    try:
        rl_engine = RLWeightEngine()
        rl_data = rl_engine.adjust_weights(models_outputs)

        ia["ensemble"]["rl"] = rl_data

        ia["confidence"] *= rl_data.get("confidence_scale", 1.0)

        ia["reasons"].append({
            "rule": "RL_ADAPTATION",
            "status": "INFO",
            "details": f"Scale {rl_data.get('confidence_scale',1.0):.2f}"
        })

    except Exception:
        pass

    # --------------------------------------------------
    # LIQUIDITY ENGINE
    # --------------------------------------------------
    try:
        from core.risk.liquidity_engine import liquidity_adjustment

        if df_5m is not None and len(df_5m) > 20:

            avg_volume = df_5m["volume"].rolling(20).mean().iloc[-1]
            spread = (
                (df_5m["high"].iloc[-1] - df_5m["low"].iloc[-1])
                / df_5m["close"].iloc[-1]
            )

            # Proxy inicial pequeño (antes de sizing final)
            order_size_proxy = 0.01

            liquidity_data = liquidity_adjustment(
                order_size_proxy,
                avg_volume,
                spread
            )

            ia["liquidity"] = liquidity_data

        else:
            ia["liquidity"] = {
                "liquidity_score": 0,
                "liquidity_scale": 1.0,
                "mode": "NORMAL"
            }

    except Exception:
        ia["liquidity"] = {
            "liquidity_score": 0,
            "liquidity_scale": 1.0,
            "mode": "NORMAL"
        }

    # --------------------------------------------------
    # LIQUIDITY SHOCK DETECTOR
    # --------------------------------------------------

    try:
        from core.risk.liquidity_shock_detector import detect_liquidity_shock
        shock_data = detect_liquidity_shock(df_5m)
        ia["liquidity_shock"] = shock_data
        shock_scale = shock_data.get("risk_scale", 1.0)
        ia["confidence"] *= shock_scale

        # defino para evitar error
        ia["risk_scales"] = ia.get("risk_scales", [])
        ia["risk_scales"].append(shock_scale)

        if not shock_data.get("allow_trade", True):
            ia["actionable"] = False
            ia["reasons"].append({
                "rule": "LIQUIDITY_SHOCK",
                "status": "BLOCKED",
                "details": shock_data.get("mode")
            })
        elif shock_data.get("mode") == "WARNING":
            ia["reasons"].append({
                "rule": "LIQUIDITY_WARNING",
                "status": "WARNING",
                "details": "Liquidity stress detected"
            })

    except Exception as e:
        ia["liquidity_shock"] = {
            "mode": "ERROR",
            "risk_scale": 1.0
        }

    # --------------------------------------------------
    # REGIME SHIFT (HMM SIMULADO)
    # --------------------------------------------------
    returns = df_5m["close"].pct_change().dropna()

    from core.risk.hmm_regime import detect_hmm_regime

    hmm = detect_hmm_regime(returns)
    ia["hmm_regime"] = hmm

    if hmm["regime"] == "HIGH_VOL":
        ia["confidence"] *= 0.8

    if hmm["regime"] == "TREND":
        ia["confidence"] += 2

    # --------------------------------------------------
    # ORDER FLOW TOXICITY ENGINE
    # --------------------------------------------------
    try:
        from core.market_microstructure.order_flow_toxicity_engine import (
            detect_order_flow_toxicity
        )
        toxicity_data = detect_order_flow_toxicity(df_5m)
        ia["order_flow_toxicity"] = toxicity_data
        risk_scale = toxicity_data.get("risk_scale", 1.0)

        ia["confidence"] *= risk_scale

        ia["risk_scales"] = ia.get("risk_scales", [])
        ia["risk_scales"].append(risk_scale)

        if risk_scale == 0:
            ia["actionable"] = False
            ia["reasons"].append({
                "rule": "ORDER_FLOW_TOXICITY",
                "status": "BLOCKED",
                "details": toxicity_data.get("mode")
            })
        else:
            ia["reasons"].append({
                "rule": "ORDER_FLOW_TOXICITY",
                "status": "INFO",
                "details": toxicity_data.get("mode")
            })
    except Exception:
        ia["order_flow_toxicity"] = {
            "mode": "ERROR"
        }

    # --------------------------------------------------
    # ORDER BOOK IMBALANCE ENGINE
    # --------------------------------------------------

    try:
        from core.market_microstructure.order_book_imbalance_engine import (
            compute_order_book_imbalance
        )

        if order_book is not None:
            ob_data = compute_order_book_imbalance(order_book)
            ia["order_book"] = ob_data
            confidence_scale = ob_data.get("confidence_scale", 1.0)
            ia["confidence"] *= confidence_scale
            ia["microstructure_signal"] = {
                "order_book": ob_data.get("signal"),
                "toxicity": ia.get("order_flow_toxicity", {}).get("mode")
            }
            ia["reasons"].append({
                "rule": "ORDER_BOOK_IMBALANCE",
                "status": "INFO",
                "details": ob_data.get("signal")
            })
    except Exception:
        ia["order_book"] = {
            "signal": "ERROR"
        }

    # --------------------------------------------------
    # AGENTES
    # --------------------------------------------------
    for v in [
        trend_agent(ia),
        risk_agent(ia),
        news_agent(),
        ml_agent(ia),
    ]:
        if v.get("veto"):
            ia["actionable"] = False
            ia["confidence"] = 0
            ia["reasons"].append({
                "rule": f"VETO_{v.get('agent')}",
                "status": "FAIL",
                "details": v.get("reason")
            })

            ia["entry_timing"] = {"state": "NO_TRADE", "reason": "Veto IA"}
            ia["execution_policy"] = {
                "allow_trade": False,
                "ui_lock": True,
                "state": "NO_TRADE",
                "message": "Bloqueado por IA",
            }
            ia["confidence"] = 0
            return ia

    # ======================================================
    # 🧠 MULTI-TF INSTITUTIONAL BRAIN (HEDGE FUND MODE)
    # ======================================================
    try:
        multi_tf = compute_multi_tf_signal(data_by_tf)

        ia["multi_tf"] = multi_tf

        mtf_action = multi_tf.get("action")
        mtf_dir = multi_tf.get("direction")
        mtf_conf = multi_tf.get("confidence", 0) * 100

        # ----------------------------------------
        # 🎯 ALINEACIÓN GLOBAL
        # ----------------------------------------
        if mtf_action == "BUY":
            ia["direction"] = "LONG"
            ia["confidence"] += mtf_conf * 0.5

            ia["reasons"].append({
                "rule": "MULTI_TF_BRAIN",
                "status": "OK",
                "details": f"BUY | score {multi_tf.get('score'):.2f}"
            })

        elif mtf_action == "SELL":
            ia["direction"] = "SHORT"
            ia["confidence"] += mtf_conf * 0.5

            ia["reasons"].append({
                "rule": "MULTI_TF_BRAIN",
                "status": "OK",
                "details": f"SELL | score {multi_tf.get('score'):.2f}"
            })

        else:
            ia["confidence"] *= 0.75

            ia["reasons"].append({
                "rule": "MULTI_TF_BRAIN",
                "status": "INFO",
                "details": "No alignment across TFs"
            })

        # ----------------------------------------
        # 🚫 HARD FILTER (CRÍTICO)
        # ----------------------------------------
        if mtf_action == "HOLD":
            ia["actionable"] = False

            ia["reasons"].append({
                "rule": "MULTI_TF_BLOCK",
                "status": "BLOCKED",
                "details": "No multi-timeframe consensus"
            })

    except Exception as e:
        ia["multi_tf"] = {"error": str(e)}

    # --------------------------------------------------
    # MARKET CONTEXT
    # --------------------------------------------------
    ia["market_context"] = market_context
    modifier = market_context.get("confidence_modifier", 0)
    ia["confidence"] += max(-10, min(10, modifier))

    # ============================================================
    # CAPITAL PRESERVATION GATE (INSTITUCIONAL FIX)
    # ============================================================
    from backend.equity_tracker import EquityTracker
    equity_tracker = EquityTracker()
    proposed_risk = ia.get("risk_pct", 0.02)
    proposed_amount = ia.get("position_size_usdt", 0)
    gate = capital_preservation_gate(
        equity_tracker=equity_tracker,
        proposed_risk_pct=proposed_risk,
        proposed_amount=proposed_amount
    )
    ia["capital_gate"] = gate
    if not gate["allowed"]:
        ia["allowed"] = False
        ia["blocked_reason"] = gate["reason"]
    else:
        ia["allowed"] = True

    # --------------------------------------------------
    # STRATEGY RISK
    # --------------------------------------------------
    try:
        from core.portfolio.strategy_nav import get_strategy_state
        from core.risk.strategy_risk import evaluate_strategy_risk

        state = get_strategy_state(ia["strategy"])
        allowed, reason = evaluate_strategy_risk(state)

        if not allowed:
            ia["actionable"] = False
            ia["confidence"] = 0
            ia["reasons"].append({
                "rule": "STRATEGY_RISK",
                "status": "FAIL",
                "details": reason
            })

            ia["entry_timing"] = {"state": "NO_TRADE", "reason": "Veto IA"}
            ia["execution_policy"] = {
                "allow_trade": False,
                "ui_lock": True,
                "state": "NO_TRADE",
                "message": "Bloqueado por IA",
            }
            ia["confidence"] = 0
            return ia
    except Exception:
        pass

    # --------------------------------------------------
    # NORMALIZACIÓN DE CONFIANZA (CRÍTICO)
    # --------------------------------------------------
    ia["confidence"] = max(0, min(100, ia["confidence"]))

    # ======================================================
    # 🚫 GLOBAL CONFIDENCE VETO
    # ======================================================
    if ia["confidence"] < 50:
        ia["actionable"] = False

        ia["reasons"].append({
            "rule": "GLOBAL_CONFIDENCE_VETO",
            "status": "BLOCKED",
            "details": f"Confidence too low ({ia['confidence']:.2f})"
        })

    # ======================================================
    # 🚨 FINAL ALIGNMENT FILTER (ANTI-FALSOS POSITIVOS)
    # ======================================================
    inst = ia.get("institutional", {})
    inst_action = inst.get("action")

    if inst_action == "BUY" and ia.get("direction") != "LONG":
        ia["confidence"] *= 0.6

    if inst_action == "SELL" and ia.get("direction") != "SHORT":
        ia["confidence"] *= 0.6

    if inst_action == "HOLD":
        ia["actionable"] = False
        ia["reasons"].append({
            "rule": "INSTITUTIONAL_BLOCK",
            "status": "BLOCKED",
            "details": "Institutional strategy says HOLD"
        })

    # ======================================================
    # 🧠 HARD CONSENSUS FILTER (SMC vs IA)
    # ======================================================
    smc_dir = ia.get("smart_money", {}).get("direction")

    if smc_dir and ia.get("direction") and smc_dir != ia["direction"]:
        ia["confidence"] *= 0.7

        ia["reasons"].append({
            "rule": "SMC_CONFLICT",
            "status": "WARNING",
            "details": f"SMC {smc_dir} vs IA {ia.get('direction')}"
        })

    # --------------------------------------------------
    # ENTRY TIMING
    # --------------------------------------------------
    ia["entry_timing"] = _compute_entry_timing(ia)

    ia["reasons"].append({
        "rule": "ENTRY_TIMING",
        "status": "OK" if ia["entry_timing"]["state"] == "ENTER_NOW" else "INFO",
        "details": f"{ia['entry_timing']['state']} — {ia['entry_timing']['reason']}"
    })

    # Microstructure alignment
    if ia.get("order_book", {}).get("signal") == "BUY_PRESSURE" and ia.get("direction") == "LONG":
        ia["confidence"] += 3
    if ia.get("order_book", {}).get("signal") == "SELL_PRESSURE" and ia.get("direction") == "SHORT":
        ia["confidence"] += 3

    # --------------------------------------------------
    # BAYESIAN WIN RATE
    # --------------------------------------------------
    from core.learning.bayesian_win_rate import compute_bayesian_win_rate

    ia["session_stats"] = get_session_stats()

    from core.learning.alpha_decay import compute_alpha_decay

    pnl_series = ia["session_stats"].get("pnl_series", [])

    alpha = compute_alpha_decay(pnl_series)

    ia["alpha_decay"] = alpha

    if alpha.get("is_decaying"):
        ia["confidence"] *= 0.7

        ia["reasons"].append({
            "rule": "ALPHA_DECAY",
            "status": "WARNING",
            "details": "Strategy losing edge"
        })

    session_stats = ia.get("session_stats", {})
    bayesian_win_rate = compute_bayesian_win_rate(session_stats)

    ia["bayesian_win_rate"] = bayesian_win_rate

    ia["reasons"].append({
        "rule": "BAYESIAN_WIN_RATE",
        "status": "OK",
        "details": (
            f"WinRate aprendido: {bayesian_win_rate:.2%} "
            f"(W:{session_stats.get('wins',0)} / L:{session_stats.get('losses',0)})"
        )
    })

    # --------------------------------------------------
    # META-ALLOCATION + KELLY + STRATEGY BUCKET
    # --------------------------------------------------
    try:
        # ============================================================
        # SAFE DATA INITIALIZATION (INSTITUTIONAL FALLBACK)
        # Evita crashes si los motores aún no tienen datos reales
        # ============================================================

        import numpy as np

        # --------------------------------------------
        # Strategy returns fallback
        # --------------------------------------------
        try:
            from core.portfolio.strategy_returns import get_strategy_returns
            strategy_returns = get_strategy_returns()

            if not strategy_returns:
                raise Exception("Empty strategy_returns")
        except Exception:
            # fallback institucional neutro
            strategy_returns = {
                "DEFENSIVE": np.random.normal(0.0001, 0.001, 200),
                "TREND_FOLLOWING": np.random.normal(0.0002, 0.002, 200),
                "MEAN_REVERSION": np.random.normal(0.00015, 0.0015, 200),
            }

        # --------------------------------------------
        # Portfolio returns fallback
        # --------------------------------------------
        try:
            from core.portfolio.portfolio_returns import get_portfolio_returns
            portfolio_returns = get_portfolio_returns()
            if portfolio_returns is None or len(portfolio_returns) == 0:
                raise Exception("Empty portfolio_returns")
        except Exception:
            portfolio_returns = np.random.normal(0.00015, 0.0018, 300)

        # --------------------------------------------
        # Benchmark returns fallback
        # --------------------------------------------
        try:
            from core.market_data.benchmark_returns import get_benchmark_returns
            benchmark_returns = get_benchmark_returns()
            if benchmark_returns is None or len(benchmark_returns) == 0:
                raise Exception("Empty benchmark")
        except Exception:
            benchmark_returns = np.random.normal(0.00012, 0.0015, 300)

        # --------------------------------------------
        # Current strategy returns fallback
        # --------------------------------------------
        strategy_name = ia.get("strategy", "DEFENSIVE")
        current_strategy_returns = strategy_returns.get(
            strategy_name,
            np.random.normal(0.0001, 0.001, 200)
        )

        from core.allocation.meta_allocator import compute_meta_allocation
        from core.allocation.kelly_allocator import compute_bayesian_kelly
        from core.portfolio.portfolio_nav import get_portfolio_state
        from core.allocation.strategy_buckets import get_strategy_capital_fraction

        # -------------------------
        # META ALLOCATION
        # -------------------------
        meta_weights = compute_meta_allocation(ia["regime"])

        strategy = ia.get("strategy", "DEFENSIVE")
        meta_weight = meta_weights.get(strategy, 0.33)
        ia["meta_weight"] = meta_weight

        from core.allocation.rl_meta_allocator import get_strategy_weight

        rl_multiplier = get_strategy_weight(strategy)
        ia["rl_weight"] = rl_multiplier
        meta_weight *= rl_multiplier

        # -------------------------
        # STRATEGY BUCKET
        # -------------------------
        bucket_fraction = get_strategy_capital_fraction(strategy)
        ia["strategy_capital_fraction"] = bucket_fraction

        # --------------------------------------------------
        # MONTE CARLO STRESS TEST
        # --------------------------------------------------
        try:
            from core.risk.monte_carlo_stress import monte_carlo_stress_test

            # Usamos equity proxy 1.0
            equity_proxy = 1.0

            # Returns históricos 5m
            if df_5m is not None and not df_5m.empty:
                returns = df_5m["close"].pct_change().dropna()
            else:
                returns = np.random.normal(0.0001, 0.001, 200)

            mc_data = monte_carlo_stress_test(
                equity_proxy,
                returns,
                sims=500
            )
 
            ia["monte_carlo"] = mc_data

        except Exception:
            ia["monte_carlo"] = {
                "monte_carlo_scale": 1.0,
                "risk_mode": "ERROR"
            }

        # -------------------------
        # OPTIMIZATION SOLVER
        # -------------------------

        from core.portfolio.optimizer import risk_parity_weights

        # Construir matriz de returns por estrategia
        returns_matrix = np.array([
            strategy_returns[name]
            for name in strategy_returns
        ])

        weights = risk_parity_weights(returns_matrix)
        optimized_weight = weights[list(strategy_returns.keys()).index(strategy)]
        meta_weight *= optimized_weight
        meta_weight = max(0.0, min(1.0, meta_weight))

        # -------------------------
        # KELLY
        # -------------------------
        pf = get_portfolio_state()

        kelly_fraction = compute_bayesian_kelly(
            win_rate=ia["bayesian_win_rate"],
            rr=2.0,
            confidence=ia["confidence"],
            drawdown=pf.get("drawdown", 0),
        )
        kelly_fraction = max(0.0, min(0.05, kelly_fraction))  # cap 5%
        ia["kelly_fraction"] = kelly_fraction

        # -------------------------
        # GLOBAL RISK GOVERNOR
        # -------------------------
        from core.risk.global_risk_governor import risk_governor_decision

        governor = risk_governor_decision()

        ia["risk_governor"] = governor

        capital_scale = governor.get("capital_scale", 1.0)

        liquidity_scale = ia.get("liquidity", {}).get("liquidity_scale", 1.0)

        monte_carlo_scale = ia.get("monte_carlo", {}).get("monte_carlo_scale", 1.0)

        final_fraction = (
            kelly_fraction *
            meta_weight *
            bucket_fraction *
            capital_scale *
            liquidity_scale *
            monte_carlo_scale
        )

        # --------------------------------------------------
        # APPLY ACCUMULATED RISK SCALES (CRÍTICO)
        # --------------------------------------------------
        for rs in ia.get("risk_scales", []):
            final_fraction *= rs

        ia["capital_fraction"] = final_fraction
        ia["capital_fraction"] = max(0.0, min(0.05, ia["capital_fraction"]))
        # --------------------------------------------------
        # CORRELATION ENGINE
        # --------------------------------------------------
        try:
            from core.risk.correlation_engine import evaluate_correlation_risk

            correlation_data = evaluate_correlation_risk(strategy_returns)

            ia["correlation"] = correlation_data

            corr_scale = correlation_data.get("correlation_scale", 1.0)
            exposure_scale = correlation_data.get("exposure_scale", 1.0)

        except Exception:
            ia["correlation"] = {
                "correlation_scale": 1.0,
                "exposure_scale": 1.0,
                "risk_mode": "ERROR"
            }
            corr_scale = 1.0
            exposure_scale = 1.0

        # --------------------------------------------------
        # FACTOR RISK MODEL
        # --------------------------------------------------
        try:
            from core.risk.factor_risk_model import evaluate_factor_exposure

            factor_data = evaluate_factor_exposure(
                strategy_returns=current_strategy_returns,
                market_returns=benchmark_returns
            )

            ia["factor_risk"] = factor_data

            factor_scale = factor_data.get("factor_scale", 1.0)

            ia["capital_fraction"] *= factor_scale

        except Exception:
            ia["factor_risk"] = {
                "factor_scale": 1.0,
                "risk_mode": "ERROR"
            }

        # --------------------------------------------------
        # PORTFOLIO VAR ENGINE
        # --------------------------------------------------
        try:
            from core.risk.portfolio_var_engine import evaluate_portfolio_var

            var_data = evaluate_portfolio_var(
                portfolio_returns=portfolio_returns
            )

            ia["portfolio_var"] = var_data

            var_scale = var_data.get("var_scale", 1.0)

            ia["capital_fraction"] *= var_scale

        except Exception:
            ia["portfolio_var"] = {
                "var_scale": 1.0,
                "risk_mode": "ERROR"
            }

        # --------------------------------------------------
        # REGIME SHIFT DETECTOR
        # --------------------------------------------------
        try:
            from core.risk.regime_detector import detect_regime_shift

            # coloco esto
            market_returns = benchmark_returns

            regime_data = detect_regime_shift(market_returns)

            ia["regime_shift"] = regime_data

            regime_scale = regime_data.get("regime_scale", 1.0)

            ia["capital_fraction"] *= regime_scale

        except Exception:
            ia["regime_shift"] = {
                "regime_scale": 1.0,
                "regime": "ERROR"
            }

        # --------------------------------------------------
        # DYNAMIC LAVERAGE DATA
        # --------------------------------------------------
        from core.risk.dynamic_leverage import compute_dynamic_leverage

        leverage_data = compute_dynamic_leverage(portfolio_returns)

        ia["leverage"] = leverage_data

        ia["capital_fraction"] *= leverage_data.get("leverage_multiplier", 1.0)

        # --------------------------------------------------
        # CONVEXITY OVERLAY DATA
        # --------------------------------------------------
        from core.risk.convexity_overlay import apply_convexity_overlay

        var_data = ia.get("portfolio_var", {})
        regime_data = ia.get("regime_shift", {})

        convexity_data = apply_convexity_overlay(var_data, regime_data)

        ia["convexity"] = convexity_data

        ia["capital_fraction"] *= convexity_data.get("convexity_scale", 1.0)

        # --------------------------------------------------
        # ADAPTIVE RISK ALLOCATOR + EQUITY REGIME ENGINE
        # --------------------------------------------------
        try:
            from core.risk.adaptive_risk_allocator import adaptive_risk_allocation
            from core.risk.equity_regime_engine import detect_equity_regime
            from backend.equity_tracker import EquityTracker

            tracker = EquityTracker()
            equity_curve = tracker.get_equity_curve()

            risk_data = adaptive_risk_allocation(equity_curve)
            regime_equity = detect_equity_regime(equity_curve)

            ia["adaptive_risk"] = risk_data
            ia["equity_regime"] = regime_equity

            risk_scale = risk_data.get("risk_scale", 1.0)
            regime_scale = regime_equity.get("regime_scale", 1.0)

            ia["capital_fraction"] *= (risk_scale * regime_scale)

        except Exception:
            ia["adaptive_risk"] = {"risk_scale": 1.0}
            ia["equity_regime"] = {"regime_scale": 1.0}
        # --------------------------------------------------
        # EXECUTION COST ENGINE
        # --------------------------------------------------
        try:
            from core.execution.execution_engine import estimate_execution_cost

            execution_data = estimate_execution_cost(
                order_fraction=ia["capital_fraction"],
                df=df_5m
            )

            ia["execution"] = execution_data

            # ======================================================
            # 🧠 REAL SLIPPAGE MODEL (INSTITUTIONAL)
            # ======================================================
            try:
                from core.execution.slippage_model import compute_slippage

                last_price = df_5m["close"].iloc[-1]

                avg_volume = df_5m["volume"].rolling(20).mean().iloc[-1]

                spread = (
                    (df_5m["high"].iloc[-1] - df_5m["low"].iloc[-1])
                    / last_price
                )

                side = "BUY" if ia.get("direction") == "LONG" else "SELL"

                slippage_data = compute_slippage(
                    price=last_price,
                    side=side,
                    order_fraction=ia.get("capital_fraction", 0.01),
                    avg_volume=avg_volume,
                    spread=spread
                )

                ia["slippage_model"] = slippage_data

                # ----------------------------------------
                # 🎯 IMPACTO REAL EN CAPITAL
                # ----------------------------------------
                slippage_scale = 1 - slippage_data["slippage"]

                ia["capital_fraction"] *= slippage_scale

                # ----------------------------------------
                # 🧠 IMPACTO EN CONFIANZA (MUY PRO)
                # ----------------------------------------
                if slippage_data["slippage"] > 0.01:
                    ia["confidence"] *= 0.9

                    ia["reasons"].append({
                        "rule": "HIGH_SLIPPAGE",
                        "status": "WARNING",
                        "details": f"{slippage_data['slippage']:.4f}"
                    })

                else:
                    ia["reasons"].append({
                        "rule": "SLIPPAGE_OK",
                        "status": "INFO",
                        "details": f"{slippage_data['slippage']:.4f}"
                    })

            except Exception as e:
                ia["slippage_model"] = {
                    "error": str(e)
                }

            execution_scale = execution_data.get("execution_scale", 1.0)
            adjusted_fraction = ia["capital_fraction"] * execution_scale
            ia["capital_fraction"] = adjusted_fraction

            # Cap institucional de riesgo
            ia["capital_fraction"] = max(
                0,
                min(ia["capital_fraction"], 0.05)  # max 5% del capital
            )
        except Exception:
            ia["execution"] = {
                "execution_scale": 1.0,
                "mode": "ERROR"
            }

        # --------------------------------------------------
        # EXECUTION QUALITY ENGINE
        # --------------------------------------------------
        try:
            from core.execution.execution_quality_engine import ExecutionQualityEngine
            if not hasattr(compute_ia_pro_decision, "_exec_quality"):
                compute_ia_pro_decision._exec_quality = ExecutionQualityEngine()
            exec_quality = compute_ia_pro_decision._exec_quality.execution_score()
            ia["execution_quality"] = exec_quality
            quality_scale = compute_ia_pro_decision._exec_quality.execution_risk_scale()
            ia["capital_fraction"] *= quality_scale
        except Exception:
            ia["execution_quality"] = {
                "execution_quality": "ERROR",
                "score": 1.0
            }

    except Exception:
        ia["meta_weight"] = 0.33
        ia["kelly_fraction"] = 0.01
        ia["strategy_capital_fraction"] = 0.01
        ia["capital_fraction"] = 0.01

    # --------------------------------------------------
    # SMART ORDER ROUTING ENGINE
    # --------------------------------------------------
    try:
        from core.execution.smart_order_router import SmartOrderRouter
        if not hasattr(compute_ia_pro_decision, "_router"):
            compute_ia_pro_decision._router = SmartOrderRouter()

        router = compute_ia_pro_decision._router
        order_size_proxy = ia.get("capital_fraction", 0)
        routing = router.route_order(
            order_size_proxy,
            order_book
        )
        ia["smart_routing"] = routing
        ia["reasons"].append({
            "rule": "SMART_ORDER_ROUTER",
            "status": "INFO",
            "details": f"{routing['strategy']} | impact {routing['market_impact']:.4f}"
        })
    except Exception:
        ia["smart_routing"] = {
            "strategy": "ERROR"
        }

    # ======================================================
    # 🧠 CONFLUENCE SCORE
    # ======================================================
    ia["confluence_score"] = len([
        r for r in ia.get("reasons", [])
        if r.get("status") == "OK"
    ])

    # --------------------------------------------------
    # FINALIZE
    # --------------------------------------------------
    ia["confidence"] = max(0, min(100, ia["confidence"]))
    ia["timestamp"] = datetime.utcnow().isoformat()
    ia["reasons"] = _normalize_reasons(ia["reasons"])
    ia["trader_explanation"] = _build_trader_explanation(ia)

    # ============================================================
    # EXECUTION POLICY ENGINE (CRÍTICO — FIX IA_INVALID_OUTPUT)
    # ============================================================

    entry = ia.get("entry_timing", {})
    state = entry.get("state", "NO_TRADE")
    capital_gate = ia.get("capital_gate", {"allowed": True})
    allowed_by_capital = capital_gate.get("allowed", True)
    allow_trade = (
        state == "ENTER_NOW"
        and allowed_by_capital
        and ia.get("actionable", True)
        and ia.get("allowed", True)
    )

    execution_policy = {
        "allow_trade": allow_trade,
        "ui_lock": not allow_trade,
        "show_countdown": state == "WAIT_CANDLE_CLOSE",
        "state": state,
        "message": {
            "ENTER_NOW": "Entrada permitida",
            "WAIT_CANDLE_CLOSE": "Esperando cierre de vela",
            "WAIT_CONFIRMATION": "Esperando confirmación institucional",
            "NO_TRADE": "Trade bloqueado por IA",
        }.get(state, "Sin señal operativa"),
        "blocked_reason": None if allow_trade else (
            ia.get("blocked_reason")
            or capital_gate.get("reason")
            or entry.get("reason")
        )
    }

    ia["execution_policy"] = execution_policy

    # ======================================================
    # 🧠 AUTO-RETRAIN (CONTINUAL LEARNING)
    # ======================================================
    try:
        retrain_trigger(ia)
    except Exception:
        pass
    # ======================================================

    try:
        send_telegram_message(
            f"IA PRO\n{symbol}\n{ia['strategy']} | {ia['entry_timing']['state']}\n"
            f"Confianza: {ia['confidence']:.2f}%\n"
            f"Capital: {ia['capital_fraction']:.2%}"
        )
    except Exception:
        pass

    audit.log_decision(
        symbol=symbol,
        context="IA_PRO_ORCHESTRATOR",
        ia_decision=ia,
        data_by_tf=df_by_tf,
    )

    return ia
