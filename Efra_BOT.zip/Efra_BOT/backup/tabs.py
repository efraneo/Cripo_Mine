# ui/tabs.py
"""
Renderiza pestañas principales: analizar, configuración, entrenar, ranking, señales, auditoría.
Muestra indicadores técnicos devueltos por TradingEngine.preview_order/predictor.
"""

import streamlit as st
import logging
import pandas as pd
from datetime import datetime
from backend.risk_engine import dynamic_risk, detect_session


# core utilities
from core.engine_utils import lazy_init_engine, preview_engine_safe
from core.cache_utils import cached_get_symbols, cached_get_balance
from core.rerun_utils import safe_rerun
from core.plot_utils import try_generate_plot_image_safe

# backend managers
from backend.user_manager import UserManager
from backend.session_manager import SessionManager

# IA PRO Scoring
#from core.ia_pro_score import compute_ia_pro_score
from core.ia_pro_orchestrator import compute_ia_pro_decision

try:
    from backend.log_manager import get_logger
    app_log = get_logger("app")
    trade_log = get_logger("trade")
    signals_log = get_logger("signals")
except Exception:
    app_log = logging.getLogger("app")
    trade_log = logging.getLogger("trade")
    signals_log = logging.getLogger("signals")
    for lg in (app_log, trade_log, signals_log):
        if not lg.handlers:
            h = logging.StreamHandler()
            h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
            lg.addHandler(h)
        lg.setLevel(logging.INFO)

DB_PATH = "data/usuarios.db"
user_m = UserManager(DB_PATH)
session_m = SessionManager(DB_PATH)

def _get_client_ip_safe():
    """
    Obtiene la IP real del cliente desde Streamlit.
    Funciona en local y producción (reverse proxy).
    """
    try:
        ctx = st.runtime.scriptrunner.get_script_run_ctx()
        if ctx and ctx.request:
            headers = ctx.request.headers or {}
            return (
                headers.get("x-forwarded-for", "")
                .split(",")[0]
                .strip()
                or ctx.request.remote_ip
            )
    except Exception:
        pass
    return "0.0.0.0"


def render_tabs():
    ia_pro = None # la puse para probar

    sid = st.session_state.get("session_id")
    if not sid:
        st.title("El Bot de EFRA +")
        st.markdown("Introduce credenciales en la barra lateral para continuar.")
        return

    if not st.session_state.get("analizando_activo", False):
        st.info("Selecciona un activo y pulsa **Analizar activo** para continuar.")
        return

    engine = st.session_state.get("engine") or lazy_init_engine(force=False)

    tabs = st.tabs([
        "📊 Analizar",
        "⚙️ Configuración",
        "🧪 Entrenar",
        "🏆 Ranking",
        "📡 Señales",
        "🔎 Auditoría",
        "🛡️ Admin IPs",
        "🚨 Seguridad IPs",
    ])

    # ============================
    # ANALIZAR
    # ============================
    with tabs[0]:
        st.header("📊 Analizar")

        # -------------------------------------------------
        # Usuario actual
        # -------------------------------------------------
        username = None
        try:
            sess = session_m.get_session(st.session_state.get("session_id"))
            username = sess.get("username") if sess else None
        except Exception:
            username = None

        # -------------------------------------------------
        # Balance
        # -------------------------------------------------
        st.subheader("Cuenta Spot")
        try:
            balance_val = cached_get_balance(engine, "USDT") if engine else None
            st.write(
                f"Balance USDT: **{balance_val:,.2f}**"
                if isinstance(balance_val, (int, float))
                else "Balance USDT: **N/D**"
            )
        except Exception:
            st.write("Balance USDT: **N/D**")

        # -------------------------------------------------
        # Estado análisis
        # -------------------------------------------------
        if not st.session_state.get("analizando_activo", False):
            st.info("Selecciona un activo desde la barra lateral y pulsa **Analizar activo**.")
            st.stop()

        symbol = st.session_state.get("selected_asset")
        if not symbol:
            st.error("No se ha seleccionado ningún activo.")
            st.stop()

        # -------------------------------------------------
        # Parámetros
        # -------------------------------------------------
        interval = st.selectbox(
            "Intervalo de velas",
            ["1m", "5m", "15m", "1h", "4h", "1d"],
            index=3,
            key="analizar_interval"
        )

        limit = st.slider(
            "Número de velas",
            min_value=50,
            max_value=2000,
            value=500,
            step=50,
            key="analizar_limit"
        )

        # -------------------------------------------------
        # Obtener velas
        # -------------------------------------------------
        try:
            df = engine.get_klines_df(
                symbol,
                interval=interval,
                limit=int(limit)
            ) if engine else None

            # -------------------------------------------------
            # Velas multi-timeframe para IA PRO
            # -------------------------------------------------
            tf_map = {
                "4h": "4h",
                "1h": "1h",
                "15m": "15m",
                "5m": "5m",
            }

            data_by_tf = {}

            for tf_name, tf_interval in tf_map.items():
                try:
                    tf_df = engine.get_klines_df(
                        symbol,
                        interval=tf_interval,
                        limit=300
                    )
                    if tf_df is not None and not tf_df.empty:
                        data_by_tf[tf_name] = tf_df
                except Exception:
                    pass

            if len(data_by_tf) < 4:
                st.warning("No hay suficientes timeframes para IA PRO.")
                st.stop()

        except Exception as e:
            app_log.exception("Error obteniendo velas: %s", e)
            df = None

        if df is None or (hasattr(df, "empty") and df.empty):
            st.error("No se pudieron cargar datos de mercado.")
            st.stop()

        # -------------------------------------------------
        # Normalizar DataFrame
        # -------------------------------------------------
        if isinstance(df, list):
            df = pd.DataFrame(df)

        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"])

        # -------------------------------------------------
        # Preview IA
        # -------------------------------------------------
        preview = {}
        pred = {}
        details = {}

        try:
            preview = engine.preview_order(
                symbol=symbol,
                usd_amount=10.0,
                klines_or_df=df,
                steps=1
            ) if engine else {}
            pred = preview.get("prediction", {}) or {}
            details = pred.get("details", {}) or {}
        except Exception as e:
            app_log.exception("preview_order falló: %s", e)

        ia_conf = float(pred.get("confidence", 0.0) or 0.0) * 100

        # -------------------------------------------------
        # IA PRO — Scoring real
        # -------------------------------------------------
        try:
            ia_pro = compute_ia_pro_decision(
                data_by_tf=data_by_tf,
                symbol=symbol
            )
        except Exception as e:
            app_log.exception("IA PRO failed: %s", e)
            ia_pro = {
                "score": 0,
                "confidence": 0,
                "direction": "NEUTRAL",
                "timestamp": "N/D",
                "reasons": [],
                "actionable": False
            }


        # -------------------------------------------------
        # Gráfica PRO
        # -------------------------------------------------
        try:
            import plotly.graph_objects as go

            fig = go.Figure()

            fig.add_trace(go.Candlestick(
                x=df["time"],
                open=df["open"],
                high=df["high"],
                low=df["low"],
                close=df["close"],
                name=symbol
            ))

            if "volume" in df.columns:
                fig.add_trace(go.Bar(
                    x=df["time"],
                    y=df["volume"],
                    name="Volumen",
                    yaxis="y2",
                    opacity=0.3
                ))

            fig.update_layout(
                title=f"{symbol} — {interval}",
                xaxis_title="Tiempo",
                yaxis_title="Precio",
                yaxis2=dict(
                    overlaying="y",
                    side="right",
                    showgrid=False
                ),
                height=520,
                template="plotly_dark",
                margin=dict(l=20, r=20, t=40, b=20),
                legend=dict(orientation="h")
            )

            if df[["open","high","low","close"]].nunique().sum() > 4:
                st.plotly_chart(fig, width="stretch")
            else:
                st.warning("Datos insuficientes para renderizar la gráfica.")

        except Exception:
            st.warning("No se pudo renderizar la gráfica.")
            app_log.debug("Plot error", exc_info=True)

        if df is None or len(df) < 100:
            st.warning("Datos insuficientes para análisis técnico confiable.")
            return

        # -------------------------------------------------
        # Panel IA + Indicadores
        # -------------------------------------------------
        col1, col2 = st.columns([2, 1])

        with col1:
            st.subheader("🧠 Predicción IA PRO")

            if not isinstance(ia_pro, dict):
                st.error("❌ IA no disponible o respuesta inválida.")
                return

            st.write(f"📅 Fecha/Hora decisión: **{ia_pro.get('timestamp', 'N/D')}**")
            st.write(f"📈 Dirección esperada: **{ia_pro.get('direction', 'N/A')}**")
            st.write(
                f"🎯 Confianza IA: **{float(ia_pro.get('confidence', 0.0)):.2f}%**"
            )

            if ia_pro.get("actionable"):
                st.success("🚦 OPERACIÓN IA PRO VALIDADA")
            else:
                st.warning("⛔ Mercado sin confluencia suficiente para operar")

            st.markdown("### 🔍 Confluencias detectadas")

            reasons = ia_pro.get("reasons")

            if isinstance(reasons, list) and reasons:
                for r in reasons:

                    # 🔹 Caso 1: razón estructurada (dict)
                    if isinstance(r, dict):
                        icon = "🟢" if r.get("status") == "OK" else "🔴"
                        rule = r.get("rule", "Regla")
                        details = r.get("details", "")
                        impact = r.get("impact", "N/D")

                        st.markdown(
                            f"{icon} **{rule}** — {details} "
                            f"(impacto {impact})"
                        )

                    # 🔹 Caso 2: razón simple (string)
                    elif isinstance(r, str):
                        st.markdown(f"🔵 {r}")

                    # 🔹 Caso 3: cualquier otra cosa
                    else:
                        st.markdown("⚠️ Confluencia no clasificable.")
            else:
                st.caption("Sin confluencias técnicas relevantes.")

            # -------------------------------------------------
            # BLOQUEO DE INVERSIÓN
            # -------------------------------------------------
            can_invest = ia_pro["actionable"]

            st.markdown("### Indicadores Técnicos")

            def fmt(v, f="{:.2f}"):
                return f.format(v) if isinstance(v, (int, float)) else "N/D"

            st.write(f"RSI(14): **{fmt(details.get('rsi'))}**")
            st.write(f"MACD Histograma: **{fmt(details.get('macd_hist'), '{:.6f}')}**")
            st.write(f"Momentum: **{fmt(details.get('momentum'), '{:.6f}')}**")
            st.write(
                f"Stochastic K/D: **{fmt(details.get('stoch_k'))} / {fmt(details.get('stoch_d'))}**"
            )
            st.write(f"ATR(14): **{fmt(details.get('atr'), '{:.6f}')}**")

            tps = details.get("tps")
            if isinstance(tps, dict) and tps:
                st.markdown("### 🎯 Take Profits sugeridos (ATR)")
                for k, v in tps.items():
                    st.write(f"{k}: **{fmt(v, '{:.6f}')}**")

            # -------------------------------------------------
            # Inversión
            # -------------------------------------------------
            st.markdown("### 💰 ¿Deseas invertir ahora?")

            amount_input = st.number_input(
                "Monto (USDT)",
                min_value=1.0,
                max_value=100000.0,
                value=10.0,
                step=1.0,
                key="invest_amount"
            )

            steps_input = st.slider(
                "Pasos DCA",
                min_value=1,
                max_value=10,
                value=3,
                key="invest_steps"
            )

            stop_pct_input = st.number_input(
                "Stop loss (%)",
                min_value=0.1,
                max_value=50.0,
                value=2.0,
                step=0.1,
                key="invest_stop_pct"
            )

            preview_engine_btn = st.button("🔎 Previsualizar orden")
            do_invest = st.button(
                "🚀 Invertir ahora",
                disabled=not can_invest
            )

            if not can_invest:
                st.info("La IA PRO solo permite invertir con ≥ 90% de confianza.")

            if preview_engine_btn:
                try:
                    pr = engine.preview_order(symbol, amount_input, df) if engine else {}
                    st.json(pr)
                except Exception as e:
                    st.error(f"Previsualización fallida: {e}")

            if do_invest:
                try:
                    usuario_dict = user_m.get_user_by_username(username) or {"username": username}
                    mode = getattr(engine, "mode", "DEMO")
                    modo_str = "REAL" if str(mode).upper() == "REAL" else "DEMO"


                    # ===========================
                    # RISK ENGINE IA PRO (SESSION AWARE)
                    # ===========================
                    from backend.risk_engine import dynamic_risk, detect_session

                    session_name = detect_session()

                    risk_cfg = dynamic_risk(
                        score=ia_conf,                 # tu score IA PRO (ya calculado arriba)
                        session=session_name,
                        signal_type="continuation",    # luego lo automatizamos
                        is_late_entry=False            # luego lo automatizamos
                    )

                    if not risk_cfg["allowed"]:
                        st.error(f"Orden bloqueada por Risk Engine: {risk_cfg['reason']}")
                        st.stop()

                    res = engine.ejecutar_compound_order(
                        usuario=usuario_dict,
                        symbol=symbol,
                        total_amount_usdt=float(amount_input),
                        steps=int(steps_input),
                        modo=modo_str,
                        stop_loss_pct=float(stop_pct_input) * risk_cfg["sl_multiplier"]
                    )

                    st.success("Orden enviada correctamente.")
                    st.json(res)

                    trade_log.info(
                        "Orden ejecutada",
                        extra={
                            "user": username,
                            "symbol": symbol,
                            "amount": amount_input
                        }
                    )

                except Exception as e:
                    st.error(f"Error ejecutando orden: {e}")
                    app_log.exception("Error inversión", exc_info=True)

        # -------------------------------------------------
        # Detalle vela
        # -------------------------------------------------
        with col2:       
            st.subheader("🕯️ Velas Analizadas (IA PRO)")

            for tf in ["4h", "1h", "15m", "5m"]:
                df_tf = data_by_tf.get(tf)
                if df_tf is None or len(df_tf) < 2:
                    continue

                last = df_tf.iloc[-1]
                prev = df_tf.iloc[-2]

                vela_tipo = "NEUTRA"
                if last["close"] > last["open"] and prev["close"] < prev["open"]:
                    vela_tipo = "ENGULFING ALCISTA"
                elif last["close"] < last["open"] and prev["close"] > prev["open"]:
                    vela_tipo = "ENGULFING BAJISTA"
                elif abs(last["close"] - last["open"]) < (last["high"] - last["low"]) * 0.2:
                    vela_tipo = "DOJI"

                st.markdown(
                    f"""
                    **{tf}**
                    - Fecha: `{last['time']}`
                    - Open: `{last['open']}`
                    - High: `{last['high']}`
                    - Low: `{last['low']}`
                    - Close: `{last['close']}`
                    - Tipo: **{vela_tipo}**
                    """
                )

    # ============================
    # CONFIGURACIÓN tab
    # ============================
    with tabs[1]:
        st.header("Configuración (Administración)")
        logged = session_m.get_session(st.session_state.get("session_id"))
        uname = logged.get("username") if logged else None
        urec = user_m.get_user_by_username(uname) if uname else None

        if not uname or not urec or not urec.get("is_admin"):
            st.error("Acceso restringido: sólo administrador.")
            st.stop()

        try:
            from backend.admin_panel import render_admin_panel

            try:
                from backend.ip_manager import IPManager
                ip_m = IPManager()
            except Exception:
                ip_m = None

            render_admin_panel(user_m, ip_m)

        except Exception as e:
            st.error("No se pudo cargar panel admin.")
            app_log.exception("admin panel error: %s", e)

        st.subheader("IPs detectadas")
        st.write(f"IP actual: **{urec.get('last_ip')}**")
        st.write(f"Aprobada: **{'Sí' if urec.get('ip_verified') else 'No'}**")
        st.write(f"Whitelist: {urec.get('ip_whitelist')}")

    # ============================
    # ENTRENAR tab
    # ============================
    with tabs[2]:
        st.header("Entrenar (Demo)")

        try:
            uname = session_m.get_session(
                st.session_state.get("session_id")
            ).get("username")
        except Exception:
            uname = None

        st.info("Modo Demo — Las órdenes NO son reales.")

        demo_sym = st.selectbox(
            "Par (DEMO)",
            ["BTCUSDT", "ETHUSDT", "BNBUSDT"]
        )

        demo_monto = st.slider(
            "Monto DEMO (USDT)",
            10,
            100,
            25
        )

        demo_pasos = st.slider(
            "Pasos (DCA)",
            1,
            5,
            3
        )

        if st.button("Ejecutar DEMO"):
            try:
                usuario_dict = user_m.get_user_by_username(uname) or {
                    "username": uname
                }

                result = engine.ejecutar_compound_order(
                    usuario=usuario_dict,
                    symbol=demo_sym,
                    total_amount_usdt=float(demo_monto),
                    steps=int(demo_pasos),
                    modo="DEMO"
                )

                st.success("Demo ejecutada.")
                st.json(result)

            except Exception as e:
                st.error(f"No se pudo ejecutar la DEMO: {e}")
                app_log.exception("DEMO failed: %s", e)

    # ============================
    # RANKING tab
    # ============================
    with tabs[3]:
        st.header("🏆 Ranking de Ganancias Reales")

        try:
            from backend.results_manager import ResultsManager
            r = ResultsManager().ranking("all")
            st.dataframe(r)
        except Exception:
            st.info("ResultsManager no disponible.")

    # ============================
    # SEÑALES tab
    # ============================
    with tabs[4]:
        st.header("📡 Señales en Tiempo Real — PRO")
        st.info("Control del SignalsEngine (si existe).")

        # ============================
        # AUDITORÍA tab
        # ============================
        with tabs[5]:
            st.header("🔎 Auditoría de Seguridad")

            logged = session_m.get_session(st.session_state.get("session_id"))
            uname = logged.get("username") if logged else None
            urec = user_m.get_user_by_username(uname) if uname else None

            if not uname or not urec:
                st.error("No hay datos válidos de sesión o usuario.")
                st.stop()

            st.subheader("Sesión actual")

            st.table({
                "Campo": [
                    "Usuario",
                    "Nombre",
                    "Email",
                    "Última IP registrada",
                    "IP aprobada",
                    "IPs autorizadas"
                ],
                "Valor": [
                    urec.get("username") or "-",
                    urec.get("full_name") or "-",
                    urec.get("email") or "-",
                    urec.get("last_ip") or "-",
                    "Sí" if urec.get("ip_verified") else "No",
                    urec.get("ip_whitelist") or "-"
                ]
            })

            # ------------------------------------
            # Acción administrativa
            # ------------------------------------
            if urec.get("is_admin"):
                st.subheader("Acción administrativa")

                if st.button("✅ Aprobar IP actual"):
                    try:
                        current_ip = None

                        # ==========================================
                        # 1️⃣ IP desde sesión activa (MÁS CONFIABLE)
                        # ==========================================
                        sid = st.session_state.get("session_id")
                        if sid:
                            try:
                                sess = session_m.get_session(sid)
                                current_ip = sess.get("ip")
                            except Exception:
                                current_ip = None

                        # ==========================================
                        # 2️⃣ Intentar Streamlit headers (si existen)
                        # ==========================================
                        if not current_ip:
                            try:
                                ctx = st.runtime.scriptrunner.get_script_run_ctx()
                                if ctx and ctx.request:
                                    headers = ctx.request.headers or {}
                                    current_ip = (
                                        headers.get("x-forwarded-for", "")
                                        .split(",")[0]
                                        .strip()
                                        or ctx.request.remote_ip
                                    )
                            except Exception:
                                current_ip = None

                        # ==========================================
                        # 3️⃣ IP local de red (fallback LAN / DEV)
                        # ==========================================
                        if not current_ip:
                            try:
                                import socket
                                current_ip = socket.gethostbyname(
                                    socket.gethostname()
                                )
                            except Exception:
                                current_ip = None

                        # ==========================================
                        # 4️⃣ Último fallback controlado
                        # ==========================================
                        if not current_ip:
                            current_ip = "127.0.0.1"

                        # ==========================================
                        # Guardar y aprobar IP
                        # ==========================================
                        user_m.update_last_ip(
                            username=urec["username"],
                            ip=current_ip
                        )

                        user_m.approve_ip(
                            username=urec["username"],
                            ip=current_ip
                        )

                        ip_m.log(
                            urec["username"],
                            current_ip,
                            "admin_ip_approved_manual"
                        )

                        st.success(f"IP {current_ip} aprobada correctamente.")
                        safe_rerun()

                    except Exception:
                        st.error("Error aprobando la IP.")
                        app_log.exception(
                            "approve_ip_current failed",
                            exc_info=True
                        )

    # ============================
    # ADMIN TAB — IPs & MEMBRESÍAS
    # ============================
    with tabs[6]:
        st.header("🛡️ Admin — Control de IPs y Membresías")

        logged = session_m.get_session(st.session_state.get("session_id"))
        uname = logged.get("username") if logged else None
        urec = user_m.get_user_by_username(uname) if uname else None

        if not urec or not urec.get("is_admin"):
            st.error("Acceso restringido: solo administrador.")
            st.stop()

        try:
            from backend.ip_manager import IPManager
            ip_m = IPManager()
        except Exception:
            st.error("IPManager no disponible.")
            app_log.exception("IPManager error", exc_info=True)
            st.stop()

        sub_tabs = st.tabs([
            "📋 IPs Aprobadas",
            "⏳ Aprobación por Token",
            "🧾 Historial IPs",
        ])

        with sub_tabs[0]:
            st.subheader("📋 IPs Aprobadas por Usuario")

            data = ip_m.list_allowed()

            if not data:
                st.info("No hay IPs aprobadas.")
            else:
                df = pd.DataFrame(data)

                def _status(row):
                    if not row["expires_at"]:
                        return "ADMIN"
                    try:
                        return (
                            "ACTIVA"
                            if pd.to_datetime(row["expires_at"])
                            > pd.Timestamp.utcnow()
                            else "EXPIRADA"
                        )
                    except Exception:
                        return "DESCONOCIDO"

                df["estado"] = df.apply(_status, axis=1)

                st.dataframe(
                    df,
                    width="stretch",
                    hide_index=True
                )

                st.markdown("### 🔧 Acciones Manuales")

                col1, col2, col3 = st.columns([3, 3, 2])

                with col1:
                    sel_user = st.selectbox(
                        "Usuario",
                        options=sorted(df["username"].unique()),
                        key="admin_ip_user"
                    )

                with col2:
                    sel_ip = st.selectbox(
                        "IP",
                        options=sorted(
                            df[df["username"] == sel_user]["ip"].unique()
                        ),
                        key="admin_ip_ip"
                    )

                with col3:
                    confirm = st.checkbox(
                        "Confirmar revocación",
                        key="confirm_revoke_ip"
                    )

                if st.button("❌ Revocar IP", disabled=not confirm):
                    try:
                        with ip_m._conn() as c:
                            c.execute(
                                "DELETE FROM allowed_ips WHERE username=? AND ip=?",
                                (sel_user, sel_ip)
                            )
                            c.commit()

                        ip_m.log(sel_user, sel_ip, "ip_revoked_admin")
                        st.success(
                            f"IP {sel_ip} revocada para {sel_user}"
                        )
                        st.rerun()

                    except Exception:
                        st.error("No se pudo revocar la IP.")
                        app_log.exception(
                            "revoke ip",
                            exc_info=True
                        )

        with sub_tabs[1]:
            st.subheader("⏳ Aprobación manual vía token")

            st.info(
                "Usa esta sección SOLO si recibiste un token "
                "por correo o Telegram para aprobar una IP."
            )

            token = st.text_input(
                "Token de aprobación IP",
                type="password"
            )

            if st.button("✅ Aprobar IP desde token"):
                try:
                    if hasattr(ip_m, "approve_from_token"):
                        res = ip_m.approve_from_token(token)
                        if res:
                            user, ip = res
                            st.success(
                                f"IP {ip} aprobada para usuario {user}"
                            )
                        else:
                            st.error(
                                "Token inválido o expirado."
                            )
                    else:
                        st.error(
                            "Este sistema no soporta aprobación por token."
                        )
                except Exception:
                    st.error("Error procesando token.")
                    app_log.exception(
                        "approve token",
                        exc_info=True
                    )

        with sub_tabs[2]:
            st.subheader("🧾 Historial de eventos IP")

            logs = ip_m.list_logs(limit=300)

            if not logs:
                st.info("No hay eventos registrados.")
            else:
                df_logs = pd.DataFrame(logs)

                st.dataframe(
                    df_logs,
                    width="stretch",
                    hide_index=True
                )

    # ============================
    # ADMIN TAB — SEGURIDAD IPs
    # ============================
    with tabs[7]:
        st.header("🚨 Admin — Seguridad de IPs")

        logged = session_m.get_session(st.session_state.get("session_id"))
        uname = logged.get("username") if logged else None
        urec = user_m.get_user_by_username(uname) if uname else None

        if not urec or not urec.get("is_admin"):
            st.error("Acceso restringido: solo administrador.")
            st.stop()

        try:
            from backend.ip_manager import IPManager
            ip_m = IPManager()
        except Exception:
            st.error("IPManager no disponible.")
            st.stop()

        sub_tabs = st.tabs([
            "🚫 IPs Bloqueadas",
            "⚠️ Riesgo & Incidentes",
            "🔓 Acciones Manuales",
        ])

        with sub_tabs[0]:
            st.subheader("🚫 IPs bloqueadas automáticamente")

            try:
                data = ip_m.list_blocked()
            except Exception:
                data = []

            if not data:
                st.success("No hay IPs bloqueadas actualmente.")
            else:
                df = pd.DataFrame(data)

                st.dataframe(
                    df,
                    width="stretch",
                    hide_index=True
                )

        with sub_tabs[1]:
            st.subheader("⚠️ Eventos de riesgo detectados")

            try:
                events = ip_m.list_risk_events(limit=300)
            except Exception:
                events = []

            if not events:
                st.info("No hay eventos de riesgo registrados.")
            else:
                df = pd.DataFrame(events)

                st.dataframe(
                    df,
                    width="stretch",
                    hide_index=True
                )

                st.markdown("### 📊 Resumen rápido")

                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        "IPs distintas",
                        df["ip"].nunique()
                        if "ip" in df else 0
                    )

                with col2:
                    st.metric(
                        "Usuarios afectados",
                        df["username"].nunique()
                        if "username" in df else 0
                    )

                with col3:
                    st.metric(
                        "Eventos totales",
                        len(df)
                    )

        with sub_tabs[2]:
            st.subheader("🔓 Control manual de IPs")

            col1, col2 = st.columns(2)

            with col1:
                ip_target = st.text_input("IP objetivo")

            with col2:
                action = st.selectbox(
                    "Acción",
                    [
                        "Desbloquear IP",
                        "Banear IP permanentemente"
                    ]
                )

            if st.button("⚡ Ejecutar acción"):
                if not ip_target:
                    st.error("Introduce una IP válida.")
                else:
                    try:
                        if action == "Desbloquear IP":
                            ip_m.unblock_ip(ip_target)
                            ip_m.log(
                                uname,
                                ip_target,
                                "manual_unblock"
                            )
                            st.success(
                                f"IP {ip_target} desbloqueada."
                            )

                        elif action == "Banear IP permanentemente":
                            ip_m.ban_ip(ip_target)
                            ip_m.log(
                                uname,
                                ip_target,
                                "manual_ban"
                            )
                            st.warning(
                                f"IP {ip_target} baneada permanentemente."
                            )

                        st.rerun()

                    except Exception:
                        st.error("No se pudo ejecutar la acción.")
