#find_bad_imports.py

import os

BAD_IMPORTS = [
    "core.sessions",
    "core.news",
]

for root, _, files in os.walk("."):
    for f in files:
        if f.endswith(".py"):
            path = os.path.join(root, f)
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    content = fh.read()
                    for bad in BAD_IMPORTS:
                        if bad in content:
                            print(f"[FOUND] {bad} -> {path}")
            except Exception:
                pass
