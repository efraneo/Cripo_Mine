# migrate_to_pro.py
"""
Migrador a "PRO" para data/usuarios.db
 - Hace backup (usuarios.db.bak.TIMESTAMP)
 - Crea tablas nuevas si faltan
 - Añade columnas password_hash, api_key_enc, api_secret_enc, must_reset
 - Crea tablas: sessions, twofa_tokens, reset_tokens, allowed_ips, ip_logs, failed_logins, lockouts
 - Si encuentra usuarios sin password_hash marca must_reset=1 y crea reset token (dev)
"""
import sqlite3, os, shutil, time, secrets, json
from datetime import datetime, timedelta

DB = os.path.join("data", "usuarios.db")
if not os.path.exists(DB):
    raise SystemExit("No existe data/usuarios.db en el directorio actual.")

bak = DB + ".bak." + str(int(time.time()))
shutil.copy2(DB, bak)
print("Backup realizado:", bak)

def conn():
    return sqlite3.connect(DB)

with conn() as c:
    cur = c.cursor()
    # add missing columns safely
    cols = [r[1] for r in cur.execute("PRAGMA table_info(users)").fetchall()]
    if "password_hash" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN password_hash TEXT")
        print("Añadida columna password_hash")
    if "api_key_enc" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN api_key_enc TEXT")
        print("Añadida columna api_key_enc")
    if "api_secret_enc" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN api_secret_enc TEXT")
        print("Añadida columna api_secret_enc")
    if "must_reset" not in cols:
        cur.execute("ALTER TABLE users ADD COLUMN must_reset INTEGER DEFAULT 0")
        print("Añadida columna must_reset")

    # Create supporting tables (from schema)
    sqls = open(os.path.join("sql","schema_pro.sql")).read()
    cur.executescript(sqls)
    c.commit()
    print("Tablas PRO creadas/aseguradas.")

    # mark users without password_hash
    cur.execute("SELECT username, password_hash FROM users")
    rows = cur.fetchall()
    created_tokens = []
    for u, ph in rows:
        if not ph or ph.strip()=="":
            token = secrets.token_urlsafe(24)
            expires = int((datetime.utcnow() + timedelta(days=1)).timestamp())
            cur.execute("INSERT INTO reset_tokens(username, token, expires_at, created_at) VALUES (?,?,?,?)",
                        (u, token, expires, int(time.time())))
            cur.execute("UPDATE users SET must_reset=1 WHERE username=?", (u,))
            created_tokens.append((u, token))
    c.commit()
    if created_tokens:
        print("Usuarios marcados para reset (must_reset). Tokens generados (dev output):")
        print(json.dumps(created_tokens, indent=2))
    else:
        print("Todos los usuarios ya tienen password_hash.")

print("Migración completada.")
