"""
dashboard_flask.py

Dashboard web (Flask + Jinja2) para tu bot.
- Crea archivos de plantilla (templates/) y assets si no existen
- Rutas:
  /           -> status general
  /trades     -> lista de trades (lee data/trade_audit.jsonl)
  /logs       -> muestra logs/app.log (tail)
  /trade      -> formulario para enviar trade manual (POST llama procesar_y_ejecutar)
  /api/trade  -> API POST para ejecutar trade (JSON)

Instrucciones:
- Coloca este archivo en la raíz del proyecto (C:\software_phyton\Efra_BOT\dashboard_flask.py)
- Ejecuta: python dashboard_flask.py
- Abre http://127.0.0.1:5000

Notas:
- Intenta integrar con backend/trading_core.procesar_y_ejecutar si está disponible.
- Diseño sencillo con Bootstrap CDN.
"""

from __future__ import annotations
import os
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash

# Create Flask app
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET', 'cambio_este_valor')

# Paths
BASE_DIR = Path.cwd()
DATA_DIR = BASE_DIR / 'data'
AUDIT_FILE = DATA_DIR / 'trade_audit.jsonl'
LOG_FILE = BASE_DIR / 'logs' / 'app.log'
TEMPLATES_DIR = BASE_DIR / 'templates'
STATIC_DIR = BASE_DIR / 'static'

# Ensure folders
TEMPLATES_DIR.mkdir(exist_ok=True)
STATIC_DIR.mkdir(exist_ok=True)

# Try to import procesar_y_ejecutar from trading_core
try:
    from backend.trading_core import procesar_y_ejecutar, SignalProcessor, TradeExecutor
    HAS_TRADING_CORE = True
except Exception:
    procesar_y_ejecutar = None
    SignalProcessor = None
    TradeExecutor = None
    HAS_TRADING_CORE = False


# ----------------------
# Helper utilities
# ----------------------

def tail_file(path: Path, lines: int = 200) -> str:
    if not path.exists():
        return ''
    try:
        with open(path, 'rb') as f:
            f.seek(0, os.SEEK_END)
            file_size = f.tell()
            block_size = 1024
            data = b''
            while file_size > 0 and lines > 0:
                read_size = min(block_size, file_size)
                f.seek(file_size - read_size)
                chunk = f.read(read_size)
                data = chunk + data
                file_size -= read_size
                lines = data.count(b"\n") - 1
            return data.decode('utf-8', errors='ignore').splitlines()[-200:]
    except Exception:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read().splitlines()[-200:]


def read_trades(limit: int = 200) -> List[Dict[str, Any]]:
    out = []
    if not AUDIT_FILE.exists():
        return out
    try:
        with open(AUDIT_FILE, 'r', encoding='utf-8') as fh:
            for i, line in enumerate(fh):
                if line.strip():
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        # tolerate malformed
                        out.append({"_raw": line.strip()})
        return out[-limit:][::-1]
    except Exception:
        return out


# ----------------------
# Create minimal templates if missing
# ----------------------
BASE_HTML = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BOT Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="/">Efra-BOT</a>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link" href="/">Status</a></li>
          <li class="nav-item"><a class="nav-link" href="/trades">Trades</a></li>
          <li class="nav-item"><a class="nav-link" href="/logs">Logs</a></li>
          <li class="nav-item"><a class="nav-link" href="/trade">Manual Trade</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container mt-4">
    {% with messages = get_flashed_messages() %}
      {% if messages %}
        <div class="alert alert-info">
          {% for m in messages %}{{ m }}<br>{% endfor %}
        </div>
      {% endif %}
    {% endwith %}
    {% block content %}{% endblock %}
  </div>
  </body>
</html>
"""

INDEX_HTML = """{% extends 'base.html' %}
{% block content %}
<h1>Estado del Bot</h1>
<p><strong>Trading core:</strong> {{ trading_core }}</p>
<p><strong>IA disponible:</strong> {{ ia_ok }}</p>
<p><strong>Último trade:</strong> {{ last_trade }}</p>
<hr>
<h4>Quick Actions</h4>
<form method="post" action="/api/trade" class="row g-3">
  <div class="col-md-2">
    <input name="symbol" class="form-control" placeholder="BTCUSDT" value="BTCUSDT">
  </div>
  <div class="col-md-2">
    <select name="signal" class="form-select"><option>BUY</option><option>SELL</option></select>
  </div>
  <div class="col-md-2">
    <input name="price" class="form-control" placeholder="price">
  </div>
  <div class="col-md-2">
    <button class="btn btn-primary">Enviar (PAPER)</button>
  </div>
</form>
{% endblock %}
"""

TRADES_HTML = """{% extends 'base.html' %}
{% block content %}
<h1>Trades (últimos)</h1>
<table class="table table-sm table-striped">
  <thead><tr><th>ts</th><th>symbol</th><th>status</th><th>notional</th><th>details</th></tr></thead>
  <tbody>
  {% for t in trades %}
    <tr>
      <td>{{ t.timestamp | default(t.get('timestamp')) }}</td>
      <td>{{ t.symbol | default(t.get('symbol')) }}</td>
      <td>{{ t.status | default(t.get('status')) }}</td>
      <td>{{ t.notional | default(t.get('notional_usdt') or '') }}</td>
      <td><pre style="max-width:400px;white-space:pre-wrap">{{ t | tojson }}</pre></td>
    </tr>
  {% endfor %}
  </tbody>
</table>
{% endblock %}
"""

LOGS_HTML = """{% extends 'base.html' %}
{% block content %}
<h1>App Logs</h1>
<pre style="max-height:70vh; overflow:auto; background:#111; color:#eee; padding:10px;">{{ logs | join('\n') }}</pre>
{% endblock %}
"""

TRADE_FORM_HTML = """{% extends 'base.html' %}
{% block content %}
<h1>Enviar Trade Manual</h1>
<form method="post" action="/api/trade">
  <div class="mb-3">
    <label class="form-label">Symbol</label>
    <input class="form-control" name="symbol" value="BTCUSDT">
  </div>
  <div class="mb-3">
    <label class="form-label">Signal</label>
    <select name="signal" class="form-select"><option>BUY</option><option>SELL</option></select>
  </div>
  <div class="mb-3">
    <label class="form-label">Price (opcional)</label>
    <input class="form-control" name="price">
  </div>
  <div class="mb-3">
    <button class="btn btn-success">Enviar</button>
  </div>
</form>
{% endblock %}
"""

# Write templates if missing
files = {
    TEMPLATES_DIR / 'base.html': BASE_HTML,
    TEMPLATES_DIR / 'index.html': INDEX_HTML,
    TEMPLATES_DIR / 'trades.html': TRADES_HTML,
    TEMPLATES_DIR / 'logs.html': LOGS_HTML,
    TEMPLATES_DIR / 'trade_form.html': TRADE_FORM_HTML,
}
for p, content in files.items():
    if not p.exists():
        p.write_text(content, encoding='utf-8')


# ----------------------
# Routes
# ----------------------
@app.route('/')
def index():
    trades = read_trades(1)
    last = trades[0] if trades else None
    ctx = {
        'trading_core': 'OK' if HAS_TRADING_CORE else 'Missing',
        'ia_ok': 'Yes' if HAS_TRADING_CORE else 'No',
        'last_trade': last
    }
    return render_template('index.html', **ctx)


@app.route('/trades')
def trades_view():
    trades = read_trades(200)
    return render_template('trades.html', trades=trades)


@app.route('/logs')
def logs_view():
    logs = tail_file(LOG_FILE)
    return render_template('logs.html', logs=logs)


@app.route('/trade')
def trade_form():
    return render_template('trade_form.html')


@app.route('/api/trade', methods=['POST'])
def api_trade():
    # accept form or json
    data = request.get_json(silent=True) or request.form.to_dict()
    symbol = data.get('symbol')
    signal = data.get('signal')
    price = data.get('price')

    if not symbol or not signal:
        flash('Symbol and signal required')
        return redirect(url_for('index'))

    hist = None
    # build minimal hist df for processor
    try:
        import pandas as pd
        hist = pd.DataFrame([{'open': float(data.get('open') or price or 0), 'high': float(data.get('high') or price or 0), 'low': float(data.get('low') or price or 0), 'close': float(price or 0), 'volume': float(data.get('volume') or 0)}])
    except Exception:
        hist = None

    # prepare objects
    if HAS_TRADING_CORE:
        sp = SignalProcessor()
        te = TradeExecutor(mode='PAPER')
        sig = {'symbol': symbol, 'signal': signal, 'price': float(price) if price else None}
        out = procesar_y_ejecutar(sig, hist, te, sp, usuario={'usuario': 'web'})
        flash('Trade enviado (PAPER).')
        return redirect(url_for('trades_view'))
    else:
        flash('Trading core no disponible, trade no enviado.')
        return redirect(url_for('index'))


# Simple API endpoint for programmatic calls
@app.route('/api/trade/json', methods=['POST'])
def api_trade_json():
    payload = request.get_json()
    if not payload:
        return jsonify({'error': 'no-json'}), 400
    symbol = payload.get('symbol')
    signal = payload.get('signal')
    price = payload.get('price')
    if not symbol or not signal:
        return jsonify({'error': 'symbol/signal required'}), 400

    if not HAS_TRADING_CORE:
        return jsonify({'error': 'trading_core_missing'}), 500

    sp = SignalProcessor()
    te = TradeExecutor(mode='PAPER')
    hist = None
    try:
        import pandas as pd
        hist = pd.DataFrame([{'open': price, 'high': price, 'low': price, 'close': price, 'volume': 0}])
    except Exception:
        hist = None

    out = procesar_y_ejecutar({'symbol': symbol, 'signal': signal, 'price': price}, hist, te, sp, usuario={'usuario': 'api'})
    return jsonify(out)


# ----------------------
# Run
# ----------------------
if __name__ == '__main__':
    print('Starting dashboard on http://127.0.0.1:5000')
    app.run(debug=False, host='127.0.0.1', port=5000)
