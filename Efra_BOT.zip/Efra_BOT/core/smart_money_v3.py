#core/smart_money_v3.py

import numpy as np


# ============================================================
# MULTI TF BIAS
# ============================================================

def compute_htf_bias(df_1h):
    if df_1h is None or len(df_1h) < 50:
        return "NEUTRAL"

    ema_fast = df_1h["close"].ewm(span=20).mean()
    ema_slow = df_1h["close"].ewm(span=50).mean()

    if ema_fast.iloc[-1] > ema_slow.iloc[-1]:
        return "BULLISH"
    elif ema_fast.iloc[-1] < ema_slow.iloc[-1]:
        return "BEARISH"

    return "NEUTRAL"


# ============================================================
# LIQUIDITY POOLS
# ============================================================

def detect_liquidity_pools(df):
    highs = df["high"].rolling(5).max()
    lows = df["low"].rolling(5).min()

    eq_highs = abs(df["high"] - highs) < 1e-5
    eq_lows = abs(df["low"] - lows) < 1e-5

    return {
        "equal_highs": int(eq_highs.sum()),
        "equal_lows": int(eq_lows.sum())
    }


# ============================================================
# STOP HUNT DETECTOR
# ============================================================

def detect_stop_hunt(df):
    last = df.iloc[-1]
    prev = df.iloc[-10:-1]

    if last["high"] > prev["high"].max() and last["close"] < prev["high"].max():
        return {"hunt": True, "side": "BUY_TRAP"}

    if last["low"] < prev["low"].min() and last["close"] > prev["low"].min():
        return {"hunt": True, "side": "SELL_TRAP"}

    return {"hunt": False}


# ============================================================
# ENTRY ENGINE PRO
# ============================================================

def compute_entry(df, bias):

    last = df.iloc[-1]

    if bias == "BULLISH":
        entry = last["close"]
        sl = entry * 0.98
        tp = entry * 1.04

    elif bias == "BEARISH":
        entry = last["close"]
        sl = entry * 1.02
        tp = entry * 0.96

    else:
        return {"valid": False}

    return {
        "valid": True,
        "entry": entry,
        "sl": sl,
        "tp": tp
    }


# ============================================================
# CORE SMC V3
# ============================================================

def compute_smc_v3(df_5m, df_15m=None, df_1h=None):

    if df_5m is None or len(df_5m) < 50:
        return {"confidence": 0, "signal": "NO_DATA"}

    score = 0
    signals = []

    # -----------------------------
    # HTF BIAS
    # -----------------------------
    htf_bias = compute_htf_bias(df_1h)
    signals.append(f"HTF: {htf_bias}")

    if htf_bias != "NEUTRAL":
        score += 20

    # -----------------------------
    # LIQUIDITY
    # -----------------------------
    liquidity = detect_liquidity_pools(df_5m)

    if liquidity["equal_highs"] > 2 or liquidity["equal_lows"] > 2:
        score += 20
        signals.append("Liquidity Pool")

    # -----------------------------
    # STOP HUNT
    # -----------------------------
    hunt = detect_stop_hunt(df_5m)

    if hunt["hunt"]:
        score += 30
        signals.append(f"Stop Hunt {hunt['side']}")

    # -----------------------------
    # ENTRY ENGINE
    # -----------------------------
    entry = compute_entry(df_5m, htf_bias)

    if entry.get("valid"):
        score += 20
        signals.append("Valid Entry")

    confidence = min(100, score)

    return {
        "confidence": confidence,
        "signal": "INSTITUTIONAL" if confidence > 80 else "WEAK",
        "htf_bias": htf_bias,
        "entry": entry,
        "details": signals
    }
