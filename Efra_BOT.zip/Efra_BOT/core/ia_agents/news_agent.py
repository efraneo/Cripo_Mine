from core.news_filter import is_high_risk_news_window

def news_agent():
    vote = {
        "agent": "news",
        "veto": False,
        "reason": None
    }

    risk, reason = is_high_risk_news_window()
    if risk:
        vote["veto"] = True
        vote["reason"] = reason

    return vote
