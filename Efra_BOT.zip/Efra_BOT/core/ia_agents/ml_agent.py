def ml_agent(ml_input):
    """
    Institutional ML Agent
    Robust to multiple input formats
    """

    vote = {
        "agent": "ml",
        "confidence_boost": 0,
        "veto": False,
        "reason": None
    }

    try:
        # ==================================================
        # NORMALIZACIÓN DE INPUT (CRÍTICO)
        # ==================================================

        ml_probability = None

        # Caso 1: viene todo el ia dict
        if isinstance(ml_input, dict):

            # prioridad 1
            if "ml_probability" in ml_input:
                ml_probability = ml_input.get("ml_probability")

            # fallback alternativo
            elif "probability" in ml_input:
                ml_probability = ml_input.get("probability")

        # Caso 2: viene directo (float/int)
        elif isinstance(ml_input, (int, float)):
            ml_probability = ml_input

        # Caso 3: None o inválido
        if ml_probability is None:
            vote["reason"] = "ML no disponible"
            return vote

        # Si aún es dict → extraer
        if isinstance(ml_probability, dict):
            ml_probability = ml_probability.get("probability", 0)

        # Convertir a float seguro
        ml_probability = float(ml_probability)

        # Clamp (seguridad)
        ml_probability = max(0.0, min(1.0, ml_probability))

        # ==================================================
        # LÓGICA DE DECISIÓN
        # ==================================================

        if ml_probability < 0.55:
            vote["veto"] = True
            vote["reason"] = f"ML baja probabilidad ({ml_probability:.2f})"

        elif ml_probability > 0.70:
            vote["confidence_boost"] = 20
            vote["reason"] = f"ML alta convicción ({ml_probability:.2f})"

        else:
            vote["confidence_boost"] = 5
            vote["reason"] = f"ML confirmación moderada ({ml_probability:.2f})"

        return vote

    except Exception as e:
        vote["reason"] = f"ML error: {str(e)}"
        vote["veto"] = True
        return vote