def trend_agent(ia_result):
    vote = {
        "agent": "trend",
        "direction": ia_result["direction"],
        "confidence_boost": 0,
        "veto": False,
        "reason": None
    }

    if ia_result["direction"] == "NEUTRAL":
        vote["confidence_boost"] = -10
        vote["reason"] = "Tendencia no clara"

    else:
        vote["confidence_boost"] = +10
        vote["reason"] = "Tendencia alineada"

    return vote
