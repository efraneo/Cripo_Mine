def risk_agent(ia_result):
    vote = {
        "agent": "risk",
        "confidence_boost": 0,
        "veto": False,
        "reason": None
    }

    regime = ia_result.get("regime")

    if regime == "CHAOS":
        vote["veto"] = True
        vote["reason"] = "Régimen caótico"

    elif regime == "RANGING":
        vote["confidence_boost"] = -20
        vote["reason"] = "Mercado lateral"

    else:
        vote["confidence_boost"] = +5
        vote["reason"] = "Riesgo aceptable"

    return vote
