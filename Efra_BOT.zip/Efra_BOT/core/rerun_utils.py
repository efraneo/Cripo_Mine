# core/rerun_utils.py
import time
import streamlit as st

def safe_rerun(delay: float = 0.15):
    """Reintenta hacer rerun sin romper si el entorno no soporta rerun."""
    try:
        time.sleep(delay)
        st.rerun()
    except Exception:
        # no-op si no se puede reiniciar
        pass
