# core/capital_rotation/capital_rotator.py

from core.capital_rotation.performance_scoring import score_strategy
from core.capital_rotation.rotation_policy import ROTATION_RULES
from core.strategy.strategy_state import get_strategy_state


def rotate_capital(strategy_stats: dict) -> dict:
    """
    strategy_stats:
    {
        "TREND_FOLLOWING": {...},
        "MEAN_REVERSION": {...}
    }
    """

    decisions = {}

    for name, stats in strategy_stats.items():
        state = get_strategy_state(name)
        score = score_strategy(stats)

        allocated = state["allocated_capital"]

        # -----------------------------
        # PROMOTION
        # -----------------------------
        if score >= ROTATION_RULES["PROMOTE_THRESHOLD"]:
            delta = min(
                ROTATION_RULES["MAX_INCREASE"],
                1 - allocated
            )
            state["allocated_capital"] += delta
            decisions[name] = f"+{delta:.2%} capital"

        # -----------------------------
        # DEMOTION
        # -----------------------------
        elif score <= ROTATION_RULES["DEMOTE_THRESHOLD"]:
            delta = min(
                ROTATION_RULES["MAX_DECREASE"],
                allocated - ROTATION_RULES["MIN_CAPITAL"]
            )
            state["allocated_capital"] -= max(0, delta)
            decisions[name] = f"-{delta:.2%} capital"

        else:
            decisions[name] = "sin cambios"

        state["allocated_capital"] = round(
            max(state["allocated_capital"], ROTATION_RULES["MIN_CAPITAL"]),
            4
        )

    return decisions
