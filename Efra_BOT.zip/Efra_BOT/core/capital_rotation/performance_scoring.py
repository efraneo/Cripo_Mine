# core/capital_rotation/performance_scoring.py

def score_strategy(stats: dict) -> float:
    """
    Score institucional por estrategia.
    """

    pnl = stats.get("pnl", 0)
    winrate = stats.get("winrate", 0)
    drawdown = abs(stats.get("drawdown", 0))
    trades = stats.get("trades", 1)

    score = (
        pnl * 0.4 +
        winrate * 0.3 -
        drawdown * 0.2 +
        min(trades / 50, 1) * 0.1
    )

    return round(score, 4)
