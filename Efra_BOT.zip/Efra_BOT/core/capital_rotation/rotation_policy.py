# core/capital_rotation/rotation_policy.py

ROTATION_RULES = {
    "PROMOTE_THRESHOLD": 0.65,
    "DEMOTE_THRESHOLD": 0.30,
    "MAX_INCREASE": 0.05,
    "MAX_DECREASE": 0.07,
    "MIN_CAPITAL": 0.02,
}
