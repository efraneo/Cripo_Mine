# core/microstructure/order_flow_toxicity.py

import numpy as np


# ============================================================
# PARAMETERS
# ============================================================

IMBALANCE_WARNING = 0.60
IMBALANCE_TOXIC = 0.75

SWEEP_THRESHOLD = 0.35
DEPTH_COLLAPSE = 0.40


# ============================================================
# ORDER BOOK DEPTH
# ============================================================

def _order_book_depth(order_book):

    bids = order_book.get("bids", [])
    asks = order_book.get("asks", [])

    bid_depth = sum(float(b[1]) for b in bids[:10])
    ask_depth = sum(float(a[1]) for a in asks[:10])

    return bid_depth, ask_depth


# ============================================================
# ORDER BOOK IMBALANCE
# ============================================================

def _order_book_imbalance(bid_depth, ask_depth):

    total = bid_depth + ask_depth

    if total <= 0:
        return 0.5

    return bid_depth / total


# ============================================================
# DEPTH COLLAPSE DETECTION
# ============================================================

def _depth_collapse(depth_series):

    if len(depth_series) < 10:
        return 0.0

    recent = depth_series[-1]
    avg = np.mean(depth_series[-10:])

    if avg <= 0:
        return 0.0

    return 1 - (recent / avg)


# ============================================================
# SWEEP DETECTION
# ============================================================

def _sweep_detection(trade_sizes):

    if len(trade_sizes) < 10:
        return 0.0

    large_trades = [t for t in trade_sizes if t > np.mean(trade_sizes) * 2]

    return len(large_trades) / len(trade_sizes)


# ============================================================
# MAIN ENGINE
# ============================================================

def detect_order_flow_toxicity(
    order_book,
    trade_sizes=None,
    depth_series=None
):

    if order_book is None:

        return {
            "mode": "UNKNOWN",
            "toxicity_score": 0.0,
            "risk_scale": 1.0,
            "allow_trade": True
        }

    bid_depth, ask_depth = _order_book_depth(order_book)

    imbalance = _order_book_imbalance(bid_depth, ask_depth)

    sweep_ratio = 0.0
    collapse = 0.0

    if trade_sizes:
        sweep_ratio = _sweep_detection(trade_sizes)

    if depth_series:
        collapse = _depth_collapse(depth_series)

    # ========================================================
    # TOXICITY SCORE
    # ========================================================

    toxicity_score = (
        abs(imbalance - 0.5) * 2
        + sweep_ratio
        + collapse
    ) / 3

    mode = "NORMAL"
    risk_scale = 1.0
    allow_trade = True

    # --------------------------------------------------------

    if toxicity_score > 0.75:

        mode = "TOXIC"
        risk_scale = 0.0
        allow_trade = False

    elif toxicity_score > 0.55:

        mode = "WARNING"
        risk_scale = 0.4

    return {

        "mode": mode,
        "toxicity_score": float(toxicity_score),
        "risk_scale": risk_scale,
        "allow_trade": allow_trade,

        "metrics": {
            "order_book_imbalance": float(imbalance),
            "sweep_ratio": float(sweep_ratio),
            "depth_collapse": float(collapse)
        }
    }