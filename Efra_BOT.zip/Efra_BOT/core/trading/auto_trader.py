# core/trading/auto_trader.py

import logging
import numpy as np
import asyncio
import time
from core.notifications.telegram_pro import send_telegram_trade_alert

logger = logging.getLogger(__name__)


class AutoTrader:

    def __init__(self, engine):
        self.engine = engine
        self.active_positions = {}

        # 🔒 protección global
        self.max_drawdown = -10  # %
        self.dynamic_drawdown_limit = -5
        self.global_pnl = 0

        # 🧠 control de re-entry
        self.last_exit_time = {}
        self.cooldown_sec = 60

    # ==================================================
    # MAIN LOOP
    # ==================================================
    async def run_cycle(self, symbol, ia):

        confidence = ia.get("confidence", 0)

        # ==============================================
        # FILTRO IA INSTITUCIONAL
        # ==============================================
        if confidence < 90:
            return self._response(False, "IA < 90")

        # ==============================================
        # FILTRO SOBREOPERACIÓN
        # ==============================================
        if not self._overtrading_guard(ia):
            return self._response(False, "Overtrading guard")

        # ==============================================
        # FILTRO DE RÉGIMEN
        # ==============================================
        if not self._market_regime_filter(ia):
            return self._response(False, "Bad market regime")

        # ==============================================
        # COOLDOWN (ANTI REVENGE TRADE)
        # ==============================================
        last_exit = self.last_exit_time.get(symbol, 0)
        if time.time() - last_exit < self.cooldown_sec:
            return self._response(False, "Cooldown active")

        # ==============================================
        # PROTECCIÓN GLOBAL
        # ==============================================
        limit = self.dynamic_drawdown_limit if len(self.active_positions) > 3 else self.max_drawdown
        if self.global_pnl <= limit:
            return self._response(False, "Dynamic drawdown protection")

        # ==============================================
        # 🧠 hedge fund validation (extra capa)
        # ==============================================
        if hasattr(self.engine, "hedge_controller"):
            ok, reason = self.engine.hedge_controller.check_directional_balance(
                self.active_positions,
                ia.get("direction")
            )
            if not ok:
                return self._response(False, reason)

        # ==============================================
        # ENTRY
        # ==============================================
        if symbol not in self.active_positions:

            pos = await self._open_position(symbol, ia)

            if pos:
                self.active_positions[symbol] = pos
                return self._response(True, "ENTRY", confidence)

            return self._response(False, "Entry failed")

        # ==============================================
        # MANAGEMENT
        # ==============================================
        return await self._manage_position(symbol, ia)

    # ==================================================
    # OPEN POSITION
    # ==================================================
    async def _open_position(self, symbol, ia):

        try:
            result = await self.engine.execute_trade(
                symbol=symbol,
                usd_amount=ia.get("capital", 10),
                ia_decision=ia
            )

            if not result.get("success"):
                return None

            entry_price = result.get("price") or result.get("entry") or result.get("avg_price") or 0

            # 📡 TELEGRAM ENTRY
            try:
                send_telegram_trade_alert(
                    symbol=symbol,
                    side=ia.get("direction"),
                    confidence=ia.get("confidence"),
                    entry=entry_price,
                    sl=ia.get("sl"),
                    tp=ia.get("tps"),
                    fig=None
                )
            except Exception:
                logger.exception("Telegram ENTRY failed")

            return {
                "symbol": symbol,
                "direction": ia.get("direction"),
                "entry_price": entry_price,
                "current_price": entry_price,
                "peak": 0,
                "trailing_sl": entry_price * 0.98,
                "pnl": 0
            }

        except Exception:
            logger.exception("Open position failed")
            return None

    # ==================================================
    # MANAGE POSITION
    # ==================================================
    async def _manage_position(self, symbol, ia):

        pos = self.active_positions.get(symbol)
        if not pos:
            return self._response(False, "No position")

        # ==============================================
        # PRECIO + PNL
        # ==============================================
        current_price = self._get_price(symbol)
        pos["current_price"] = current_price

        pnl = self._calculate_pnl(pos)
        pos["pnl"] = pnl

        # ==============================================
        # PROTECCIÓN ESTADO
        # ==============================================
        pos.setdefault("peak", 0)
        pos.setdefault("trailing_sl", pos["entry_price"] * 0.98)

        # ==============================================
        # TRACK PEAK
        # ==============================================
        if pnl > pos["peak"]:
            pos["peak"] = pnl

        # ==============================================
        # 🧠 PARTIAL TAKE PROFIT
        # ==============================================
        if pnl >= 2 and not pos.get("tp1_hit"):
            pos["tp1_hit"] = True

            try:
                self.engine.order_manager.reduce_position(
                    symbol=symbol,
                    reduce_pct=0.3,
                    reason="TP1"
                )
            except Exception:
                logger.exception("TP1 failed")

            return self._response(True, "TP1", pnl=pnl)

        if pnl >= 4 and not pos.get("tp2_hit"):
            pos["tp2_hit"] = True

            try:
                self.engine.order_manager.reduce_position(
                    symbol=symbol,
                    reduce_pct=0.3,
                    reason="TP2"
                )
            except Exception:
                logger.exception("TP2 failed")

            return self._response(True, "TP2", pnl=pnl)

        # ==============================================
        # 📈 PYRAMIDING
        # ==============================================
        if pnl >= 1.5 and not pos.get("pyramid_1"):

            pos["pyramid_1"] = True

            try:
                asyncio.create_task(
                    self.engine.execute_trade(
                        symbol=symbol,
                        usd_amount=5,
                        ia_decision=ia
                    )
                )
            except Exception:
                logger.exception("Pyramiding failed")

        # ==============================================
        # 🧠 TRAILING ADAPTATIVO
        # ==============================================
        volatility_factor = max(0.5, min(2.0, ia.get("confidence", 50) / 100))
        dynamic_trailing = 1.0 * volatility_factor

        if pos["peak"] > 1.0:
            pos["trailing_sl"] = max(
                pos["trailing_sl"],
                current_price * (1 - dynamic_trailing / 100)
            )

        # ==============================================
        # STOP LOSS
        # ==============================================
        if pnl <= -2:
            self._close_position(symbol)
            return self._response(True, "STOP LOSS")

        # ==============================================
        # TRAILING HIT
        # ==============================================
        if current_price <= pos["trailing_sl"]:
            self._close_position(symbol)
            return self._response(True, "TRAILING")

        # ==============================================
        # REVERSAL
        # ==============================================
        if ia.get("direction") != pos["direction"] and ia.get("confidence", 0) > 92:
            self._close_position(symbol)
            return await self.run_cycle(symbol, ia)

        # ==============================================
        # TAKE PROFIT FINAL
        # ==============================================
        if pnl >= self._dynamic_tp(ia):
            self._close_position(symbol)
            return self._response(True, "TP FINAL")

        return self._response(False, "HOLD", pnl=pnl)

    # ==================================================
    # CLOSE
    # ==================================================
    def _close_position(self, symbol):

        pos = self.active_positions.get(symbol)
        if not pos:
            return

        self.global_pnl += pos.get("pnl", 0)
        self.last_exit_time[symbol] = time.time()

        # 📡 TELEGRAM CLOSE
        try:
            send_telegram_trade_alert(
                symbol=symbol,
                side="CLOSE",
                confidence=pos.get("pnl", 0),
                entry=pos.get("entry_price"),
                sl="--",
                tp="--",
                fig=None
            )
        except Exception:
            logger.exception("Telegram CLOSE failed")

        del self.active_positions[symbol]
        logger.info(f"Closed position {symbol}")

    # ==================================================
    # FILTROS
    # ==================================================
    def _market_regime_filter(self, ia):

        regime = ia.get("regime", "neutral")

        if regime in ["range", "choppy", "low_volatility"]:
            return False

        return True

    def _overtrading_guard(self, ia):

        return ia.get("confidence", 0) >= 92

    # ==================================================
    # HELPERS
    # ==================================================
    def _calculate_pnl(self, pos):

        entry = pos["entry_price"]
        current = pos["current_price"]

        if pos["direction"] in ["BUY", "LONG"]:
            return (current - entry) / entry * 100
        else:
            return (entry - current) / entry * 100

    def _get_price(self, symbol):

        try:
            return self.engine.binance.get_price(symbol)
        except Exception:
            return 0

    def _dynamic_tp(self, ia):

        c = ia.get("confidence", 50)

        if c > 85:
            return 5
        elif c > 75:
            return 3
        return 2

    def _response(self, executed, reason, confidence=None, pnl=None):
        return {
            "executed": executed,
            "type": reason,
            "confidence": confidence,
            "pnl": pnl
        }

