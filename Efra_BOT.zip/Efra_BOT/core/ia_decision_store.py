from typing import List, Optional, Dict
from datetime import datetime
import json
import os

IA_AUDIT_PATH = "data/ia_audit_log.jsonl"


class IADecisionStore:
    """
    Store de solo lectura para replay / UI.
    NO recalcula IA.
    """

    def __init__(self, path: str = IA_AUDIT_PATH):
        self.path = path

    def _load_all(self) -> List[Dict]:
        if not os.path.exists(self.path):
            return []

        out = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
        return out

    def get_latest(self, symbol: Optional[str] = None) -> Optional[Dict]:
        data = self._load_all()
        for item in reversed(data):
            if not symbol or item.get("symbol") == symbol:
                return item
        return None

    def get_by_symbol(self, symbol: str, limit: int = 50) -> List[Dict]:
        data = self._load_all()
        filtered = [d for d in data if d.get("symbol") == symbol]
        return filtered[-limit:]

    def get_by_context(self, context: str, limit: int = 50) -> List[Dict]:
        data = self._load_all()
        filtered = [d for d in data if d.get("context") == context]
        return filtered[-limit:]
