def resolve_execution_policy(
    entry_timing: dict,
    confidence: float = 0
) -> dict:

    """
    Traduce entry_timing en reglas operativas reales
    """

    state = entry_timing.get(
        "state",
        "NO_TRADE"
    )

    policy = {

        "allow_trade": False,
        "ui_lock": True,
        "show_countdown": False,
        "message": "Operación bloqueada"
    }

    # ==================================================
    # ENTRADA DIRECTA
    # ==================================================

    if state == "ENTER_NOW":

        policy.update({

            "allow_trade": True,
            "ui_lock": False,
            "show_countdown": False,
            "message": "Entrada habilitada"
        })

    # ==================================================
    # CONFIRMACIÓN SUAVE
    # ==================================================

    elif state == "WAIT_CONFIRMATION":

        if confidence >= 68:

            policy.update({

                "allow_trade": True,
                "ui_lock": False,
                "show_countdown": True,
                "message":
                "Entrada permitida por confianza elevada"
            })

        else:

            policy.update({

                "allow_trade": False,
                "ui_lock": True,
                "show_countdown": True,
                "message":
                "Esperando confirmación institucional"
            })

    # ==================================================
    # ESPERAR CIERRE VELA
    # ==================================================

    elif state == "WAIT_NEXT_CLOSE":

        policy.update({

            "allow_trade": False,
            "ui_lock": True,
            "show_countdown": True,
            "message":
            "Esperando cierre de vela"
        })

    # ==================================================
    # BLOQUEO TOTAL
    # ==================================================

    elif state == "NO_TRADE":

        policy.update({

            "allow_trade": False,
            "ui_lock": True,
            "show_countdown": False,
            "message":
            "Condiciones no operables"
        })

    return policy
