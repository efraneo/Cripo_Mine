# core/market_microstructure/order_book_imbalance_engine.py

import numpy as np

# ============================================================
# ORDER BOOK IMBALANCE ENGINE
# ============================================================

def compute_order_book_imbalance(order_book, depth_levels=10):
    """
    Calcula el imbalance del libro de órdenes.

    order_book ejemplo:

    {
        "bids": [[price, volume], ...],
        "asks": [[price, volume], ...]
    }
    """

    if order_book is None:
        return _default()

    bids = order_book.get("bids", [])
    asks = order_book.get("asks", [])

    if len(bids) == 0 or len(asks) == 0:
        return _default()

    # limitar profundidad
    bids = bids[:depth_levels]
    asks = asks[:depth_levels]

    bid_volume = sum(float(b[1]) for b in bids)
    ask_volume = sum(float(a[1]) for a in asks)

    total_volume = bid_volume + ask_volume

    if total_volume == 0:
        return _default()

    imbalance = (bid_volume - ask_volume) / total_volume

    # ------------------------------------------------
    # CLASSIFICATION
    # ------------------------------------------------

    signal = "NEUTRAL"
    alpha_score = 0.0
    confidence_scale = 1.0

    if imbalance > 0.25:
        signal = "STRONG_BUY_PRESSURE"
        alpha_score = imbalance
        confidence_scale = 1.15

    elif imbalance > 0.10:
        signal = "BUY_PRESSURE"
        alpha_score = imbalance
        confidence_scale = 1.08

    elif imbalance < -0.25:
        signal = "STRONG_SELL_PRESSURE"
        alpha_score = imbalance
        confidence_scale = 0.85

    elif imbalance < -0.10:
        signal = "SELL_PRESSURE"
        alpha_score = imbalance
        confidence_scale = 0.92

    return {
        "imbalance": float(imbalance),
        "bid_volume": float(bid_volume),
        "ask_volume": float(ask_volume),
        "signal": signal,
        "alpha_score": float(alpha_score),
        "confidence_scale": confidence_scale
    }

# ============================================================
# DEFAULT RESPONSE
# ============================================================

def _default():
    return {
        "imbalance": 0.0,
        "bid_volume": 0.0,
        "ask_volume": 0.0,
        "signal": "UNKNOWN",
        "alpha_score": 0.0,
        "confidence_scale": 1.0
    }
