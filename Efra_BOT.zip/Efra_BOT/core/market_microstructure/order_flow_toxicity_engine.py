# core/market_microstructure/order_flow_toxicity_engine.py

import numpy as np
import pandas as pd


# ============================================================
# ORDER FLOW TOXICITY ENGINE
# ============================================================

def detect_order_flow_toxicity(df: pd.DataFrame):

    if df is None or len(df) < 60:

        return {
            "toxicity_score": 0.0,
            "mode": "UNKNOWN",
            "risk_scale": 1.0
        }

    returns = df["close"].pct_change()
    volume = df["volume"]

    # ----------------------------------------
    # VPIN approximation (Volume-synchronized)
    # ----------------------------------------

    vol_mean = volume.rolling(30).mean()
    imbalance = abs(volume - vol_mean) / vol_mean
    vpin = imbalance.rolling(20).mean().iloc[-1]

    # ----------------------------------------
    # Volatility clustering
    # ----------------------------------------

    vol = returns.rolling(10).std()
    vol_long = returns.rolling(50).std()

    vol_ratio = vol.iloc[-1] / vol_long.iloc[-1] if vol_long.iloc[-1] > 0 else 1

    # ----------------------------------------
    # Toxicity classification
    # ----------------------------------------

    toxicity_score = max(vpin, vol_ratio)

    mode = "NORMAL"
    risk_scale = 1.0

    if toxicity_score > 3:

        mode = "EXTREME_TOXICITY"
        risk_scale = 0.0

    elif toxicity_score > 2:

        mode = "HIGH_TOXICITY"
        risk_scale = 0.4

    elif toxicity_score > 1.3:

        mode = "ELEVATED_TOXICITY"
        risk_scale = 0.7

    return {
        "toxicity_score": float(toxicity_score),
        "mode": mode,
        "risk_scale": risk_scale,
        "metrics": {
            "vpin": float(vpin),
            "volatility_ratio": float(vol_ratio)
        }
    }
