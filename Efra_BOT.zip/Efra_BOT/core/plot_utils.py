# core/plot_utils.py
"""
Generación de gráficos candlestick a imagen PNG con máxima estabilidad.
Manejo robusto de exceptions, integración plotly/kaleido,
y fallback seguro para UI.
"""

import logging
import os
import time
import pandas as pd

# Inicializar logger seguro
try:
    from backend.log_manager import get_logger
    app_log = get_logger("plot")
except Exception:
    app_log = logging.getLogger("plot")
    if not app_log.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        app_log.addHandler(h)
    app_log.setLevel(logging.INFO)


# ============================================================
# FUNCIÓN PRINCIPAL
# ============================================================
def try_generate_plot_image(df, preview=None, symbol="UNKNOWN", width=900, height=520):
    """
    Genera un gráfico PNG utilizando plotly + kaleido.
    Devuelve la ruta temporal del PNG o None si algo falla.
    """

    # Asegurar plotly
    try:
        import plotly.graph_objects as go
    except Exception as e:
        app_log.error("plotly no disponible: %s", e)
        return None

    # Convertir a DataFrame si es lista
    try:
        if isinstance(df, list):
            df = pd.DataFrame(df)
    except Exception as e:
        app_log.exception("Error normalizando DF: %s", e)
        return None

    # Convertir time
    try:
        if "time" in df.columns:
            df["time"] = pd.to_datetime(df["time"], errors="coerce")
    except Exception:
        pass

    # Crear figura
    try:
        fig = go.Figure(data=[
            go.Candlestick(
                x=df["time"],
                open=df["open"],
                high=df["high"],
                low=df["low"],
                close=df["close"],
                name=symbol
            )
        ])
    except Exception as e:
        app_log.exception("Error creando candlestick: %s", e)
        return None

    # Integrar predicción IA si existe
    try:
        if preview and isinstance(preview, dict) and "prediction_date" in preview:
            pred_dt = preview.get("prediction_date")
            pred_time = preview.get("prediction_time")
            confidence = preview.get("ia_confidence_pct", 0.0)

            try:
                if pred_time:
                    pred_ts = pd.to_datetime(f"{pred_dt} {pred_time}")
                else:
                    pred_ts = pd.to_datetime(pred_dt)

                fig.add_trace(go.Scatter(
                    x=[pred_ts],
                    y=[df["close"].iloc[-1]],
                    mode="markers+text",
                    text=[f"IA {confidence:.1f}%"],
                    textposition="top center",
                    marker=dict(size=12)
                ))
            except Exception:
                pass
    except Exception:
        pass

    # Layout
    fig.update_layout(
        width=width,
        height=height,
        template="plotly_dark",
        margin=dict(l=10, r=10, t=30, b=10)
    )
    fig.update_xaxes(tickformat="%Y-%m-%d %H:%M", nticks=10)

    # Guardar imagen temporal
    filename = f"plot_{symbol}_{int(time.time())}.png"
    tmp_path = os.path.join("data", filename)

    try:
        fig.write_image(tmp_path, engine="kaleido")
        return tmp_path

    except Exception as e:
        app_log.warning("Kaleido falló, intentando fallback: %s", e)

        try:
            fig.write_image(tmp_path)
            return tmp_path
        except Exception as e2:
            app_log.exception("Error guardando imagen plotly: %s", e2)
            return None


# ============================================================
# FUNCIÓN SEGURA (API estándar)
# ============================================================
def try_generate_plot_image_safe(*args, **kwargs):
    """
    Wrapper completamente seguro.
    Nunca deja caer la app.
    Solo devuelve ruta o None.
    """
    try:
        return try_generate_plot_image(*args, **kwargs)
    except Exception as e:
        app_log.exception("try_generate_plot_image_safe: %s", e)
        return None
