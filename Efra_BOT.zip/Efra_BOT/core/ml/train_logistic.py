# core/ml/train_logistic.py
"""
Entrenamiento ML Base — Logistic Regression
"""

import pandas as pd
import joblib
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

# ==================================================
# PATHS
# ==================================================
DATASET = Path("data/ml/dataset_ml.csv")
MODEL_DIR = Path("core/ml/models")
MODEL_DIR.mkdir(parents=True, exist_ok=True)

MODEL_PATH = MODEL_DIR / "logistic_model.pkl"
SCALER_PATH = MODEL_DIR / "scaler.pkl"

# ==================================================
def main():
    print("📊 Cargando dataset...")
    df = pd.read_csv(DATASET)

    # --- Selección de features numéricos ---
    drop_cols = ["timestamp", "symbol", "timeframe", "label"]
    X = df.drop(columns=drop_cols, errors="ignore")
    y = df["label"]

    X = X.select_dtypes(include=["number"])

    # --- Split ---
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    # --- Escalado ---
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # --- Modelo ---
    model = LogisticRegression(
        multi_class="multinomial",
        max_iter=1000,
        n_jobs=-1
    )

    print("🤖 Entrenando Logistic Regression...")
    model.fit(X_train, y_train)

    # --- Evaluación ---
    preds = model.predict(X_test)
    print("\n📈 MÉTRICAS:")
    print(classification_report(y_test, preds))

    # --- Guardar ---
    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)

    print(f"✅ Modelo guardado en {MODEL_PATH}")

# ==================================================
if __name__ == "__main__":
    main()
