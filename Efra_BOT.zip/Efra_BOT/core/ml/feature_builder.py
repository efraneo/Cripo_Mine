# core/ml/feature_builder.py
"""
Feature Builder — IA PRO ML
Convierte data_by_tf en un vector ML estable
"""

import numpy as np


def build_features(data_by_tf):
    """
    Devuelve una lista de floats (features)
    ORDEN FIJO = modelo estable
    """

    feats = []

    def safe_last(df, col):
        try:
            return float(df[col].iloc[-1])
        except Exception:
            return 0.0

    # ===============================
    # TIMEFRAMES USADOS
    # ===============================
    for tf in ["5m", "15m", "1h", "4h"]:
        df = data_by_tf.get(tf)
        if df is None:
            feats.extend([0.0] * 6)
            continue

        feats.extend([
            safe_last(df, "rsi"),
            safe_last(df, "macd_hist"),
            safe_last(df, "atr"),
            safe_last(df, "ema50") - safe_last(df, "ema200"),
            safe_last(df, "close") - safe_last(df, "open"),
            safe_last(df, "high") - safe_last(df, "low"),
        ])

    return np.array(feats, dtype=float)
