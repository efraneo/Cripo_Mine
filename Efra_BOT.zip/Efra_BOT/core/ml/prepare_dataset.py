# core/ml/prepare_dataset.py
"""
Preparación del dataset ML unificado
- Carga históricos
- Aplica etiquetas LONG / SHORT / NO-TRADE
- Exporta dataset final
"""

import pandas as pd
from pathlib import Path

from core.ml.label_builder import build_labels

# ==================================================
# PATHS
# ==================================================
HIST_DIR = Path("data/historical")
OUT_DIR = Path("data/ml")
OUT_DIR.mkdir(parents=True, exist_ok=True)

OUT_FILE = OUT_DIR / "dataset_ml.csv"

# ==================================================
# MAIN
# ==================================================
def main():
    all_frames = []

    files = list(HIST_DIR.glob("*.csv"))
    if not files:
        raise RuntimeError("❌ No se encontraron CSV en data/historical/")

    print(f"📂 Encontrados {len(files)} archivos históricos")

    for f in files:
        print(f"📊 Procesando {f.name}")
        df = pd.read_csv(f)

        required = {"timestamp", "open", "high", "low", "close", "volume"}
        if not required.issubset(df.columns):
            print(f"⚠️ Saltando {f.name} (columnas incompletas)")
            continue

        df = build_labels(df)

        # Metadata
        symbol, tf = f.stem.split("_")
        df["symbol"] = symbol
        df["timeframe"] = tf

        all_frames.append(df)

    if not all_frames:
        raise RuntimeError("❌ No se pudo construir ningún dataframe")

    dataset = pd.concat(all_frames, ignore_index=True)

    # Limpieza final
    dataset.dropna(inplace=True)
    dataset.reset_index(drop=True, inplace=True)

    dataset.to_csv(OUT_FILE, index=False)

    print(f"✅ Dataset ML generado: {OUT_FILE}")
    print("📈 Distribución de etiquetas:")
    print(dataset["label"].value_counts())

# ==================================================
if __name__ == "__main__":
    main()
