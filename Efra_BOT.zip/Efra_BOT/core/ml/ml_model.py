# core/ml/ml_model.py
import pickle
from sklearn.linear_model import LogisticRegression

class IAProMLModel:

    def __init__(self):
        self.model = LogisticRegression(
            class_weight="balanced",
            max_iter=500
        )

    def train(self, X, y):
        self.model.fit(X, y)

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        with open(path, "wb") as f:
            pickle.dump(self.model, f)

    @staticmethod
    def load(path):
        with open(path, "rb") as f:
            m = IAProMLModel()
            m.model = pickle.load(f)
            return m
