# core/ml/train_xgboost.py
"""
Entrenamiento XGBoost PRO (multiclase corregido)
"""

import pandas as pd
import joblib
from pathlib import Path

from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

DATASET = Path("data/ml/dataset_ml.csv")
MODEL_DIR = Path("core/ml/models")
MODEL_DIR.mkdir(parents=True, exist_ok=True)

MODEL_PATH = MODEL_DIR / "xgb_model.pkl"

# ===============================================
# Mapeo etiquetas trading -> ML
# ===============================================
LABEL_MAP = {-1: 0, 0: 1, 1: 2}
INV_LABEL_MAP = {0: -1, 1: 0, 2: 1}

def main():
    print("📊 Cargando dataset...")
    df = pd.read_csv(DATASET)

    X = df.drop(columns=["timestamp", "symbol", "timeframe", "label"], errors="ignore")
    X = X.select_dtypes(include=["number"])

    y = df["label"].map(LABEL_MAP)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.25,
        random_state=42,
        stratify=y
    )

    model = XGBClassifier(
        n_estimators=300,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="multi:softprob",
        num_class=3,
        eval_metric="mlogloss",
        tree_method="hist"
    )

    print("🔥 Entrenando XGBoost...")
    model.fit(X_train, y_train)

    preds = model.predict(X_test)

    # Reporte con etiquetas originales
    y_test_orig = y_test.map(INV_LABEL_MAP)
    preds_orig = pd.Series(preds).map(INV_LABEL_MAP)

    print("\n📈 MÉTRICAS XGBOOST:")
    print(classification_report(y_test_orig, preds_orig))

    joblib.dump(model, MODEL_PATH)
    print(f"✅ Modelo guardado en {MODEL_PATH}")

if __name__ == "__main__":
    main()
