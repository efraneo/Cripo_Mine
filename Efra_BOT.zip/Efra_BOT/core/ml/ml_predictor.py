# core/ml/ml_predictor.py
import os
import numpy as np
from core.ml.feature_store import build_features
from core.ml.ml_model import IAProMLModel

MODEL_PATH = "core/ml/models/ia_pro_v1.pkl"

class IAProMLPredictor:

    def __init__(self):
        self.model = None
        if os.path.exists(MODEL_PATH):
            self.model = IAProMLModel.load(MODEL_PATH)

    def predict(self, data_by_tf, ia_result):
        if not self.model:
            return None  # fallback silencioso

        x = build_features(data_by_tf, ia_result)
        prob = self.model.predict_proba(x.reshape(1, -1))[0]
        return float(prob)
