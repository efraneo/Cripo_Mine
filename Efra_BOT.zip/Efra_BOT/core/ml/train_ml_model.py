# core/ml/train_ml_model.py
"""
Entrenamiento ML OFFLINE — IA PRO (Nivel 14.2)
Ejecutar MANUALMENTE:
> python core/ml/train_ml_model.py
"""

import pickle
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

from core.ml.feature_builder import build_features


# ======================================================
# SIMULADOR DE ETIQUETAS (GANAR / PERDER)
# ======================================================
def label_trade(
    df,
    rr=2.0,          # Risk / Reward
    atr_mult=1.2,    # SL basado en ATR
    max_bars=20      # horizonte máximo
):
    """
    Etiquetado profesional:
    1 = TP alcanzado
    0 = SL alcanzado
    None = indefinido / ruido
    """

    try:
        entry = df["close"].iloc[-1]
        atr = df["atr"].iloc[-1]

        if atr <= 0:
            return None

        stop_loss = entry - atr * atr_mult
        take_profit = entry + atr * atr_mult * rr

        future = df.iloc[-max_bars:]

        for _, row in future.iterrows():
            if row["low"] <= stop_loss:
                return 0
            if row["high"] >= take_profit:
                return 1

        return None  # no alcanzó TP ni SL

    except Exception:
        return None


# ======================================================
# DATASET BUILDER
# ======================================================
def build_dataset(historical_batches):
    """
    historical_batches = lista de (data_by_tf)
    """
    X, y = [], []

    for data_by_tf in historical_batches:
        features = build_features(data_by_tf)
        label = label_trade(data_by_tf["5m"])

        if label is None:
            continue

        X.append(features)
        y.append(label)

    return np.array(X), np.array(y)


# ======================================================
# MAIN
# ======================================================
def main():
    print("📊 Construyendo dataset...")

    # ⚠️ AQUÍ conectas TU fuente real de históricos
    # Debe devolver lista de data_by_tf (como ya usas en vivo)
    from core.data_loader import load_historical_batches  # EJEMPLO

    historical_batches = load_historical_batches(limit=5000)

    X, y = build_dataset(historical_batches)

    print(f"Samples: {len(X)}")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=True, random_state=42
    )

    model = LogisticRegression(
        max_iter=2000,
        class_weight="balanced",
        n_jobs=-1
    )

    model.fit(X_train, y_train)

    preds = model.predict(X_test)

    print("\n📈 RESULTADOS ML\n")
    print(classification_report(y_test, preds))

    with open("core/ml/ml_model.pkl", "wb") as f:
        pickle.dump(model, f)

    print("\n✅ Modelo guardado en core/ml/ml_model.pkl")


if __name__ == "__main__":
    main()
