# core/ml/explain_shap.py
"""
SHAP analysis para XGBoost
"""

import shap
import pandas as pd
import joblib
from pathlib import Path

DATASET = Path("data/ml/dataset_ml.csv")
MODEL_PATH = Path("core/ml/models/xgb_model.pkl")

def main():
    df = pd.read_csv(DATASET)

    X = df.drop(columns=["timestamp", "symbol", "timeframe", "label"], errors="ignore")
    X = X.select_dtypes(include=["number"])

    model = joblib.load(MODEL_PATH)

    explainer = shap.Explainer(model)
    shap_values = explainer(X.sample(500))

    shap.summary_plot(shap_values, X, show=True)

if __name__ == "__main__":
    main()
