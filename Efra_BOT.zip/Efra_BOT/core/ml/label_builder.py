# core/ml/label_builder.py
"""
Construcción de etiquetas ML bidireccionales
LONG / SHORT / NO-TRADE
"""

import pandas as pd
import numpy as np

# ==================================================
# CONFIG
# ==================================================
LOOKAHEAD = 8        # velas futuras (8 x 15m = 2h)
TP_ATR = 1.2         # target mínimo en ATR
SL_ATR = 0.8         # stop lógico (informativo)

# ==================================================
# ATR simple
# ==================================================
def compute_atr(df, period=14):
    high = df["high"]
    low = df["low"]
    close = df["close"].shift(1)

    tr = np.maximum(
        high - low,
        np.maximum(abs(high - close), abs(low - close))
    )

    return tr.rolling(period).mean()

# ==================================================
# Construir etiquetas
# ==================================================
def build_labels(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # ATR
    if "atr" not in df.columns:
        df["atr"] = compute_atr(df)

    df["future_max"] = (
        df["high"]
        .shift(-1)
        .rolling(LOOKAHEAD)
        .max()
    )

    df["future_min"] = (
        df["low"]
        .shift(-1)
        .rolling(LOOKAHEAD)
        .min()
    )

    labels = []

    for i in range(len(df)):
        atr = df["atr"].iloc[i]
        close = df["close"].iloc[i]

        if np.isnan(atr):
            labels.append(0)
            continue

        up_move = (df["future_max"].iloc[i] - close)
        down_move = (close - df["future_min"].iloc[i])

        if up_move >= atr * TP_ATR:
            labels.append(1)      # LONG
        elif down_move >= atr * TP_ATR:
            labels.append(-1)     # SHORT
        else:
            labels.append(0)      # NO TRADE

    df["label"] = labels

    # Limpieza
    df.drop(columns=["future_max", "future_min"], inplace=True)

    return df
