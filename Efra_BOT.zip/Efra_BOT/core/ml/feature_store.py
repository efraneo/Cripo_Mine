# core/ml/feature_store.py
import numpy as np

def build_features(data_by_tf, ia_score_result):
    """
    Convierte el estado del mercado en features ML.
    Nunca lanza excepción.
    """

    def safe(v):
        try:
            return float(v)
        except Exception:
            return 0.0

    features = {
        # --- IA PRO ---
        "ia_score": safe(ia_score_result["score"]),
        "ia_prob": safe(ia_score_result["probability"]),
        "direction_long": 1 if ia_score_result["direction"] == "LONG" else 0,

        # --- Momentum ---
        "rsi_15m": safe(data_by_tf["15m"].get("rsi", [0])[-1]),
        "macd_15m": safe(data_by_tf["15m"].get("macd_hist", [0])[-1]),

        # --- Volatilidad ---
        "atr_15m": safe(data_by_tf["15m"].get("atr", [0])[-1]),
        "atr_1h": safe(data_by_tf["1h"].get("atr", [0])[-1]),

        # --- Tendencia ---
        "ema_trend_1h": safe(
            data_by_tf["1h"]["ema50"].iloc[-1]
            - data_by_tf["1h"]["ema200"].iloc[-1]
        ),
    }

    return np.array(list(features.values()), dtype=np.float32)
