# core/market/session_detector.py

from datetime import datetime, timezone


def detect_market_session():

    now = datetime.now(
        timezone.utc
    )

    hour = now.hour

    # ==============================
    # ASIA
    # ==============================

    if 0 <= hour < 8:

        return {
            "active": "ASIA",
            "bias": "RANGE"
        }

    # ==============================
    # LONDON
    # ==============================

    elif 8 <= hour < 13:

        return {
            "active": "LONDON",
            "bias": "TREND"
        }

    # ==============================
    # NEW YORK
    # ==============================

    elif 13 <= hour < 21:

        return {
            "active": "NEW_YORK",
            "bias": "VOLATILITY"
        }

    # ==============================
    # OVERLAP
    # ==============================

    elif 13 <= hour < 16:

        return {
            "active": "LONDON_NY_OVERLAP",
            "bias": "HIGH_VOLATILITY"
        }

    return {
        "active": "UNKNOWN",
        "bias": "NEUTRAL"
    }
