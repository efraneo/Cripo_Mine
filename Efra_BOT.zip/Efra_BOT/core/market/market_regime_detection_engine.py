# core/market/market_regime_detection_engine.py

# ============================================================
# MARKET REGIME DETECTION ENGINE — INSTITUTIONAL VERSION
# ============================================================

import numpy as np
import pandas as pd
from typing import Dict


# ============================================================
# HURST EXPONENT
# ============================================================

def _hurst_exponent(ts):

    lags = range(2, 20)
    tau = [
        np.sqrt(np.std(np.subtract(ts[lag:], ts[:-lag])))
        for lag in lags
    ]

    poly = np.polyfit(np.log(lags), np.log(tau), 1)

    return poly[0] * 2.0


# ============================================================
# TREND STRENGTH
# ============================================================

def _trend_strength(close):

    x = np.arange(len(close))
    y = close.values

    slope = np.polyfit(x, y, 1)[0]

    return slope / close.mean()


# ============================================================
# VOLATILITY
# ============================================================

def _volatility(returns):

    return returns.std()


# ============================================================
# KURTOSIS SHOCK DETECTION
# ============================================================

def _kurtosis_shock(returns):

    return pd.Series(returns).kurtosis()


# ============================================================
# REGIME CLASSIFIER
# ============================================================

def classify_market_regime(df: pd.DataFrame) -> Dict:

    close = df["close"]

    returns = close.pct_change().dropna()

    if len(returns) < 50:

        return {
            "regime": "UNKNOWN",
            "confidence": 0.0
        }

    hurst = _hurst_exponent(close.values)

    trend = _trend_strength(close)

    vol = _volatility(returns)

    kurt = _kurtosis_shock(returns)

    vol_mean = returns.rolling(50).std().mean()

    regime = "SIDEWAYS"
    confidence = 0.5

    # ------------------------------------------------
    # CRISIS
    # ------------------------------------------------

    if kurt > 6 and vol > vol_mean * 2:

        regime = "CRISIS"
        confidence = 0.9

    # ------------------------------------------------
    # VOLATILITY SPIKE
    # ------------------------------------------------

    elif vol > vol_mean * 1.8:

        regime = "VOLATILITY_SPIKE"
        confidence = 0.8

    # ------------------------------------------------
    # TRENDING
    # ------------------------------------------------

    elif hurst > 0.6 and abs(trend) > 0.0005:

        if trend > 0:

            regime = "BULL"

        else:

            regime = "BEAR"

        confidence = 0.75

    # ------------------------------------------------
    # RANGE
    # ------------------------------------------------

    elif hurst < 0.45:

        regime = "SIDEWAYS"
        confidence = 0.7

    return {
        "regime": regime,
        "confidence": confidence,
        "metrics": {
            "hurst": float(hurst),
            "trend_strength": float(trend),
            "volatility": float(vol),
            "kurtosis": float(kurt)
        }
    }

def detect_regime(df):
    result = classify_market_regime(df)
    return result.get("regime", "UNKNOWN")
