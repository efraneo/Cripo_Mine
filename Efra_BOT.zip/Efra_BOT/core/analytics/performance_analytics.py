# core/analytics/performance_analytics.py

import numpy as np
import logging
import random

logger = logging.getLogger(__name__)


class PerformanceAnalytics:
    """
    Motor institucional de análisis de performance.
    """

    def __init__(self):

        self.trades = []

    # =====================================================
    # REGISTER TRADE
    # =====================================================

    def register_trade(self, pnl):

        """
        pnl: profit/loss del trade (% o R)
        """

        self.trades.append(pnl)

    # =====================================================
    # WIN RATE
    # =====================================================

    def winrate(self):

        if not self.trades:
            return 0

        wins = [t for t in self.trades if t > 0]

        return len(wins) / len(self.trades)

    # =====================================================
    # EXPECTANCY
    # =====================================================

    def expectancy(self):

        if not self.trades:
            return 0

        wins = [t for t in self.trades if t > 0]
        losses = [t for t in self.trades if t <= 0]

        winrate = len(wins) / len(self.trades)

        avg_win = np.mean(wins) if wins else 0
        avg_loss = abs(np.mean(losses)) if losses else 0

        expectancy = (winrate * avg_win) - ((1 - winrate) * avg_loss)

        return expectancy

    # =====================================================
    # EQUITY CURVE
    # =====================================================

    def equity_curve(self, initial=10000):

        equity = [initial]

        for trade in self.trades:

            new_equity = equity[-1] * (1 + trade / 100)

            equity.append(new_equity)

        return equity

    # =====================================================
    # DRAWDOWN
    # =====================================================

    def max_drawdown(self):

        equity = self.equity_curve()

        peak = equity[0]
        max_dd = 0

        for e in equity:

            if e > peak:
                peak = e

            dd = (peak - e) / peak

            if dd > max_dd:
                max_dd = dd

        return max_dd * 100

    # =====================================================
    # SHARPE RATIO
    # =====================================================

    def sharpe_ratio(self, risk_free=0):

        if len(self.trades) < 2:
            return 0

        returns = np.array(self.trades)

        excess = returns - risk_free

        std = np.std(excess)

        if std == 0:
            return 0

        sharpe = np.mean(excess) / std

        return sharpe * np.sqrt(252)

    # =====================================================
    # SORTINO RATIO
    # =====================================================

    def sortino_ratio(self, risk_free=0):

        if len(self.trades) < 2:
            return 0

        returns = np.array(self.trades)

        downside = returns[returns < 0]

        if len(downside) == 0:
            return 0

        downside_std = np.std(downside)

        if downside_std == 0:
            return 0

        sortino = (np.mean(returns) - risk_free) / downside_std

        return sortino * np.sqrt(252)

    # =====================================================
    # RISK OF RUIN
    # =====================================================

    def risk_of_ruin(self, risk_per_trade=1, capital_risk=30):

        """
        Estimación simplificada de riesgo de ruina
        """

        wr = self.winrate()

        if wr == 0:
            return 1.0

        loss_rate = 1 - wr

        edge = wr - loss_rate

        if edge <= 0:
            return 1.0

        ror = (loss_rate / wr) ** (capital_risk / risk_per_trade)

        return ror

    # =====================================================
    # MONTE CARLO
    # =====================================================

    def monte_carlo(self, simulations=500):

        if not self.trades:
            return []

        results = []

        for _ in range(simulations):

            equity = 10000

            shuffled = random.sample(self.trades, len(self.trades))

            for trade in shuffled:

                equity *= (1 + trade / 100)

            results.append(equity)

        return results

    # =====================================================
    # FULL REPORT
    # =====================================================

    def report(self):

        return {

            "trades": len(self.trades),

            "winrate": self.winrate(),

            "expectancy": self.expectancy(),

            "sharpe": self.sharpe_ratio(),

            "sortino": self.sortino_ratio(),

            "max_drawdown": self.max_drawdown(),

            "risk_of_ruin": self.risk_of_ruin(),
        }