# core/analytics/equity_stability_engine.py

import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class EquityStabilityEngine:
    """
    Institutional Equity Stability Analyzer.

    Detecta:

    - degradación de estrategias
    - inestabilidad del Sharpe
    - exceso de volatilidad del equity
    - deterioro estructural del sistema
    """

    def __init__(self):

        self.mode = "NORMAL"
        self.risk_scale = 1.0

    # ======================================================
    # EQUITY SMOOTHNESS
    # ======================================================

    def equity_smoothness(self, equity_series):

        try:

            returns = equity_series.pct_change().dropna()

            if len(returns) < 20:
                return 1.0

            vol = returns.std()
            mean = returns.mean()

            if vol == 0:
                return 1.0

            smoothness = mean / vol

            return float(np.clip(smoothness, -5, 5))

        except Exception:

            logger.exception("Smoothness calculation failed")

            return 0

    # ======================================================
    # ROLLING SHARPE
    # ======================================================

    def rolling_sharpe(self, equity_series, window=50):

        try:

            returns = equity_series.pct_change().dropna()

            if len(returns) < window:
                return 0

            rolling_mean = returns.rolling(window).mean()
            rolling_std = returns.rolling(window).std()

            sharpe = (rolling_mean / rolling_std) * np.sqrt(252)

            return sharpe.iloc[-1]

        except Exception:

            logger.exception("Rolling Sharpe failed")

            return 0

    # ======================================================
    # SHARPE STABILITY
    # ======================================================

    def sharpe_stability(self, equity_series):

        try:

            returns = equity_series.pct_change().dropna()

            if len(returns) < 100:
                return 0

            rolling_sharpes = []

            window = 30

            for i in range(window, len(returns)):

                segment = returns[i-window:i]

                mean = segment.mean()
                std = segment.std()

                if std == 0:
                    continue

                sharpe = (mean / std) * np.sqrt(252)

                rolling_sharpes.append(sharpe)

            if len(rolling_sharpes) < 5:
                return 0

            stability = np.std(rolling_sharpes)

            return float(stability)

        except Exception:

            logger.exception("Sharpe stability failed")

            return 0

    # ======================================================
    # EQUITY VOLATILITY
    # ======================================================

    def equity_volatility(self, equity_series):

        try:

            returns = equity_series.pct_change().dropna()

            if len(returns) < 20:
                return 0

            vol = returns.std() * np.sqrt(252)

            return float(vol)

        except Exception:

            logger.exception("Equity volatility failed")

            return 0

    # ======================================================
    # STRATEGY DEGRADATION
    # ======================================================

    def strategy_degradation(self, equity_series):

        try:

            returns = equity_series.pct_change().dropna()

            if len(returns) < 100:
                return 0

            early = returns[: len(returns)//2]
            late = returns[len(returns)//2 :]

            early_mean = early.mean()
            late_mean = late.mean()

            if early_mean == 0:
                return 0

            degradation = (late_mean - early_mean) / abs(early_mean)

            return float(degradation)

        except Exception:

            logger.exception("Strategy degradation failed")

            return 0

    # ======================================================
    # STABILITY SCORE
    # ======================================================

    def stability_score(self, equity_series):

        try:

            smooth = self.equity_smoothness(equity_series)

            sharpe = self.rolling_sharpe(equity_series)

            sharpe_var = self.sharpe_stability(equity_series)

            vol = self.equity_volatility(equity_series)

            degr = self.strategy_degradation(equity_series)

            score = 0

            if smooth > 0.2:
                score += 1

            if sharpe > 1:
                score += 1

            if sharpe_var < 1:
                score += 1

            if vol < 0.40:
                score += 1

            if degr > -0.3:
                score += 1

            score = score / 5

            # ================================
            # RISK MODE
            # ================================

            if score >= 0.8:

                mode = "STRONG"

                scale = 1.0

            elif score >= 0.6:

                mode = "STABLE"

                scale = 0.8

            elif score >= 0.4:

                mode = "WEAK"

                scale = 0.6

            elif score >= 0.2:

                mode = "DEGRADING"

                scale = 0.4

            else:

                mode = "CRITICAL"

                scale = 0.2

            self.mode = mode
            self.risk_scale = scale

            return {

                "stability_score": score,

                "mode": mode,

                "risk_scale": scale,

                "metrics": {

                    "smoothness": smooth,

                    "rolling_sharpe": sharpe,

                    "sharpe_variability": sharpe_var,

                    "equity_volatility": vol,

                    "strategy_degradation": degr

                }
            }

        except Exception:

            logger.exception("Equity stability evaluation failed")

            return {

                "stability_score": 0,

                "mode": "ERROR",

                "risk_scale": 0.5

            }