# core/quant/spoofing_detector.py

def detect_spoofing(df):

    if df is None or len(df) < 30:
        return {"spoofing": False}

    spikes = (df["volume"] > df["volume"].rolling(20).mean() * 2)

    reversals = df["close"].diff().abs() > df["close"] * 0.002

    spoof_score = (spikes & reversals).sum()

    if spoof_score > 3:
        return {
            "spoofing": True,
            "score": int(spoof_score)
        }

    return {"spoofing": False}

