# core/quant/ensemble_brain.py

import numpy as np


def _normalize(scores):
    total = sum(abs(s) for s in scores) or 1
    return [s / total for s in scores]


def ensemble_decision(models_outputs):
    """
    models_outputs = [
        {"model": "RULE_BASED", "direction": "LONG", "confidence": 70},
        {"model": "ML", "direction": "LONG", "confidence": 60},
        {"model": "SMC", "direction": "SHORT", "confidence": 80},
        ...
    ]
    """

    vote_map = {
        "LONG": 0,
        "SHORT": 0,
        "HOLD": 0
    }

    weights = []

    for m in models_outputs:
        direction = m.get("direction", "HOLD")
        confidence = m.get("confidence", 0)

        vote_map[direction] += confidence
        weights.append(confidence)

    norm_weights = _normalize(weights)

    # decisión final
    final_direction = max(vote_map, key=vote_map.get)

    # confianza agregada
    final_confidence = sum(weights) / len(weights)

    return {
        "direction": final_direction,
        "confidence": min(100, final_confidence),
        "votes": vote_map,
        "models": models_outputs
    }

