# core/quant/feature_importance.py

import numpy as np

def compute_feature_importance(features_df):

    if features_df is None or len(features_df) < 20:
        return {"status": "INSUFFICIENT_DATA"}

    correlations = {}

    target = features_df["close"].pct_change().shift(-1)

    for col in features_df.columns:
        if col == "close":
            continue

        try:
            corr = np.corrcoef(features_df[col].fillna(0), target.fillna(0))[0,1]
            correlations[col] = abs(corr)
        except:
            correlations[col] = 0

    top_features = sorted(
        correlations.items(),
        key=lambda x: x[1],
        reverse=True
    )[:5]

    return {
        "top_features": top_features,
        "raw": correlations
    }

