# core/quant/liquidity_traps.py

def detect_fake_breakout(df):

    if df is None or len(df) < 25:
        return {"trap": False}

    high_20 = df["high"].rolling(20).max().iloc[-2]
    low_20 = df["low"].rolling(20).min().iloc[-2]

    last = df.iloc[-1]

    # Bull trap
    if last["high"] > high_20 and last["close"] < high_20:
        return {
            "trap": True,
            "type": "BULL_TRAP"
        }

    # Bear trap
    if last["low"] < low_20 and last["close"] > low_20:
        return {
            "trap": True,
            "type": "BEAR_TRAP"
        }

    return {"trap": False}

