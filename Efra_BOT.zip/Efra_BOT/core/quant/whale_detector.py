# core/quant/whale_detector.py

import numpy as np

def detect_whales(df):

    if df is None or len(df) < 30 or "volume" not in df.columns:
        return {"active": False}

    vol = df["volume"]
    vol_mean = vol.rolling(20).mean()
    vol_std = vol.rolling(20).std()

    last_vol = vol.iloc[-1]
    threshold = vol_mean.iloc[-1] + 2 * vol_std.iloc[-1]

    if last_vol > threshold:
        return {
            "active": True,
            "type": "VOLUME_SPIKE",
            "strength": float((last_vol / threshold))
        }

    return {"active": False}

