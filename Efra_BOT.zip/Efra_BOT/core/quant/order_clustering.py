# core/quant/order_clustering.py

import numpy as np

def kmeans_1d(data, k=3, iters=10):
    centroids = np.random.choice(data, k)

    for _ in range(iters):
        clusters = [[] for _ in range(k)]

        for d in data:
            idx = np.argmin([abs(d - c) for c in centroids])
            clusters[idx].append(d)

        new_centroids = []
        for cluster in clusters:
            if cluster:
                new_centroids.append(np.mean(cluster))
            else:
                new_centroids.append(np.random.choice(data))

        centroids = new_centroids

    return centroids


def detect_volume_clusters(df):

    if df is None or len(df) < 50:
        return {"clusters": [], "dominant": None}

    volumes = df["volume"].values

    clusters = kmeans_1d(volumes, k=3)

    dominant = max(clusters)

    return {
        "clusters": [float(c) for c in clusters],
        "dominant": float(dominant)
    }

