# core/quant/footprint_simulator.py

def compute_footprint(df):

    if df is None or len(df) < 20:
        return {"imbalance": 0, "signal": "NEUTRAL"}

    buy_vol = df[df["close"] > df["open"]]["volume"].sum()
    sell_vol = df[df["close"] < df["open"]]["volume"].sum()

    total = buy_vol + sell_vol or 1

    imbalance = (buy_vol - sell_vol) / total

    if imbalance > 0.2:
        signal = "BUY_IMBALANCE"
    elif imbalance < -0.2:
        signal = "SELL_IMBALANCE"
    else:
        signal = "NEUTRAL"

    return {
        "imbalance": float(imbalance),
        "signal": signal
    }

