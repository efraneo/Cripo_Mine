# core/quant/auto_retrainer.py

def retrain_trigger(session_stats):

    wins = session_stats.get("wins", 0)
    losses = session_stats.get("losses", 0)

    total = wins + losses

    if total < 20:
        return False

    winrate = wins / total

    # si cae rendimiento → reentrenar
    if winrate < 0.45:
        return True

    return False

