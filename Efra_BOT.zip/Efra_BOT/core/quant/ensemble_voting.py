# core/quant/ensemble_voting.py

def ensemble_decision(signals):

    votes = {
        "BUY": 0,
        "SELL": 0
    }

    for s in signals:

        if s == "BUY":
            votes["BUY"] += 1
        elif s == "SELL":
            votes["SELL"] += 1

    if votes["BUY"] > votes["SELL"]:
        return "BUY", votes["BUY"]

    if votes["SELL"] > votes["BUY"]:
        return "SELL", votes["SELL"]

    return "HOLD", 0

