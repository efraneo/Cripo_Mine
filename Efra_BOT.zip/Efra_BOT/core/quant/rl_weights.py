# core/quant/rl_weights.py

class RLWeightEngine:

    def __init__(self):

        self.weights = {
            "INSTITUTIONAL_RULE": 1.0,
            "ML_AGENT": 1.0,
            "SMART_MONEY": 1.0,
            "BASE_IA": 1.0
        }

    # =====================================================
    # UPDATE LEARNING
    # =====================================================
    def update(self, model, reward):

        if model not in self.weights:
            return

        self.weights[model] += 0.1 * reward

        self.weights[model] = max(
            0.1,
            min(3.0, self.weights[model])
        )

    # =====================================================
    # GET WEIGHTS
    # =====================================================
    def get_weights(self):

        return self.weights

    # =====================================================
    # ADAPTIVE RL WEIGHTING
    # =====================================================
    def adjust_weights(self, models_outputs):

        votes = {
            "LONG": 0.0,
            "SHORT": 0.0,
            "RANGE": 0.0
        }

        total_conf = 0.0

        for m in models_outputs:

            model = m.get("model")

            direction = str(
                m.get("direction", "RANGE")
            ).upper()

            # 🔥 NORMALIZACIÓN
            if direction == "NEUTRAL":
                direction = "RANGE"

            if direction not in votes:
                direction = "RANGE"

            confidence = float(
                m.get("confidence", 0)
            )

            weight = self.weights.get(model, 1.0)

            score = confidence * weight

            votes[direction] += score

            total_conf += score

        dominant = max(votes, key=votes.get)

        # ============================================
        # SCALE
        # ============================================
        confidence_scale = 1.0

        if dominant in ["LONG", "SHORT"]:
            confidence_scale = 1.15

        elif dominant == "RANGE":
            confidence_scale = 0.75

        # ============================================
        # NORMALIZED CONFIDENCE
        # ============================================
        normalized = {}

        if total_conf > 0:

            for k, v in votes.items():

                normalized[k] = round(
                    v / total_conf,
                    4
                )

        else:

            normalized = {
                "LONG": 0,
                "SHORT": 0,
                "RANGE": 1
            }

        return {
            "votes": votes,
            "probabilities": normalized,
            "dominant": dominant,
            "confidence_scale": confidence_scale,
            "weights": self.weights,
            "total_confidence": total_conf
        }
