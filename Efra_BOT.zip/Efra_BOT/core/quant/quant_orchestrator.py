# core/quant/quant_orchestrator.py

from core.quant.order_flow_simulator import simulate_order_flow
from core.quant.market_maker_detector import detect_market_maker
from core.quant.liquidity_trap_detector import detect_liquidity_trap
from core.quant.latency_arbitrage import latency_edge
from core.quant.ensemble_voting import ensemble_decision


def compute_quant_layer(df):

    order_flow = simulate_order_flow(df)
    mm = detect_market_maker(df)
    trap = detect_liquidity_trap(df)
    latency = latency_edge(df)

    signals = []

    # -----------------------------------
    # ORDER FLOW
    # -----------------------------------
    if order_flow["pressure"] == "BUY_DOMINANT":
        signals.append("BUY")
    elif order_flow["pressure"] == "SELL_DOMINANT":
        signals.append("SELL")

    # -----------------------------------
    # LATENCY MOMENTUM
    # -----------------------------------
    if latency["edge"] > 0:
        signals.append("BUY")
    elif latency["edge"] < 0:
        signals.append("SELL")

    # -----------------------------------
    # TRAPS (ANTI-SIGNAL)
    # -----------------------------------
    if trap.get("trap"):
        if trap["side"] == "BULL_TRAP":
            signals.append("SELL")

    decision, strength = ensemble_decision(signals)

    return {
        "decision": decision,
        "strength": strength,
        "order_flow": order_flow,
        "market_maker": mm,
        "trap": trap,
        "latency": latency
    }

