# core/quant/liquidity_trap_detector.py

def detect_liquidity_trap(df):

    if df is None or len(df) < 20:
        return {"trap": False}

    last = df.iloc[-1]

    breakout = last["high"] > df["high"].rolling(20).max().iloc[-2]

    rejection = last["close"] < last["high"] * 0.98

    if breakout and rejection:
        return {
            "trap": True,
            "side": "BULL_TRAP"
        }

    return {"trap": False}

