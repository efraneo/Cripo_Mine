# core/quant/market_maker_detector.py

def detect_market_maker(df):

    if df is None or len(df) < 30:
        return {"active": False}

    wick_ratio = ((df["high"] - df["low"]) / df["close"]).mean()

    fake_moves = (df["close"].diff().abs() > df["close"] * 0.002).sum()

    if wick_ratio > 0.01 and fake_moves > 5:
        return {
            "active": True,
            "type": "LIQUIDITY_HUNT"
        }

    return {"active": False}

