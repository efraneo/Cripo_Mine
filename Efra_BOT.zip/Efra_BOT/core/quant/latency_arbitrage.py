# core/quant/latency_arbitrage.py

def latency_edge(df):

    if df is None or len(df) < 10:
        return {"edge": 0}

    momentum = df["close"].pct_change().rolling(5).mean().iloc[-1]

    return {
        "edge": float(momentum)
    }

