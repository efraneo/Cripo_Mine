# core/quant/order_flow_simulator.py

import numpy as np

def simulate_order_flow(df):

    if df is None or len(df) < 20:
        return {"delta": 0, "pressure": "NEUTRAL"}

    buy_pressure = (df["close"] > df["open"]).astype(int)
    sell_pressure = (df["close"] < df["open"]).astype(int)

    delta = buy_pressure.sum() - sell_pressure.sum()

    if delta > 5:
        pressure = "BUY_DOMINANT"
    elif delta < -5:
        pressure = "SELL_DOMINANT"
    else:
        pressure = "NEUTRAL"

    return {
        "delta": int(delta),
        "pressure": pressure
    }

