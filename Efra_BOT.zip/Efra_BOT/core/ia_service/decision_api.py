#core/ia_service/decision_api.py

def ia_decision_service(payload: dict) -> dict:
    symbol = payload["symbol"]
    data_by_tf = payload["data"]

    return compute_ia_pro_decision(
        symbol=symbol,
        data_by_tf=data_by_tf
    )
