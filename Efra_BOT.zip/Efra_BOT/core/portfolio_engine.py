#core/portfolio_engine.py

import numpy as np


class PortfolioEngine:

    def __init__(self, engine):
        self.engine = engine

    # ==========================================================
    # FILTRO INSTITUCIONAL
    # ==========================================================
    def filter_opportunities(self, opportunities):

        valid = []

        for r in opportunities:
            ia = r["ia"]

            if (
                r["confidence"] >= 80 and
                ia.get("execution_policy", {}).get("allow_trade")
            ):
                valid.append(r)

        return valid

    # ==========================================================
    # ASIGNACIÓN DE CAPITAL (RISK PARITY SIMPLE)
    # ==========================================================
    def allocate_capital(self, opportunities, total_balance):

        if not opportunities:
            return []

        confidences = np.array([r["confidence"] for r in opportunities])

        # normalizar
        weights = confidences / confidences.sum()

        allocations = []

        for r, w in zip(opportunities, weights):
            capital = total_balance * w

            allocations.append({
                "symbol": r["symbol"],
                "weight": float(w),
                "capital": float(capital),
                "ia": r["ia"]
            })

        return allocations

    # ==========================================================
    # EJECUCIÓN MULTI-TRADE
    # ==========================================================
    def execute_portfolio(self, allocations):

        results = []

        for a in allocations:

            symbol = a["symbol"]
            ia = a["ia"]
            capital = a["capital"]

            try:
                balance = self.engine.get_balance("USDT") or 0

                if balance <= 0:
                    results.append({
                        "symbol": symbol,
                        "status": "ERROR",
                        "reason": "Sin balance"
                    })
                    continue

                ia["capital_fraction"] = capital / balance

                res = self.engine.run_auto_trade(symbol, ia)

                results.append({
                    "symbol": symbol,
                    "status": "OK" if res["executed"] else "FAIL",
                    "details": res
                })

            except Exception as e:
                results.append({
                    "symbol": symbol,
                    "status": "ERROR",
                    "reason": str(e)
                })

        return results
