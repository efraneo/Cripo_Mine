# core/controller/institutional_market_controller.py

import time
import logging

logger = logging.getLogger(__name__)

class InstitutionalMarketController:

    """
    Controlador institucional del sistema de trading.
    """

    def __init__(
        self,
        scanner,
        portfolio_risk_manager,
        trade_executor,
        trade_lifecycle_manager
    ):
        self.scanner = scanner
        self.portfolio_risk_manager = portfolio_risk_manager
        self.trade_executor = trade_executor
        self.trade_lifecycle_manager = trade_lifecycle_manager
        self.running = False

    # ======================================================
    # START BOT
    # ======================================================

    def start(self, interval=60):
        logger.info("Institutional Market Controller started")
        self.running = True
        while self.running:
            try:
                opportunities = self.scanner.top_opportunities(5)

                for opp in opportunities:
                    symbol = opp["symbol"]
                    capital = opp.get("capital_allocation", 0)
                    decision = {
                        "symbol": symbol,
                        "risk": capital
                    }
                    validation = self.portfolio_risk_manager.validate_new_trade(
                        signal=type("obj", (object,), {"symbol": symbol}),
                        risk={"risk": capital}
                    )
                    if not validation["allowed"]:
                        logger.info(
                            f"Trade rejected {symbol}: {validation['reason']}"
                        )
                        continue
                    logger.info(
                        f"Executing trade {symbol} allocation {capital:.2f}"
                    )
                    trade = self.trade_executor.execute_trade(
                        symbol=symbol,
                        risk_fraction=capital
                    )
                    if trade:
                        self.trade_lifecycle_manager.register_trade(trade)
                        self.portfolio_risk_manager.register_position(
                            {
                                "symbol": symbol,
                                "risk": capital
                            }
                        )
                self.monitor_positions()
            except Exception as e:
                logger.error(f"Controller error: {e}")
            time.sleep(interval)

    # ======================================================
    # STOP BOT
    # ======================================================

    def stop(self):
        logger.info("Stopping controller")
        self.running = False

    # ======================================================
    # MONITOR POSITIONS
    # ======================================================

    def monitor_positions(self):
        open_trades = self.trade_lifecycle_manager.get_open_trades()

        for trade in open_trades:
            symbol = trade["symbol"]

            try:
                price = self.trade_executor.get_price(symbol)
                self.trade_lifecycle_manager.update_trade(
                    trade["id"],
                    price
                )
            except Exception as e:
                logger.warning(f"Monitor error {symbol}: {e}")