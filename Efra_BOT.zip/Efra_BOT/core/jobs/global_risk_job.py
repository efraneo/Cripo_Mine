# core/jobs/global_risk_job.py

from core.risk.risk_matrix import build_risk_matrix
from core.risk.global_risk_governor import risk_governor_decision


def run_global_risk_cycle(nav, var, dd, exposure):

    score = build_risk_matrix(nav, var, dd, exposure)
    decision = risk_governor_decision(score)

    return decision
