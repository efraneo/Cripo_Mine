# core/jobs/daily_close_job.py

from datetime import datetime
import pytz
import logging

log = logging.getLogger("daily_close")

_last_run_day = None


def is_utc_day_close(now=None) -> bool:
    global _last_run_day

    now = now or datetime.utcnow().replace(tzinfo=pytz.UTC)

    if now.hour == 0 and now.minute < 5:
        day = now.strftime("%Y-%m-%d")

        if _last_run_day != day:
            _last_run_day = day
            return True

    return False


def run_daily_close():
    try:
        from core.capital_rotation.capital_rotator import rotate_capital
        from core.session.session_stats import get_strategy_stats
        from core.reporting.daily_nav_snapshot import build_daily_snapshot
        from core.portfolio.portfolio_state import get_portfolio_state
        from core.trades.trade_store import get_trades_today

        # -------------------------
        # CAPITAL ROTATION
        # -------------------------
        stats = get_strategy_stats()
        decisions = rotate_capital(stats)

        # -------------------------
        # NAV + ATTRIBUTION
        # -------------------------
        portfolio = get_portfolio_state()
        trades = get_trades_today()

        snapshot = build_daily_snapshot(portfolio, trades)

        log.info("Daily close completed", extra={
            "nav": snapshot["nav"]["nav"]
        })

        return {
            "rotation": decisions,
            "nav_snapshot": snapshot
        }

    except Exception:
        log.exception("Daily close job failed")
        return None
