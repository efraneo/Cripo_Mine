# core/market_scanner.py

import logging
import time
import pandas as pd
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger("market_scanner")

class MarketScanner:

    def __init__(self, engine, ia_function):
        self.engine = engine
        self.ia_function = ia_function
        self.cache = {}

    # ==========================================================
    # SYMBOLS
    # ==========================================================
    def get_tradeable_symbols(self):
        # ======================================================
        # BLACKLIST INSTITUCIONAL
        # ======================================================

        BLACKLIST = {

            # Tokens sintéticos / basura
            "0GUSDT",

            # Hyper leveraged meme contracts
            "1000SHIBUSDT",
            "1000BONKUSDT",
            "1000PEPEUSDT",
            "1000FLOKIUSDT",
            "1000BONKUSDT",

            # Baja liquidez / inestables
            "LUNAUSDT",
            "USTCUSDT",

            # Fan tokens ultra manipulables
            "PSGUSDT",
            "CITYUSDT",

            # Otros problemáticos
            "BTCDOMUSDT",
        }

        try:
            symbols = self.engine.get_symbols()
            symbols = [
                s for s in symbols
                if (
                    s.endswith("USDT")
                    and s not in BLACKLIST
                )
            ]
            logger.info(
                f"Scanner encontró {len(symbols)} símbolos"
            )
        except Exception as e:
            logger.exception(
                "Scanner symbols failed"
            )
            return []


        filtered = []

        for s in symbols:

            try:

                # ---------------------------------------------
                # FILTRO BASE
                # ---------------------------------------------

                if not isinstance(s, str):
                    continue

                s = s.upper().strip()

                if not s.endswith("USDT"):
                    continue

                # ---------------------------------------------
                # BLACKLIST
                # ---------------------------------------------

                if s in BLACKLIST:
                    continue

                # ---------------------------------------------
                # EXCLUIR APALANCADOS
                # ---------------------------------------------

                leveraged_keywords = (
                    "UPUSDT",
                    "DOWNUSDT",
                    "BULLUSDT",
                    "BEARUSDT",
                )

                if any(
                    s.endswith(k)
                    for k in leveraged_keywords
                ):
                    continue

                # ---------------------------------------------
                # LONGITUD MÍNIMA
                # evita símbolos corruptos
                # ---------------------------------------------

                if len(s) < 6:
                    continue

                filtered.append(s)

            except Exception:
                continue

        return filtered

    # ==========================================================
    # CACHE MULTI TF
    # ==========================================================
    def get_cached_tf(self, symbol, timeframe):

        key = f"{symbol}_{timeframe}"

        now = time.time()

        if key in self.cache:

            data, ts = self.cache[key]

            if now - ts < 30:
                return data

        try:

            df = self.engine.get_klines_df(
                symbol=symbol,
                interval=timeframe,
                limit=300
            )

            if df is None or df.empty:
                return None

            self.cache[key] = (df, now)

            return df

        except Exception:
            return None

    # ==========================================================
    # MULTI TF DATA
    # ==========================================================
    def build_multi_tf_data(self, symbol):

        tfs = ["5m", "15m", "1h", "4h"]

        out = {}

        for tf in tfs:

            df = self.get_cached_tf(symbol, tf)

            if df is not None and not df.empty:
                out[tf] = {"df": df}

        return out

    # ==========================================================
    # ANALYZE ONE
    # ==========================================================
    def analyze_symbol(self, symbol):
        try:
            data_by_tf = {}
            for tf in [
                "5m",
                "15m",
                "1h",
                "4h"
            ]:
                tf_df = self.engine.get_ohlc_df_for_ui(
                    symbol=symbol,
                    timeframe=tf,
                    limit=300
                )
                if tf_df is not None and not tf_df.empty:
                    data_by_tf[tf] = {
                        "df": tf_df
                    }
            if "5m" not in data_by_tf:
                return None
            ia = self.ia_function(
                symbol=symbol,
                data_by_tf=data_by_tf
            )
            return {
                "symbol": symbol,
                "confidence": ia.get(
                    "confidence",
                    0
                ),
                "ia": ia
            }
        except Exception:
            logger.exception(
                f"Analyze failed {symbol}"
            )
            return None

    # ==========================================================
    # PARALLEL SCAN
    # ==========================================================
    def scan_market(self, limit=30, workers=5):

        logger = logging.getLogger(__name__)

        BLACKLIST = {
            "0GUSDT",
            "1000SHIBUSDT",
            "1000BONKUSDT"
        }
 
        symbols = self.get_tradeable_symbols()[:limit]
        results = []

        with ThreadPoolExecutor(max_workers=workers) as executor:

            futures = [
                executor.submit(self.analyze_symbol, s)
                for s in symbols
            ]

            for f in as_completed(futures):

                try:
                    r = f.result()

                    if r:
                        results.append(r)

                except Exception:
                    pass

        results.sort(
            key=lambda x: x["confidence"],
            reverse=True
        )

        return results

    # ==========================================================
    # TOP N
    # ==========================================================
    def get_top_opportunities(self, n=5):

        results = self.scan_market()

        filtered = [
            r for r in results
            if r["confidence"] >= 80
        ]

        return filtered[:n]

    # ==========================================================
    # BEST ≥95%
    # ==========================================================
    def get_best_high_confidence(self):

        results = self.scan_market()

        for r in results:

            ia = r["ia"]

            if (
                r["confidence"] >= 95 and
                ia.get("execution_policy", {}).get("allow_trade")
            ):
                return r

        return None
