from datetime import datetime, timedelta, timezone
import math

# ======================================================
# ⏱️ ENTRY TIMING ENGINE (FASE 2)
# ======================================================
def compute_entry_timing(ia: dict, tf_minutes: int = 5) -> dict:
    """
    Decide si se entra ahora, se espera cierre de vela,
    o se bloquea la operación.
    """

    now = datetime.utcnow().replace(tzinfo=timezone.utc)

    confidence = ia.get("confidence", 0)
    direction = ia.get("direction")
    regime = ia.get("regime", "UNKNOWN")
    candle_ctx = ia.get("candlestick_context", {})
    candle_bias = candle_ctx.get("bias", "neutral")

    # --------------------------------------------------
    # 1) BLOQUEOS DUROS
    # --------------------------------------------------
    if confidence < 65:
        return {
            "state": "NO_TRADE",
            "seconds_to_close": None,
            "recommended_time_utc": None,
            "reason": "Confianza insuficiente (<65%)"
        }

    if direction not in ("LONG", "SHORT"):
        return {
            "state": "NO_TRADE",
            "seconds_to_close": None,
            "recommended_time_utc": None,
            "reason": "Dirección no operable"
        }

    # --------------------------------------------------
    # 2) CÁLCULO CIERRE DE VELA
    # --------------------------------------------------
    epoch = now.timestamp()
    tf_seconds = tf_minutes * 60

    seconds_into_candle = int(epoch % tf_seconds)
    seconds_to_close = tf_seconds - seconds_into_candle

    next_close = now + timedelta(seconds=seconds_to_close)

    # --------------------------------------------------
    # 3) DECISIÓN DE ENTRADA
    # --------------------------------------------------

    # Alta confianza → permitir entrada
    if confidence >= 65:

        return {
            "state":"ENTER_NOW",
            "seconds_to_close":seconds_to_close,
            "recommended_time_utc":now.isoformat(),
            "reason":"Confluencia institucional válida"
        }

    # confianza baja → esperar
    return {
        "state":"WAIT_CONFIRMATION",
        "seconds_to_close":seconds_to_close,
        "recommended_time_utc":next_close.isoformat(),
        "reason":"Esperando más confirmaciones"
    }
