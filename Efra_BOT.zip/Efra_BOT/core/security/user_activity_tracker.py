# core/security/user_activity_tracker.py

from datetime import datetime

_ACTIVITY_LOGS = []


def register_activity(
    username,
    role,
    action,
    ip="N/A",
    symbol=None,
    extra=None
):

    event = {
        "timestamp": datetime.utcnow().isoformat(),
        "username": username,
        "role": role,
        "ip": ip,
        "action": action,
        "symbol": symbol,
        "extra": extra or {}
    }

    _ACTIVITY_LOGS.append(event)

    return event


def get_activity_logs():
    return _ACTIVITY_LOGS
