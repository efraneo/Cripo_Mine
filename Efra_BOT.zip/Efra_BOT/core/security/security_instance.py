# core/security/security_instance.py

from backend.security_engine import SecurityEngine

# instancia única global
security_engine = SecurityEngine()