# core/env_loader.py
"""
Carga centralizada de variables .env para todo el Bot de Efra.
Se ejecuta SIEMPRE antes de importar mailer, binance, telegram, etc.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

BASE = Path(__file__).resolve().parent.parent

ENV_FILES = [
    BASE / "env" / "binance.env",
    BASE / "env" / "clave_correo.env",
    BASE / "env" / "credenciales.env",
    BASE / "env" / "telegram.env",
]

def load_all_envs():
    if not hasattr(load_all_envs, "_already_loaded"):
        load_all_envs._already_loaded = True

        for f in ENV_FILES:
            if f.exists():
                load_dotenv(f, override=True)
                print(f"[ENV] cargado: {f}")
            else:
                print(f"[ENV] faltante: {f}")
