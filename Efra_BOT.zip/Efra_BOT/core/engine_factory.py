from backend.trading_engine import TradingEngine
from backend.order_manager import OrderManager
from backend.risk_manager import RiskManager
from backend.binance_manager import BinanceManager
import os


def build_trading_engine():
    # ============================
    # Credenciales Binance (OBLIGATORIAS)
    # ============================
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        raise RuntimeError("BINANCE_API_KEY / BINANCE_API_SECRET no definidas")

    # ============================
    # Binance Manager (TRADING)
    # ============================
    binance = BinanceManager(
        api_key=api_key,
        api_secret=api_secret
    )

    # ============================
    # Risk Manager
    # ============================
    risk_manager = RiskManager(mode="live")

    # ============================
    # Order Manager
    # ============================
    order_manager = OrderManager()

    # ============================
    # Trading Engine
    # ============================
    engine = TradingEngine(
        binance=binance,
        order_manager=order_manager,
        risk_manager=risk_manager,
        mode="LIVE"
    )

    return engine
