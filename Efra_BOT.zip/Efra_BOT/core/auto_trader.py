# core/auto_trader.py

"""
COMPAT WRAPPER
NO usar directamente.
Usar: core.trading.auto_trader.AutoTrader
"""

from core.trading.auto_trader import AutoTrader

__all__ = ["AutoTrader"]
