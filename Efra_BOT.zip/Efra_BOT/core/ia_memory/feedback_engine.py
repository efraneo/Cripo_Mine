#core/ia_memory/feedback_engine.py
import json
from pathlib import Path


def apply_trade_feedback(
    decision_id: str,
    pnl: float,
    exit_price: float,
    reason: str = ""
):
    """
    Aplica resultado real a una decisión IA.
    """

    file = Path("data/ia_memory") / f"{decision_id}.json"
    if not file.exists():
        return

    with file.open("r", encoding="utf-8") as f:
        record = json.load(f)

    record["result"] = {
        "pnl": pnl,
        "exit_price": exit_price,
        "success": pnl > 0,
        "reason": reason,
    }

    with file.open("w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)
