import json
import uuid
from datetime import datetime
from pathlib import Path

BASE_PATH = Path("data/ia_memory")
BASE_PATH.mkdir(parents=True, exist_ok=True)


def store_ia_decision(symbol: str, ia: dict) -> str:
    """
    Guarda una decisión IA completa.
    Retorna decision_id.
    """

    decision_id = str(uuid.uuid4())
    record = {
        "decision_id": decision_id,
        "symbol": symbol,
        "timestamp": datetime.utcnow().isoformat(),
        "ia": ia,
        "result": None,  # se llena post-trade
    }

    file = BASE_PATH / f"{decision_id}.json"
    with file.open("w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)

    return decision_id
