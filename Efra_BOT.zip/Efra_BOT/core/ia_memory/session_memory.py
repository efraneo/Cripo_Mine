#core/ia_memory/session_memory.py
from collections import defaultdict

_SESSION_STATS = defaultdict(lambda: {
    "trades": 0,
    "wins": 0,
    "losses": 0,
    "pnl": 0.0,
})


def update_session_stats(symbol: str, pnl: float):
    stats = _SESSION_STATS[symbol]
    stats["trades"] += 1
    stats["pnl"] += pnl

    if pnl > 0:
        stats["wins"] += 1
    else:
        stats["losses"] += 1


def get_session_confidence_modifier(symbol: str) -> int:
    stats = _SESSION_STATS.get(symbol)
    if not stats or stats["trades"] < 3:
        return 0

    winrate = stats["wins"] / max(1, stats["trades"])

    if winrate >= 0.7:
        return +5
    if winrate <= 0.4:
        return -10

    return 0
