#core/ia_memory/audit_exporter.py
import json
import csv
from pathlib import Path


def export_audit_csv(output="audit_report.csv"):
    base = Path("data/ia_memory")
    files = list(base.glob("*.json"))

    rows = []
    for f in files:
        with f.open("r", encoding="utf-8") as file:
            record = json.load(file)

        ia = record.get("ia", {})
        result = record.get("result") or {}

        rows.append({
            "decision_id": record["decision_id"],
            "symbol": record["symbol"],
            "timestamp": record["timestamp"],
            "direction": ia.get("direction"),
            "confidence": ia.get("confidence"),
            "state": ia.get("entry_timing", {}).get("state"),
            "pnl": result.get("pnl"),
            "success": result.get("success"),
        })

    with open(output, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
