# core/ia_pro_score.py
# ============================================================
# IA PRO v3 — INSTITUTIONAL PROBABILISTIC ENGINE
# ============================================================

from datetime import datetime
from math import log

import numpy as np

from backend.fake_breakout_pro import detect_fake_breakout_pro
from backend.ia_memory import IAMemory
from backend.session_bias import apply_session_bias

from core.news_filter import is_high_risk_news_window


# ======================================================
# UTILIDADES MATEMÁTICAS
# ======================================================

def softmax(x):

    e = np.exp(x - np.max(x))

    return e / e.sum()


def entropy(p):

    return -sum(
        pi * log(pi + 1e-9)
        for pi in p
    )


def normalize_entropy(h, n=3):

    return h / log(n)


# ======================================================
# MAIN
# ======================================================

def compute_ia_pro_score(data_by_tf, symbol: str):

    ts = datetime.utcnow().strftime(
        "%Y-%m-%d %H:%M:%S UTC"
    )

    # ==================================================
    # NEWS FILTER
    # ==================================================

    news_risk, news_reason = (
        is_high_risk_news_window()
    )

    # ==================================================
    # LOGITS
    # ==================================================

    logits = {
        "LONG": 0.0,
        "SHORT": 0.0,
    }

    # RANGE NO ES DIRECCIÓN
    range_penalty = 0.0

    explain = {}

    reasons = []

    # ==================================================
    # FAKE BREAKOUT
    # ==================================================

    try:

        df_5m = data_by_tf["5m"]["df"]

        if df_5m is not None:

            is_fake, r = detect_fake_breakout_pro(
                df_5m
            )

            if is_fake:

                range_penalty += 2.5

                explain["fake_breakout"] = {
                    "impact": "range",
                    "reason": r
                }

    except Exception:

        explain["fake_breakout"] = {
            "impact": "unknown"
        }

    # ==================================================
    # TREND ENGINE (4H + 1H)
    # ==================================================

    trend_score = 0

    for tf in ("4h", "1h"):

        pack = data_by_tf.get(tf)

        if isinstance(pack, dict):
            df = pack.get("df")
        else:
            df = pack

        if df is None:
            continue

        df = df.copy()

        try:

            df["ema50"] = (
                df["close"]
                .ewm(span=50)
                .mean()
            )

            df["ema200"] = (
                df["close"]
                .ewm(span=200)
                .mean()
            )

            price = df["close"].iloc[-1]
            ema50 = df["ema50"].iloc[-1]
            ema200 = df["ema200"].iloc[-1]

            # ----------------------------------------
            # BULL
            # ----------------------------------------

            if price > ema50 > ema200:

                trend_score += 1

            # ----------------------------------------
            # BEAR
            # ----------------------------------------

            elif price < ema50 < ema200:

                trend_score -= 1

            # ----------------------------------------
            # NEUTRAL
            # ----------------------------------------

            else:

                range_penalty += 0.5

        except Exception:
            continue

    # ==================================================
    # TREND LOGITS
    # ==================================================

    if trend_score > 0:

        logits["LONG"] += (
            2.0 + abs(trend_score)
        )

        explain["trend"] = "bullish"

    elif trend_score < 0:

        logits["SHORT"] += (
            2.0 + abs(trend_score)
        )

        explain["trend"] = "bearish"

    else:

        range_penalty += 1.0

        explain["trend"] = "neutral"

    # ==================================================
    # MOMENTUM ENGINE
    # ==================================================

    momentum_score = 0

    for tf in ("1h", "15m"):

        pack = data_by_tf.get(tf)

        if isinstance(pack, dict):
            df = pack.get("df")
        else:
            df = pack

        if df is None:
            continue

        df = df.copy()

        try:

            delta = df["close"].diff()

            gain = (
                delta.clip(lower=0)
                .rolling(14)
                .mean()
            )

            loss = (
                delta.abs()
                .rolling(14)
                .mean()
            )

            rsi = 100 - (
                100 / (
                    1 + gain / (loss + 1e-9)
                )
            )

            macd = (
                df["close"]
                .ewm(span=12)
                .mean()
                -
                df["close"]
                .ewm(span=26)
                .mean()
            )

            rsi_last = rsi.iloc[-1]
            macd_last = macd.iloc[-1]

            # ----------------------------------------
            # LONG
            # ----------------------------------------

            if rsi_last > 58 and macd_last > 0:

                momentum_score += 1

            # ----------------------------------------
            # SHORT
            # ----------------------------------------

            elif rsi_last < 42 and macd_last < 0:

                momentum_score -= 1

            # ----------------------------------------
            # FLAT
            # ----------------------------------------

            else:

                range_penalty += 0.35

        except Exception:
            continue

    # ==================================================
    # MOMENTUM LOGITS
    # ==================================================

    if momentum_score > 0:

        logits["LONG"] += (
            1.5 + abs(momentum_score)
        )

        explain["momentum"] = "positive"

    elif momentum_score < 0:

        logits["SHORT"] += (
            1.5 + abs(momentum_score)
        )

        explain["momentum"] = "negative"

    else:

        range_penalty += 0.75

        explain["momentum"] = "flat"

    # ==================================================
    # IA MEMORY BIAS
    # ==================================================

    try:

        bias = IAMemory().bias(symbol)

        if bias > 0:

            logits["LONG"] += bias

        elif bias < 0:

            logits["SHORT"] += abs(bias)

        explain["memory_bias"] = bias

    except Exception:
        pass

    # ==================================================
    # SESSION BIAS
    # ==================================================

    try:

        session_boost = apply_session_bias(
            symbol=symbol
        )

        if isinstance(session_boost, dict):

            direction = str(
                session_boost.get(
                    "direction",
                    ""
                )
            ).upper()

            strength = float(
                session_boost.get(
                    "strength",
                    0
                )
            )

            if direction == "LONG":

                logits["LONG"] += strength

            elif direction == "SHORT":

                logits["SHORT"] += strength

            explain["session_bias"] = (
                session_boost
            )

    except Exception:
        pass

    # ==================================================
    # NEWS RISK
    # ==================================================

    if news_risk:

        range_penalty += 1.0

        reasons.append(news_reason)

    # ==================================================
    # SOFTMAX DIRECCIONAL
    # ==================================================

    directional_logits = np.array([
        logits["LONG"],
        logits["SHORT"]
    ])

    directional_probs = softmax(
        directional_logits
    )

    p_long = float(directional_probs[0])

    p_short = float(directional_probs[1])

    # ==================================================
    # RANGE PROBABILITY
    # ==================================================

    p_range = min(
        0.95,
        max(
            0.0,
            range_penalty / 10
        )
    )

    # ==================================================
    # SCALE
    # ==================================================

    directional_scale = (
        1.0 - p_range
    )

    p_long *= directional_scale
    p_short *= directional_scale

    # ==================================================
    # MAP
    # ==================================================

    p_map = {
        "LONG": round(p_long, 4),
        "SHORT": round(p_short, 4),
        "RANGE": round(p_range, 4)
    }

    # ==================================================
    # CONFIDENCE
    # ==================================================

    dominant_prob = max(
        p_long,
        p_short
    )

    confidence = round(
        dominant_prob * 100 * (
            1 - p_range
        ),
        2
    )

    confidence = max(
        1.0,
        min(confidence, 99.0)
    )

    # ==================================================
    # DIRECTION
    # ==================================================

    if p_range >= 0.55:

        direction = "RANGE"

    elif p_long > p_short:

        direction = "LONG"

    else:

        direction = "SHORT"

    # ==================================================
    # ACTIONABLE
    # ==================================================

    actionable = (
        confidence >= 60
        and p_range < 0.45
    )

    # ==================================================
    # SMART MONEY
    # ==================================================

    smart_money = {
        "direction": direction,
        "confidence": round(
            max(
                p_long,
                p_short
            ) * 100,
            2
        )
    }

    # ==================================================
    # XAI
    # ==================================================

    reasons.append(
        f"P(LONG)={p_map['LONG']:.2f} | "
        f"P(SHORT)={p_map['SHORT']:.2f} | "
        f"P(RANGE)={p_map['RANGE']:.2f}"
    )

    # ==================================================
    # MARKET CONTEXT
    # ==================================================

    market_context = {
        "news_risk": bool(news_risk),
        "range_penalty": round(
            range_penalty,
            2
        ),
        "trend_score": trend_score,
        "momentum_score": momentum_score
    }

    # ======================================================
    # MARKET CONTEXT
    # ======================================================

    try:

        session_data = apply_session_bias(symbol)

    except Exception:

        session_data = {
            "active": "UNKNOWN",
            "bias": "neutral"
        }

    market_context = {
        "session": session_data,
        "news": {
            "risk": "HIGH" if news_risk else "LOW",
            "headline_count": 1 if news_risk else 0
        }
    }

    # ==================================================
    # RETURN
    # ==================================================

    return {

        "timestamp": ts,

        "direction": direction,

        "confidence": confidence,

        "probabilities": p_map,

        "market_context": market_context,

        "score": round(
            max(
                logits["LONG"],
                logits["SHORT"]
            ),
            2
        ),

        "actionable": actionable,

        "reasons": reasons,

        "xai": explain,

        "smart_money": smart_money,

        "market_context": market_context,
    }
