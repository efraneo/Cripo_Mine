# core/scanner/opportunity_ranking_engine.py

import numpy as np


class OpportunityRankingEngine:

    """
    Motor institucional para rankear oportunidades de trading.
    """

    def __init__(self):

        # pesos institucionales
        self.weights = {
            "confidence": 0.35,
            "capital_efficiency": 0.20,
            "liquidity": 0.15,
            "volatility": 0.15,
            "risk_reward": 0.15
        }

    # ======================================================
    # NORMALIZATION
    # ======================================================

    def _normalize(self, value, min_v, max_v):
        if max_v - min_v == 0:
            return 0.5
        return (value - min_v) / (max_v - min_v)

    # ======================================================
    # SCORE OPPORTUNITY
    # ======================================================

    def score_opportunity(self, opp):
        confidence = opp.get("confidence", 0.5)
        capital_fraction = opp.get("capital_fraction", 0.1)
        liquidity = opp.get("liquidity_score", 0.5)
        volatility = opp.get("volatility_score", 0.5)
        rr = opp.get("risk_reward", 1.0)

        score = (
            confidence * self.weights["confidence"]
            + capital_fraction * self.weights["capital_efficiency"]
            + liquidity * self.weights["liquidity"]
            + (1 - volatility) * self.weights["volatility"]
            + rr * self.weights["risk_reward"]
        )
        return score

    # ======================================================
    # RANK OPPORTUNITIES
    # ======================================================

    def rank(self, opportunities):
        ranked = []

        for opp in opportunities:
            score = self.score_opportunity(opp)
            opp["score"] = float(score)
            ranked.append(opp)

        ranked = sorted(
            ranked,
            key=lambda x: x["score"],
            reverse=True
        )
        return ranked
