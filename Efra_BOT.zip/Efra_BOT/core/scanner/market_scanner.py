# core/scanner/market_scanner.py

import logging
import time
from core.scanner.opportunity_ranking_engine import OpportunityRankingEngine
from core.portfolio.cross_market_capital_allocator import CrossMarketCapitalAllocator

logger = logging.getLogger(__name__)


class InstitutionalMarketScanner:

    """
    Escáner institucional de mercado.

    Escanea múltiples símbolos
    ejecuta el pipeline IA
    rankea oportunidades
    """

    def __init__(self, exchange, ia_pipeline):

        self.exchange = exchange
        self.ia_pipeline = ia_pipeline
        self.ranker = OpportunityRankingEngine()
        self.allocator = CrossMarketCapitalAllocator()

    # =========================================================
    # GET MARKET SYMBOLS
    # =========================================================

    def get_tradeable_symbols(self):

        markets = self.exchange.load_markets()

        symbols = []

        for symbol, data in markets.items():

            if "/USDT" in symbol and data.get("active", True):

                symbols.append(symbol)

        return symbols

    # =========================================================
    # SCAN MARKET
    # =========================================================

    def scan_market(self, limit=30):

        symbols = self.get_tradeable_symbols()
        opportunities = []
        logger.info(f"Scanning {len(symbols)} markets")

        for symbol in symbols[:limit]:
            try:
                ia = self.ia_pipeline.run(symbol)
                if not ia:
                    continue
                if not ia.get("actionable"):
                    continue
                opportunities.append({
                    "symbol": symbol,
                    "action": ia.get("action"),
                    "confidence": ia.get("confidence", 0),
                    "capital_fraction": ia.get("capital_fraction", 0)
                })
            except Exception as e:
                logger.warning(f"Scanner error {symbol}: {e}")

            time.sleep(0.2)

        opportunities = self.ranker.rank(opportunities)
        opportunities = self.allocator.allocate(opportunities)

        return opportunities

    # =========================================================
    # TOP OPPORTUNITIES
    # =========================================================

    def top_opportunities(self, n=5):
        results = self.scan_market()
        return results[:n]