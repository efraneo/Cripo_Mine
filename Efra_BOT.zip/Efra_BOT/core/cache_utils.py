# core/cache_utils.py
"""
Funciones cacheadas para obtener símbolos y balance.
Usan st.cache_data para integrarse bien con Streamlit.
"""

import streamlit as st
from typing import List

@st.cache_data(ttl=300, show_spinner=False)
def cached_get_symbols(_engine) -> List[str]:
    try:
        symbols_list = None
        if getattr(_engine, "binance", None):
            b = _engine.binance
            if getattr(b, "get_all_symbols", None):
                symbols_list = b.get_all_symbols()
            elif getattr(b, "get_symbols", None):
                symbols_list = b.get_symbols()
            elif getattr(b, "get_all_tickers", None):
                res = b.get_all_tickers()
                symbols_list = [r.get("symbol") for r in res if isinstance(r, dict)]

        if not symbols_list and getattr(_engine, "get_symbols", None):
            symbols_list = _engine.get_symbols()

        if not symbols_list:
            return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

        cleaned = []
        for s in symbols_list:
            if isinstance(s, dict) and "symbol" in s:
                cleaned.append(str(s["symbol"]).upper())
            else:
                cleaned.append(str(s).upper())
        cleaned = sorted(set(cleaned))
        usdt = [c for c in cleaned if c.endswith("USDT")]
        others = [c for c in cleaned if not c.endswith("USDT")]
        return usdt + others
    except Exception as e:
        # fallback hardcoded
        return ["BTCUSDT", "ETHUSDT", "BNBUSDT"]

@st.cache_data(ttl=120, show_spinner=False)
def cached_get_balance(_engine, asset="USDT"):
    try:
        if getattr(_engine, "binance", None):
            b = _engine.binance
            if getattr(b, "get_spot_balance", None):
                res = b.get_spot_balance(asset)
                if isinstance(res, dict) and res.get("ok"):
                    return float(res.get("free", 0.0))
            if getattr(b, "get_asset_balance", None):
                bal = b.get_asset_balance(asset)
                if isinstance(bal, dict):
                    return float(bal.get("free") or bal.get("balance") or 0.0)
                if isinstance(bal, (int, float, str)):
                    return float(bal)
        if getattr(_engine, "get_balance", None):
            bal = _engine.get_balance(asset)
            if isinstance(bal, (int, float, str)):
                return float(bal)
        return 0.0
    except Exception:
        return 0.0
