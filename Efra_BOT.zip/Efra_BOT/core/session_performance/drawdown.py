import numpy as np

def rolling_drawdown(equity_curve: list[float]) -> dict:
    """
    Calcula drawdown máximo y actual sobre curva de equity.
    """

    if not equity_curve or len(equity_curve) < 2:
        return {
            "max_dd": 0.0,
            "current_dd": 0.0,
            "peak": None
        }

    equity = np.array(equity_curve)
    peaks = np.maximum.accumulate(equity)

    drawdowns = (equity - peaks) / peaks

    return {
        "max_dd": float(drawdowns.min()),          # negativo
        "current_dd": float(drawdowns[-1]),
        "peak": float(peaks[-1])
    }
