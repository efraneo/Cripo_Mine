from datetime import datetime
from collections import defaultdict

from core.session_performance.drawdown import rolling_drawdown
from core.session_performance.performance_metrics import compute_performance
from core.market_context.session_adapter import get_session_context
from core.learning.rolling_winrate import update_rolling_trade
from core.learning.regime_winrate import record_regime_trade


# ======================================================
# 🏛 ESTADO EN MEMORIA (MVP INSTITUCIONAL)
# ======================================================
_SESSION_STATE = {
    "equity_curve": [],
    "trades": defaultdict(list),
    "global_trades": []
}


# ======================================================
# 📌 RECORD TRADE
# ======================================================
def record_trade(trade: dict):
    """
    trade = {
        pnl: float,
        r_multiple: float,
        symbol: str
    }
    """

    session = get_session_context(trade["symbol"]).get("active", "UNKNOWN")

    _SESSION_STATE["trades"][session].append(trade)
    _SESSION_STATE["global_trades"].append(trade)

    last_equity = (
        _SESSION_STATE["equity_curve"][-1]
        if _SESSION_STATE["equity_curve"]
        else 100.0
    )

    _SESSION_STATE["equity_curve"].append(last_equity + trade["pnl"])

    #Agregue esto para probar 🧠 ROLLING WIN RATE LEARNING
    update_rolling_trade(trade["pnl"])

    record_regime_trade(
        trade.get("regime", "UNKNOWN"),
        trade["pnl"]
    )


# ======================================================
# 📊 GLOBAL PERFORMANCE
# ======================================================
def _compute_global_stats(trades):

    wins = sum(1 for t in trades if t.get("pnl", 0) > 0)
    losses = sum(1 for t in trades if t.get("pnl", 0) < 0)

    total = len(trades)
    pnl_total = sum(t.get("pnl", 0) for t in trades)

    win_rate = wins / total if total > 0 else 0.5

    return {
        "wins": wins,
        "losses": losses,
        "total_trades": total,
        "win_rate": win_rate,
        "pnl_total": pnl_total
    }


# ======================================================
# 📊 SESSION STATS (MAIN ENTRY)
# ======================================================
def get_session_stats() -> dict:
    """
    Stats globales + por sesión
    """

    equity_curve = _SESSION_STATE["equity_curve"]
    global_trades = _SESSION_STATE["global_trades"]

    dd = rolling_drawdown(equity_curve)

    # -----------------------------------
    # GLOBAL
    # -----------------------------------
    global_stats = _compute_global_stats(global_trades)

    # -----------------------------------
    # POR SESSION
    # -----------------------------------
    session_stats = {}

    for session, trades in _SESSION_STATE["trades"].items():
        session_stats[session] = compute_performance(trades)

    return {
        "timestamp": datetime.utcnow().isoformat(),

        # 🔥 GLOBAL (CRÍTICO PARA KELLY + BAYES)
        "wins": global_stats["wins"],
        "losses": global_stats["losses"],
        "total_trades": global_stats["total_trades"],
        "win_rate": global_stats["win_rate"],
        "pnl_total": global_stats["pnl_total"],

        # 🔥 RISK CORE
        "drawdown": dd,

        # 🔥 CONTEXTO
        "sessions": session_stats,

        # DEBUG / OPS
        "equity_curve_len": len(equity_curve)
    }
