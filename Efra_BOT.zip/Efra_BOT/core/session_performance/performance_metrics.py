def compute_performance(trades: list[dict]) -> dict:
    """
    trades: [{pnl, r_multiple}]
    """

    if not trades:
        return {
            "winrate": 0.0,
            "expectancy": 0.0,
            "avg_r": 0.0,
            "count": 0
        }

    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] <= 0]

    winrate = len(wins) / len(trades)

    avg_win = sum(t["r_multiple"] for t in wins) / len(wins) if wins else 0
    avg_loss = abs(sum(t["r_multiple"] for t in losses) / len(losses)) if losses else 0

    expectancy = (winrate * avg_win) - ((1 - winrate) * avg_loss)

    return {
        "winrate": round(winrate * 100, 2),
        "expectancy": round(expectancy, 3),
        "avg_r": round(avg_win - avg_loss, 3),
        "count": len(trades)
    }
