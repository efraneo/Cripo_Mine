"""
Market Utils
Acceso seguro y NORMALIZADO a datos de mercado multi-timeframe
Contrato único OHLCV para todo el sistema
"""

import logging
from typing import Dict
import streamlit as st
import pandas as pd

try:
    from backend.log_manager import get_logger
    log = get_logger("market_utils")
except Exception:
    log = logging.getLogger("market_utils")


# ==========================================================
# NORMALIZADOR OHLCV (DOBLE FORMATO)
# ==========================================================
def _normalize_to_df(raw) -> pd.DataFrame:
    if raw is None:
        return pd.DataFrame()

    if isinstance(raw, pd.DataFrame):
        df = raw.copy()
    elif isinstance(raw, list):
        df = pd.DataFrame(raw)
    else:
        return pd.DataFrame()

    # Columnas Binance / estándar
    col_map = {
        "open_time": "time",
        "timestamp": "time",
        "t": "time",
        "o": "open",
        "h": "high",
        "l": "low",
        "c": "close",
        "v": "volume",
    }

    df = df.rename(columns=col_map)

    if "time" not in df.columns:
        if df.index.name:
            df["time"] = df.index
        else:
            return pd.DataFrame()

    df["time"] = pd.to_datetime(df["time"], unit="ms", errors="coerce")

    for c in ("open", "high", "low", "close", "volume"):
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["time", "open", "high", "low", "close"])
    return df.reset_index(drop=True)


# ==========================================================
# API PÚBLICA (CRÍTICA)
# ==========================================================
def get_multi_tf_data_safe(symbol: str, timeframes: tuple) -> Dict[str, dict]:
    """
    Devuelve por timeframe:
    {
        "df": DataFrame,
        "ohlcv": list[dict]
    }
    """

    engine = st.session_state.get("engine")
    if not engine:
        log.error("Engine no disponible en session_state")
        return {}

    if not hasattr(engine, "get_ohlcv"):
        log.error("TradingEngine no expone get_ohlcv")
        return {}

    results = {}

    for tf in timeframes:
        try:
            raw = engine.get_ohlcv(symbol=symbol, timeframe=tf, limit=300)
            df = _normalize_to_df(raw)

            if df.empty:
                log.warning(f"Datos vacíos {symbol} {tf}")
                continue

            results[tf] = {
                "df": df,
                "ohlcv": df.to_dict("records")
            }

        except Exception:
            log.exception(f"Error obteniendo datos {symbol} {tf}")

    return results
