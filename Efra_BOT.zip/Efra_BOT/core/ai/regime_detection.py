# core/ai/regime_detection.py

import numpy as np


def detect_regime(returns, vol_window=30):

    if len(returns) < vol_window:
        return "UNKNOWN"

    vol = np.std(returns[-vol_window:])
    trend = np.mean(returns[-vol_window:])

    if vol > 0.03 and trend < 0:
        return "CRISIS"

    if vol > 0.02:
        return "HIGH_VOL"

    if trend > 0.001:
        return "TREND_BULL"

    if trend < -0.001:
        return "TREND_BEAR"

    return "RANGE"
