# core/ai/super_risk_ai.py

from core.ai.regime_detection import detect_regime
from core.portfolio.kelly_allocator import regime_scaled_kelly
from core.risk.liquidity_engine import liquidity_score
from core.risk.tail_hedging import tail_hedge_signal


def super_risk_pipeline(
    returns,
    win_rate,
    win_loss,
    order_size,
    avg_volume,
    spread,
    var_99,
    drawdown,
):

    regime = detect_regime(returns)

    kelly = regime_scaled_kelly(
        win_rate - ((1 - win_rate) / win_loss),
        regime
    )

    liq_score = liquidity_score(order_size, avg_volume, spread)

    hedge = tail_hedge_signal(var_99, drawdown)

    return {
        "regime": regime,
        "kelly": kelly,
        "liquidity_risk": liq_score,
        "tail_hedge": hedge
    }
