# core/trailing_stop.py

class TrailingStopManager:

    def __init__(self, trail_pct=0.02):
        self.trail_pct = trail_pct
        self.max_price = None

    def update(self, current_price):

        if self.max_price is None:
            self.max_price = current_price

        if current_price > self.max_price:
            self.max_price = current_price

        stop_price = self.max_price * (1 - self.trail_pct)

        return stop_price
