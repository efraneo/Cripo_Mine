# core/data/export_historical.py
"""
Exportador histórico PRO para ML
Genera CSVs en data/historical/
"""

import os
import pandas as pd
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv

# ==================================================
# Cargar binance.env explícitamente
# ==================================================
BASE_DIR = Path(__file__).resolve().parents[2]
ENV_PATH = BASE_DIR / "env" / "binance.env"

if not ENV_PATH.exists():
    raise RuntimeError(f"❌ No se encontró binance.env en {ENV_PATH}")

load_dotenv(dotenv_path=ENV_PATH)

# ==================================================
# Resolver claves Binance (tolerante a nombres)
# ==================================================
BINANCE_API_KEY = (
    os.getenv("BINANCE_API_KEY")
    or os.getenv("API_KEY")
    or os.getenv("BINANCE_KEY")
)

BINANCE_API_SECRET = (
    os.getenv("BINANCE_API_SECRET")
    or os.getenv("API_SECRET")
    or os.getenv("BINANCE_SECRET")
)

if not BINANCE_API_KEY or not BINANCE_API_SECRET:
    raise RuntimeError(
        "❌ No se pudieron resolver las claves de Binance desde binance.env"
    )

print("🔐 Binance API cargada correctamente")

# ==================================================
# Cliente Binance
# ==================================================
from backend.binance_client import BinanceClient

# ==================================================
# CONFIG
# ==================================================
SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
TIMEFRAME = "15m"
LIMIT = 2000  # ~20 días en 15m

OUT_DIR = BASE_DIR / "data" / "historical"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ==================================================
# Descarga y guardado
# ==================================================
def fetch_and_save(symbol: str):
    print(f"📥 Descargando {symbol} {TIMEFRAME}")

    client = BinanceClient(
        api_key=BINANCE_API_KEY,
        api_secret=BINANCE_API_SECRET
    )

    klines = client.get_klines(
        symbol=symbol,
        interval=TIMEFRAME,
        limit=LIMIT
    )

    if not klines:
        print(f"❌ Sin datos para {symbol}")
        return

    rows = []
    for k in klines:
        rows.append({
            "timestamp": datetime.utcfromtimestamp(k[0] / 1000).isoformat(),
            "open": float(k[1]),
            "high": float(k[2]),
            "low": float(k[3]),
            "close": float(k[4]),
            "volume": float(k[5]),
        })

    df = pd.DataFrame(rows)

    out = OUT_DIR / f"{symbol}_{TIMEFRAME}.csv"
    df.to_csv(out, index=False)

    print(f"✅ Guardado {out} ({len(df)} velas)")

# ==================================================
# MAIN
# ==================================================
def main():
    for s in SYMBOLS:
        fetch_and_save(s)

if __name__ == "__main__":
    main()
