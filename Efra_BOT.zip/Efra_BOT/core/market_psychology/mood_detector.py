#core/market_psychology/mood_detector.py

def detect_market_mood(market_context: dict) -> dict:
    news_risk = market_context.get("news", {}).get("risk", "low")
    session = market_context.get("session", {}).get("active")

    if news_risk == "high":
        return {"mood": "FEAR", "modifier": -15}

    if session in ("ASIA",) and news_risk == "low":
        return {"mood": "LOW_LIQUIDITY", "modifier": -5}

    if session == "NEW_YORK" and news_risk == "low":
        return {"mood": "RISK_ON", "modifier": +5}

    return {"mood": "NEUTRAL", "modifier": 0}
