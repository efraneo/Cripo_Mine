# core/engine_utils.py
"""
Engine Utils PRO — IA CANÓNICA
✔ NO recalcula IA
✔ Preview + Execute usan la MISMA decisión IA
✔ Streamlit-safe
"""

import os
import logging
from datetime import datetime
import streamlit as st

from backend.binance_manager import BinanceManager
from backend.order_manager import OrderManager
from backend.risk_manager import RiskManager
from backend.trading_engine import init_engine_singleton, get_engine_singleton

log = logging.getLogger("core.engine_utils")


# ======================================================
# LAZY INIT ENGINE (STREAMLIT SAFE)
# ======================================================
def lazy_init_engine(force: bool = False):
    if not force and st.session_state.get("engine") is not None:
        return st.session_state["engine"]

    if st.session_state.get("engine_init_attempted") and not force:
        return st.session_state.get("engine")

    st.session_state["engine_init_attempted"] = True

    try:
        binance_mgr = BinanceManager(
            api_key=os.getenv("BINANCE_API_KEY", ""),
            api_secret=os.getenv("BINANCE_API_SECRET", ""),
            base_url=os.getenv("BINANCE_BASE_URL", "https://api.binance.com"),
        )

        om = OrderManager({"mode": os.getenv("BOT_MODE", "DEMO")})
        rm = RiskManager()

        eng = init_engine_singleton(
            binance=binance_mgr,
            order_manager=om,
            risk_manager=rm,
            predictor=None,
            feature_builder=None,
        )

        try:
            eng = get_engine_singleton()
        except Exception:
            pass

        st.session_state["engine"] = eng
        log.info("Engine inicializado (lazy).")
        return eng

    except Exception as e:
        log.exception("lazy_init_engine failed")
        st.session_state["engine"] = None
        return None


# ======================================================
# 🧠 PREVIEW DESDE IA CANÓNICA (OBLIGATORIO)
# ======================================================
def preview_trade_from_ia(symbol: str, amount: float, ia_decision: dict):
    """
    Preview PRO:
    ✔ NO recalcula IA
    ✔ Usa IA ya validada por UI
    """

    if not ia_decision:
        return {"status": "ERROR", "reason": "IA_DECISION_REQUIRED"}

    engine = lazy_init_engine()
    if not engine:
        return {"status": "ERROR", "reason": "ENGINE_NOT_AVAILABLE"}

    confidence = float(ia_decision.get("confidence", 0))
    if confidence < 0.9:
        return {
            "status": "REJECTED",
            "reason": "IA_CONFIDENCE_TOO_LOW",
            "confidence": confidence,
        }

    preview = {
        "symbol": symbol,
        "amount": float(amount),
        "direction": ia_decision.get("direction"),
        "confidence": confidence,
        "ia_confidence_pct": round(confidence * 100.0, 2),
        "tps": ia_decision.get("tps"),
        "sl": ia_decision.get("sl"),
        "regime": ia_decision.get("regime"),
        "xai": ia_decision.get("xai"),
        "source": "IA_PRO_CANONICAL",
        "timestamp": datetime.utcnow().isoformat(),
    }

    return {
        "status": "OK",
        "preview": preview,
    }


# ======================================================
# 🚀 EJECUCIÓN DESDE IA CANÓNICA (BLINDADA)
# ======================================================
from core.portfolio.portfolio_decider import evaluate_ia_for_portfolio
from core.strategy.strategy_allocator import allocate_strategy

def execute_trade_from_ia(symbol, amount, ia_decision):

    # --------------------------------------------------
    # 1️⃣ BLOQUEO IA BÁSICO
    # --------------------------------------------------
    if not ia_decision.get("actionable"):
        return {
            "status": "blocked",
            "reason": "IA no accionable"
        }

    # --------------------------------------------------
    # 🔟 STRATEGY ALLOCATION (FASE 10)
    # --------------------------------------------------
    allowed, payload = allocate_strategy(symbol, ia_decision)

    if not allowed:
        ia_decision["actionable"] = False
        ia_decision["reasons"].append({
            "rule": "STRATEGY_ALLOCATION",
            "status": "FAIL",
            "details": payload
        })
        return {"status": "blocked", "reason": payload}

    # --------------------------------------------------
    # 2️⃣ PORTFOLIO GUARD (FASE 9)
    # --------------------------------------------------
    allowed, payload = evaluate_ia_for_portfolio(symbol, ia_decision)

    if not allowed:
        ia_decision["actionable"] = False
        ia_decision["confidence"] = 0

        ia_decision.setdefault("reasons", []).append({
            "rule": "PORTFOLIO_GUARD",
            "status": "FAIL",
            "details": payload
        })

        return {
            "status": "blocked",
            "reason": "Portfolio guard",
            "details": payload
        }

    # --------------------------------------------------
    # 3️⃣ EJECUCIÓN REAL (OMS)
    # --------------------------------------------------
    order = client.create_order(
        symbol=symbol,
        side=ia_decision["direction"],
        size=payload["size"],   # ⬅️ MUY IMPORTANTE
    )

    return {
        "status": "executed",
        "order": order
    }
