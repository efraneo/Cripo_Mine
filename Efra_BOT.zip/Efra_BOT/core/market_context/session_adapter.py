from datetime import datetime
import pytz
import logging

log = logging.getLogger("session_adapter")


def _fallback_session() -> dict:
    now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    hour = now.hour

    if 0 <= hour < 7:
        name = "ASIA"
    elif 7 <= hour < 13:
        name = "EUROPE"
    elif 13 <= hour < 20:
        name = "NEW_YORK"
    else:
        name = "OVERLAP"

    return {
        "active": name,
        "bias": "neutral",
        "confidence": 55,
        "details": {"fallback": True}
    }


def get_session_context(symbol: str) -> dict:
    """
    Determina la sesión institucional dominante.
    Nunca lanza excepción.
    """

    try:
        from core.market_context.sessions.asia import analyze_asia
        from core.market_context.sessions.europe import analyze_europe
        from core.market_context.sessions.new_york import analyze_new_york

        asia = analyze_asia(symbol)
        europe = analyze_europe(symbol)
        ny = analyze_new_york(symbol)

        dominant = max(
            [asia, europe, ny],
            key=lambda x: x.get("confidence", 0)
        )

        return {
            "active": dominant["name"],
            "bias": dominant["bias"],
            "confidence": dominant["confidence"],
            "details": {
                "asia": asia,
                "europe": europe,
                "new_york": ny,
            }
        }

    except Exception as e:
        log.warning(f"Session analysis unavailable, fallback used: {e}")
        return _fallback_session()
