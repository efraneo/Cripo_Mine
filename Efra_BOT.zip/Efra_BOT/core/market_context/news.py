# core/market_context/news.py
"""
Institutional News Risk Engine
------------------------------
Evalúa riesgo macro-institucional por horario.
NO usa feeds externos (fase 1).
Se centra en cuándo los institucionales EVITAN operar.
"""

from datetime import datetime, timezone
from typing import Dict, Any


# ==========================================================
# VENTANAS DE RIESGO MACRO (UTC)
# ==========================================================
# Estas horas concentran:
# - CPI
# - NFP
# - FOMC
# - Powell / Lagarde
# - Inventarios energéticos
# - Flash crashes inducidos por noticias

HIGH_RISK_WINDOWS = [
    (12, 14),   # 12:00–14:00 UTC → macro USA / Europa
    (18, 20),   # 18:00–20:00 UTC → FOMC / Powell
]

MEDIUM_RISK_WINDOWS = [
    (7, 9),     # Europa open
    (13, 15),   # NY open
]


# ==========================================================
# HELPERS
# ==========================================================

def _utc_hour(now: datetime | None = None) -> int:
    if not now:
        now = datetime.now(timezone.utc)
    return now.hour


def _in_window(hour: int, start: int, end: int) -> bool:
    return start <= hour < end


# ==========================================================
# API PRINCIPAL
# ==========================================================

def get_news_risk(symbol: str | None = None, now: datetime | None = None) -> Dict[str, Any]:
    """
    Evalúa riesgo institucional por ventana horaria.

    Returns:
        {
            "risk": "low" | "medium" | "high" | "unknown",
            "impact": [],
            "headline_count": int,
            "details": {
                "utc_hour": int,
                "reason": str
            }
        }
    """

    hour = _utc_hour(now)

    for start, end in HIGH_RISK_WINDOWS:
        if _in_window(hour, start, end):
            return {
                "risk": "high",
                "impact": [],
                "headline_count": 1,
                "details": {
                    "utc_hour": hour,
                    "reason": "Ventana macroeconómica de alto impacto (institucional)"
                }
            }

    for start, end in MEDIUM_RISK_WINDOWS:
        if _in_window(hour, start, end):
            return {
                "risk": "medium",
                "impact": [],
                "headline_count": 1,
                "details": {
                    "utc_hour": hour,
                    "reason": "Apertura de sesión con volatilidad inducida"
                }
            }

    return {
        "risk": "low",
        "impact": [],
        "headline_count": 0,
        "details": {
            "utc_hour": hour,
            "reason": "Sin eventos macro relevantes detectados"
        }
    }
