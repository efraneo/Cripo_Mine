# core/market_context/news_adapter.py

from core.market_context.news import get_news_risk


def get_news_context(symbol: str) -> dict:
    """
    Adaptador institucional de riesgo por noticias.
    """

    news = get_news_risk(symbol)

    return {
        "risk": news.get("risk", "unknown"),
        "impact": news.get("impact", []),
        "headline_count": news.get("headline_count", 0),
        "details": news.get("details", {})
    }
