# core/market_context/context_builder.py

import logging
from datetime import datetime, timezone

from core.market_context.session_adapter import get_session_context
from core.market_context.news_adapter import get_news_context

try:
    from backend.log_manager import get_logger
    log = get_logger("market_context")
except Exception:
    log = logging.getLogger("market_context")


def build_market_context(symbol: str) -> dict:
    """
    Construye el contexto macro institucional del mercado.
    NO decide trades.
    SOLO condiciona la IA.
    """

    context = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session": {},
        "news": {},
        "global_bias": "neutral",
        "confidence_modifier": 0,
        "reasons": []
    }

    try:
        session_ctx = get_session_context(symbol)
        context["session"] = session_ctx

        if session_ctx.get("bias") == "bullish":
            context["confidence_modifier"] += 5
            context["global_bias"] = "bullish"
            context["reasons"].append("Sesión dominante con sesgo alcista")
        elif session_ctx.get("bias") == "bearish":
            context["confidence_modifier"] -= 5
            context["global_bias"] = "bearish"
            context["reasons"].append("Sesión dominante con sesgo bajista")

    except Exception:
        log.exception("Session context failed")
        context["reasons"].append(
            "Contexto de sesiones no disponible — usando fallback institucional"
        )

    try:
        news_ctx = get_news_context(symbol)
        context["news"] = news_ctx

        if news_ctx.get("risk") == "high":
            context["confidence_modifier"] -= 10
            context["reasons"].append("Noticias de alto impacto detectadas")

    except Exception:
        log.exception("News context failed")
        context["reasons"].append(
            "Motor de noticias no disponible — riesgo no cuantificado"
        )

    return context
