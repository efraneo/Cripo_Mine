# core/market_context/sessions.py
"""
Institutional Trading Sessions Engine
-------------------------------------
Detecta sesión dominante, sesgo institucional y nivel de confianza
basado en horario UTC y reglas profesionales de mercado.
"""

from datetime import datetime, timezone
from typing import Dict, Any


# ==========================================================
# DEFINICIÓN DE SESIONES INSTITUCIONALES (UTC)
# ==========================================================

SESSIONS = {
    "ASIA": {
        "start": 23,   # 23:00 UTC
        "end": 7,      # 07:00 UTC
        "default_bias": "neutral",
        "confidence": 60
    },
    "EUROPE": {
        "start": 7,    # 07:00 UTC
        "end": 13,     # 13:00 UTC
        "default_bias": "bullish",
        "confidence": 75
    },
    "NY": {
        "start": 13,   # 13:00 UTC
        "end": 21,     # 21:00 UTC
        "default_bias": "volatile",
        "confidence": 85
    },
    "NY_CLOSE": {
        "start": 21,   # 21:00 UTC
        "end": 23,     # 23:00 UTC
        "default_bias": "range",
        "confidence": 55
    }
}


# ==========================================================
# HELPERS
# ==========================================================

def _utc_hour_now() -> int:
    return datetime.now(timezone.utc).hour


def _in_session(hour: int, start: int, end: int) -> bool:
    """
    Maneja rangos normales y rangos cruzando medianoche.
    """
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end


# ==========================================================
# API PRINCIPAL
# ==========================================================

def get_market_session(now: datetime | None = None) -> Dict[str, Any]:
    """
    Devuelve el contexto institucional de sesión actual.

    Returns:
        {
            "active": "ASIA" | "EUROPE" | "NY" | "NY_CLOSE",
            "bias": "bullish" | "bearish" | "neutral" | "range" | "volatile",
            "confidence": int (0–100),
            "details": {
                "utc_hour": int,
                "fallback": False
            }
        }
    """

    if not now:
        now = datetime.now(timezone.utc)

    hour = now.hour

    for name, cfg in SESSIONS.items():
        if _in_session(hour, cfg["start"], cfg["end"]):
            return {
                "active": name,
                "bias": cfg["default_bias"],
                "confidence": cfg["confidence"],
                "details": {
                    "utc_hour": hour,
                    "fallback": False
                }
            }

    # 🔒 Fallback ultra defensivo (no debería ocurrir)
    return {
        "active": "UNKNOWN",
        "bias": "neutral",
        "confidence": 40,
        "details": {
            "utc_hour": hour,
            "fallback": True
        }
    }
