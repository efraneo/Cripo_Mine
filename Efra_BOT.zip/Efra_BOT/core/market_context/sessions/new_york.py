from datetime import datetime
import pytz


def analyze_new_york(symbol: str) -> dict:
    now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    hour = now.hour

    active = 13 <= hour < 20

    return {
        "name": "NEW_YORK",
        "bias": "neutral",
        "confidence": 85 if active else 25,
        "active": active
    }
