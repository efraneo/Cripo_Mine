from datetime import datetime
import pytz


def analyze_europe(symbol: str) -> dict:
    now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    hour = now.hour

    active = 7 <= hour < 13

    return {
        "name": "EUROPE",
        "bias": "neutral",
        "confidence": 75 if active else 20,
        "active": active
    }
