from datetime import datetime
import pytz


def analyze_asia(symbol: str) -> dict:
    """
    Análisis institucional sesión ASIA
    """
    now = datetime.utcnow().replace(tzinfo=pytz.UTC)
    hour = now.hour

    active = 0 <= hour < 7

    return {
        "name": "ASIA",
        "bias": "neutral",
        "confidence": 70 if active else 15,
        "active": active
    }
