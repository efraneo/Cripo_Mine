import json
import hashlib
from datetime import datetime


def canonical_ia_hash(ia_decision: dict) -> str:
    """
    Genera hash determinístico del snapshot IA.
    - Ordena claves
    - Elimina campos volátiles
    """

    if not isinstance(ia_decision, dict):
        raise ValueError("ia_decision debe ser dict")

    volatile_keys = {"timestamp"}

    clean = {
        k: v
        for k, v in ia_decision.items()
        if k not in volatile_keys
    }

    payload = json.dumps(
        clean,
        sort_keys=True,
        ensure_ascii=False,
        default=str,
    )

    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
