# core/post_trade/post_trade_analyzer.py

from core.post_trade.trade_metrics import compute_trade_metrics
from core.post_trade.ia_feedback import update_ia_feedback
from core.post_trade.regime_feedback import update_regime_memory
from core.post_trade.session_memory import update_session_stats

def analyze_trade(trade: dict, ia_decision: dict):
    """
    Post-trade intelligence canonical entry point.
    """

    metrics = compute_trade_metrics(trade)

    # -----------------------------
    # Feedback IA
    # -----------------------------
    update_ia_feedback(ia_decision, metrics)

    # -----------------------------
    # Feedback régimen
    # -----------------------------
    update_regime_memory(
        regime=ia_decision.get("regime"),
        metrics=metrics
    )

    # -----------------------------
    # Sesión / capital
    # -----------------------------
    update_session_stats(metrics)

    return metrics
