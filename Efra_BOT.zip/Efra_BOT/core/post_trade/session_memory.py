# core/post_trade/session_memory.py

_SESSION_STATS = {
    "trades": 0,
    "wins": 0,
    "losses": 0,
    "pnl_total": 0,
    "drawdown": 0,
    "peak": 0,
}

def update_session_stats(metrics: dict):
    s = _SESSION_STATS

    s["trades"] += 1
    s["pnl_total"] += metrics["pnl"]

    if metrics["win"]:
        s["wins"] += 1
    else:
        s["losses"] += 1

    # drawdown rolling
    s["peak"] = max(s["peak"], s["pnl_total"])
    s["drawdown"] = s["peak"] - s["pnl_total"]

def get_session_stats():
    return _SESSION_STATS.copy()
