# core/post_trade/trade_metrics.py

def compute_trade_metrics(trade: dict) -> dict:
    """
    Métricas institucionales post-trade.
    """

    entry = trade["entry_price"]
    exit_ = trade["exit_price"]
    side = trade["side"]

    pnl = (exit_ - entry) if side == "LONG" else (entry - exit_)
    pnl_pct = pnl / entry * 100

    return {
        "pnl": pnl,
        "pnl_pct": pnl_pct,
        "win": pnl > 0,
        "duration_sec": trade.get("duration_sec", 0),
        "slippage": trade.get("slippage", 0),
        "fees": trade.get("fees", 0),
    }
