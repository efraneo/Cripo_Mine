# core/post_trade/ia_feedback.py

def update_ia_feedback(ia: dict, metrics: dict):
    """
    Ajusta confianza futura de la IA.
    """

    score = ia.get("score", 0)

    if metrics["win"]:
        score += 0.5
    else:
        score -= 1.0

    ia["score"] = max(-10, min(10, score))
