# core/post_trade/regime_feedback.py

_REGIME_MEMORY = {}

def update_regime_memory(regime: str, metrics: dict):
    if not regime:
        return

    mem = _REGIME_MEMORY.setdefault(regime, {
        "wins": 0,
        "losses": 0
    })

    if metrics["win"]:
        mem["wins"] += 1
    else:
        mem["losses"] += 1
