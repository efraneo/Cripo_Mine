# core/post_trade/post_trade_orchestrator.py

from core.capital_rotation.capital_rotator import rotate_capital
from core.session.session_stats import get_strategy_stats
from core.ia_audit_log import get_ia_audit_logger

log = get_ia_audit_logger()


def end_of_session_rotation(trigger: str = "SESSION_END") -> dict:
    """
    Ejecuta rotación de capital entre estrategias.
    Se llama SOLO post-trade o cierre de sesión.
    """

    stats = get_strategy_stats()

    if not stats:
        return {"status": "NO_STATS", "decisions": {}}

    decisions = rotate_capital(stats)

    log.log_event(
        context="CAPITAL_ROTATION",
        payload={
            "trigger": trigger,
            "decisions": decisions,
            "stats_snapshot": stats,
        }
    )

    return {
        "status": "ROTATION_EXECUTED",
        "decisions": decisions
    }
