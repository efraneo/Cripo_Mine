# core/notifications/telegram_pro.py

import os
import requests
import tempfile
from datetime import datetime


# ======================================================
# EMOJIS INTELIGENTES
# ======================================================

def _get_trade_emoji(side: str, confidence: float):
    side = str(side).upper()

    if side in ["BUY", "LONG"]:
        return "🟢📈🐂" if confidence > 75 else "🟡📈"
    elif side in ["SELL", "SHORT"]:
        return "🔴📉🐻" if confidence > 75 else "🟡📉"

    return "⚪"


# ======================================================
# GIF DINÁMICO
# ======================================================

def _get_gif_url(side: str):
    side = str(side).upper()

    if side in ["BUY", "LONG"]:
        return "https://media.giphy.com/media/l0HlBO7eyXzSZkJri/giphy.gif"
    return "https://media.giphy.com/media/3o7TKtnuHOHHUjR38Y/giphy.gif"


# ======================================================
# BUILD MENSAJE PRO
# ======================================================

def _build_message(symbol, side, confidence, entry, sl, tp, ia=None, username=None):

    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    emoji = _get_trade_emoji(side, confidence)

    # ------------------------------------------
    # SEÑALES IA
    # ------------------------------------------
    signals = ""

    if ia:
        reasons = ia.get("reasons", [])
        for r in reasons[:5]:
            status = "✅" if r.get("status") == "OK" else "❌"
            signals += f"\n{status} {r.get('rule')}"

    # ------------------------------------------
    # USUARIO
    # ------------------------------------------
    user_line = f"👤 Usuario: {username}\n" if username else ""

    return f"""
🏦 <b>EFRA BOT — TRADE INSTITUCIONAL</b>

{user_line}
📊 Activo: <b>{symbol}</b>
📈 Dirección: <b>{emoji} {side}</b>
🧠 Confianza IA: <b>{confidence:.2f}%</b>

💰 Entry: {entry}
🛑 Stop Loss: {sl}
🎯 Take Profit: {tp}

🧩 <b>Confluencias IA:</b>{signals}

🕒 {now}
"""


# ======================================================
# ENVÍO PRINCIPAL
# ======================================================

def send_telegram_trade_alert(
    symbol,
    side,
    confidence,
    entry,
    sl,
    tp,
    fig=None,
    ia=None,
    username=None
):

    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

    if not TOKEN or not CHAT_ID:
        return

    message = _build_message(
        symbol, side, confidence, entry, sl, tp, ia, username
    )

    gif_url = _get_gif_url(side)

    try:
        # ==================================================
        # 1. ENVIAR GIF (IMPACTO VISUAL)
        # ==================================================
        requests.post(
            f"https://api.telegram.org/bot{TOKEN}/sendAnimation",
            data={
                "chat_id": CHAT_ID,
                "animation": gif_url
            },
            timeout=10
        )

        # ==================================================
        # 2. ENVIAR GRÁFICA REAL
        # ==================================================
        if fig:

            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:

                fig.write_image(tmp.name, scale=2)

                with open(tmp.name, "rb") as f:

                    requests.post(
                        f"https://api.telegram.org/bot{TOKEN}/sendPhoto",
                        data={
                            "chat_id": CHAT_ID,
                            "caption": message,
                            "parse_mode": "HTML"
                        },
                        files={"photo": f},
                        timeout=15
                    )

                return

    except Exception as e:
        print("Telegram PRO error:", e)

    # ==================================================
    # 3. FALLBACK TEXTO
    # ==================================================
    try:
        requests.post(
            f"https://api.telegram.org/bot{TOKEN}/sendMessage",
            data={
                "chat_id": CHAT_ID,
                "text": message,
                "parse_mode": "HTML"
            },
            timeout=10
        )
    except Exception:
        pass
