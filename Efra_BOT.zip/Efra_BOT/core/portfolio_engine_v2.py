# core/portfolio_engine_v2.py

import numpy as np
import pandas as pd


class PortfolioEngineV2:

    def __init__(self, engine):
        self.engine = engine

    # ==========================================================
    # MATRIZ DE CORRELACIÓN
    # ==========================================================
    def compute_correlation_matrix(self, opportunities):

        price_data = {}

        for r in opportunities:
            symbol = r["symbol"]

            try:
                df = self.engine.get_ohlcv(symbol, "5m", 100)

                if not df:
                    continue

                closes = [c["close"] for c in df]
                price_data[symbol] = closes

            except Exception:
                continue

        if len(price_data) < 2:
            return None

        df_prices = pd.DataFrame(price_data)
        returns = df_prices.pct_change().dropna()

        return returns.corr()

    # ==========================================================
    # FILTRO POR CORRELACIÓN (NO SOBRE-EXPOSICIÓN)
    # ==========================================================
    def filter_correlation(self, opportunities, corr_matrix, threshold=0.8):

        if corr_matrix is None:
            return opportunities

        selected = []

        for r in opportunities:
            symbol = r["symbol"]

            allow = True

            for s in selected:
                if symbol in corr_matrix and s["symbol"] in corr_matrix:
                    corr = corr_matrix.loc[symbol, s["symbol"]]

                    if abs(corr) > threshold:
                        allow = False
                        break

            if allow:
                selected.append(r)

        return selected

    # ==========================================================
    # CONTROL DE DRAWDOWN GLOBAL
    # ==========================================================
    def check_drawdown(self, max_dd=0.15):

        try:
            from backend.equity_tracker import EquityTracker

            tracker = EquityTracker()
            curve = tracker.get_equity_curve()

            if len(curve) < 10:
                return True

            peak = max(curve)
            current = curve[-1]

            dd = (peak - current) / peak

            return dd < max_dd

        except Exception:
            return True

    # ==========================================================
    # ASIGNACIÓN INSTITUCIONAL
    # ==========================================================
    def allocate(self, opportunities, balance):

        if not opportunities:
            return []

        confidences = np.array([r["confidence"] for r in opportunities])

        # Penalización por correlación implícita (suavizado)
        weights = confidences / confidences.sum()

        # Cap institucional: máximo 30% por activo
        weights = np.clip(weights, 0, 0.3)
        weights = weights / weights.sum()

        allocations = []

        for r, w in zip(opportunities, weights):
            capital = balance * w

            allocations.append({
                "symbol": r["symbol"],
                "capital": float(capital),
                "weight": float(w),
                "ia": r["ia"]
            })

        return allocations

    # ==========================================================
    # REBALANCEO DINÁMICO
    # ==========================================================
    def rebalance_needed(self, current_allocs, new_allocs, threshold=0.1):

        for c, n in zip(current_allocs, new_allocs):
            if abs(c["weight"] - n["weight"]) > threshold:
                return True

        return False

    # ==========================================================
    # PIPELINE COMPLETO
    # ==========================================================
    def build_portfolio(self, opportunities, balance):

        # 1. Filtro base
        valid = [
            r for r in opportunities
            if r["confidence"] >= 85 and
            r["ia"].get("execution_policy", {}).get("allow_trade")
        ]

        if not valid:
            return []

        # 2. Correlación
        corr = self.compute_correlation_matrix(valid)

        # 3. Filtrado por correlación
        filtered = self.filter_correlation(valid, corr)

        # 4. Top 5
        filtered = sorted(filtered, key=lambda x: x["confidence"], reverse=True)[:5]

        # 5. Asignación
        return self.allocate(filtered, balance)
