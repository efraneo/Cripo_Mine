# core/execution/order_router.py

from datetime import datetime


def route_order(
    engine,
    order: dict
):

    mode = order.get(
        "mode",
        "MARKET"
    )

    orders = order.get(
        "orders",
        []
    )

    results=[]

    # ==========================================
    # DEMO MODE
    # ==========================================

    if mode=="DEMO":

        return {

            "status":"EXECUTED",

            "mode":"DEMO",

            "symbol":
            order["symbol"],

            "side":
            order["side"],

            "executed_qty":
            order["size"],

            "avg_price":
            0,

            "timestamp":
            datetime.utcnow().isoformat()
        }

    # ==========================================
    # MARKET
    # ==========================================

    elif mode=="MARKET":
        result = engine.execute_market_order(
            symbol=order["symbol"],
            side=order["side"],
            amount=order["size"]
        )
        result.setdefault(
            "entry_price",
            result.get(
                "price",
                0
            )
        )
        result.setdefault(
            "executed_qty",
            order["size"]
        )
        result.setdefault(
            "status",
            "EXECUTED"
        )
        return result

    # ==========================================
    # TWAP/VWAP/ICEBERG
    # ==========================================

    elif mode in [

        "TWAP",
        "VWAP",
        "ICEBERG"

    ]:

        total_qty=0
        weighted_price=0

        for o in orders:

            if o.get(
                "type"
            )=="limit":

                result=engine.execute_limit_order(

                    symbol=order["symbol"],

                    side=order["side"],

                    amount=o["size"],

                    price=o.get(
                        "price"
                    )
                )

            else:

                result=engine.execute_market_order(

                    symbol=order["symbol"],

                    side=order["side"],

                    amount=o["size"]
                )

            if (
                not result
                or
                result.get(
                    "status"
                )=="ERROR"
            ):

                return {

                    "status":
                    "FAILED",

                    "reason":
                    "Slice execution failed",

                    "failed_order":
                    o
                }

            results.append(
                result
            )

            qty=float(
                result.get(
                    "executed_qty",
                    0
                )
            )

            price=float(
                result.get(
                    "avg_price",
                    0
                )
            )

            total_qty+=qty

            weighted_price+=(
                price*qty
            )

        avg_price=(
            weighted_price
            /
            total_qty
        ) if total_qty>0 else 0

        return {

            "status":
            "EXECUTED",

            "mode":
            mode,

            "executions":
            results,

            "avg_price":
            avg_price,

            "total_qty":
            total_qty
        }

    raise NotImplementedError(
        f"Modo no soportado: {mode}"
    )
