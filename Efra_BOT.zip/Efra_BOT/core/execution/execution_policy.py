# core/execution/execution_policy.py

from core.risk.capital_preservation import capital_preservation_gate
from core.session_performance.session_tracker import get_session_stats

def resolve_execution_policy(ia: dict) -> dict:
    """
    Traduce decisión IA a política ejecutable.
    """

    policy = {
        "allow_execution": False,
        "reason": "No evaluado",
        "mode": "BLOCKED",
    }

    # 1️⃣ IA debe permitir entrada
    timing = ia.get("entry_timing", {})
    if timing.get("state") != "ENTER_NOW":
        policy["reason"] = "IA no autoriza entrada"
        return policy

    # 2️⃣ Capital preservation gate (FASE 5.2)
    session_stats = get_session_stats()
    gate = capital_preservation_gate(session_stats)

    if gate["block"]:
        policy["reason"] = gate["reason"]
        return policy

    # 3️⃣ Confianza mínima institucional
    if ia.get("confidence", 0) < 70:
        policy["reason"] = "Confianza < 70%"
        return policy

    policy.update({
        "allow_execution": True,
        "mode": "MARKET",
        "reason": "Condiciones OMS aprobadas"
    })

    return policy
