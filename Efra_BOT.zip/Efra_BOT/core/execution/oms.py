# core/execution/oms.py

from core.execution.execution_policy import resolve_execution_policy
from core.execution.order_validator import validate_order
from core.execution.position_sizer import calculate_position_size
from core.execution.order_router import route_order
from core.execution.execution_audit import log_execution

from backend.security_engine import SecurityEngine

def execute_via_oms(symbol: str, ia: dict, engine):
    """
    Punto único de ejecución institucional.

    Flujo institucional:
    IA → Execution Policy → Position Sizing → Validation → Routing → Audit → Trade History
    """

    security = SecurityEngine()

    ip = "unknown"
    username = ia.get("user")

    risk = security.compute_ip_risk(ip, username)

    if risk >= 80:

        security.log_security_event(
            username,
            ip,
            "TRADE_BLOCKED_RISK",
            risk
        )

        return {
            "status": "BLOCKED",
            "reason": "Security risk too high"
        }

    try:

        # ============================================================
        # RESOLVER POLÍTICA DE EJECUCIÓN
        # ============================================================

        policy = resolve_execution_policy(
            ia.get(
                "entry_timing",
                {}
            )
        )

        # ==========================================
        # USAR POLICY YA CALCULADA SI EXISTE
        # ==========================================

        if ia.get("execution_policy"):

            policy = ia["execution_policy"]

        if not policy.get(
            "allow_trade",
            False
        ):

            result = {
                "status": "BLOCKED",
                "reason": policy.get("reason", "Execution policy blocked trade")
            }

            # Registrar intento bloqueado
            try:
                if engine and hasattr(engine, "record_trade"):
                    engine.record_trade({
                        "symbol": symbol,
                        "side": ia.get("direction"),
                        "size": 0,
                        "price": None,
                        "confidence": ia.get("confidence"),
                        "strategy": ia.get("strategy"),
                        "mode": ia.get(
                            "execution_mode",
                            "DEMO"
                        ),
                        "status": "BLOCKED"
                    })
            except Exception:
                if engine and hasattr(engine, "log"):
                    engine.log.exception("Trade BLOCKED recording failed")

            return result

        # ============================================================
        # POSITION SIZING
        # ============================================================

        size = calculate_position_size(
            confidence=ia["confidence"],
            direction=ia["direction"]
        )

        # ============================================================
        # CONSTRUIR ORDEN
        # ============================================================

        order = {
            "symbol": symbol,
            "side": ia["direction"],
            "size": size,
            "mode": ia.get(
                "execution_mode",
                "DEMO"
            )
        }

        # ============================================================
        # VALIDACIÓN INSTITUCIONAL
        # ============================================================

        validate_order(order)

        # ============================================================
        # SECURITY ENGINE — ANTIFRAUDE
        # ============================================================

        try:

            sec = SecurityEngine()

            username = getattr(engine, "current_user", "unknown")
            ip = getattr(engine, "current_ip", "unknown")

            anomaly_score = sec.detect_anomaly(
                username=username,
                ip=ip,
                trade_amount=order["size"]
            )

            if anomaly_score >= 60:

                sec.auto_block_ip(ip, "Trade anomaly detected")

                return {
                    "status": "BLOCKED_SECURITY",
                    "reason": "Trade blocked by security engine",
                    "anomaly_score": anomaly_score
                }

        except Exception:
            if engine and hasattr(engine, "log"):
                engine.log.exception("SecurityEngine trade check failed")

        # ============================================================
        # ROUTING / EJECUCIÓN
        # ============================================================

        result = route_order(engine, order)

        # ============================================================
        # AUDITORÍA
        # ============================================================

        log_execution(symbol, ia, order, result)

        # ============================================================
        # REGISTRO EN TRADE HISTORY (CRÍTICO)
        # ============================================================

        try:
            if engine and hasattr(engine, "record_trade"):
                engine.record_trade({
                    "symbol": symbol,
                    "side": order["side"],
                    "size": order["size"],
                    "price": result.get("price"),
                    "confidence": ia.get("confidence"),
                    "strategy": ia.get("strategy"),
                    "mode": ia.get(
                        "execution_mode",
                        "DEMO"
                    ),
                    "status": result.get(
                        "status",
                        "EXECUTED"
                    )
                })

        except Exception:

            if engine and hasattr(engine, "log"):
                engine.log.exception("Trade history recording failed")

        # ============================================================
        # RETURN RESULTADO FINAL
        # ============================================================

        return result

    except Exception as e:

        if engine and hasattr(engine, "log"):
            engine.log.exception("OMS execution failed")

        return {
            "status": "ERROR",
            "reason": str(e)
        }