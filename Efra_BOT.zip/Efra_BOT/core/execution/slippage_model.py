# core/execution/slippage_model.py

import numpy as np

def compute_slippage(
    price: float,
    side: str,
    order_fraction: float,
    avg_volume: float,
    spread: float = 0.0005
):
    """
    Institutional Slippage Model v2 (impact-aware)
    """

    # ----------------------------------------
    # Market impact dinámico
    # ----------------------------------------
    participation_rate = order_fraction / max(avg_volume, 1e-6)

    impact = min(0.02, participation_rate * 0.1)

    # ----------------------------------------
    # Spread cost
    # ----------------------------------------
    spread_component = spread * 0.5

    # ----------------------------------------
    # Latency noise
    # ----------------------------------------
    noise = np.random.normal(0, impact * 0.25)

    total_slippage = impact + spread_component + noise
    total_slippage = max(0.0, total_slippage)

    # ----------------------------------------
    # Fill price
    # ----------------------------------------
    if side in ["BUY", "LONG"]:
        fill_price = price * (1 + total_slippage)
    else:
        fill_price = price * (1 - total_slippage)

    return {
        "fill_price": float(fill_price),
        "slippage": float(total_slippage),
        "impact": float(impact),
        "participation_rate": float(participation_rate)
    }
