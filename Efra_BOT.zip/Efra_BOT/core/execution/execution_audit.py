# core/execution/execution_audit.py

import logging

log = logging.getLogger("execution_audit")


def log_execution(symbol, ia, order, result):
    """
    Auditoría institucional segura
    """

    try:

        log.info({

            "symbol":
            symbol,

            "direction":
            ia.get(
                "direction",
                "UNKNOWN"
            ),

            "confidence":
            ia.get(
                "confidence",
                0
            ),

            "order":
            order,

            "result":
            result

        })

        # =====================================
        # POST TRADE ANALYZER
        # =====================================

        try:

            from core.post_trade.post_trade_analyzer import (
                analyze_trade
            )

            analyze_trade(
                trade=result,
                ia_decision=ia
            )

        except Exception as e:

            log.warning(
                f"PostTradeAnalyzer error: {e}"
            )

    except Exception as e:

        log.exception(
            f"Audit failed: {e}"
        )
