# core/execution/trade_lifecycle_manager.py

import logging
import uuid
from datetime import datetime

from core.analytics.performance_analytics import PerformanceAnalytics

logger = logging.getLogger(__name__)


class TradeLifecycleManager:
    """
    Gestor institucional del ciclo de vida de trades.
    """

    def __init__(self):

        self.open_trades = {}
        self.closed_trades = []
        self.analytics = PerformanceAnalytics()

    # =====================================================
    # REGISTER TRADE
    # =====================================================

    def register_trade(self, trade):

        trade_id = trade.get("id", str(uuid.uuid4()))

        trade["id"] = trade_id
        trade["status"] = "OPEN"

        trade["open_time"] = datetime.utcnow()
        trade["close_time"] = None

        # 🔥 INSTITUCIONAL
        trade["entry_price"] = trade.get("entry_price")
        trade["entry_net_price"] = trade.get("entry_net_price", trade.get("entry_price"))
        trade["size"] = trade.get("size", 0)

        trade["exit_price"] = None
        trade["exit_net_price"] = None

        trade["pnl_usd"] = 0.0
        trade["pnl_pct"] = 0.0

        self.open_trades[trade_id] = trade

        logger.info(f"Trade registrado {trade_id}")
        return trade_id

    # =====================================================
    # UPDATE TRADE (SOLO GESTIÓN)
    # =====================================================

    def update_trade(self, trade_id, price):
        trade = self.open_trades.get(trade_id)
        if not trade:
            return None

        entry = trade["entry_net_price"]
        direction = trade["direction"].upper()

        # 🔥 PnL flotante REAL
        if direction in ["BUY", "LONG"]:
            pnl_pct = (price - entry) / entry
        else:
            pnl_pct = (entry - price) / entry

        trade["pnl_pct"] = pnl_pct

        return trade

    # =====================================================
    # CLOSE TRADE
    # =====================================================

    def close_trade(self, trade_id, exit_price, exit_net_price=None, reason="EXIT"):

        trade = self.open_trades.get(trade_id)

        if not trade:
            return None

        entry = trade["entry_net_price"]
        size = trade.get("size", 0)
        direction = trade["direction"].upper()

        exit_net_price = exit_net_price or exit_price

        # =========================================
        # 🔥 PnL REAL (USD)
        # =========================================
        if direction in ["BUY", "LONG"]:
            pnl_usd = (exit_net_price - entry) * size
        else:
            pnl_usd = (entry - exit_net_price) * size

        # =========================================
        # 🔥 PnL %
        # =========================================
        pnl_pct = pnl_usd / max(entry * size, 1e-9)

        trade["exit_price"] = exit_price
        trade["exit_net_price"] = exit_net_price

        trade["pnl_usd"] = pnl_usd
        trade["pnl_pct"] = pnl_pct

        trade["status"] = reason
        trade["close_time"] = datetime.utcnow()

        logger.info(
            f"Trade {trade_id} cerrado | "
            f"{reason} | "
            f"PnL ${pnl_usd:.2f} ({pnl_pct:.2%})"
        )

        # =========================================
        # ANALYTICS
        # =========================================
        try:
            self.analytics.register_trade({
                "pnl_usd": pnl_usd,
                "pnl_pct": pnl_pct
            })
        except Exception:
            logger.exception("Error registrando analytics")

        self.closed_trades.append(trade)
        del self.open_trades[trade_id]

        return trade

    # =====================================================
    # GETTERS
    # =====================================================

    def get_open_trades(self):
        return list(self.open_trades.values())

    def get_closed_trades(self):
        return self.closed_trades

    def performance_report(self):
        return self.analytics.report()
