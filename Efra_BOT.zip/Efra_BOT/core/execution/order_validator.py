# core/execution/order_validator.py

def validate_order(order: dict):
    if order["size"] <= 0:
        raise ValueError("Order size inválido")

    if order["side"] not in ("LONG", "SHORT"):
        raise ValueError("Side inválido")

    return True
