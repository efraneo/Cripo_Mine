import numpy as np
from typing import Dict, List


class SmartOrderRouter:
    """
    Institutional Smart Order Routing Engine

    Features
    --------
    - TWAP execution
    - VWAP execution
    - Liquidity slicing
    - Market impact estimation
    - Adaptive routing
    """

    def __init__(self):
        self.max_slice_size = 0.15
        self.impact_threshold = 0.02

    # ==========================================================
    # ORDER BOOK LIQUIDITY
    # ==========================================================

    def _estimate_liquidity(self, order_book: Dict):

        bids = order_book.get("bids", [])[:10]
        asks = order_book.get("asks", [])[:10]

        bid_liq = sum(float(price) * float(size) for price, size in bids)
        ask_liq = sum(float(price) * float(size) for price, size in asks)

        total_liq = bid_liq + ask_liq

        imbalance = 0
        if total_liq > 0:
            imbalance = (bid_liq - ask_liq) / total_liq

        return {
            "bid_liq": bid_liq,
            "ask_liq": ask_liq,
            "total_liq": total_liq,
            "imbalance": imbalance
        }

    # ==========================================================
    # MARKET IMPACT ESTIMATE
    # ==========================================================

    def estimate_market_impact(self, order_size: float, order_book: Dict):

        liq = self._estimate_liquidity(order_book)
        total_liq = liq["total_liq"]

        if total_liq <= 0:
            return 0.05

        participation = order_size / total_liq

        # Square-root impact model (institucional)
        impact = np.sqrt(participation)

        return float(np.clip(impact, 0.0, 0.1))

    # ==========================================================
    # TWAP EXECUTION
    # ==========================================================

    def generate_twap_orders(self, total_size: float, slices: int = 5):

        slice_size = total_size / slices
        interval = 5  # segundos (simulación)

        orders = []

        for i in range(slices):
            orders.append({
                "size": slice_size,
                "type": "market",
                "delay": i * interval
            })

        return orders

    # ==========================================================
    # VWAP EXECUTION
    # ==========================================================

    def generate_vwap_orders(self, total_size: float, order_book: Dict, side: str):

        if side == "BUY":
            levels = order_book.get("asks", [])[:10]
        else:
            levels = order_book.get("bids", [])[:10]

        total_volume = sum(float(l[1]) for l in levels)

        if total_volume <= 0:
            return [{"size": total_size, "type": "market"}]

        orders = []

        for price, volume in levels:

            weight = float(volume) / total_volume

            orders.append({
                "price": float(price),
                "size": total_size * weight,
                "type": "limit"
            })

        return orders

    # ==========================================================
    # LIQUIDITY SLICING
    # ==========================================================

    def liquidity_slicing(self, total_size: float):

        max_slice = total_size * self.max_slice_size

        orders = []
        remaining = total_size

        while remaining > 0:

            size = min(max_slice, remaining)

            orders.append({
                "size": size,
                "type": "market"
            })

            remaining -= size

        return orders

    # ==========================================================
    # MAIN ROUTER
    # ==========================================================

    def route_order(self, order_size: float, order_book: Dict, side: str = "BUY"):

        order_size = float(max(0.0, min(order_size, 1.0)))

        if order_book is None:
            return {
                "strategy": "DIRECT",
                "market_impact": 0,
                "orders": [{"size": order_size, "type": "market"}]
            }

        impact = self.estimate_market_impact(order_size, order_book)

        liq = self._estimate_liquidity(order_book)
        imbalance = liq["imbalance"]

        if side == "BUY" and imbalance > 0.2:
            impact *= 0.8  # favorable liquidity

        elif side == "SELL" and imbalance < -0.2:
            impact *= 0.8

        if impact > 0.05:
            strategy = "ICEBERG"
            orders = self.generate_iceberg_orders(order_size)

        elif impact > self.impact_threshold:
            strategy = "TWAP"
            orders = self.generate_twap_orders(order_size)

        elif impact > self.impact_threshold * 0.5:
            strategy = "VWAP"
            orders = self.generate_vwap_orders(order_size, order_book, side)

        else:
            strategy = "DIRECT"
            orders = [{
                "size": order_size,
                "type": "market"
            }]

        return {
            "strategy": strategy,
            "market_impact": impact,
            "orders": orders,
            "execution_profile": {
                "impact": impact,
                "imbalance": imbalance,
                "liquidity": liq["total_liq"]
            }
        }

    # ==========================================
    # ICEBERG STRATEGY
    # ==========================================
    def generate_iceberg_orders(self, total_size: float):

        visible_fraction = 0.1
        visible_size = total_size * visible_fraction

        return [{
            "size": visible_size,
            "hidden_size": total_size - visible_size,
            "type": "iceberg"
        }]
