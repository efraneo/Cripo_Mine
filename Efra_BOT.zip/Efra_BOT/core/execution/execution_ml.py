# core/execution/execution_ml.py

import numpy as np


_EXECUTION_DATA = []


def record_execution_sample(
    volume_ratio,
    volatility,
    spread,
    real_slippage
):
    _EXECUTION_DATA.append(
        (volume_ratio, volatility, spread, real_slippage)
    )


def fit_execution_model():
    if len(_EXECUTION_DATA) < 50:
        return None

    X = []
    y = []

    for vr, vol, sp, slip in _EXECUTION_DATA:
        X.append([vr, vol, sp])
        y.append(slip)

    X = np.array(X)
    y = np.array(y)

    # Linear regression closed-form
    beta = np.linalg.pinv(X.T @ X) @ X.T @ y

    return {
        "a": float(beta[0]),
        "b": float(beta[1]),
        "c": float(beta[2]),
        "samples": len(_EXECUTION_DATA)
    }
