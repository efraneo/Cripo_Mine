# core/execution/position_sizer.py

def calculate_position_size(confidence: float, direction: str) -> float:
    """
    Position sizing adaptativo institucional.
    """

    base = 0.01  # 1% capital

    if confidence >= 85:
        return base * 2.0
    if confidence >= 75:
        return base * 1.5
    if confidence >= 65:
        return base

    return 0.0
