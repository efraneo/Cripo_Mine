# core/execution/execution_quality_engine.py

import numpy as np
from typing import Dict


class ExecutionQualityEngine:

    """
    Motor institucional de calidad de ejecución
    """

    def __init__(self):

        self.slippage_history = []

        self.latency_history = []

        self.spread_history = []

    # ======================================================
    # SPREAD COST
    # ======================================================

    def spread_cost(self, bid: float, ask: float) -> float:

        if bid <= 0 or ask <= 0:
            return 0

        mid = (bid + ask) / 2

        spread = ask - bid

        return spread / mid

    # ======================================================
    # SLIPPAGE
    # ======================================================

    def compute_slippage(
        self,
        expected_price: float,
        executed_price: float
    ) -> float:

        if expected_price <= 0:
            return 0

        slippage = abs(executed_price - expected_price) / expected_price

        self.slippage_history.append(slippage)

        return slippage

    # ======================================================
    # LATENCY
    # ======================================================

    def record_latency(self, milliseconds):

        self.latency_history.append(milliseconds)

    # ======================================================
    # EXECUTION SCORE
    # ======================================================

    def execution_score(self):

        if not self.slippage_history:

            return {
                "execution_quality": "UNKNOWN",
                "score": 1.0
            }

        avg_slippage = np.mean(self.slippage_history)

        avg_latency = (
            np.mean(self.latency_history)
            if self.latency_history
            else 0
        )

        score = 1.0

        if avg_slippage > 0.002:
            score *= 0.7

        if avg_latency > 500:
            score *= 0.8

        quality = "GOOD"

        if score < 0.6:
            quality = "POOR"

        elif score < 0.85:
            quality = "MODERATE"

        return {
            "execution_quality": quality,
            "score": score,
            "avg_slippage": float(avg_slippage),
            "avg_latency": float(avg_latency)
        }

    # ======================================================
    # RISK ADJUSTMENT
    # ======================================================

    def execution_risk_scale(self):

        score = self.execution_score()["score"]

        if score < 0.5:
            return 0.3

        if score < 0.7:
            return 0.6

        if score < 0.9:
            return 0.85

        return 1.0