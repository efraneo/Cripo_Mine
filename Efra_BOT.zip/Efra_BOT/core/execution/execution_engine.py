# core/execution/execution_engine.py

import logging
import numpy as np
from datetime import datetime

from core.analytics.performance_analytics import PerformanceAnalytics
from core.execution.trade_lifecycle_manager import TradeLifecycleManager
from core.execution.smart_order_router import SmartOrderRouter

logger = logging.getLogger(__name__)
analytics = PerformanceAnalytics()


# ======================================================
# EXECUTION COST MODEL
# ======================================================

def estimate_execution_cost(order_fraction, df, a=0.6, b=0.3, c=0.1):

    if df is None or len(df) < 20:
        return _default_response()

    try:
        returns = df["close"].pct_change().dropna()
        volatility = returns.rolling(20).std().iloc[-1]

        if np.isnan(volatility):
            volatility = 0.001

        spread = (
            (df["high"].iloc[-1] - df["low"].iloc[-1])
            / df["close"].iloc[-1]
        )

        avg_volume = df["volume"].rolling(20).mean().iloc[-1]
        price = df["close"].iloc[-1]

        market_volume_usd = avg_volume * price
        order_notional = order_fraction * market_volume_usd * 0.01
        volume_ratio = order_notional / max(market_volume_usd, 1e-9)

        impact_cost = a * volume_ratio + b * volatility + c * spread
        impact_cost = float(np.clip(impact_cost, 0.0, 0.05))

        latency_noise = np.random.normal(0, impact_cost * 0.3)
        slippage = max(0.0, impact_cost + latency_noise + spread * 0.5)

        execution_scale = float(np.exp(-impact_cost * 10))
        execution_scale = max(0.4, min(1.0, execution_scale))

        mode = "NORMAL"
        if impact_cost > 0.02:
            mode = "HIGH_IMPACT"
        elif impact_cost > 0.01:
            mode = "MODERATE_IMPACT"

        return {
            "expected_slippage": slippage,
            "impact_cost": impact_cost,
            "execution_scale": execution_scale,
            "mode": mode,
            "execution_quality": {
                "slippage": slippage,
                "impact": impact_cost,
                "latency": latency_noise,
            }
        }

    except Exception:
        logger.exception("Execution cost model failed")
        return _default_response()


def _default_response():
    return {
        "expected_slippage": 0.0,
        "impact_cost": 0.0,
        "execution_scale": 1.0,
        "mode": "NO_DATA"
    }


# ======================================================
# EXECUTION ENGINE
# ======================================================

class ExecutionEngine:

    def __init__(self, broker=None):
        self.broker = broker
        self.lifecycle = TradeLifecycleManager()
        self.router = SmartOrderRouter()

    # ==================================================

    def execute_trade(self, signal, risk, market_df=None, order_book=None):
        try:

            logger.info(
                f"Executing trade {signal.symbol} {signal.direction}"
            )

            order_fraction = float(risk.get("capital_fraction", 0.01))

            exec_cost = estimate_execution_cost(order_fraction, market_df)
            execution_scale = exec_cost["execution_scale"]

            adjusted_risk = round(
                risk["adjusted_risk"] * execution_scale,
                4
            )
            adjusted_risk = max(0.001, adjusted_risk)

            # =====================================
            # SLIPPAGE MODEL
            # =====================================
            from core.execution.slippage_model import compute_slippage

            slip = compute_slippage(
                price=signal.entry_price,
                side=signal.direction,
                impact=exec_cost["impact_cost"]
            )

            simulated_price = slip["fill_price"]

            # =====================================
            # POSITION SIZING
            # =====================================
            capital = risk.get("capital_usdt", 100)
            position_size_usdt = capital * order_fraction
            quantity = position_size_usdt / signal.entry_price

            # =====================================
            # SMART ROUTING
            # =====================================
            routing = None

            if order_book and isinstance(order_book, dict) and len(order_book) > 0:
                routing = self.router.route_order(
                    order_size=quantity,
                    order_book=order_book
                )

            # =====================================
            # ORDER OBJECT (TRACKING)
            # =====================================
            order = {
                "symbol": signal.symbol,
                "direction": signal.direction,
                "entry_price": simulated_price,
                "stop_loss": signal.stop_loss,
                "take_profit": signal.take_profit,
                "risk_percent": adjusted_risk,
                "expected_slippage": exec_cost["expected_slippage"],
                "execution_mode": exec_cost["mode"],
                "smart_routing": routing
            }

            self.lifecycle.register_trade(order)

            # =====================================
            # ROUTING PAYLOAD
            # =====================================
            from core.execution.order_router import route_order

            order_payload = {
                "symbol": signal.symbol,
                "side": signal.direction,
                "size": quantity,
                "mode": routing["strategy"] if routing else "MARKET",
                "orders": routing["orders"] if routing else [],
                "price": simulated_price
            }

            # =====================================
            # EXECUTION
            # =====================================
            if self.broker:
                result = route_order(self.broker, order_payload)

                from core.notifications.telegram_pro import send_telegram_trade_alert
                import streamlit as st

                try:
                    fig = None

                    if "last_chart_fig" in st.session_state:
                        fig = st.session_state["last_chart_fig"]

                    ia_data = st.session_state.get("ia_decision", {})
                    user = st.session_state.get("session", {}).get("username")

                    send_telegram_trade_alert(
                        symbol=signal.symbol,
                        side=signal.direction,
                        confidence=ia_data.get("confidence", 0),
                        entry=signal.entry_price,
                        sl=signal.stop_loss,
                        tp=signal.take_profit,
                        fig=fig,
                        ia=ia_data,
                        username=user
                    )

                except Exception:
                    logger.warning("Telegram PRO failed")

                real_fill = result.get("avg_price", simulated_price)

                latency = result.get("latency", 0)
                status = result.get("status", "OK")

                analytics.record_execution({
                    "symbol": signal.symbol,
                    "fill_price": real_fill,
                    "expected_slippage": exec_cost.get("expected_slippage", 0),
                    "slippage": slip.get("slippage", 0),
                    "latency": latency,
                    "size": quantity,
                    "strategy": order_payload["mode"],
                    "timestamp": datetime.utcnow(),
                    "status": status
                })

                return result

            else:
                logger.warning("Paper trade")

                analytics.record_execution({
                    "symbol": signal.symbol,
                    "fill_price": simulated_price,
                    "expected_slippage": exec_cost.get("expected_slippage", 0),
                    "slippage": slip.get("slippage", 0),
                    "latency": 0,
                    "size": quantity,
                    "strategy": order_payload["mode"],
                    "timestamp": datetime.utcnow(),
                    "status": "PAPER"
                })

                return order_payload

        except Exception:
            logger.exception("ExecutionEngine failed")
            return None