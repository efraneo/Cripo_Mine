# core/orchestrators/ensemble_orchestrator.py

from core.quant.ensemble_brain import ensemble_decision
from core.quant.rl_weights import RLWeightEngine


# ============================================================
# NORMALIZADOR DIRECCIONAL
# ============================================================

def _normalize_direction(direction: str) -> str:

    if not direction:
        return "NEUTRAL"

    direction = str(direction).upper().strip()

    LONG_SET = {
        "LONG",
        "BUY",
        "BULL",
        "UP",
        "BULLISH"
    }

    SHORT_SET = {
        "SHORT",
        "SELL",
        "BEAR",
        "DOWN",
        "BEARISH"
    }

    HOLD_SET = {
        "HOLD",
        "RANGE",
        "SIDEWAYS",
        "NEUTRAL",
        "UNKNOWN",
        "WAIT"
    }

    if direction in LONG_SET:
        return "LONG"

    if direction in SHORT_SET:
        return "SHORT"

    if direction in HOLD_SET:
        return "NEUTRAL"

    return "NEUTRAL"


# ============================================================
# SANITIZE MODELS
# ============================================================

def _sanitize_models(models_outputs: list):

    clean = []

    for m in models_outputs:

        try:

            raw_dir = m.get("direction")

            normalized_dir = (
                _normalize_direction(
                    raw_dir
                )
            )

            confidence = float(
                m.get("confidence", 0)
            )

            confidence = max(
                0.0,
                min(confidence, 100.0)
            )

            # =====================================
            # PENALIZAR NEUTRAL
            # =====================================

            if normalized_dir == "NEUTRAL":

                confidence *= 0.25

            # =====================================
            # BONUS DIRECCIONAL
            # =====================================

            else:

                confidence *= 1.05

            clean.append({

                **m,

                "direction": normalized_dir,

                "confidence": round(
                    confidence,
                    2
                )
            })

        except Exception:
            continue

    return clean


# ============================================================
# CONSENSUS
# ============================================================

def _compute_consensus(models_outputs):

    long_votes = 0.0
    short_votes = 0.0
    neutral_votes = 0.0

    for m in models_outputs:

        d = m.get("direction")
        c = float(
            m.get("confidence", 0)
        )

        if d == "LONG":

            long_votes += c

        elif d == "SHORT":

            short_votes += c

        else:

            neutral_votes += c

    total = (
        long_votes +
        short_votes +
        neutral_votes
    )

    if total <= 0:

        return {
            "direction": "NEUTRAL",
            "strength": 0
        }

    directional_total = (
        long_votes +
        short_votes
    )

    if directional_total <= 0:

        return {
            "direction": "NEUTRAL",
            "strength": 0
        }

    if long_votes > short_votes:

        dominant = "LONG"
        strength = (
            long_votes /
            directional_total
        )

    else:

        dominant = "SHORT"
        strength = (
            short_votes /
            directional_total
        )

    return {
        "direction": dominant,
        "strength": round(
            strength,
            4
        ),
        "votes": {
            "LONG": round(long_votes, 2),
            "SHORT": round(short_votes, 2),
            "NEUTRAL": round(neutral_votes, 2)
        }
    }


# ============================================================
# MAIN
# ============================================================

def process_ensemble(
    ia: dict,
    models_outputs: list
):

    if not models_outputs:
        return ia

    # ========================================================
    # SANITIZE
    # ========================================================

    models_outputs = _sanitize_models(
        models_outputs
    )

    # ========================================================
    # CONSENSUS
    # ========================================================

    consensus = _compute_consensus(
        models_outputs
    )

    # ========================================================
    # ENSEMBLE
    # ========================================================

    try:

        ensemble = ensemble_decision(
            models_outputs
        )

    except Exception as e:

        ia["ensemble"] = {
            "error": str(e)
        }

        ia["reasons"].append({
            "rule": "ENSEMBLE_ERROR",
            "status": "FAIL",
            "details": str(e)
        })

        return ia

    # ========================================================
    # DATA
    # ========================================================

    ensemble_direction = (
        _normalize_direction(
            ensemble.get("direction")
        )
    )

    ensemble_confidence = float(
        ensemble.get("confidence", 0)
    )

    # ========================================================
    # CONSENSUS OVERRIDE
    # ========================================================

    consensus_strength = consensus.get(
        "strength",
        0
    )

    if consensus_strength >= 0.7:

        ensemble_direction = consensus.get(
            "direction"
        )

        ensemble_confidence = max(
            ensemble_confidence,
            consensus_strength * 100
        )

    # ========================================================
    # RL ENGINE
    # ========================================================

    rl_scale = 1.0

    try:

        rl_engine = RLWeightEngine()

        rl_data = rl_engine.adjust_weights(
            models_outputs
        )

        rl_scale = float(
            rl_data.get(
                "confidence_scale",
                1.0
            )
        )

        ensemble["rl"] = rl_data

        ia["reasons"].append({

            "rule": "RL_ADAPTATION",

            "status": "INFO",

            "details": (
                f"Scale={rl_scale:.2f}"
            )
        })

    except Exception as e:

        ia["reasons"].append({

            "rule": "RL_ERROR",

            "status": "WARNING",

            "details": str(e)
        })

    # ========================================================
    # CONFIDENCE FUSION
    # ========================================================

    base_confidence = float(
        ia.get("confidence", 0)
    )

    final_confidence = (

        base_confidence * 0.65 +

        ensemble_confidence * 0.35
    )

    final_confidence *= rl_scale

    final_confidence = max(
        1.0,
        min(final_confidence, 99.0)
    )

    # ========================================================
    # RANGE FILTER
    # ========================================================

    probabilities = ia.get(
        "probabilities",
        {}
    )

    p_range = float(
        probabilities.get(
            "RANGE",
            0
        )
    )

    if p_range >= 0.60:

        ensemble_direction = "RANGE"

        final_confidence *= 0.65

    # ========================================================
    # UPDATE IA
    # ========================================================

    ia["direction"] = ensemble_direction

    ia["confidence"] = round(
        final_confidence,
        2
    )

    ia["ensemble"] = {

        **ensemble,

        "consensus": consensus,

        "final_direction": (
            ensemble_direction
        ),

        "final_confidence": round(
            final_confidence,
            2
        )
    }

    # ========================================================
    # REASONS
    # ========================================================

    ia["reasons"].append({

        "rule": "ENSEMBLE_BRAIN",

        "status": "OK",

        "details": (
            f"Direction={ensemble_direction} | "
            f"Confidence={final_confidence:.2f}"
        )
    })

    ia["reasons"].append({

        "rule": "ENSEMBLE_CONSENSUS",

        "status": "INFO",

        "details": (
            f"{consensus}"
        )
    })

    return ia
