# core/orchestrators/hedge_fund_orchestrator.py

from datetime import datetime, timezone
from core.portfolio.portfolio_orchestrator import PortfolioOrchestrator
from core.risk.drawdown_guardian import evaluate_drawdown_risk
from core.risk.position_heat_engine import evaluate_portfolio_heat
from core.risk.liquidity_shock_detector import detect_liquidity_shock

# ============================
# NAV & PERFORMANCE
# ============================
from core.performance.nav_calculator import compute_daily_nav
from core.performance.equity_curve import update_equity_curve

# ============================
# REGIME & CAPITAL
# ============================
from core.ai.regime_detection import detect_regime
from core.portfolio.kelly_allocator import regime_scaled_kelly

# ============================
# RISK ENGINES
# ============================
from core.risk.liquidity_engine import liquidity_score
from core.risk.monte_carlo_stress import monte_carlo_equity_paths
from core.risk.tail_hedging import tail_hedge_signal

# ============================
# GOVERNORS
# ============================
from core.risk.risk_governor import evaluate_global_risk
from core.capital_rotation.capital_rotator import rotate_capital

# ============================
# AUDIT
# ============================
from core.ia_audit_log import get_ia_audit_logger


# ======================================================
# 🏛 MASTER ORCHESTRATOR — HEDGE FUND CORE
# ======================================================
def hedge_fund_orchestrator(
    *,
    symbol: str,
    ia_decision: dict,
    session_stats: dict,
    portfolio_state: dict,
    market_snapshot: dict,
):
    """
    Orquestador institucional final.
    Decide SI se puede operar, CUÁNTO capital asignar
    y BAJO QUÉ RIESGO.
    """

    audit = get_ia_audit_logger()
    portfolio = PortfolioOrchestrator()
    now = datetime.now(timezone.utc)

    # ==================================================
    # 1️⃣ NAV + EQUITY
    # ==================================================
    nav = compute_daily_nav(portfolio_state)
    equity = update_equity_curve(portfolio_state)

    # ==================================================
    # DRAWDOWN GUARDIAN
    # ==================================================

    current_equity = equity
    peak_equity = portfolio_state.get("peak_equity", equity)

    dd_guard = evaluate_drawdown_risk(
        current_equity,
        peak_equity
    )

    ia_decision["drawdown_guardian"] = dd_guard

    if not dd_guard["allow_trading"]:

        ia_decision["actionable"] = False

        ia_decision.setdefault("reasons", []).append({
            "rule": "DRAWDOWN_GUARDIAN",
            "status": "FAIL",
            "details": "Max drawdown reached — trading paused"
        })

        return ia_decision

    # ==================================================
    # 2️⃣ REGIME DETECTION
    # ==================================================
    returns = market_snapshot.get("returns", [])
    regime = detect_regime(returns)

    # ==================================================
    # 3️⃣ KELLY DINÁMICO
    # ==================================================
    win_rate = session_stats.get("win_rate", 0.5)
    win_loss = session_stats.get("win_loss_ratio", 1.0)

    raw_kelly = win_rate - ((1 - win_rate) / max(win_loss, 1e-6))
    kelly = regime_scaled_kelly(raw_kelly, regime)

    # ==================================================
    # 4️⃣ LIQUIDITY RISK
    # ==================================================
    liq_risk = liquidity_score(
        order_size=ia_decision.get("suggested_size", 0),
        avg_volume=market_snapshot.get("avg_volume", 1),
        spread=market_snapshot.get("spread", 0),
    )

    # ==================================================
    # 5️⃣ STRESS TEST
    # ==================================================
    stress_paths = monte_carlo_equity_paths(
        equity=nav,
        returns=returns,
        sims=300,
    )

    worst_dd = abs((stress_paths.min(axis=1) / nav - 1).min())

    # ==================================================
    # 6️⃣ TAIL RISK
    # ==================================================
    var_99 = market_snapshot.get("var_99", 0)
    tail_signal = tail_hedge_signal(var_99, worst_dd)

    # ==================================================
    # 7️⃣ RISK GOVERNOR GLOBAL
    # ==================================================
    allowed, reason = evaluate_global_risk(
        nav=nav,
        drawdown=portfolio_state.get("drawdown", 0),
        liquidity_risk=liq_risk,
        tail_signal=tail_signal,
        confidence=ia_decision.get("confidence", 0),
    )

    if not allowed:
        ia_decision["actionable"] = False
        ia_decision.setdefault("reasons", []).append({
            "rule": "RISK_GOVERNOR",
            "status": "FAIL",
            "details": reason
        })

        audit.log_decision(
            symbol=symbol,
            context="HEDGE_FUND_ORCHESTRATOR_BLOCK",
            ia_decision=ia_decision,
            data_by_tf={}
        )

        return ia_decision

    # ==================================================
    # 7.5 PORTFOLIO RISK ENGINE
    # ==================================================

    symbol = symbol
    amount = ia_decision.get("capital_fraction", 0)

    allowed, portfolio_decision = portfolio.evaluate_trade(
        symbol=symbol,
        amount=amount,
        ia_decision=ia_decision,
        base_risk=portfolio_state.get("base_risk", 0.01)
    )

    if not allowed:

        ia_decision["actionable"] = False
        ia_decision.setdefault("reasons", []).append({
            "rule": "PORTFOLIO_DECIDER",
            "status": "FAIL",
            "details": portfolio_decision.get("reason")
        })

        audit.log_decision(
            symbol=symbol,
            context="PORTFOLIO_DECIDER_BLOCK",
            ia_decision=ia_decision,
            data_by_tf={}
        )
        return ia_decision

    # riesgo ajustado por estrategia
    ia_decision["risk_per_trade"] = portfolio_decision.get(
        "adjusted_risk",
        portfolio_state.get("base_risk", 0.01)
    )

    # ==================================================
    # POSITION HEAT ENGINE
    # ==================================================

    heat_data = evaluate_portfolio_heat()
    ia_decision["portfolio_heat"] = heat_data
    if not heat_data["allow_trade"]:
        ia_decision["actionable"] = False
        ia_decision.setdefault("reasons", []).append({
            "rule": "PORTFOLIO_HEAT",
            "status": "FAIL",
            "details": "Portfolio overheated"
        })
        return ia_decision

    # ==================================================
    # LIQUIDITY SHOCK DETECTOR
    # ==================================================

    df = market_snapshot.get("df")
    liquidity_shock = detect_liquidity_shock(df)
    ia_decision["liquidity_shock"] = liquidity_shock

    if not liquidity_shock["allow_trade"]:
        ia_decision["actionable"] = False
        ia_decision.setdefault("reasons", []).append({
            "rule": "LIQUIDITY_SHOCK",
            "status": "FAIL",
            "details": "Liquidity shock detected"
        })
        return ia_decision

    # ==================================================
    # 8️⃣ CAPITAL ROTATION (SESSION LEVEL)
    # ==================================================
    rotation_decisions = rotate_capital(session_stats)

    # ==================================================
    # 9️⃣ FINAL CAPITAL ASSIGNMENT
    # ==================================================
    ia_decision["regime"] = regime
    ia_decision["kelly_fraction"] = round(kelly, 4)
    ia_decision["liquidity_risk"] = liq_risk
    ia_decision["tail_hedge"] = tail_signal
    ia_decision["capital_allocation"] = round(
        portfolio_state.get("available_capital", 0) * kelly,
        2
    )

    # ==================================================
    # APPLY DRAWDOWN RISK SCALING
    # ==================================================

    # drawdown scaling
    risk_scale = dd_guard.get("risk_scale", 1.0)
    ia_decision["capital_allocation"] *= risk_scale

    # portfolio heat scaling
    heat_scale = heat_data.get("heat_scale", 1.0)
    ia_decision["capital_allocation"] *= heat_scale

    # liquidity shock scaling
    shock_scale = liquidity_shock.get("risk_scale", 1.0)
    ia_decision["capital_allocation"] *= shock_scale

    ia_decision.setdefault("reasons", []).append({
        "rule": "MASTER_ORCHESTRATOR",
        "status": "OK",
        "details": (
            f"Regime={regime} | Kelly={kelly:.2f} | "
            f"LiqRisk={liq_risk} | Tail={tail_signal}"
        )
    })

    # ==================================================
    # 🔒 AUDIT FINAL
    # ==================================================
    audit.log_decision(
        symbol=symbol,
        context="HEDGE_FUND_ORCHESTRATOR_ALLOW",
        ia_decision=ia_decision,
        data_by_tf={}
    )

    return ia_decision
