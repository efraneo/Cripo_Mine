# core/orchestrators/meta_allocation_orchestrator.py

def finalize_allocation(ia: dict):

    reasons = ia.get("reasons", [])

    # ----------------------------------------
    # 🧠 SANITIZAR REASONS (CRÍTICO)
    # ----------------------------------------
    clean_reasons = []

    for r in reasons:
        if isinstance(r, dict):
            clean_reasons.append(r)
        else:
            clean_reasons.append({
                "rule": "UNKNOWN",
                "status": "FAIL",
                "details": str(r)
            })

    ia["reasons"] = clean_reasons

    # ----------------------------------------
    # CONFLUENCE SCORE
    # ----------------------------------------
    ia["confluence_score"] = len([
        r for r in clean_reasons
        if r.get("status") == "OK"
    ])

    # ----------------------------------------
    # NORMALIZACIÓN FINAL
    # ----------------------------------------
    ia["confidence"] = max(0, min(100, ia.get("confidence", 0)))

    return ia
