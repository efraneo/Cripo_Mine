# core/orchestrators/microstructure_orchestrator.py

from core.quant.whale_detector import detect_whales
from core.quant.footprint_simulator import compute_footprint
from core.quant.liquidity_traps import detect_fake_breakout
from core.quant.order_clustering import detect_volume_clusters


def process_microstructure(ia: dict, df_5m):

    try:
        whales = detect_whales(df_5m)
        footprint = compute_footprint(df_5m)
        traps = detect_fake_breakout(df_5m)
        clusters = detect_volume_clusters(df_5m)

        ia["microstructure"] = {
            "whales": whales,
            "footprint": footprint,
            "traps": traps,
            "clusters": clusters
        }

        # ----------------------------------------
        # CLUSTERS
        # ----------------------------------------
        if clusters.get("high_activity_zone"):
            ia["confidence"] += 2

            ia["reasons"].append({
                "rule": "VOLUME_CLUSTER",
                "status": "OK",
                "details": "High liquidity zone detected"
            })

        if clusters.get("absorption"):
            ia["confidence"] += 2

        # ----------------------------------------
        # WHALES
        # ----------------------------------------
        if whales.get("active"):
            ia["confidence"] += min(5, whales.get("strength", 1) * 2)

            ia["reasons"].append({
                "rule": "WHALE_ACTIVITY",
                "status": "OK",
                "details": f"Strength {whales.get('strength'):.2f}"
            })

        # ----------------------------------------
        # FOOTPRINT
        # ----------------------------------------
        fp_signal = footprint.get("signal")

        if fp_signal == "BUY_IMBALANCE" and ia.get("direction") == "LONG":
            ia["confidence"] += 3

        elif fp_signal == "SELL_IMBALANCE" and ia.get("direction") == "SHORT":
            ia["confidence"] += 3

        # ----------------------------------------
        # TRAPS
        # ----------------------------------------
        if traps.get("trap"):

            if traps["type"] == "BULL_TRAP" and ia.get("direction") == "LONG":
                ia["confidence"] *= 0.6
                ia["actionable"] = False

            elif traps["type"] == "BEAR_TRAP" and ia.get("direction") == "SHORT":
                ia["confidence"] *= 0.6
                ia["actionable"] = False

            ia["reasons"].append({
                "rule": "LIQUIDITY_TRAP",
                "status": "BLOCKED",
                "details": traps["type"]
            })

    except Exception as e:
        ia["microstructure"] = {"error": str(e)}

    return ia
