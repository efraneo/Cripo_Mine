# core/orchestrators/execution_orchestrator.py

def process_execution(ia: dict, df_5m):

    try:
        from core.execution.execution_engine import estimate_execution_cost
        from core.execution.slippage_model import compute_slippage

        execution_data = estimate_execution_cost(
            order_fraction=ia["capital_fraction"],
            df=df_5m
        )

        ia["execution"] = execution_data

        # ----------------------------------------
        # SLIPPAGE REAL
        # ----------------------------------------
        last_price = df_5m["close"].iloc[-1]

        avg_volume = df_5m["volume"].rolling(20).mean().iloc[-1]

        spread = (
            (df_5m["high"].iloc[-1] - df_5m["low"].iloc[-1])
            / last_price
        )

        side = "BUY" if ia.get("direction") == "LONG" else "SELL"

        slippage_data = compute_slippage(
            price=last_price,
            side=side,
            impact=ia.get("capital_fraction", 0.01),
            spread=spread
        )

        ia["slippage_model"] = slippage_data

        # ----------------------------------------
        # IMPACTO
        # ----------------------------------------
        slippage_scale = 1 - slippage_data["slippage"]

        ia["capital_fraction"] *= slippage_scale

        if slippage_data["slippage"] > 0.01:
            ia["confidence"] *= 0.9

            ia["reasons"].append({
                "rule": "HIGH_SLIPPAGE",
                "status": "WARNING",
                "details": f"{slippage_data['slippage']:.4f}"
            })

    except Exception:
        ia["execution"] = {"mode": "ERROR"}

    return ia
