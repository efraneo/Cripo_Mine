# core/orchestrators/risk_orchestrator.py

def apply_global_risk_filters(ia: dict):

    # ----------------------------------------
    # GLOBAL VETO
    # ----------------------------------------
    if ia["confidence"] < 50:
        ia["actionable"] = False

        ia["reasons"].append({
            "rule": "GLOBAL_CONFIDENCE_VETO",
            "status": "BLOCKED",
            "details": f"{ia['confidence']:.2f}"
        })

    # ----------------------------------------
    # HARD CONSENSUS SMC
    # ----------------------------------------
    smc_dir = ia.get("smart_money", {}).get("direction")

    if smc_dir and ia.get("direction") and smc_dir != ia["direction"]:
        ia["confidence"] *= 0.7

    return ia
