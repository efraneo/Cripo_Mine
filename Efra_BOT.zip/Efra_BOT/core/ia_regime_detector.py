# core/ia_regime_detector.py
import numpy as np

def detect_regime(df):
    """
    Detecta régimen de mercado:
    TRENDING / RANGING / CHAOS
    """

    try:
        atr = df["atr"].iloc[-1]
        atr_mean = df["atr"].rolling(50).mean().iloc[-1]

        rsi = df["rsi"].iloc[-1]
        macd = df["macd_hist"].iloc[-1]

        if atr > atr_mean * 1.5:
            return "CHAOS"

        if macd > 0 and rsi > 55:
            return "TRENDING"

        return "RANGING"

    except Exception:
        return "UNKNOWN"
