# core/utils/direction_normalizer.py

def normalize_direction(direction):

    if not direction:
        return "NEUTRAL"

    d = str(direction).upper()

    mapping = {
        "BUY": "LONG",
        "SELL": "SHORT",
        "LONG": "LONG",
        "SHORT": "SHORT",
        "BULLISH": "LONG",
        "BEARISH": "SHORT",
        "HOLD": "NEUTRAL",
        "RANGE": "NEUTRAL",
        "SIDEWAYS": "NEUTRAL",
        "UNKNOWN": "NEUTRAL",
    }

    return mapping.get(d, "NEUTRAL")
