from datetime import timezone, timedelta
import pandas as pd

COL_TZ = timezone(timedelta(hours=-5))

def to_colombia_time(ts):
    dt = pd.to_datetime(ts, utc=True)
    return dt.tz_convert(COL_TZ)

def format_colombia(dt):
    return dt.strftime("%d-%m-%Y %H:%M:%S")
