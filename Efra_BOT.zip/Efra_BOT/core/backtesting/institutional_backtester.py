# core/backtesting/institutional_backtester.py

import logging
import pandas as pd

logger = logging.getLogger(__name__)


class InstitutionalBacktester:

    """
    Motor institucional de backtesting.
    """

    def __init__(
        self,
        ia_pipeline,
        initial_equity=10000
    ):
        self.ia_pipeline = ia_pipeline
        self.initial_equity = initial_equity
        self.equity = initial_equity
        self.trades = []
        self.equity_curve = []

    # ======================================================
    # RUN BACKTEST
    # ======================================================

    def run(self, symbol, df):

        logger.info(f"Backtesting {symbol}")

        for i in range(100, len(df)):
            window = df.iloc[:i]

            try:
                ia = self.ia_pipeline.run_backtest(symbol, window)

                if not ia:
                    continue

                if not ia.get("actionable"):
                    continue

                entry = window["close"].iloc[-1]

                capital_fraction = ia.get("capital_fraction", 0.01)

                trade_size = self.equity * capital_fraction
                exit_price = df["close"].iloc[i]
                direction = ia.get("action")
                pnl = self.calculate_pnl(
                    direction,
                    entry,
                    exit_price,
                    trade_size
                )
                self.equity += pnl
                self.trades.append({
                    "entry": entry,
                    "exit": exit_price,
                    "pnl": pnl,
                    "equity": self.equity
                })
                self.equity_curve.append(self.equity)
            except Exception as e:
                logger.warning(f"Backtest error: {e}")
        return self.report()

    # ======================================================
    # PNL CALC
    # ======================================================

    def calculate_pnl(self, direction, entry, exit_price, size):
        if direction == "BUY":
            return size * ((exit_price - entry) / entry)
        elif direction == "SELL":
            return size * ((entry - exit_price) / entry)
        return 0

    # ======================================================
    # REPORT
    # ======================================================

    def report(self):
        if not self.trades:
            return {
                "trades": 0,
                "equity_final": self.equity
            }
        wins = [t for t in self.trades if t["pnl"] > 0]
        win_rate = len(wins) / len(self.trades)

        return {
            "initial_equity": self.initial_equity,
            "final_equity": self.equity,
            "total_trades": len(self.trades),
            "win_rate": win_rate,
            "return_pct": (self.equity / self.initial_equity - 1) * 100
        }