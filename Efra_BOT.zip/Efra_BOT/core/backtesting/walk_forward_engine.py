# core/backtesting/walk_forward_engine.py

import logging
import numpy as np

logger = logging.getLogger(__name__)


class WalkForwardEngine:

    """
    Walk-Forward Optimization Engine
    """

    def __init__(
        self,
        strategy_pipeline,
        train_size=1000,
        test_size=300
    ):

        self.strategy_pipeline = strategy_pipeline
        self.train_size = train_size
        self.test_size = test_size

    # ======================================================
    # MAIN WALK FORWARD
    # ======================================================

    def run(self, symbol, df):

        results = []

        start = 0

        while True:

            train_end = start + self.train_size
            test_end = train_end + self.test_size

            if test_end >= len(df):
                break

            train_df = df.iloc[start:train_end]
            test_df = df.iloc[train_end:test_end]

            logger.info(
                f"WFO window train:{start}-{train_end} test:{train_end}-{test_end}"
            )

            params = self.optimize(train_df)

            performance = self.validate(
                symbol,
                test_df,
                params
            )

            results.append(performance)

            start += self.test_size

        return self._aggregate(results)

    # ======================================================
    # PARAMETER OPTIMIZATION
    # ======================================================

    def optimize(self, df):

        """
        Aquí se optimizan parámetros de estrategia.
        En versión avanzada se pueden probar grids.
        """

        best_params = {
            "risk_scale": 1.0
        }

        return best_params

    # ======================================================
    # VALIDATION
    # ======================================================

    def validate(self, symbol, df, params):

        equity = 10000
        trades = 0

        for i in range(100, len(df)):

            window = df.iloc[:i]

            ia = self.strategy_pipeline.run_backtest(
                symbol,
                window,
                params=params
            )

            if not ia:
                continue

            if not ia.get("actionable"):
                continue

            entry = window["close"].iloc[-1]
            exit_price = df["close"].iloc[i]

            direction = ia.get("action")

            size = equity * 0.01

            pnl = self._pnl(
                direction,
                entry,
                exit_price,
                size
            )

            equity += pnl

            trades += 1

        return {
            "equity": equity,
            "trades": trades
        }

    # ======================================================
    # PNL
    # ======================================================

    def _pnl(self, direction, entry, exit_price, size):

        if direction == "BUY":
            return size * ((exit_price - entry) / entry)

        if direction == "SELL":
            return size * ((entry - exit_price) / entry)

        return 0

    # ======================================================
    # AGGREGATE RESULTS
    # ======================================================

    def _aggregate(self, results):

        if not results:
            return {}

        equities = [r["equity"] for r in results]
        trades = sum(r["trades"] for r in results)

        return {
            "walk_forward_equity_mean": float(np.mean(equities)),
            "walk_forward_equity_std": float(np.std(equities)),
            "walk_forward_trades": trades
        }
