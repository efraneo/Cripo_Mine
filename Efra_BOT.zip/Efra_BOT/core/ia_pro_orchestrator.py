# core/ia_pro_orchestrator.py

"""
ORCHESTRATOR PRINCIPAL (REFactorizado PRO)
- Compatible con tu bot actual
- Totalmente alineado con core/orchestrators/*
"""

from datetime import datetime

# CORE IA
from core.ia_pro_score import compute_ia_pro_score
from core.ia_audit_log import get_ia_audit_logger
from core.ia_entry_timing import compute_entry_timing
from core.utils.direction_normalizer import normalize_direction

# ORCHESTRATORS (CORRECTOS)
from core.orchestrators.microstructure_orchestrator import process_microstructure
from core.orchestrators.ensemble_orchestrator import process_ensemble
from core.orchestrators.execution_orchestrator import process_execution
from core.orchestrators.risk_orchestrator import apply_global_risk_filters
from core.orchestrators.meta_allocation_orchestrator import finalize_allocation
from core.market.session_detector import detect_market_session

# CONTEXTO
from core.learning.pnl_learning_engine import PnLLearningEngine
from core.market.market_regime_detection_engine import classify_market_regime
from backend.patrones_velas import detectar_patrones_velas

pnl_engine = PnLLearningEngine()


# ============================================
# NORMALIZADOR
# ============================================
def _normalize_reasons(reasons):
    out = []

    for r in reasons or []:
        if not isinstance(r, dict):
            out.append({
                "rule": "UNKNOWN",
                "status": "FAIL",
                "details": str(r)
            })
            continue

        out.append({
            "rule": str(r.get("rule", "UNKNOWN")),
            "status": str(r.get("status", "FAIL")).upper(),
            "details": str(r.get("details", ""))
        })

    return out


# ============================================
# BUILD MODELS OUTPUTS (CLAVE PARA ENSEMBLE)
# ============================================
def _build_models_outputs(ia, df_5m):

    models_outputs = []

    # -----------------------------------
    # 1. ML AGENT
    # -----------------------------------
    try:
        ml_conf = ia.get("ml", {}).get("confidence", 0)

        models_outputs.append({
            "model": "ML_AGENT",
            "direction": normalize_direction(
                ia.get("direction")
            ),
            "confidence": ml_conf
        })
    except Exception:
        pass

    # -----------------------------------
    # 2. SMART MONEY
    # -----------------------------------
    try:
        smc = ia.get("smart_money", {})

        models_outputs.append({
            "model": "SMART_MONEY",
            "direction": normalize_direction(
                smc.get("direction")
            ),
            "confidence": smc.get("confidence", 0)
        })
    except Exception:
        pass

    # -----------------------------------
    # 3. RULE BASED (fallback institucional)
    # -----------------------------------
    try:
        if ia.get("direction"):
            models_outputs.append({
                "model": "BASE_IA",
                "direction": ia.get("direction"),
                "confidence": ia.get("confidence", 0)
            })
    except Exception:
        pass

    return models_outputs


# ============================================
# MAIN
# ============================================
def compute_ia_pro_decision(data_by_tf, symbol: str, order_book=None):

    audit = get_ia_audit_logger()

    # ----------------------------------------
    # DATA
    # ----------------------------------------
    df_by_tf = {
        tf: pack["df"]
        for tf, pack in data_by_tf.items()
        if isinstance(pack, dict) and "df" in pack
    }

    df_5m = df_by_tf.get("5m")

    # ============================================
    # BASE IA
    # ============================================
    ia = compute_ia_pro_score(df_by_tf, symbol)
    ia.setdefault("smart_money", {
        "direction": "NEUTRAL",
        "confidence": 0
    })
    ia.setdefault("confidence", 0.0)
    ia.setdefault("reasons", [])
    ia.setdefault("actionable", True)
    ia.setdefault("capital_fraction", 0.01)

    # ====================================
    # MARKET SESSION
    # ====================================
    session = detect_market_session()
    ia.setdefault(
        "market_context",
        {}
    )
    ia["market_context"]["session"] = session

    # ============================================
    # REGIME
    # ============================================
    try:
        regime_data = classify_market_regime(df_5m)
        ia["regime"] = regime_data.get("regime", "UNKNOWN")
    except Exception as e:
        ia["regime"] = "UNKNOWN"

        ia["reasons"].append({
            "rule": "REGIME_ERROR",
            "status": "FAIL",
            "details": str(e)
        })

    # ============================================
    # PNL LEARNING
    # ============================================
    strategy = ia.get("strategy", "DEFENSIVE")
    learning_score = pnl_engine.get_strategy_score(strategy)

    learning_score = max(
        0.7,
        min(1.3, learning_score)
    )
    ia["confidence"] *= learning_score
    ia["reasons"].append({
        "rule": "PNL_LEARNING",
        "status": "INFO",
        "details": f"{learning_score:.2f}"
    })

    # ============================================
    # CANDLES
    # ============================================
    try:
        if df_5m is not None:
            patterns = detectar_patrones_velas(df_5m)

            ia["candlestick_context"] = {
                "patterns": patterns
            }

            if patterns:
                ia["confidence"] += min(10, len(patterns) * 2)

                ia["reasons"].append({
                    "rule": "CANDLESTICK",
                    "status": "OK",
                    "details": f"{len(patterns)} patrones"
                })

    except Exception:
        pass

    # ============================================
    # MICROSTRUCTURE
    # ============================================
    ia = process_microstructure(ia, df_5m)

    # ============================================
    # ENSEMBLE (construcción inputs correcta)
    # ============================================
    models_outputs = _build_models_outputs(ia, df_5m)
    ia = process_ensemble(ia, models_outputs)

    # ============================================
    # EXECUTION (incluye slippage)
    # ============================================
    ia = process_execution(ia, df_5m)

    # ==========================================
    # FIX EXECUTION MODE
    # ==========================================

    if (
        ia.get("execution", {})
        .get("mode")
        in [None, "ERROR"]
    ):

        ia["execution"] = {
            "mode": "DEMO"
        }

    # ==================================================
    # FIX DATAFRAME
    # ==================================================
    if "df" not in locals():
        if "df_5m" in locals():
            df=df_5m
        elif "market_df" in locals():
            df=market_df
        elif "ohlc_df" in locals():
            df=ohlc_df
        else:
            raise RuntimeError(
                "No existe DataFrame OHLC para IA"
            )
    if df is None:
        raise RuntimeError(
            "DataFrame vacío"
        )
    if len(df)==0:
        raise RuntimeError(
            "DataFrame sin filas"
        )

    # ======================================================
    # ENTRY TIMING INSTITUCIONAL
    # ======================================================
    confidence = ia.get(
        "confidence",
        0
    )
    direction = ia.get(
        "direction",
        "UNKNOWN"
    )
    current_close = df["close"].iloc[-1]
    previous_close = df["close"].iloc[-2]

    # ==========================================
    # FUERZA DE MOVIMIENTO
    # ==========================================
    move_strength = abs(
        (
            current_close
            -
            previous_close
        )
        /
        previous_close
    )*100

    # ==========================================
    # DECISIÓN
    # ==========================================
    entry_timing={}
    # señales extremadamente fuertes
    if confidence >= 85:
        entry_timing={
            "state":"ENTER_NOW",
            "reason":
            "Confianza extrema"
        }

    # señal fuerte + movimiento real
    elif (
        confidence>=70
        and move_strength>=0.20
    ):
        entry_timing={
            "state":"ENTER_NOW",
            "reason":
            "Momentum confirmado"
        }

    # señal media
    elif confidence>=60:
        entry_timing={
            "state":"WAIT_CONFIRMATION",
            "reason":
            "Esperando confirmación"
        }

    # señal débil
    else:
        entry_timing={
            "state":"NO_TRADE",
            "reason":
            "Confianza insuficiente"
        }
    ia["entry_timing"]=entry_timing

    # ======================================================
    # EXECUTION POLICY INSTITUCIONAL
    # ======================================================
    state = entry_timing["state"]
    allow_trade = False
    ui_lock = True
    show_countdown = False

    # =====================================
    # ENTRADA DIRECTA
    # =====================================
    if state == "ENTER_NOW":
        allow_trade = True
        ui_lock = False

    # =====================================
    # CONFIRMACIÓN SUAVE
    # =====================================
    elif state == "WAIT_CONFIRMATION":
        show_countdown = True
        if confidence >= 68:
            allow_trade = True
            ui_lock = False

    # =====================================
    # ESPERAR CIERRE
    # =====================================
    elif state == "WAIT_NEXT_CLOSE":
        show_countdown = True

    # =====================================
    # BLOQUEO TOTAL
    # =====================================
    elif state == "NO_TRADE":
        allow_trade = False
        ui_lock = True
    ia["execution_policy"] = {
        "allow_trade": allow_trade,
        "show_countdown": show_countdown,
        "ui_lock": ui_lock,
        "message": entry_timing["reason"]
    }

    # ============================================
    # RISK LAYER (VETO + CONSENSO)
    # ============================================
    ia = apply_global_risk_filters(ia)

    # ============================================
    # META FINAL
    # ============================================
    ia = finalize_allocation(ia)

    # ==========================================
    # SINCRONIZAR ACTIONABLE
    # ==========================================

    policy = ia.get(
        "execution_policy",
        {}
    )

    ia["actionable"] = (
        policy.get(
            "allow_trade",
            False
        )
    )

    # ============================================
    # LIMPIEZA DE REASONS INVALIDOS
    # ============================================

    clean_reasons = []

    for r in ia.get("reasons", []):
        if isinstance(r, dict):
            clean_reasons.append(r)
        elif isinstance(r, str):
            clean_reasons.append({
                "rule": "MODEL_OUTPUT",
                "status": "INFO",
                "details": r
            })
    ia["reasons"] = clean_reasons

    # ============================================
    # FINAL
    # ============================================
    ia["timestamp"] = datetime.utcnow().isoformat()
    ia["reasons"] = _normalize_reasons(ia["reasons"])

    # ============================================
    # DEBUG INSTITUCIONAL
    # ============================================
    ia["debug"] = {
        "models_outputs": models_outputs,
        "regime": ia.get("regime"),
        "entry_timing": ia.get("entry_timing"),
        "smart_money": ia.get("smart_money"),
    }

    # ============================================
    # AUDIT
    # ============================================
    audit.log_decision(
        symbol=symbol,
        context="IA_PRO_ORCHESTRATOR",
        ia_decision=ia,
        data_by_tf=df_by_tf,
    )

    ia["confidence"] = max(
        0,
        min(100, ia.get("confidence", 0))
    )

    return ia
