# core/portfolio/cross_market_capital_allocator.py

import numpy as np


class CrossMarketCapitalAllocator:

    """
    Gestor institucional de asignación de capital.
    """

    def __init__(self):

        self.max_allocation_per_asset = 0.40
        self.min_allocation = 0.05

    # =====================================================
    # SOFTMAX ALLOCATION
    # =====================================================

    def _softmax(self, scores):

        scores = np.array(scores)

        exp_scores = np.exp(scores - np.max(scores))

        weights = exp_scores / exp_scores.sum()

        return weights

    # =====================================================
    # CAPITAL ALLOCATION
    # =====================================================

    def allocate(self, opportunities):

        if not opportunities:
            return []

        scores = [o.get("score", 0) for o in opportunities]

        weights = self._softmax(scores)

        results = []

        for opp, w in zip(opportunities, weights):

            allocation = float(w)

            allocation = min(allocation, self.max_allocation_per_asset)

            if allocation < self.min_allocation:
                allocation = 0

            opp["capital_allocation"] = allocation

            results.append(opp)

        return results