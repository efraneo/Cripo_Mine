# core/portfolio/kelly_allocator.py

def kelly_fraction(win_rate, win_loss_ratio):
    return win_rate - ((1 - win_rate) / win_loss_ratio)


def regime_scaled_kelly(kelly, regime):

    scale_map = {
        "CRISIS": 0.2,
        "HIGH_VOL": 0.4,
        "TREND_BULL": 1.0,
        "TREND_BEAR": 0.7,
        "RANGE": 0.5
    }

    return max(0, kelly * scale_map.get(regime, 0.3))
