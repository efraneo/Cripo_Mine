# core/portfolio/hedge_fund_engine.py

import numpy as np


class HedgeFundEngine:

    def __init__(self, engine):
        self.engine = engine

    # ==========================================================
    # VOLATILITY TARGETING
    # ==========================================================
    def compute_volatility(self, df):
        returns = df["close"].pct_change().dropna()
        return returns.std()

    def volatility_target_position(self, capital, df, target_vol=0.02):

        vol = self.compute_volatility(df)

        if vol == 0:
            return capital

        scale = target_vol / vol

        return capital * scale

    # ==========================================================
    # LONG / SHORT SELECTION
    # ==========================================================
    def split_long_short(self, opportunities):

        longs = []
        shorts = []

        for r in opportunities:

            direction = r["ia"].get("direction")

            if direction == "LONG":
                longs.append(r)

            elif direction == "SHORT":
                shorts.append(r)

        return longs, shorts

    # ==========================================================
    # MARKET NEUTRAL BALANCE
    # ==========================================================
    def balance_market_neutral(self, longs, shorts, balance):

        if not longs or not shorts:
            return []

        half = balance / 2

        long_alloc = self._allocate_side(longs, half)
        short_alloc = self._allocate_side(shorts, half)

        return long_alloc + short_alloc

    def _allocate_side(self, assets, capital):

        confidences = np.array([a["confidence"] for a in assets])
        weights = confidences / confidences.sum()

        allocations = []

        for a, w in zip(assets, weights):
            allocations.append({
                "symbol": a["symbol"],
                "capital": capital * w,
                "side": a["ia"].get("direction"),
                "ia": a["ia"]
            })

        return allocations

    # ==========================================================
    # EXECUTION SLICING (TWAP SIMPLE)
    # ==========================================================
    def execute_twap(self, symbol, capital, slices=3):

        orders = []

        slice_size = capital / slices

        for i in range(slices):
            orders.append({
                "symbol": symbol,
                "capital": slice_size,
                "type": "market"
            })

        return orders

    # ==========================================================
    # PIPELINE COMPLETO
    # ==========================================================
    def build_hedge_portfolio(self, opportunities, balance):

        # 1. FILTRO DURO
        valid = []

        for r in opportunities:

            ia = r.get("ia", {})

            policy = ia.get(
                "execution_policy",
                {}
            )

            if (
                r.get("confidence", 0) >= 90
                and policy.get(
                    "allow_trade",
                    False
                )
            ):
                valid.append(r)

        if len(valid) < 2:
            return []

        # 2. SPLIT LONG / SHORT
        longs, shorts = self.split_long_short(valid)

        # 3. BALANCE NEUTRAL
        portfolio = self.balance_market_neutral(longs, shorts, balance)

        # 4. VOL TARGETING
        final = []

        for p in portfolio:

            try:
                df = self.engine.get_klines_df(
                    symbol=p["symbol"],
                    interval="5m",
                    limit=100
                )

                if df is None or df.empty:
                    continue

                adjusted_capital = self.volatility_target_position(
                    p["capital"],
                    df
                )

                p["capital"] = float(adjusted_capital)

            except Exception:
                pass

            final.append(p)

        return final
