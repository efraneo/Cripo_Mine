# core/portfolio/hedge_engine.py

import logging

logger = logging.getLogger(
    "hedge_fund"
)

from core.portfolio.hedge_fund_engine import HedgeFundEngine
from core.risk.hedge_fund_controller import HedgeFundController

logger.info(
    f"Hedge valid setups={len(valid)}"
)
logger.info(
    f"Hedge final portfolio={len(final)}"
)

class InstitutionalHedgeEngine:

    def __init__(self, engine):

        self.engine = engine

        self.fund = HedgeFundEngine(
            engine
        )

        self.controller = HedgeFundController()

    def build_hedge_portfolio(
        self,
        opportunities,
        balance
    ):

        portfolio = self.fund.build_hedge_portfolio(
            opportunities,
            balance
        )

        if not portfolio:
            return []

        validated=[]

        current_portfolio={}

        for p in portfolio:

            exposure_ok,_ = (
                self.controller.check_exposure(
                    current_portfolio,
                    {
                        "symbol":p["symbol"],
                        "size":(
                            p["capital"]/balance
                        )
                    }
                )
            )

            directional_ok,_=(

                self.controller.check_directional_balance(
                    current_portfolio,
                    p["side"]
                )
            )

            if exposure_ok and directional_ok:

                validated.append(
                    p
                )

                current_portfolio[
                    p["symbol"]
                ]={
                    "size":(
                        p["capital"]/balance
                    ),
                    "direction":(
                        p["side"]
                    )
                }

        return validated


    def execute_twap(
        self,
        symbol,
        capital
    ):

        return self.fund.execute_twap(
            symbol,
            capital
        )
