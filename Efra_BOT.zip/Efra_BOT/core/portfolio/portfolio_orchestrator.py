# core/portfolio/portfolio_orchestrator.py

from core.portfolio.strategy_router import StrategyRouter
from core.portfolio.meta_strategy_allocator import MetaStrategyAllocator
from core.portfolio.portfolio_decider import evaluate_ia_for_portfolio


class PortfolioOrchestrator:

    def __init__(self):

        self.router = StrategyRouter()
        self.allocator = MetaStrategyAllocator()

    # ------------------------------------------------
    # UPDATE STRATEGY PERFORMANCE
    # ------------------------------------------------

    def update_strategy_returns(self, strategy, returns):

        self.allocator.update_strategy_returns(
            strategy,
            returns
        )

    # ------------------------------------------------
    # COMPUTE RISK ADJUSTMENT
    # ------------------------------------------------

    def compute_risk_adjustment(self, strategy, base_risk):

        risk_scale = self.allocator.get_strategy_risk_scale(strategy)

        return base_risk * risk_scale

    # ------------------------------------------------
    # MAIN PORTFOLIO DECISION
    # ------------------------------------------------

    def evaluate_trade(
        self,
        symbol,
        amount,
        ia_decision,
        base_risk
    ):

        # ROUTE STRATEGY
        routed = self.router.route(ia_decision)

        strategy = routed["strategy"]

        # STRATEGY RISK SCALE
        adjusted_risk = self.compute_risk_adjustment(
            strategy,
            base_risk
        )

        # PORTFOLIO RISK CHECK
        allowed, decision = evaluate_ia_for_portfolio(
            symbol,
            amount,
            ia_decision
        )

        if not allowed:
            return False, decision

        decision["adjusted_risk"] = adjusted_risk
        decision["strategy"] = strategy

        return True, decision
