# core/portfolio/optimizer.py

import numpy as np


def mean_variance_weights(returns_matrix, risk_aversion=1.0):
    """
    returns_matrix: shape (n_assets, T)
    """

    cov = np.cov(returns_matrix)
    mean_returns = np.mean(returns_matrix, axis=1)

    inv_cov = np.linalg.pinv(cov)

    weights = inv_cov @ mean_returns
    weights = weights / np.sum(np.abs(weights))

    return weights


def risk_parity_weights(returns_matrix):

    cov = np.cov(returns_matrix)

    vol = np.sqrt(np.diag(cov))
    inv_vol = 1 / (vol + 1e-9)

    weights = inv_vol / np.sum(inv_vol)

    return weights

