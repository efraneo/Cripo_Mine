# core/portfolio/strategy_nav.py

from dataclasses import dataclass
from datetime import datetime


@dataclass
class StrategyState:
    strategy: str
    nav: float
    peak_nav: float
    drawdown: float
    last_update: str


# ======================================================
# STORAGE SIMPLE (puedes migrar a DB después)
# ======================================================
_STRATEGY_STATES = {}


# ======================================================
# INIT
# ======================================================
def init_strategy(strategy: str, initial_nav: float):
    _STRATEGY_STATES[strategy] = StrategyState(
        strategy=strategy,
        nav=initial_nav,
        peak_nav=initial_nav,
        drawdown=0.0,
        last_update=datetime.utcnow().isoformat()
    )


# ======================================================
# UPDATE NAV
# ======================================================
def update_strategy_nav(strategy: str, pnl: float):

    if strategy not in _STRATEGY_STATES:
        init_strategy(strategy, 10000)

    s = _STRATEGY_STATES[strategy]

    s.nav += pnl

    if s.nav > s.peak_nav:
        s.peak_nav = s.nav

    s.drawdown = (
        (s.peak_nav - s.nav) / s.peak_nav
        if s.peak_nav > 0 else 0
    )

    s.last_update = datetime.utcnow().isoformat()


# ======================================================
# GETTERS
# ======================================================
def get_strategy_state(strategy: str):
    return _STRATEGY_STATES.get(strategy)


def get_all_strategies():
    return _STRATEGY_STATES
