# core/portfolio/multi_asset_engine.py

import numpy as np


class MultiAssetEngine:

    def __init__(self, engine):

        self.engine = engine

        # ⚙️ parámetros institucionales
        self.max_positions = 5
        self.min_confidence = 85
        self.capital_fraction = 0.8  # usar 80% del capital

    # ==================================================
    # MAIN
    # ==================================================
    def select_best_trades(self, market_results):

        """
        market_results = [
            {"symbol": ..., "ia": {...}},
            ...
        ]
        """

        scored = []

        for item in market_results:

            ia = item["ia"]

            if ia.get("confidence", 0) < self.min_confidence:
                continue

            score = self._score_trade(ia)

            scored.append({
                "symbol": item["symbol"],
                "ia": ia,
                "score": score
            })

        # ordenar mejores
        scored.sort(key=lambda x: x["score"], reverse=True)

        return scored[:self.max_positions]

    # ==================================================
    # SCORE INSTITUCIONAL
    # ==================================================
    def _score_trade(self, ia):

        confidence = ia.get("confidence", 0)
        regime = ia.get("regime", "neutral")

        regime_bonus = {
            "trend": 1.2,
            "breakout": 1.3,
            "range": 0.7,
            "choppy": 0.5
        }.get(regime, 1)

        return confidence * regime_bonus

    # ==================================================
    # CAPITAL ALLOCATION
    # ==================================================
    def allocate_capital(self, selected_trades):

        if not selected_trades:
            return []

        total_score = sum(t["score"] for t in selected_trades)

        balance = self.engine.get_balance("USDT")
        capital = balance * self.capital_fraction

        allocation = []

        for trade in selected_trades:

            weight = trade["score"] / total_score

            usd = capital * weight

            allocation.append({
                "symbol": trade["symbol"],
                "usd": usd,
                "ia": trade["ia"]
            })

        return allocation

