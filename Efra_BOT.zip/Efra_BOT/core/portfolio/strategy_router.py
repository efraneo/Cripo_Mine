# core/portfolio/strategy_router.py

# ============================================================
# STRATEGY ROUTER — INSTITUTIONAL VERSION
# ============================================================

from typing import Dict

class StrategyRouter:

    def __init__(self):
        self.strategy_map = {
            "BULL": "trend_following",
            "BEAR": "trend_following",
            "SIDEWAYS": "mean_reversion",
            "VOLATILITY_SPIKE": "volatility_breakout",
            "CRISIS": "capital_preservation"
        }

    # ------------------------------------------------
    # ROUTE STRATEGY
    # ------------------------------------------------

    def route(self, ia_decision: Dict):
        regime = ia_decision.get("regime", "SIDEWAYS")
        strategy = self.strategy_map.get(
            regime,
            "mean_reversion"
        )

        return {
            "strategy": strategy,
            "regime": regime
        }