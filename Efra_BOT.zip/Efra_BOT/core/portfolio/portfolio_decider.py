# ============================================================
# PORTFOLIO DECIDER — INSTITUTIONAL UNIFIED VERSION
# ============================================================

import os
import json
from typing import Dict, Any, Tuple

try:
    from core.logger import get_logger
    log = get_logger(__name__)
except Exception:
    import logging
    log = logging.getLogger(__name__)


ACTIVE_TRADES_FILE = "data/active_trades.json"

MAX_PORTFOLIO_EXPOSURE = 0.30
MAX_SYMBOL_EXPOSURE = 0.10
MIN_CONFIDENCE = 0.55


# ============================================================
# LOAD ACTIVE TRADES
# ============================================================

def _load_active_trades() -> Dict[str, Any]:
    try:
        if not os.path.exists(ACTIVE_TRADES_FILE):
            return {}
        with open(ACTIVE_TRADES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        log.exception("Failed loading active trades")
        return {}

# ============================================================
# CALCULATE TOTAL EXPOSURE
# ============================================================
def _calculate_total_exposure(trades: Dict[str, Any]) -> float:
    total = 0.0
    for symbol, trade in trades.items():
        exposure = trade.get("exposure", 0.0)
        total += exposure
    return total

# ============================================================
# MAIN DECISION FUNCTION (COMPATIBLE WITH ENGINE)
# ============================================================

def evaluate_ia_for_portfolio(
    symbol: str,
    amount: float,
    ia_decision: Dict[str, Any]
) -> Tuple[bool, Dict[str, Any]]:
    """
    Returns:
    allowed: bool
    decision: dict
    """
    try:
        trades = _load_active_trades()
        total_exposure = _calculate_total_exposure(trades)
        if total_exposure >= MAX_PORTFOLIO_EXPOSURE:
            return False, {
                "reason": "MAX_PORTFOLIO_EXPOSURE_REACHED"
            }
        symbol_trade = trades.get(symbol)
        if symbol_trade:
            symbol_exposure = symbol_trade.get("exposure", 0.0)
            if symbol_exposure >= MAX_SYMBOL_EXPOSURE:
                return False, {
                    "reason": "MAX_SYMBOL_EXPOSURE_REACHED"
                }
        confidence = ia_decision.get("confidence", 0.0)
        if confidence < MIN_CONFIDENCE:
            return False, {
                "reason": "LOW_CONFIDENCE"
            }
        regime = ia_decision.get("regime", "NORMAL")
        if regime == "CHAOTIC":
            return False, {
                "reason": "CHAOTIC_MARKET"
            }
        # APPROVED
        return True, {
            "symbol": symbol,
            "amount": amount,
            "confidence": confidence,
            "approved": True
        }
    except Exception:
        log.exception("Portfolio decision failed")
        return False, {
            "reason": "INTERNAL_ERROR"
        }
