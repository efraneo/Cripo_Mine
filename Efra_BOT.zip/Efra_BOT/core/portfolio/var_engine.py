# core/portfolio/var_engine.py

import numpy as np


def historical_var(returns, confidence=0.95):
    """
    VaR histórico institucional
    """

    if len(returns) < 10:
        return 0

    percentile = (1 - confidence) * 100
    return np.percentile(returns, percentile)


def portfolio_var(equity_curve):
    returns = np.diff(equity_curve) / equity_curve[:-1]
    return {
        "VaR_95": historical_var(returns, 0.95),
        "VaR_99": historical_var(returns, 0.99)
    }
