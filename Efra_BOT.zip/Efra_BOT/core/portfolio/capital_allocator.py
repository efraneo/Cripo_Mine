# core/portfolio/capital_allocator.py

def allocate_capital(confidence: float) -> float:
    """
    Position sizing basado en confianza IA.
    """

    if confidence >= 90:
        return 0.10
    if confidence >= 80:
        return 0.07
    if confidence >= 70:
        return 0.05
    if confidence >= 60:
        return 0.03

    return 0.0
