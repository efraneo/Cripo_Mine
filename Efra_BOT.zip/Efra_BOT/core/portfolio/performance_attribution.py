# core/portfolio/performance_attribution.py

def build_attribution(trades: list) -> dict:
    """
    Attribution institucional:
    - Por símbolo
    - Por estrategia
    - Por sesión
    """

    by_symbol = {}
    by_strategy = {}
    by_session = {}

    for t in trades:
        pnl = t.get("pnl", 0)

        sym = t.get("symbol", "UNK")
        strat = t.get("strategy", "UNK")
        sess = t.get("session", "UNK")

        by_symbol[sym] = by_symbol.get(sym, 0) + pnl
        by_strategy[strat] = by_strategy.get(strat, 0) + pnl
        by_session[sess] = by_session.get(sess, 0) + pnl

    return {
        "symbol": by_symbol,
        "strategy": by_strategy,
        "session": by_session
    }
