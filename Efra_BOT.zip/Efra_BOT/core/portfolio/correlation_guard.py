# core/portfolio/correlation_guard.py

CORRELATED_GROUPS = [
    {"BTCUSDT", "ETHUSDT"},
    {"NASDAQ", "SP500"},
]

def check_correlation(symbol, portfolio):
    for group in CORRELATED_GROUPS:
        if symbol in group:
            for s in group:
                if s in portfolio["open_positions"]:
                    return False, f"Alta correlación con {s}"
    return True, "OK"
