# core/portfolio/exposure_manager.py

MAX_PORTFOLIO_EXPOSURE = 0.30
MAX_SINGLE_ASSET = 0.10

def check_exposure(symbol, proposed_size, portfolio):
    total_exposure = sum(portfolio["exposure_by_asset"].values())

    if total_exposure + proposed_size > MAX_PORTFOLIO_EXPOSURE:
        return False, "Exposición total excedida"

    if portfolio["exposure_by_asset"].get(symbol, 0) + proposed_size > MAX_SINGLE_ASSET:
        return False, "Exposición por activo excedida"

    return True, "OK"
