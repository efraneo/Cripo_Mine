# core/portfolio/portfolio_state.py

_PORTFOLIO_STATE = {
    "capital": 100_000,
    "open_positions": {},
    "exposure_by_asset": {},
    "exposure_by_side": {"LONG": 0, "SHORT": 0},
}

def get_portfolio_state():
    return _PORTFOLIO_STATE

def register_position(symbol, side, size):
    s = _PORTFOLIO_STATE
    s["open_positions"][symbol] = {"side": side, "size": size}
    s["exposure_by_asset"][symbol] = size
    s["exposure_by_side"][side] += size

def close_position(symbol):
    s = _PORTFOLIO_STATE
    pos = s["open_positions"].pop(symbol, None)
    if pos:
        s["exposure_by_side"][pos["side"]] -= pos["size"]
        s["exposure_by_asset"].pop(symbol, None)
