# core/portfolio/multi_level_nav.py

from collections import defaultdict


def build_multi_level_nav(trades: list):
    """
    NAV jerárquico institucional
    """

    strategy_nav = defaultdict(float)
    desk_nav = defaultdict(float)
    session_nav = defaultdict(float)

    for t in trades:
        pnl = t.get("pnl", 0)

        strategy = t.get("strategy", "UNK")
        desk = t.get("desk", "CORE")
        session = t.get("session", "GLOBAL")

        strategy_nav[strategy] += pnl
        desk_nav[desk] += pnl
        session_nav[session] += pnl

    return {
        "strategy_nav": dict(strategy_nav),
        "desk_nav": dict(desk_nav),
        "session_nav": dict(session_nav)
    }
