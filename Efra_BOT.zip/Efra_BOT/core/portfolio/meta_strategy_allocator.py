# core/portfolio/meta_strategy_allocator.py

import logging
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


class MetaStrategyAllocator:
    """
    Meta Strategy Allocator (Institutional).

    Gestiona múltiples estrategias y asigna capital
    dinámicamente según performance y estabilidad.
    """

    def __init__(self):

        self.strategy_stats = {}
        self.strategy_weights = {}

        self.min_weight = 0.05
        self.max_weight = 0.50

    # ======================================
    # UPDATE STRATEGY RETURNS
    # ======================================

    def update_strategy_returns(
        self,
        strategy_name,
        returns_series
    ):

        try:

            returns = pd.Series(returns_series).dropna()

            if len(returns) < 10:
                return

            mean = returns.mean()
            vol = returns.std()

            sharpe = 0

            if vol > 0:
                sharpe = (mean / vol) * np.sqrt(252)

            drawdown = self._max_drawdown(returns)

            self.strategy_stats[strategy_name] = {

                "mean": mean,
                "vol": vol,
                "sharpe": sharpe,
                "drawdown": drawdown,
                "n": len(returns)

            }

        except Exception:

            logger.exception(
                "Strategy stats update failed"
            )

    # ======================================
    # MAX DRAWDOWN
    # ======================================

    def _max_drawdown(self, returns):

        equity = (1 + returns).cumprod()

        peak = equity.cummax()

        dd = (equity - peak) / peak

        return abs(dd.min())

    # ======================================
    # COMPUTE STRATEGY SCORE
    # ======================================

    def strategy_score(self, stats):

        sharpe = stats["sharpe"]
        dd = stats["drawdown"]
        vol = stats["vol"]

        score = 0

        if sharpe > 2:
            score += 3
        elif sharpe > 1:
            score += 2
        elif sharpe > 0.5:
            score += 1

        if dd < 0.10:
            score += 2
        elif dd < 0.20:
            score += 1

        if vol < 0.30:
            score += 1

        return score

    # ======================================
    # COMPUTE ALLOCATION
    # ======================================

    def compute_allocations(self):

        try:

            scores = {}

            for strat, stats in self.strategy_stats.items():

                score = self.strategy_score(stats)

                scores[strat] = score

            if not scores:
                return {}

            total_score = sum(scores.values())

            if total_score == 0:

                equal_weight = 1 / len(scores)

                for strat in scores:
                    self.strategy_weights[strat] = equal_weight

                return self.strategy_weights

            weights = {}

            for strat, score in scores.items():

                w = score / total_score

                w = max(self.min_weight, w)
                w = min(self.max_weight, w)

                weights[strat] = w

            # normalizar

            total = sum(weights.values())

            for strat in weights:

                weights[strat] /= total

            self.strategy_weights = weights

            logger.info(
                f"Strategy allocations: {weights}"
            )

            return weights

        except Exception:

            logger.exception(
                "Strategy allocation failed"
            )

            return {}

    # ======================================
    # GET STRATEGY RISK SCALE
    # ======================================

    def get_strategy_risk_scale(self, strategy_name):

        if strategy_name not in self.strategy_weights:

            return 0.1

        weight = self.strategy_weights[strategy_name]

        return weight

    # ======================================
    # PORTFOLIO SUMMARY
    # ======================================

    def portfolio_summary(self):

        return {

            "strategies": list(self.strategy_stats.keys()),

            "weights": self.strategy_weights,

            "stats": self.strategy_stats

        }