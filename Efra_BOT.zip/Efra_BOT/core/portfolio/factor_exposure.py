# core/portfolio/factor_exposure.py

def build_factor_exposure(trades):
    """
    Factor model simplificado institucional
    """

    factors = {
        "trend": 0,
        "volatility": 0,
        "momentum": 0,
        "mean_reversion": 0
    }

    for t in trades:
        pnl = t.get("pnl", 0)
        tags = t.get("factors", [])

        for f in tags:
            if f in factors:
                factors[f] += pnl

    return factors
