# core/portfolio/nav_calculator.py

from datetime import datetime
import pytz


def calculate_nav(portfolio_state: dict) -> dict:
    """
    NAV institucional real:
    NAV = Cash + Σ (Position Size * Mark Price)
    """

    cash = portfolio_state.get("cash", 0.0)
    positions = portfolio_state.get("positions", [])

    positions_value = 0.0

    for p in positions:
        qty = p.get("qty", 0.0)
        price = p.get("mark_price", 0.0)
        positions_value += qty * price

    nav = cash + positions_value

    return {
        "timestamp": datetime.utcnow().replace(tzinfo=pytz.UTC).isoformat(),
        "cash": cash,
        "positions_value": positions_value,
        "nav": nav
    }
