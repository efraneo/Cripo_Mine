# core/portfolio/equity_curve_store.py

import json
from pathlib import Path

STORE = Path("data/nav_history.json")


def _load():
    if not STORE.exists():
        return []
    return json.loads(STORE.read_text())


def append_nav_snapshot(snapshot: dict):
    data = _load()
    data.append(snapshot)
    STORE.write_text(json.dumps(data, indent=2))


def get_equity_curve():
    return _load()
