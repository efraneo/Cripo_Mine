# core/portfolio/portfolio_nav.py

from datetime import datetime


_PORTFOLIO_STATE = {
    "nav": 10000.0,
    "peak_nav": 10000.0,
    "drawdown": 0.0,
    "last_update": datetime.utcnow().isoformat(),
}


# ======================================================
# UPDATE NAV GLOBAL
# ======================================================
def update_portfolio_nav(pnl: float):

    _PORTFOLIO_STATE["nav"] += pnl

    if _PORTFOLIO_STATE["nav"] > _PORTFOLIO_STATE["peak_nav"]:
        _PORTFOLIO_STATE["peak_nav"] = _PORTFOLIO_STATE["nav"]

    peak = _PORTFOLIO_STATE["peak_nav"]
    nav = _PORTFOLIO_STATE["nav"]

    _PORTFOLIO_STATE["drawdown"] = (
        (peak - nav) / peak if peak > 0 else 0
    )

    _PORTFOLIO_STATE["last_update"] = datetime.utcnow().isoformat()


# ======================================================
# GET STATE
# ======================================================
def get_portfolio_state():
    return _PORTFOLIO_STATE
