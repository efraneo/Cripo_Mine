# core/reporting/daily_nav_snapshot.py

from core.portfolio.nav_calculator import calculate_nav
from core.portfolio.equity_curve_store import append_nav_snapshot
from core.portfolio.performance_attribution import build_attribution


def build_daily_snapshot(portfolio_state, trades_today):
    nav = calculate_nav(portfolio_state)
    attribution = build_attribution(trades_today)

    snapshot = {
        "nav": nav,
        "attribution": attribution
    }

    append_nav_snapshot(nav)

    return snapshot
