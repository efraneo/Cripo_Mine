import pandas as pd
import numpy as np


# ============================================================
# HELPERS
# ============================================================

def _swing_highs_lows(df):
    highs = df["high"]
    lows = df["low"]

    swing_highs = (highs.shift(1) < highs) & (highs.shift(-1) < highs)
    swing_lows = (lows.shift(1) > lows) & (lows.shift(-1) > lows)

    return swing_highs, swing_lows


# ============================================================
# LIQUIDITY SWEEP
# ============================================================

def detect_liquidity_sweep(df):
    if len(df) < 10:
        return {"sweep": False, "type": None}

    last = df.iloc[-1]
    prev = df.iloc[-5:-1]

    high_sweep = last["high"] > prev["high"].max() and last["close"] < last["high"]
    low_sweep = last["low"] < prev["low"].min() and last["close"] > last["low"]

    if high_sweep:
        return {"sweep": True, "type": "BUY_SIDE_LIQUIDITY"}
    if low_sweep:
        return {"sweep": True, "type": "SELL_SIDE_LIQUIDITY"}

    return {"sweep": False, "type": None}


# ============================================================
# BREAK OF STRUCTURE (BOS)
# ============================================================

def detect_bos(df):
    swing_highs, swing_lows = _swing_highs_lows(df)

    recent_highs = df["high"][swing_highs]
    recent_lows = df["low"][swing_lows]

    if len(recent_highs) < 2 or len(recent_lows) < 2:
        return {"bos": False, "direction": None}

    last_close = df["close"].iloc[-1]

    if last_close > recent_highs.iloc[-2]:
        return {"bos": True, "direction": "BULLISH"}

    if last_close < recent_lows.iloc[-2]:
        return {"bos": True, "direction": "BEARISH"}

    return {"bos": False, "direction": None}


# ============================================================
# FAIR VALUE GAP (FVG)
# ============================================================

def detect_fvg(df):
    gaps = []

    for i in range(2, len(df)):
        c1 = df.iloc[i - 2]
        c2 = df.iloc[i - 1]
        c3 = df.iloc[i]

        # gap alcista
        if c1["high"] < c3["low"]:
            gaps.append("BULLISH")

        # gap bajista
        elif c1["low"] > c3["high"]:
            gaps.append("BEARISH")

    if not gaps:
        return {"fvg": False, "type": None}

    return {
        "fvg": True,
        "type": gaps[-1]
    }


# ============================================================
# ORDER BLOCK (simple institucional)
# ============================================================

def detect_order_block(df):
    last = df.iloc[-3:]

    body_sizes = abs(last["close"] - last["open"])

    if body_sizes.mean() < (df["close"].std() * 0.5):
        return {"ob": False, "type": None}

    if last["close"].iloc[-1] > last["open"].iloc[-1]:
        return {"ob": True, "type": "BULLISH"}

    else:
        return {"ob": True, "type": "BEARISH"}


# ============================================================
# CORE SMC V2
# ============================================================

def compute_smart_money_score(df):

    if df is None or len(df) < 20:
        return {
            "confidence": 0,
            "signal": "NO_DATA"
        }

    score = 0
    signals = []

    # -----------------------------
    # LIQUIDITY SWEEP
    # -----------------------------
    sweep = detect_liquidity_sweep(df)
    if sweep["sweep"]:
        score += 25
        signals.append(f"Sweep {sweep['type']}")

    # -----------------------------
    # BOS
    # -----------------------------
    bos = detect_bos(df)
    if bos["bos"]:
        score += 25
        signals.append(f"BOS {bos['direction']}")

    # -----------------------------
    # FVG
    # -----------------------------
    fvg = detect_fvg(df)
    if fvg["fvg"]:
        score += 20
        signals.append(f"FVG {fvg['type']}")

    # -----------------------------
    # ORDER BLOCK
    # -----------------------------
    ob = detect_order_block(df)
    if ob["ob"]:
        score += 20
        signals.append(f"OB {ob['type']}")

    # -----------------------------
    # NORMALIZACIÓN
    # -----------------------------
    confidence = min(100, score)

    # señal final
    if confidence >= 80:
        signal = "STRONG_SMART_MONEY"
    elif confidence >= 60:
        signal = "MODERATE_SMART_MONEY"
    else:
        signal = "WEAK_SMART_MONEY"

    return {
        "confidence": confidence,
        "signal": signal,
        "details": signals
    }
