# core/risk/convexity_overlay.py

def apply_convexity_overlay(
    var_data,
    regime_data
):

    scale = 1.0
    mode = "NORMAL"

    if regime_data.get("regime") == "VOLATILITY_SPIKE":
        scale *= 0.7
        mode = "VOL_SHOCK"

    if var_data.get("var_95", 0) > 0.03:
        scale *= 0.6
        mode = "TAIL_RISK"

    return {
        "convexity_scale": scale,
        "mode": mode
    }
