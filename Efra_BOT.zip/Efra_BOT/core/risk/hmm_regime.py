# core/risk/hmm_regime.py

import numpy as np

def detect_hmm_regime(returns):

    if len(returns) < 50:
        return {"regime": "UNKNOWN", "confidence": 0}

    vol = np.std(returns[-50:])
    mean = np.mean(returns[-50:])

    if vol > 0.02:
        regime = "HIGH_VOL"
    elif abs(mean) < 0.001:
        regime = "SIDEWAYS"
    else:
        regime = "TREND"

    return {
        "regime": regime,
        "confidence": min(1.0, vol * 10)
    }

