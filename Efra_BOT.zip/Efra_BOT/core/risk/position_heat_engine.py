# core/risk/position_heat_engine.py

# ============================================================
# POSITION HEAT ENGINE — PORTFOLIO RISK CONTROL
# ============================================================

import os
import json
import numpy as np
import pandas as pd
from typing import Dict

ACTIVE_TRADES_FILE = "data/active_trades.json"

MAX_PORTFOLIO_HEAT = 0.35
CORRELATION_PENALTY = 0.25


# ============================================================
# LOAD ACTIVE TRADES
# ============================================================

def _load_active_trades():

    if not os.path.exists(ACTIVE_TRADES_FILE):
        return {}

    try:
        with open(ACTIVE_TRADES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


# ============================================================
# PORTFOLIO HEAT
# ============================================================

def compute_portfolio_heat(trades: Dict):

    heat = 0.0

    for symbol, trade in trades.items():

        exposure = trade.get("exposure", 0)

        heat += exposure

    return heat


# ============================================================
# CORRELATION RISK
# ============================================================

def compute_correlation_penalty(price_matrix: pd.DataFrame):

    if price_matrix is None or len(price_matrix.columns) < 2:
        return 0.0

    corr = price_matrix.corr()

    upper = corr.where(
        np.triu(np.ones(corr.shape), k=1).astype(bool)
    )

    avg_corr = upper.stack().mean()

    if np.isnan(avg_corr):
        return 0.0

    return avg_corr * CORRELATION_PENALTY


# ============================================================
# HEAT DECISION ENGINE
# ============================================================

def evaluate_portfolio_heat(price_matrix: pd.DataFrame = None):

    trades = _load_active_trades()

    heat = compute_portfolio_heat(trades)

    corr_penalty = compute_correlation_penalty(price_matrix)

    adjusted_heat = heat + corr_penalty

    allow_trade = True
    heat_scale = 1.0
    mode = "NORMAL"

    if adjusted_heat > MAX_PORTFOLIO_HEAT:

        allow_trade = False
        mode = "OVERHEATED"
        heat_scale = 0.0

    elif adjusted_heat > MAX_PORTFOLIO_HEAT * 0.8:

        mode = "HOT"
        heat_scale = 0.5

    return {
        "mode": mode,
        "heat": heat,
        "correlation_penalty": corr_penalty,
        "adjusted_heat": adjusted_heat,
        "heat_scale": heat_scale,
        "allow_trade": allow_trade
    }