# core/risk/equity_regime_engine.py

import numpy as np


def detect_equity_regime(equity_curve):

    if len(equity_curve) < 80:
        return {
            "regime": "NORMAL",
            "regime_scale": 1.0
        }

    equity = np.array(equity_curve)

    returns = np.diff(equity) / equity[:-1]

    short = np.mean(returns[-20:])
    long = np.mean(returns[-80:])

    volatility = np.std(returns[-40:])

    regime = "NORMAL"
    scale = 1.0

    if short > long * 1.5 and short > 0:
        regime = "HOT_STREAK"
        scale = 1.2

    elif short < 0 and long > 0:
        regime = "COLD_STREAK"
        scale = 0.6

    elif short < 0 and long < 0:
        regime = "CRISIS_MODE"
        scale = 0.4

    if volatility > 0.04:
        scale *= 0.7

    scale = max(0.2, min(scale, 1.3))

    return {
        "regime": regime,
        "regime_scale": scale,
        "volatility": float(volatility),
        "short_return": float(short),
        "long_return": float(long)
    }
