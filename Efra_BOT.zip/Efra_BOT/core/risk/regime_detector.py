# core/risk/regime_detector.py

import numpy as np


def detect_regime_shift(returns):

    if returns is None or len(returns) < 50:
        return _default_response()

    try:
        recent_vol = np.std(returns[-20:])
        long_vol = np.std(returns[-100:])

        vol_ratio = recent_vol / (long_vol + 1e-9)

        autocorr = np.corrcoef(
            returns[-20:],
            returns[-21:-1]
        )[0, 1]

        regime = "NORMAL"
        regime_scale = 1.0

        if vol_ratio > 1.8:
            regime = "VOLATILITY_SPIKE"
            regime_scale = 0.6

        elif autocorr > 0.4:
            regime = "TRENDING"

        elif abs(autocorr) < 0.05:
            regime = "RANGE"

        return {
            "regime": regime,
            "vol_ratio": float(vol_ratio),
            "autocorrelation": float(autocorr),
            "regime_scale": float(regime_scale)
        }

    except Exception:
        return _default_response()


def _default_response():
    return {
        "regime": "UNKNOWN",
        "vol_ratio": 1.0,
        "autocorrelation": 0.0,
        "regime_scale": 1.0
    }
