# core/risk/drawdown_guardian.py

# ============================================================
# DRAWDOWN GUARDIAN — INSTITUTIONAL RISK PROTECTION
# ============================================================

from typing import Dict


# thresholds institucionales
DD_DEFENSIVE = 0.05
DD_REDUCED = 0.10
DD_PAUSE = 0.15


# ============================================================
# CALCULATE DRAWDOWN
# ============================================================

def compute_drawdown(current_equity: float, peak_equity: float) -> float:

    if peak_equity <= 0:
        return 0.0

    return (peak_equity - current_equity) / peak_equity


# ============================================================
# DRAWDOWN POLICY ENGINE
# ============================================================

def evaluate_drawdown_risk(
    current_equity: float,
    peak_equity: float
) -> Dict:

    drawdown = compute_drawdown(current_equity, peak_equity)

    mode = "NORMAL"
    risk_scale = 1.0
    allow_trading = True

    if drawdown >= DD_PAUSE:

        mode = "PAUSE"
        risk_scale = 0.0
        allow_trading = False

    elif drawdown >= DD_REDUCED:

        mode = "REDUCED"
        risk_scale = 0.25

    elif drawdown >= DD_DEFENSIVE:

        mode = "DEFENSIVE"
        risk_scale = 0.5

    return {
        "mode": mode,
        "drawdown": drawdown,
        "risk_scale": risk_scale,
        "allow_trading": allow_trading
    }
