# core/risk/dynamic_leverage.py

import numpy as np


def compute_dynamic_leverage(
    portfolio_returns,
    target_vol=0.02,
    max_leverage=3.0,
    min_leverage=0.5
):

    if portfolio_returns is None or len(portfolio_returns) < 30:
        return _default_response()

    try:
        realized_vol = np.std(portfolio_returns)

        if realized_vol == 0:
            return _default_response()

        leverage = target_vol / realized_vol

        leverage = np.clip(
            leverage,
            min_leverage,
            max_leverage
        )

        mode = "NORMAL"

        if leverage == max_leverage:
            mode = "MAX_LEVERAGE"
        elif leverage == min_leverage:
            mode = "MIN_LEVERAGE"

        return {
            "realized_vol": float(realized_vol),
            "target_vol": target_vol,
            "leverage_multiplier": float(leverage),
            "mode": mode
        }

    except Exception:
        return _default_response()


def _default_response():
    return {
        "realized_vol": 0.0,
        "target_vol": 0.0,
        "leverage_multiplier": 1.0,
        "mode": "INSUFFICIENT_DATA"
    }
