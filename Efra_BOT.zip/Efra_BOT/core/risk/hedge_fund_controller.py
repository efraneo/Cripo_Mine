# core/risk/hedge_fund_controller.py

import numpy as np


class HedgeFundController:

    def __init__(self):
        self.max_total_exposure = 0.3   # 30% del capital total
        self.max_symbol_exposure = 0.1  # 10% por activo
        self.max_correlation = 0.8

    # ==========================================
    # EXPOSURE CONTROL
    # ==========================================
    def check_exposure(self, portfolio, new_trade):

        total_exposure = sum(p["size"] for p in portfolio.values())

        if total_exposure >= self.max_total_exposure:
            return False, "MAX_TOTAL_EXPOSURE"

        symbol = new_trade["symbol"]

        symbol_exposure = sum(
            p["size"] for s, p in portfolio.items() if s == symbol
        )

        if symbol_exposure >= self.max_symbol_exposure:
            return False, "MAX_SYMBOL_EXPOSURE"

        return True, "OK"

    # ==========================================
    # LONG / SHORT BALANCE
    # ==========================================
    def check_directional_balance(self, portfolio, new_direction):

        longs = sum(1 for p in portfolio.values() if p["direction"] in ["LONG", "BUY"])
        shorts = sum(1 for p in portfolio.values() if p["direction"] in ["SHORT", "SELL"])

        if new_direction in ["LONG", "BUY"] and longs > shorts * 2:
            return False, "LONG_OVEREXPOSED"

        if new_direction in ["SHORT", "SELL"] and shorts > longs * 2:
            return False, "SHORT_OVEREXPOSED"

        return True, "OK"

    # ==========================================
    # CORRELATION CONTROL
    # ==========================================
    def check_correlation(self, price_matrix, new_series):

        if price_matrix is None or len(price_matrix) < 2:
            return True, "NO_DATA"

        for col in price_matrix:
            corr = np.corrcoef(price_matrix[col], new_series)[0, 1]

            if abs(corr) > self.max_correlation:
                return False, f"CORRELATED_{col}"

        return True, "OK"
