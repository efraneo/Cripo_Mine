# core/risk/risk_matrix.py

def build_risk_matrix(nav, var, drawdown, exposure):
    score = 0

    if drawdown > 0.05:
        score += 2

    if abs(var["VaR_95"]) > 0.02:
        score += 2

    if abs(exposure.get("volatility", 0)) > 0.3:
        score += 1

    return score
