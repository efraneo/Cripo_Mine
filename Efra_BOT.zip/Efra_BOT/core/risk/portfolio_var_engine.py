# core/risk/portfolio_var_engine.py

import numpy as np
from scipy.stats import norm


def evaluate_portfolio_var(
    portfolio_returns,
    confidence=0.95,
    var_threshold=0.02
):
    """
    portfolio_returns: np.array de returns agregados
    """

    if portfolio_returns is None or len(portfolio_returns) < 30:
        return _default_response()

    try:
        sigma = np.std(portfolio_returns)

        z = norm.ppf(confidence)

        var = z * sigma

        # Expected Shortfall (CVaR)
        cvar = sigma * (
            norm.pdf(z) / (1 - confidence)
        )

        var_scale = 1.0
        risk_mode = "NORMAL"

        if var > var_threshold:
            var_scale = max(0.5, 1 - (var / var_threshold) * 0.5)
            risk_mode = "ELEVATED_VAR"

        return {
            "var_95": float(var),
            "cvar_95": float(cvar),
            "var_scale": float(var_scale),
            "risk_mode": risk_mode
        }

    except Exception:
        return _default_response()


def _default_response():
    return {
        "var_95": 0.0,
        "cvar_95": 0.0,
        "var_scale": 1.0,
        "risk_mode": "INSUFFICIENT_DATA"
    }
