# core/risk/risk_governor.py

from typing import Tuple


# ======================================================
# CONFIG INSTITUCIONAL (AJUSTABLE)
# ======================================================
MAX_DAILY_DRAWDOWN = 0.05        # 5%
MAX_SESSION_DRAWDOWN = 0.03      # 3%
MIN_CONFIDENCE = 60              # %
MAX_LIQUIDITY_RISK = 0.7         # 0–1
MAX_TAIL_RISK = 0.08             # 8%


# ======================================================
# 🏛 GLOBAL RISK GOVERNOR
# ======================================================
def evaluate_global_risk(
    *,
    nav: float,
    drawdown: float,
    liquidity_risk: float,
    tail_signal: dict | None,
    confidence: float,
) -> Tuple[bool, str]:
    """
    Autoridad final de riesgo.
    Devuelve:
        (allowed: bool, reason: str)
    """

    # -----------------------------
    # 1️⃣ DRAWDOWN DURO
    # -----------------------------
    if drawdown >= MAX_DAILY_DRAWDOWN:
        return False, (
            f"Daily drawdown excedido ({drawdown:.2%} ≥ {MAX_DAILY_DRAWDOWN:.2%})"
        )

    if drawdown >= MAX_SESSION_DRAWDOWN:
        return False, (
            f"Session drawdown excedido ({drawdown:.2%} ≥ {MAX_SESSION_DRAWDOWN:.2%})"
        )

    # -----------------------------
    # 2️⃣ CONFIANZA IA
    # -----------------------------
    if confidence < MIN_CONFIDENCE:
        return False, (
            f"Confianza IA insuficiente ({confidence:.1f}% < {MIN_CONFIDENCE}%)"
        )

    # -----------------------------
    # 3️⃣ LIQUIDEZ
    # -----------------------------
    if liquidity_risk > MAX_LIQUIDITY_RISK:
        return False, (
            f"Riesgo de liquidez alto ({liquidity_risk:.2f})"
        )

    # -----------------------------
    # 4️⃣ TAIL RISK
    # -----------------------------
    if tail_signal and tail_signal.get("hedge_required"):
        severity = tail_signal.get("severity", 0)
        if severity >= MAX_TAIL_RISK:
            return False, (
                f"Tail risk extremo detectado ({severity:.2%})"
            )

    # -----------------------------
    # ✅ TODO APROBADO
    # -----------------------------
    return True, "Risk Governor: condiciones aceptables"
