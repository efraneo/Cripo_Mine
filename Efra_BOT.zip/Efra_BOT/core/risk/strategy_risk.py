# core/risk/strategy_risk.py

MAX_STRATEGY_DRAWDOWN = 0.10
SOFT_WARNING_DD = 0.07


def evaluate_strategy_risk(strategy_state):

    if not strategy_state:
        return True, "Strategy state missing (allowed)"

    dd = strategy_state.drawdown

    if dd >= MAX_STRATEGY_DRAWDOWN:
        return False, f"Strategy DD hard limit ({dd:.2%})"

    if dd >= SOFT_WARNING_DD:
        return True, f"Strategy DD warning ({dd:.2%})"

    return True, "Strategy risk OK"
