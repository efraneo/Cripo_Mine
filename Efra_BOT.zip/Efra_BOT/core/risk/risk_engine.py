# core/risk/risk_engine.py

from datetime import datetime


class RiskEngine:
    """
    Motor institucional de control de riesgo.

    Responsabilidades:
    - Detectar sesión institucional
    - Calcular riesgo dinámico
    - Aprobar o bloquear operaciones
    """

    # =========================================
    # SESIONES INSTITUCIONALES (UTC)
    # =========================================

    SESSIONS = {
        "ASIA": {"start": 0, "end": 7},
        "LONDON": {"start": 7, "end": 16},
        "NY": {"start": 13, "end": 21},
    }

    # =========================================
    # SESSION DETECTION
    # =========================================

    def detect_session(self, now_utc=None):
        """
        Detecta la sesión institucional actual.
        """

        if not now_utc:
            now_utc = datetime.utcnow()

        hour = now_utc.hour

        if self.SESSIONS["ASIA"]["start"] <= hour < self.SESSIONS["ASIA"]["end"]:
            return "ASIA"

        if self.SESSIONS["LONDON"]["start"] <= hour < self.SESSIONS["LONDON"]["end"]:
            return "LONDON"

        if self.SESSIONS["NY"]["start"] <= hour < self.SESSIONS["NY"]["end"]:
            return "NY"

        return "OFF"

    # =========================================
    # RISK ENGINE PRINCIPAL
    # =========================================

    def evaluate_trade(
        self,
        score: float,
        signal_type: str = "CONTINUATION",
        is_late_entry: bool = False,
        session: str = None,
    ):
        """
        Evalúa si una operación puede ejecutarse.

        Retorna:
        - allowed
        - risk %
        - multiplicadores SL/TP
        """

        # -----------------------------
        # Detectar sesión
        # -----------------------------

        if not session:
            session = self.detect_session()

        # -----------------------------
        # BLOQUEOS DUROS
        # -----------------------------

        if score < 90:
            return {
                "allowed": False,
                "reason": "Score insuficiente para riesgo institucional",
            }

        if session in ("OFF", None):
            return {
                "allowed": False,
                "reason": "Fuera de sesiones operables",
            }

        if is_late_entry and score < 95:
            return {
                "allowed": False,
                "reason": "Entrada tardía sin score extremo",
            }

        # -----------------------------
        # BASE SEGÚN SCORE
        # -----------------------------

        if score >= 97:
            base_risk = 1.0
            sl_mult = 1.0
            tp_mult = 2.8

        elif score >= 95:
            base_risk = 0.85
            sl_mult = 1.2
            tp_mult = 2.4

        elif score >= 90:
            base_risk = 0.65
            sl_mult = 1.5
            tp_mult = 2.0

        else:
            return {
                "allowed": False,
                "reason": "Score no operativo",
            }

        # -----------------------------
        # AJUSTE POR SESIÓN
        # -----------------------------

        session_modifier = {
            "ASIA": 0.5,
            "LONDON": 1.1,
            "NY": 0.9,
        }.get(session, 0.0)

        risk = round(base_risk * session_modifier, 2)

        if risk <= 0:
            return {
                "allowed": False,
                "reason": "Riesgo ajustado a cero por sesión",
            }

        # -----------------------------
        # AJUSTE POR TIPO DE SEÑAL
        # -----------------------------

        signal_type = (signal_type or "").upper()

        if signal_type == "BREAKOUT":
            risk *= 0.8
            sl_mult *= 1.15

        elif signal_type == "REVERSAL":
            risk *= 0.7
            sl_mult *= 1.3
            tp_mult *= 0.9

        # -----------------------------
        # NORMALIZACIÓN FINAL
        # -----------------------------

        risk = round(min(risk, 1.0), 2)

        return {
            "allowed": True,
            "risk": risk,
            "sl_multiplier": round(sl_mult, 2),
            "tp_multiplier": round(tp_mult, 2),
            "session": session,
            "signal_type": signal_type,
            "reason": "Riesgo aprobado por motor institucional",
        }

# =========================================
# GLOBAL ENGINE INSTANCE
# =========================================

_risk_engine = RiskEngine()

# =========================================
# FUNCTIONAL WRAPPERS (compatibilidad bot)
# =========================================

def detect_session(now_utc=None):
    """
    Wrapper funcional para compatibilidad
    con módulos que esperan función global.
    """
    return _risk_engine.detect_session(now_utc)

def dynamic_risk(
    score,
    signal_type="CONTINUATION",
    is_late_entry=False,
    session=None
):
    """
    Wrapper para el motor institucional de riesgo.
    """
    return _risk_engine.evaluate_trade(
        score=score,
        signal_type=signal_type,
        is_late_entry=is_late_entry,
        session=session
    )
