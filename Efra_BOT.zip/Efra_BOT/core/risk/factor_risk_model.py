# core/risk/factor_risk_model.py

import numpy as np


def evaluate_factor_exposure(
    strategy_returns,
    market_returns,
    vol_index_returns=None
):
    """
    strategy_returns: np.array
    market_returns: np.array (benchmark)
    vol_index_returns: opcional (proxy VIX)
    """

    if len(strategy_returns) < 30:
        return _default_response()

    try:
        # Align lengths
        min_len = min(len(strategy_returns), len(market_returns))
        r = strategy_returns[-min_len:]
        m = market_returns[-min_len:]

        # 1️⃣ Market Beta
        beta = np.cov(r, m)[0, 1] / np.var(m)

        # 2️⃣ Volatility exposure (std sensitivity)
        vol_exposure = np.corrcoef(
            np.abs(r),
            np.abs(m)
        )[0, 1]

        # Scaling logic
        factor_scale = 1.0
        risk_mode = "NORMAL"

        if abs(beta) > 1.2:
            factor_scale *= 0.6
            risk_mode = "HIGH_BETA"

        if abs(vol_exposure) > 0.7:
            factor_scale *= 0.7
            risk_mode = "VOL_CLUSTER"

        return {
            "beta": float(beta),
            "vol_exposure": float(vol_exposure),
            "factor_scale": float(factor_scale),
            "risk_mode": risk_mode
        }

    except Exception:
        return _default_response()


def _default_response():
    return {
        "beta": 0.0,
        "vol_exposure": 0.0,
        "factor_scale": 1.0,
        "risk_mode": "INSUFFICIENT_DATA"
    }
