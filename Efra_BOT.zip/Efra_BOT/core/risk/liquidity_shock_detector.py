# core/risk/liquidity_shock_detector.py

# ============================================================
# LIQUIDITY SHOCK DETECTOR — MARKET MICROSTRUCTURE ENGINE
# ============================================================

import numpy as np
import pandas as pd
from typing import Dict


SPREAD_WARNING_MULT = 2.0
SPREAD_SHOCK_MULT = 3.5

VOLUME_COLLAPSE_LEVEL = 0.4

VOL_SPIKE_MULT = 2.5


# ============================================================
# SPREAD ESTIMATION
# ============================================================

def _estimate_spread(df: pd.DataFrame):

    spread = (df["high"] - df["low"]) / df["close"]

    return spread.iloc[-1], spread.mean()


# ============================================================
# VOLUME COLLAPSE
# ============================================================

def _volume_collapse(df: pd.DataFrame):

    vol = df["volume"]

    recent = vol.iloc[-1]
    avg = vol.rolling(50).mean().iloc[-1]

    if avg <= 0:
        return 1.0

    return recent / avg


# ============================================================
# VOLATILITY SPIKE
# ============================================================

def _volatility_spike(df: pd.DataFrame):

    returns = df["close"].pct_change()

    vol = returns.std()

    vol_avg = returns.rolling(50).std().mean()

    if vol_avg <= 0:
        return 1.0

    return vol / vol_avg


# ============================================================
# GAP DETECTOR
# ============================================================

def _price_gap(df: pd.DataFrame):

    prev_close = df["close"].iloc[-2]
    open_price = df["open"].iloc[-1]

    return abs(open_price - prev_close) / prev_close


# ============================================================
# MAIN ENGINE
# ============================================================

def detect_liquidity_shock(df: pd.DataFrame) -> Dict:

    if df is None or len(df) < 60:

        return {
            "mode": "UNKNOWN",
            "risk_scale": 1.0,
            "allow_trade": True
        }

    spread_now, spread_avg = _estimate_spread(df)

    spread_ratio = spread_now / spread_avg if spread_avg > 0 else 1.0

    volume_ratio = _volume_collapse(df)

    vol_spike = _volatility_spike(df)

    gap = _price_gap(df)

    mode = "NORMAL"
    risk_scale = 1.0
    allow_trade = True

    # ------------------------------------------------
    # SHOCK DETECTION
    # ------------------------------------------------

    if (
        spread_ratio > SPREAD_SHOCK_MULT
        or volume_ratio < VOLUME_COLLAPSE_LEVEL * 0.5
        or vol_spike > VOL_SPIKE_MULT * 1.5
        or gap > 0.04
    ):

        mode = "SHOCK"
        risk_scale = 0.0
        allow_trade = False

    # ------------------------------------------------
    # WARNING MODE
    # ------------------------------------------------

    elif (
        spread_ratio > SPREAD_WARNING_MULT
        or volume_ratio < VOLUME_COLLAPSE_LEVEL
        or vol_spike > VOL_SPIKE_MULT
        or gap > 0.02
    ):

        mode = "WARNING"
        risk_scale = 0.4

    return {
        "mode": mode,
        "risk_scale": risk_scale,
        "allow_trade": allow_trade,
        "metrics": {
            "spread_ratio": float(spread_ratio),
            "volume_ratio": float(volume_ratio),
            "volatility_spike": float(vol_spike),
            "price_gap": float(gap)
        }
    }
