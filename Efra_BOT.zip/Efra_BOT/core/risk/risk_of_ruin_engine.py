# core/risk/risk_of_ruin_engine.py

import logging
import numpy as np

logger = logging.getLogger(__name__)


class RiskOfRuinEngine:
    """
    Institutional Risk of Ruin model.

    Calcula:

    - Probabilidad de ruina
    - Riesgo sostenible por trade
    - Capital buffer
    - Escalado automático del riesgo
    """

    def __init__(self):

        self.max_ruin_probability = 0.02
        self.risk_scale = 1.0
        self.mode = "NORMAL"

    # ============================================
    # RISK OF RUIN FORMULA
    # ============================================

    def risk_of_ruin(
        self,
        winrate,
        rr,
        risk_per_trade,
        capital_units=100
    ):
        """
        Estimación clásica de probabilidad de ruina.

        winrate : probabilidad de ganar
        rr : reward/risk ratio
        risk_per_trade : fracción del capital
        capital_units : capital dividido en unidades de riesgo
        """

        try:

            if winrate <= 0 or rr <= 0:
                return 1.0

            edge = (winrate * rr) - (1 - winrate)

            if edge <= 0:
                return 1.0

            loss_prob = 1 - winrate

            ruin_prob = (loss_prob / winrate) ** capital_units

            ruin_prob = float(np.clip(ruin_prob, 0.0, 1.0))

            return ruin_prob

        except Exception:

            logger.exception("RiskOfRuin calculation failed")

            return 1.0

    # ============================================
    # OPTIMAL RISK SCALE
    # ============================================

    def compute_risk_scale(
        self,
        winrate,
        rr,
        risk_per_trade
    ):

        ruin = self.risk_of_ruin(
            winrate,
            rr,
            risk_per_trade
        )

        if ruin > 0.20:

            scale = 0.25
            mode = "CRITICAL"

        elif ruin > 0.10:

            scale = 0.40
            mode = "HIGH_RISK"

        elif ruin > 0.05:

            scale = 0.60
            mode = "MODERATE_RISK"

        elif ruin > 0.02:

            scale = 0.80
            mode = "CAUTION"

        else:

            scale = 1.0
            mode = "SAFE"

        self.risk_scale = scale
        self.mode = mode

        return {

            "risk_of_ruin": ruin,
            "risk_scale": scale,
            "mode": mode
        }

    # ============================================
    # ADJUST TRADE RISK
    # ============================================

    def adjust_trade_risk(
        self,
        base_risk,
        winrate,
        rr
    ):

        result = self.compute_risk_scale(
            winrate,
            rr,
            base_risk
        )

        adjusted = base_risk * result["risk_scale"]

        return {

            "adjusted_risk": round(adjusted, 4),

            "risk_of_ruin": result["risk_of_ruin"],

            "mode": result["mode"]
        }