# core/risk/portfolio_correlation_matrix.py

import numpy as np
import pandas as pd


class PortfolioCorrelationMatrix:

    """
    Motor institucional de correlación de portafolio
    """

    def __init__(self, max_correlation=0.8):

        self.max_correlation = max_correlation

        self.matrix = None

    # ======================================================
    # BUILD MATRIX
    # ======================================================

    def build(self, price_data: dict):

        """
        price_data example

        {
            BTCUSDT: df
            ETHUSDT: df
        }
        """

        returns = {}

        for symbol, df in price_data.items():

            returns[symbol] = df["close"].pct_change()

        returns_df = pd.DataFrame(returns)

        self.matrix = returns_df.corr()

        return self.matrix

    # ======================================================
    # VALIDATE TRADE
    # ======================================================

    def validate_trade(self, symbol, open_positions):

        """
        Evita trades con alta correlación
        """

        if self.matrix is None:
            return True

        for pos in open_positions:

            other = pos["symbol"]

            if other not in self.matrix:
                continue

            if symbol not in self.matrix:
                continue

            corr = self.matrix.loc[symbol, other]

            if abs(corr) >= self.max_correlation:

                return False

        return True
