# core/risk/correlation_engine.py

import numpy as np


def evaluate_correlation_risk(strategy_returns_dict):
    """
    strategy_returns_dict:
        {
            "strategy_A": np.array([...]),
            "strategy_B": np.array([...]),
            ...
        }
    """

    if not strategy_returns_dict or len(strategy_returns_dict) < 2:
        return _default_response()

    try:
        # -----------------------------------
        # Align returns length
        # -----------------------------------
        min_len = min(len(r) for r in strategy_returns_dict.values())

        if min_len < 20:
            return _default_response()

        matrix = []

        for r in strategy_returns_dict.values():
            matrix.append(r[-min_len:])

        matrix = np.array(matrix)

        # -----------------------------------
        # Correlation matrix
        # -----------------------------------
        corr_matrix = np.corrcoef(matrix)

        # Remove diagonal
        mask = ~np.eye(corr_matrix.shape[0], dtype=bool)
        avg_corr = np.mean(np.abs(corr_matrix[mask]))

        # -----------------------------------
        # Concentration (Herfindahl proxy)
        # -----------------------------------
        n = len(strategy_returns_dict)
        equal_weights = np.ones(n) / n
        concentration = np.sum(equal_weights ** 2)

        # -----------------------------------
        # Scaling logic
        # -----------------------------------
        correlation_scale = 1.0
        risk_mode = "NORMAL"

        if avg_corr > 0.75:
            correlation_scale = 0.4
            risk_mode = "EXTREME_CLUSTER"
        elif avg_corr > 0.6:
            correlation_scale = 0.6
            risk_mode = "HIGH_CORRELATION_CLUSTER"
        elif avg_corr > 0.4:
            correlation_scale = 0.8
            risk_mode = "MODERATE_CLUSTER"

        exposure_scale = 1 - concentration

        return {
            "avg_correlation": float(avg_corr),
            "concentration_risk": float(concentration),
            "correlation_scale": float(correlation_scale),
            "exposure_scale": float(exposure_scale),
            "risk_mode": risk_mode
        }

    except Exception:
        return _default_response()


def _default_response():
    return {
        "avg_correlation": 0.0,
        "concentration_risk": 0.0,
        "correlation_scale": 1.0,
        "exposure_scale": 1.0,
        "risk_mode": "INSUFFICIENT_DATA"
    }
