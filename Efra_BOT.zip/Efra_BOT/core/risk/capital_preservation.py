# core/risk/capital_preservation.py
# ============================================================
# CAPITAL PRESERVATION SYSTEM — NIVEL INSTITUCIONAL
# ============================================================

"""
Responsable de:
• preservar capital
• bloquear trades en drawdown alto
• activar kill switch
• controlar riesgo por operación
• ajustar allocation dinámicamente
"""

from typing import Dict, Any
from backend.equity_tracker import EquityTracker
from backend.log_manager import get_logger

log = get_logger("capital_preservation")

# ============================================================
# LIMITES INSTITUCIONALES
# ============================================================

MAX_RISK_PER_TRADE = 0.02       # 2%
MAX_POSITION_EQUITY_RATIO = 0.25
MAX_ALLOWED_DRAWDOWN = 0.25
MIN_EQUITY_REQUIRED = 10.0

# ============================================================
# CAPITAL PRESERVATION GATE (EL QUE FALTABA)
# ============================================================

def capital_preservation_gate(
    equity_tracker: EquityTracker,
    proposed_risk_pct: float,
    proposed_amount: float
) -> Dict[str, Any]:
    """
    Gate institucional.
    Retorna:
    {
        "allowed": bool,
        "reason": str
    }
    """
    try:
        state = equity_tracker.get_state()
        equity = float(state.get("equity", 0))
        drawdown = float(state.get("drawdown", 0))
        kill_switch = bool(state.get("kill_switch", False))

        # --------------------------------------------
        # Kill switch
        # --------------------------------------------

        if kill_switch:
            log.critical("BLOCKED: Kill switch active")
            return {
                "allowed": False,
                "reason": "Kill switch active"
            }

        # --------------------------------------------
        # Equity mínima
        # --------------------------------------------

        if equity < MIN_EQUITY_REQUIRED:
            return {
                "allowed": False,
                "reason": "Equity too low"
            }

        # --------------------------------------------
        # Drawdown protection
        # --------------------------------------------

        if drawdown >= MAX_ALLOWED_DRAWDOWN:
            return {
                "allowed": False,
                "reason": "Drawdown limit exceeded"
            }

        # --------------------------------------------
        # Riesgo máximo por trade
        # --------------------------------------------

        if proposed_risk_pct > MAX_RISK_PER_TRADE:
            return {
                "allowed": False,
                "reason": "Risk exceeds max allowed"
            }

        # --------------------------------------------
        # Tamaño vs equity
        # --------------------------------------------

        if proposed_amount > equity * MAX_POSITION_EQUITY_RATIO:
            return {
                "allowed": False,
                "reason": "Position too large vs equity"
            }
        return {
            "allowed": True,
            "reason": "Capital preservation approved"
        }
    except Exception as e:
        log.exception("Capital preservation failure")
        return {
            "allowed": False,
            "reason": str(e)
        }

# ============================================================
# CAPITAL ALLOCATION ADJUSTMENT (TU FUNCION ORIGINAL)
# ============================================================

def adjust_capital_allocation(
    strategies: Dict[str, float],
    scale: float
) -> Dict[str, float]:
    """
    Ajusta el capital asignado a estrategias según scale.
    """
    try:
        out = {}
        for s, capital in strategies.items():
            out[s] = float(capital) * float(scale)
        return out
    except Exception:
        log.exception("Capital allocation adjustment error")
        return strategies

