# core/risk/global_risk_governor.py

from core.portfolio.portfolio_nav import get_portfolio_state
from core.session_performance.session_tracker import get_session_stats


# ======================================================
# INTERNAL RISK SCORE (PORTFOLIO-AWARE)
# ======================================================
def _compute_dynamic_risk_score():

    pf = get_portfolio_state()
    session = get_session_stats()

    drawdown = pf.get("drawdown", 0.0)
    wins = session.get("wins", 0)
    losses = session.get("losses", 0)

    risk_score = 0

    # -----------------------------
    # Drawdown component
    # -----------------------------
    if drawdown <= -0.15:
        risk_score += 5
    elif drawdown <= -0.10:
        risk_score += 4
    elif drawdown <= -0.07:
        risk_score += 3
    elif drawdown <= -0.05:
        risk_score += 2

    # -----------------------------
    # Loss streak component
    # -----------------------------
    if losses >= 5:
        risk_score += 3
    elif losses >= 3:
        risk_score += 2

    # -----------------------------
    # Win/Loss imbalance
    # -----------------------------
    if losses > wins:
        risk_score += 1

    return risk_score


# ======================================================
# PUBLIC GOVERNOR
# ======================================================
def risk_governor_decision(risk_score=None):

    # Si no se pasa risk_score, lo calculamos dinámicamente
    if risk_score is None:
        risk_score = _compute_dynamic_risk_score()

    if risk_score >= 5:
        return {
            "mode": "DEFENSE",
            "capital_scale": 0.3,
            "risk_score": risk_score
        }

    if risk_score >= 3:
        return {
            "mode": "CAUTION",
            "capital_scale": 0.6,
            "risk_score": risk_score
        }

    return {
        "mode": "NORMAL",
        "capital_scale": 1.0,
        "risk_score": risk_score
    }
