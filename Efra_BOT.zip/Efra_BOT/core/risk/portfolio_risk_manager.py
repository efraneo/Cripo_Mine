# core/risk/portfolio_risk_manager.py

import logging
from collections import defaultdict
from datetime import datetime

from core.risk.monte_carlo_stress import monte_carlo_stress_test

from core.risk.risk_of_ruin_engine import RiskOfRuinEngine

from core.analytics.equity_stability_engine import EquityStabilityEngine

logger = logging.getLogger(__name__)


class PortfolioRiskManager:
    """
    Gestor institucional de riesgo de portafolio.

    Controla:

    - riesgo total del portafolio
    - exposición por divisa
    - correlación entre trades
    - drawdown máximo
    - número máximo de trades
    - kill switch automático
    - escalado de riesgo por Monte Carlo
    """

    def __init__(self):

        # ======================================
        # LIMITES INSTITUCIONALES
        # ======================================

        self.max_portfolio_risk = 5.0        # % total
        self.max_currency_exposure = 6.0     # % por divisa
        self.max_trades = 6                  # trades simultáneos
        self.max_drawdown = 10.0             # % equity
        self.max_correlated_positions = 3

        # ======================================
        # ESTADO
        # ======================================

        self.open_positions = []

        self.equity_peak = None
        self.current_equity = None

        self.kill_switch = False

        # Monte Carlo scaling
        self.monte_carlo_scale = 1.0
        self.risk_mode = "NORMAL"

        self.ruin_engine = RiskOfRuinEngine()
        self.equity_engine = EquityStabilityEngine()
        self.equity_scale = 1.0

    # =====================================================
    # EQUITY TRACKER
    # =====================================================

    def update_equity(self, equity):

        self.current_equity = equity

        if self.equity_peak is None:
            self.equity_peak = equity
            return

        if equity > self.equity_peak:
            self.equity_peak = equity

        drawdown = 100 * (self.equity_peak - equity) / self.equity_peak

        if drawdown >= self.max_drawdown:

            logger.critical(
                f"MAX DRAWDOWN EXCEEDED {drawdown:.2f}%"
            )

            self.kill_switch = True

    # =====================================================
    # MONTE CARLO STRESS UPDATE
    # =====================================================

    def update_monte_carlo(self, equity, returns):

        result = monte_carlo_stress_test(
            equity=equity,
            returns=returns
        )

        self.monte_carlo_scale = result["monte_carlo_scale"]
        self.risk_mode = result["risk_mode"]

        logger.info(
            f"MonteCarlo RiskMode={self.risk_mode} "
            f"scale={self.monte_carlo_scale}"
        )

    # =====================================================
    # REGISTER POSITION
    # =====================================================

    def register_position(self, position):

        """
        position example

        {
            id: "trade123",
            symbol: "EURUSD",
            risk: 1.0
        }
        """

        position["open_time"] = datetime.utcnow()

        self.open_positions.append(position)

    # =====================================================
    # REMOVE POSITION
    # =====================================================

    def close_position(self, trade_id):

        self.open_positions = [
            p for p in self.open_positions
            if p.get("id") != trade_id
        ]

    # =====================================================
    # PORTFOLIO RISK
    # =====================================================

    def current_portfolio_risk(self):

        return sum(
            p["risk"] for p in self.open_positions
        )

    # =====================================================
    # CURRENCY EXPOSURE
    # =====================================================

    def currency_exposure(self):

        exposure = defaultdict(float)

        for p in self.open_positions:

            symbol = p["symbol"]

            base = symbol[:3]
            quote = symbol[3:]

            exposure[base] += p["risk"]
            exposure[quote] += p["risk"]

        return exposure

    # =====================================================
    # CORRELATION CLUSTER
    # =====================================================

    def correlated_positions(self, symbol):

        base = symbol[:3]
        quote = symbol[3:]

        count = 0

        for p in self.open_positions:

            s = p["symbol"]

            if base in s or quote in s:
                count += 1

        return count

    # =====================================================
    # PORTFOLIO METRICS
    # =====================================================

    def portfolio_metrics(self):

        if not self.equity_peak or not self.current_equity:

            drawdown = 0

        else:

            drawdown = (
                100 * (self.equity_peak - self.current_equity)
                / self.equity_peak
            )

        return {
            "open_trades": len(self.open_positions),
            "portfolio_risk": self.current_portfolio_risk(),
            "currency_exposure": dict(self.currency_exposure()),
            "drawdown": drawdown,
            "monte_carlo_scale": self.monte_carlo_scale,
            "risk_mode": self.risk_mode,
            "kill_switch": self.kill_switch
        }

    # =====================================================
    # ACTUALIZAR EQUITY RISK
    # =====================================================

    def update_equity_stability(self, equity_series):
        result = self.equity_engine.stability_score(equity_series)
        self.equity_scale = result["risk_scale"]
        logger.info(
            f"Equity Stability mode={result['mode']} "
            f"scale={self.equity_scale}"
        )
        return result

    # =====================================================
    # MAIN VALIDATION
    # =====================================================

    def validate_new_trade(self, signal, risk):

        """
        Valida si el trade puede abrirse.
        """

        if self.kill_switch:

            return {
                "allowed": False,
                "reason": "Kill switch activado"
            }

        # ---------------------------------
        # APPLY MONTE CARLO SCALING
        # ---------------------------------

        mc_adjusted_risk = risk["risk"] * self.monte_carlo_scale

        # ---------------------------------
        # SCALING
        # ---------------------------------

        adjusted_risk *= self.equity_scale

        # ---------------------------------
        # APPLY RISK OF RUIN MODEL
        # ---------------------------------

        ruin_adjustment = self.ruin_engine.adjust_trade_risk(
            base_risk=mc_adjusted_risk,
            winrate=risk.get("winrate", 0.5),
            rr=risk.get("rr", 1.5)
        )

        adjusted_risk = ruin_adjustment["adjusted_risk"]

        # ---------------------------------
        # MAX TRADES
        # ---------------------------------

        if len(self.open_positions) >= self.max_trades:

            return {
                "allowed": False,
                "reason": "Máximo trades abiertos alcanzado"
            }

        # ---------------------------------
        # PORTFOLIO RISK
        # ---------------------------------

        total_risk = self.current_portfolio_risk()

        if total_risk + adjusted_risk > self.max_portfolio_risk:

            return {
                "allowed": False,
                "reason": "Riesgo total de portafolio excedido"
            }

        # ---------------------------------
        # CURRENCY EXPOSURE
        # ---------------------------------

        exposure = self.currency_exposure()

        base = signal.symbol[:3]
        quote = signal.symbol[3:]

        if exposure[base] + adjusted_risk > self.max_currency_exposure:

            return {
                "allowed": False,
                "reason": f"Exposición excesiva en {base}"
            }

        if exposure[quote] + adjusted_risk > self.max_currency_exposure:

            return {
                "allowed": False,
                "reason": f"Exposición excesiva en {quote}"
            }

        # ---------------------------------
        # CORRELATION CLUSTER
        # ---------------------------------

        correlated = self.correlated_positions(signal.symbol)

        if correlated >= self.max_correlated_positions:

            return {
                "allowed": False,
                "reason": "Cluster de correlación excesivo"
            }

        return {
            "allowed": True,
            "adjusted_risk": round(adjusted_risk, 4),
            "risk_mode": self.risk_mode,
            "ruin_probability": ruin_adjustment["risk_of_ruin"],
            "ruin_mode": ruin_adjustment["mode"],
            "reason": "Portfolio risk aprobado"
        }
