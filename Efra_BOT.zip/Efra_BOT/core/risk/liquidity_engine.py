# core/risk/liquidity_engine.py

# ======================================================
# CORE LIQUIDITY SCORE (original logic preserved)
# ======================================================
def liquidity_score(order_size, avg_volume, spread):

    if avg_volume == 0:
        return 0

    volume_ratio = order_size / avg_volume

    score = 0

    if volume_ratio > 0.05:
        score += 2

    if spread > 0.002:
        score += 1

    return score


# ======================================================
# INSTITUTIONAL WRAPPER (adds scaling logic)
# ======================================================
def liquidity_adjustment(order_size, avg_volume, spread):

    score = liquidity_score(order_size, avg_volume, spread)

    # Mapping score → capital scale
    # 0 = excelente liquidez
    # 1 = leve fricción
    # 2 = impacto moderado
    # 3 = alto impacto

    if score >= 3:
        scale = 0.5
        mode = "HIGH_IMPACT"
    elif score == 2:
        scale = 0.7
        mode = "MODERATE_IMPACT"
    elif score == 1:
        scale = 0.85
        mode = "LIGHT_IMPACT"
    else:
        scale = 1.0
        mode = "NORMAL"

    return {
        "liquidity_score": score,
        "liquidity_scale": scale,
        "mode": mode
    }
