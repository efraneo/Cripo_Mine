# core/risk/tail_hedging.py

def tail_hedge_signal(var_99, drawdown):

    if abs(var_99) > 0.04 or drawdown > 0.1:
        return "HEDGE_ON"

    return "HEDGE_OFF"
