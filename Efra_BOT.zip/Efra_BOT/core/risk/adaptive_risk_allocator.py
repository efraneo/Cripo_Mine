# core/risk/adaptive_risk_allocator.py

import numpy as np


def rolling_sharpe(returns, window=50):
    if len(returns) < window:
        return 0

    r = returns[-window:]
    mean = np.mean(r)
    std = np.std(r)

    if std == 0:
        return 0

    return (mean / std) * np.sqrt(252)


def equity_volatility(equity_curve, window=50):
    if len(equity_curve) < window:
        return 0

    returns = np.diff(equity_curve) / equity_curve[:-1]
    return np.std(returns[-window:])


def performance_decay(returns, short=30, long=100):
    if len(returns) < long:
        return 0

    short_perf = np.mean(returns[-short:])
    long_perf = np.mean(returns[-long:])

    return short_perf - long_perf


def compute_drawdown(equity_curve):

    peak = equity_curve[0]
    max_dd = 0

    for v in equity_curve:
        peak = max(peak, v)
        dd = (peak - v) / peak
        max_dd = max(max_dd, dd)

    return max_dd


def adaptive_risk_allocation(equity_curve):

    if len(equity_curve) < 60:
        return {
            "risk_scale": 1.0,
            "mode": "INSUFFICIENT_DATA"
        }

    equity = np.array(equity_curve)

    returns = np.diff(equity) / equity[:-1]

    sharpe = rolling_sharpe(returns)
    vol = equity_volatility(equity)
    decay = performance_decay(returns)
    drawdown = compute_drawdown(equity)

    risk_scale = 1.0

    # drawdown control
    if drawdown > 0.20:
        risk_scale *= 0.4
    elif drawdown > 0.10:
        risk_scale *= 0.7

    # sharpe control
    if sharpe < 0:
        risk_scale *= 0.6
    elif sharpe > 2:
        risk_scale *= 1.2

    # volatility control
    if vol > 0.03:
        risk_scale *= 0.7

    # performance decay
    if decay < -0.001:
        risk_scale *= 0.7

    risk_scale = max(0.2, min(risk_scale, 1.5))

    return {
        "risk_scale": risk_scale,
        "metrics": {
            "rolling_sharpe": float(sharpe),
            "equity_volatility": float(vol),
            "performance_decay": float(decay),
            "drawdown": float(drawdown),
        }
    }
