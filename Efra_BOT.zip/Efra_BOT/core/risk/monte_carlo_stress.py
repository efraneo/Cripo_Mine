# core/risk/monte_carlo_stress.py 

import numpy as np


# ======================================================
# ORIGINAL FUNCTION (preserved)
# ======================================================
def monte_carlo_equity_paths(equity, returns, sims=500):

    mu = np.mean(returns)
    sigma = np.std(returns)

    paths = []

    for _ in range(sims):
        sim_returns = np.random.normal(mu, sigma, len(returns))
        path = equity * np.cumprod(1 + sim_returns)
        paths.append(path)

    return np.array(paths)


# ======================================================
# DRAWNDOWN CALCULATION
# ======================================================
def _max_drawdown(path):
    peak = np.maximum.accumulate(path)
    dd = (path - peak) / peak
    return np.min(dd)


# ======================================================
# INSTITUTIONAL STRESS WRAPPER
# ======================================================
def monte_carlo_stress_test(
    equity,
    returns,
    sims=500,
    confidence_percentile=5
):
    """
    Devuelve worst-case drawdown estimado
    """

    if returns is None or len(returns) < 20:
        return _default_response()

    paths = monte_carlo_equity_paths(equity, returns, sims)

    drawdowns = []

    for path in paths:
        dd = _max_drawdown(path)
        drawdowns.append(dd)

    drawdowns = np.array(drawdowns)

    worst_case_dd = np.percentile(drawdowns, confidence_percentile)

    # Capital scale dinámico
    if worst_case_dd <= -0.30:
        scale = 0.3
        risk_mode = "EXTREME_TAIL"
    elif worst_case_dd <= -0.20:
        scale = 0.5
        risk_mode = "HIGH_TAIL"
    elif worst_case_dd <= -0.15:
        scale = 0.7
        risk_mode = "MODERATE_TAIL"
    else:
        scale = 1.0
        risk_mode = "NORMAL"

    return {
        "worst_case_drawdown": float(worst_case_dd),
        "monte_carlo_scale": scale,
        "risk_mode": risk_mode
    }


def _default_response():
    return {
        "worst_case_drawdown": 0.0,
        "monte_carlo_scale": 1.0,
        "risk_mode": "INSUFFICIENT_DATA"
    }
