# core/risk/tail_risk_hedger.py

def evaluate_tail_risk(ia_decision):

    monte = ia_decision.get("monte_carlo", {})
    governor = ia_decision.get("risk_governor", {})
    liquidity = ia_decision.get("liquidity", {})

    worst_dd = monte
