# core/broker/binance_broker.py

from binance.client import Client
import os
import logging
import numpy as np

logger = logging.getLogger(__name__)


class BinanceBroker:

    def __init__(self):
        self.client = Client(
            os.getenv("BINANCE_API_KEY"),
            os.getenv("BINANCE_API_SECRET")
        )

    def _adjust_quantity(self, symbol, quantity):
        """
        Ajusta cantidad según reglas de Binance (LOT_SIZE)
        """
        try:
            info = self.client.get_symbol_info(symbol)

            for f in info["filters"]:
                if f["filterType"] == "LOT_SIZE":
                    step_size = float(f["stepSize"])
                    min_qty = float(f["minQty"])

                    # Ajuste a step_size
                    precision = int(round(-np.log10(step_size), 0))
                    quantity = round(quantity, precision)

                    # Asegurar mínimo
                    if quantity < min_qty:
                        quantity = min_qty

                    return quantity

        except Exception as e:
            logger.warning(f"Precision adjust failed: {e}")

        return quantity

    # ==================================================
    # MARKET ORDER REAL
    # ==================================================
    import time

    def execute_market_order(self, symbol, side, amount):
        for attempt in range(3):

            try:
                logger.info(f"Executing MARKET order {symbol} {side} {amount}")

                amount = self._adjust_quantity(symbol, amount)

                start_time = time.time()

                order = self.client.create_order(
                    symbol=symbol,
                    side=self._map_side(side),
                    type="MARKET",
                    quantity=amount
                )

                latency = time.time() - start_time

                fills = order.get("fills", [])

                if fills:
                    total_qty = sum(float(f["qty"]) for f in fills)
                    weighted_price = sum(float(f["price"]) * float(f["qty"]) for f in fills)
                    avg_price = weighted_price / total_qty if total_qty > 0 else 0
                else:
                    # fallback (algunos casos futures)
                    avg_price = float(order.get("cummulativeQuoteQty", 0)) / max(float(order.get("executedQty", 1)), 1e-9)
                    total_qty = float(order.get("executedQty", 0))

                    # =====================================
                    # FEE MODEL
                    # =====================================
                    fee_rate = 0.001  # 0.1% Binance spot

                    fee = avg_price * total_qty * fee_rate

                    if self._map_side(side) == "BUY":
                        net_price = avg_price + (fee / max(total_qty, 1e-9))
                    else:
                        net_price = avg_price - (fee / max(total_qty, 1e-9))

                return {
                    "status": "FILLED",
                    "avg_price": float(avg_price),
                    "executed_qty": float(total_qty),
                    "fee": float(fee),
                    "net_price": float(net_price),
                    "latency": float(latency),
                    "order": order,
                    "fills": fills
                }

            except Exception as e:
                logger.warning(f"Retry {attempt+1}/3 failed: {e}")
                time.sleep(0.5)

        return {
            "status": "ERROR",
            "error": "Max retries reached"
        }

    # ==================================================
    # GENERIC ENTRY POINT
    # ==================================================
    def place_order(self, order: dict):

        return self.execute_market_order(
            symbol=order["symbol"],
            side=order["direction"],
            amount=order["size"]  # ⚠️ luego refinamos esto
        )

    def execute_limit_order(self, symbol, side, amount, price):

        try:
            amount = self._adjust_quantity(symbol, amount)
            start_time = time.time()

            order = self.client.create_order(
                symbol=symbol,
                side=self._map_side(side),
                type="LIMIT",
                timeInForce="GTC",
                quantity=amount,
                price=str(price)
            )

            latency = time.time() - start_time

            fills = order.get("fills", [])

            if fills:
                total_qty = sum(float(f["qty"]) for f in fills)
                weighted_price = sum(float(f["price"]) * float(f["qty"]) for f in fills)
                avg_price = weighted_price / total_qty if total_qty > 0 else 0
            else:
                # fallback (algunos casos futures)
                executed_qty = float(order.get("executedQty", 0))
                quote_qty = float(order.get("cummulativeQuoteQty", 0))

                total_qty = executed_qty
                avg_price = quote_qty / max(executed_qty, 1e-9)

            # =====================================
            # 🔥 FEE MODEL (INSTITUCIONAL)
            # =====================================
            fee_rate = 0.001  # 0.1% Binance spot

            fee = avg_price * total_qty * fee_rate

            mapped_side = self._map_side(side)

            if mapped_side == "BUY":
                net_price = avg_price + (fee / max(total_qty, 1e-9))
            else:
                net_price = avg_price - (fee / max(total_qty, 1e-9))

            return {
                "status": "FILLED",
                "avg_price": float(avg_price),
                "executed_qty": float(total_qty),
                "fee": float(fee),
                "net_price": float(net_price),
                "latency": float(latency),
                "order": order,
                "fills": fills
            }

        except Exception as e:
            return {
                "status": "ERROR",
                "error": str(e)
            }

    def _map_side(self, side: str):
        if side in ["LONG", "BUY"]:
            return "BUY"
        elif side in ["SHORT", "SELL"]:
            return "SELL"
        else:
            raise ValueError(f"Invalid side: {side}")
