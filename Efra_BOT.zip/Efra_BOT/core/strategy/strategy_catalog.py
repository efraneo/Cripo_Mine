# core/strategy/strategy_catalog.py

STRATEGY_MAP = {
    "TREND_FOLLOWING": {
        "allowed_regimes": {"TREND"},
        "min_confidence": 65,
        "max_capital_pct": 0.30,
    },
    "MEAN_REVERSION": {
        "allowed_regimes": {"RANGE"},
        "min_confidence": 70,
        "max_capital_pct": 0.20,
    },
    "BREAKOUT": {
        "allowed_regimes": {"VOLATILE"},
        "min_confidence": 75,
        "max_capital_pct": 0.15,
    },
    "ML_PREDICTIVE": {
        "allowed_regimes": {"TREND", "RANGE"},
        "min_confidence": 80,
        "max_capital_pct": 0.10,
    },
}
