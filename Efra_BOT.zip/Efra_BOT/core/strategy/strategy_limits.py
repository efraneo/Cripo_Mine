# core/strategy/strategy_limits.py

MAX_ACTIVE_STRATEGIES = 3
GLOBAL_STRATEGY_DRAWDOWN_LIMIT = -0.12
