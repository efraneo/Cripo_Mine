# core/execution/execution_engine.py

import logging
import numpy as np

logger = logging.getLogger(__name__)


# ======================================================
# PARAMETRIC EXECUTION COST MODEL
# ======================================================

def estimate_execution_cost(
    order_fraction,
    df,
    a=0.6,
    b=0.3,
    c=0.1
):
    """
    Modelo paramétrico de impacto de mercado.

    Parameters
    ----------
    order_fraction : float
        fracción del capital usado en la orden

    df : DataFrame
        OHLCV dataframe (idealmente 5m)

    Returns
    -------
    dict
    """

    if df is None or len(df) < 20:
        return _default_response()

    try:

        # -----------------------------
        # Volatility
        # -----------------------------

        returns = df["close"].pct_change().dropna()
        volatility = returns.rolling(20).std().iloc[-1]

        # -----------------------------
        # Spread proxy
        # -----------------------------

        spread = (
            (df["high"].iloc[-1] - df["low"].iloc[-1])
            / df["close"].iloc[-1]
        )

        # -----------------------------
        # Volume ratio proxy
        # -----------------------------

        avg_volume = df["volume"].rolling(20).mean().iloc[-1]

        volume_ratio = order_fraction / max(avg_volume, 1e-9)

        # -----------------------------
        # Impact model
        # -----------------------------

        impact_cost = (
            a * volume_ratio +
            b * volatility +
            c * spread
        )

        impact_cost = float(np.clip(impact_cost, 0.0, 0.05))

        execution_scale = max(0.5, 1 - impact_cost * 5)

        mode = "NORMAL"

        if impact_cost > 0.02:
            mode = "HIGH_IMPACT"

        elif impact_cost > 0.01:
            mode = "MODERATE_IMPACT"

        return {
            "expected_slippage": impact_cost,
            "impact_cost": impact_cost,
            "execution_scale": execution_scale,
            "mode": mode
        }

    except Exception:
        logger.exception("Execution cost model failed")
        return _default_response()


def _default_response():
    return {
        "expected_slippage": 0.0,
        "impact_cost": 0.0,
        "execution_scale": 1.0,
        "mode": "NO_DATA"
    }


# ======================================================
# INSTITUTIONAL EXECUTION ENGINE
# ======================================================

class ExecutionEngine:
    """
    Motor institucional de ejecución.

    Responsabilidades:

    - Ajustar tamaño de orden
    - Evaluar impacto de mercado
    - Enviar orden al broker
    """

    def __init__(self, broker=None):

        self.broker = broker

    # ==================================================
    # TRADE EXECUTION
    # ==================================================

    def execute_trade(self, signal, risk, market_df=None):
        """
        Ejecuta una operación aprobada por RiskEngine
        """

        try:

            logger.info(
                f"Executing trade {signal.symbol} "
                f"{signal.direction} "
                f"risk={risk['risk']}"
            )

            # --------------------------------
            # Order fraction
            # --------------------------------

            order_fraction = risk["risk"] / 100.0

            # --------------------------------
            # Execution cost model
            # --------------------------------

            exec_cost = estimate_execution_cost(
                order_fraction,
                market_df
            )

            execution_scale = exec_cost["execution_scale"]

            # --------------------------------
            # Adjust risk based on liquidity
            # --------------------------------

            adjusted_risk = round(
                risk["risk"] * execution_scale,
                4
            )

            # --------------------------------
            # Order payload
            # --------------------------------

            order = {

                "symbol": signal.symbol,

                "direction": signal.direction,

                "entry_price": signal.entry_price,

                "stop_loss": signal.stop_loss,

                "take_profit": signal.take_profit,

                "risk_percent": adjusted_risk,

                "expected_slippage": exec_cost["expected_slippage"],

                "execution_mode": exec_cost["mode"]
            }

            # --------------------------------
            # Broker execution
            # --------------------------------

            if self.broker:

                try:

                    result = self.broker.place_order(order)

                    logger.info(
                        f"Order sent to broker: {result}"
                    )

                    return result

                except Exception:
                    logger.exception("Broker execution failed")
                    return None

            else:

                logger.warning(
                    "No broker configured - paper trade"
                )

                return order

        except Exception:

            logger.exception("ExecutionEngine failed")

            return None