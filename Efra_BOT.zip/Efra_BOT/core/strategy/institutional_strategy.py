# core/strategy/institutional_strategy.py

import talib
import pandas as pd


# =========================================================
# FEATURE ENGINEERING
# =========================================================
def build_features(df: pd.DataFrame) -> pd.DataFrame:

    df = df.copy()

    # -------------------------
    # VALIDACIÓN BASE
    # -------------------------
    required_cols = ["open", "high", "low", "close", "volume"]
    for col in required_cols:
        if col not in df.columns:
            raise ValueError(f"Falta columna requerida: {col}")

    # -------------------------
    # PATRONES
    # -------------------------
    df["engulfing"] = talib.CDLENGULFING(
        df["open"],
        df["high"],
        df["low"],
        df["close"]
    )

    # -------------------------
    # TENDENCIA
    # -------------------------
    df["ema_50"] = talib.EMA(df["close"], timeperiod=50)
    df["ema_200"] = talib.EMA(df["close"], timeperiod=200)

    # -------------------------
    # ZONAS
    # -------------------------
    df["support"] = df["low"].rolling(20).min()
    df["resistance"] = df["high"].rolling(20).max()

    # -------------------------
    # CONFIRMACIÓN
    # -------------------------
    df["rsi"] = talib.RSI(df["close"], timeperiod=14)
    df["vol_mean"] = df["volume"].rolling(20).mean()

    return df


# =========================================================
# SIGNAL ENGINE
# =========================================================
def institutional_signal(df: pd.DataFrame) -> dict:

    if df.empty or len(df) < 50:
        return {
            "action": "HOLD",
            "confidence": 0,
            "reasons": ["insufficient_data"]
        }

    last = df.iloc[-1]

    signal = {
        "action": "HOLD",
        "confidence": 0,
        "reasons": []
    }

    # =========================
    # BULLISH
    # =========================
    if last["engulfing"] > 0:

        score = 0

        if last["ema_50"] > last["ema_200"]:
            score += 1
            signal["reasons"].append("trend_bull")

        if last["rsi"] < 35:
            score += 1
            signal["reasons"].append("rsi_oversold")

        if last["volume"] > last["vol_mean"]:
            score += 1
            signal["reasons"].append("volume_ok")

        if last["close"] <= last["support"] * 1.02:
            score += 1
            signal["reasons"].append("near_support")

        if score >= 3:
            signal["action"] = "BUY"
            signal["confidence"] = round(score / 4, 2)

    # =========================
    # BEARISH
    # =========================
    elif last["engulfing"] < 0:

        score = 0

        if last["ema_50"] < last["ema_200"]:
            score += 1
            signal["reasons"].append("trend_bear")

        if last["rsi"] > 65:
            score += 1
            signal["reasons"].append("rsi_overbought")

        if last["volume"] > last["vol_mean"]:
            score += 1
            signal["reasons"].append("volume_ok")

        if last["close"] >= last["resistance"] * 0.98:
            score += 1
            signal["reasons"].append("near_resistance")

        if score >= 3:
            signal["action"] = "SELL"
            signal["confidence"] = round(score / 4, 2)

    return signal

