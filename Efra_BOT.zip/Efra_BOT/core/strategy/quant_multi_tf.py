# core/strategy/quant_multi_tf.py

import numpy as np

# ==========================================================
# 🧠 TREND POR TIMEFRAME
# ==========================================================
def compute_trend(df):
    if df is None or len(df) < 50:
        return {"trend": "UNKNOWN", "strength": 0}

    ema50 = df["close"].ewm(span=50).mean()
    ema200 = df["close"].ewm(span=200).mean()

    if ema50.iloc[-1] > ema200.iloc[-1]:
        return {"trend": "BULL", "strength": 1}
    elif ema50.iloc[-1] < ema200.iloc[-1]:
        return {"trend": "BEAR", "strength": 1}
    else:
        return {"trend": "SIDEWAYS", "strength": 0}


# ==========================================================
# 🧠 SCORE POR TIMEFRAME
# ==========================================================
def score_timeframe(df):
    if df is None or df.empty:
        return 0

    score = 0

    # Momentum
    returns = df["close"].pct_change().tail(5).mean()
    if returns > 0:
        score += 1
    else:
        score -= 1

    # Volumen
    if "volume" in df.columns:
        vol_mean = df["volume"].rolling(20).mean().iloc[-1]
        if df["volume"].iloc[-1] > vol_mean:
            score += 1

    return score


# ==========================================================
# 🧠 FUSIÓN MULTI-TF
# ==========================================================
def multi_tf_analysis(df_by_tf):

    weights = {
        "1h": 0.5,
        "15m": 0.3,
        "5m": 0.2
    }

    total_score = 0
    direction_votes = []

    for tf, df in df_by_tf.items():

        trend_data = compute_trend(df)
        tf_score = score_timeframe(df)

        weight = weights.get(tf, 0.1)

        if trend_data["trend"] == "BULL":
            direction_votes.append("LONG")
            total_score += tf_score * weight

        elif trend_data["trend"] == "BEAR":
            direction_votes.append("SHORT")
            total_score -= tf_score * weight

    # ------------------------------------------------------
    # DECISIÓN FINAL
    # ------------------------------------------------------
    long_votes = direction_votes.count("LONG")
    short_votes = direction_votes.count("SHORT")

    if long_votes > short_votes:
        direction = "LONG"
    elif short_votes > long_votes:
        direction = "SHORT"
    else:
        direction = "NEUTRAL"

    confidence = min(100, abs(total_score) * 20)

    return {
        "direction": direction,
        "confidence": confidence,
        "votes": direction_votes,
        "score": total_score
    }

