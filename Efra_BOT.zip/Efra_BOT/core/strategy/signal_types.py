# core/strategy/signal_types.py

from dataclasses import dataclass


@dataclass
class TradeSignal:
    """
    Modelo institucional de señal de trading
    """

    symbol: str
    direction: str
    score: float

    signal_type: str = "CONTINUATION"
    is_late_entry: bool = False

    entry_price: float = None
    stop_loss: float = None
    take_profit: float = None

    timeframe: str = "M5"
    strategy: str = "default"