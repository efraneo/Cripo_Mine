# core/strategy/strategy_state.py

_strategy_state = {}


def get_strategy_state(name: str) -> dict:
    return _strategy_state.setdefault(name, {
        "allocated_capital": 0.0,
        "open_positions": 0,
        "drawdown": 0.0,
    })
