# core/strategy/strategy_allocator.py

from core.strategy.strategy_catalog import STRATEGY_MAP
from core.strategy.strategy_state import get_strategy_state


def allocate_strategy(symbol: str, ia: dict) -> tuple[bool, dict]:

    strategy = ia.get("strategy")
    if not strategy or strategy not in STRATEGY_MAP:
        return False, "Estrategia no reconocida"

    cfg = STRATEGY_MAP[strategy]
    state = get_strategy_state(strategy)

    # --------------------------------------------------
    # Régimen permitido
    # --------------------------------------------------
    if ia.get("regime") not in cfg["allowed_regimes"]:
        return False, "Régimen no permitido para la estrategia"

    # --------------------------------------------------
    # Confianza mínima
    # --------------------------------------------------
    if ia.get("confidence", 0) < cfg["min_confidence"]:
        return False, "Confianza insuficiente para la estrategia"

    # --------------------------------------------------
    # Capital máximo por estrategia
    # --------------------------------------------------
    if state["allocated_capital"] >= cfg["max_capital_pct"]:
        return False, "Capital máximo de estrategia alcanzado"

    return True, {
        "strategy": strategy,
        "max_capital_pct": cfg["max_capital_pct"],
    }
