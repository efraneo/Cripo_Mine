# core/strategy/multi_tf_institutional.py

import numpy as np

from core.strategy.institutional_strategy import (
    build_features,
    institutional_signal
)

TF_WEIGHTS = {
    "5m": 0.2,
    "15m": 0.3,
    "1h": 0.5
}


def compute_multi_tf_signal(data_by_tf: dict):

    signals = {}
    weighted_score = 0
    total_weight = 0

    directions = []

    for tf, weight in TF_WEIGHTS.items():

        pack = data_by_tf.get(tf)
        if not pack:
            continue

        df = pack.get("df")
        if df is None or df.empty:
            continue

        try:
            df_feat = build_features(df.copy())
            sig = institutional_signal(df_feat)

            signals[tf] = sig

            action = sig.get("action")
            confidence = sig.get("confidence", 0)

            # ----------------------------------------
            # SCORING
            # ----------------------------------------
            score = 0

            if action == "BUY":
                score = +1 * confidence
                directions.append("LONG")

            elif action == "SELL":
                score = -1 * confidence
                directions.append("SHORT")

            weighted_score += score * weight
            total_weight += weight

        except Exception:
            signals[tf] = {"action": "ERROR"}

    if total_weight == 0:
        return {
            "action": "HOLD",
            "confidence": 0,
            "signals": signals
        }

    final_score = weighted_score / total_weight

    # ----------------------------------------
    # DECISIÓN FINAL
    # ----------------------------------------
    if final_score > 0.25:
        action = "BUY"
        direction = "LONG"
    elif final_score < -0.25:
        action = "SELL"
        direction = "SHORT"
    else:
        action = "HOLD"
        direction = None

    confidence = abs(final_score)

    return {
        "action": action,
        "direction": direction,
        "confidence": confidence,
        "score": final_score,
        "signals": signals
    }

