# core/data_loader.py
import pandas as pd
from pathlib import Path

DATA_DIR = Path("data/historical")

def load_historical_batches(symbols=None, tf="15m", limit=None):
    """
    Carga históricos para entrenamiento ML.
    Espera CSVs en data/historical/{symbol}_{tf}.csv
    """

    datasets = []

    for file in DATA_DIR.glob(f"*_{tf}.csv"):
        symbol = file.stem.replace(f"_{tf}", "")

        if symbols and symbol not in symbols:
            continue

        try:
            df = pd.read_csv(file)

            if "close" not in df.columns:
                continue

            df["symbol"] = symbol
            datasets.append(df)

        except Exception as e:
            print(f"[WARN] No se pudo cargar {file}: {e}")

    if not datasets:
        raise RuntimeError("No se encontraron datos históricos válidos")

    full = pd.concat(datasets, ignore_index=True)

    if limit:
        full = full.tail(limit)

    return full
