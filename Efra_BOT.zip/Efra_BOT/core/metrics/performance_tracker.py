# core/metrics/performance_tracker.py

import os
import json
from datetime import datetime


METRICS_FILE = os.path.join("data", "performance_metrics.json")


class PerformanceTracker:
    """
    Tracker institucional de performance cuantitativa.
    """

    def __init__(self):
        self.metrics = self._load()

    # ============================================================
    # LOAD / SAVE
    # ============================================================

    def _load(self):
        try:
            if os.path.exists(METRICS_FILE):
                with open(METRICS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return {
            "equity": 1000.0,
            "peak_equity": 1000.0,
            "max_drawdown": 0.0,
            "trades": 0,
            "wins": 0,
            "losses": 0,
            "total_profit": 0.0,
            "total_loss": 0.0,
            "fees": 0.0,
            "equity_curve": []
        }

    def _save(self):
        os.makedirs("data", exist_ok=True)
        with open(METRICS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.metrics, f, indent=4)

    # ============================================================
    # REGISTRAR TRADE
    # ============================================================

    def record_trade(self, trade):
        try:
            pnl = trade.get("pnl", 0.0)
            fee = trade.get("fee", 0.0)
            self.metrics["trades"] += 1
            self.metrics["fees"] += fee
            self.metrics["equity"] += pnl - fee

            if pnl >= 0:
                self.metrics["wins"] += 1
                self.metrics["total_profit"] += pnl
            else:
                self.metrics["losses"] += 1
                self.metrics["total_loss"] += abs(pnl)

            # actualizar peak equity
            if self.metrics["equity"] > self.metrics["peak_equity"]:
                self.metrics["peak_equity"] = self.metrics["equity"]

            # calcular drawdown
            drawdown = (
                (self.metrics["peak_equity"] - self.metrics["equity"])
                / self.metrics["peak_equity"]
            )

            if drawdown > self.metrics["max_drawdown"]:
                self.metrics["max_drawdown"] = drawdown

            # equity curve
            self.metrics["equity_curve"].append({
                "timestamp": datetime.utcnow().isoformat(),
                "equity": self.metrics["equity"]
            })

            self._save()
        except Exception:
            pass

    # ============================================================
    # GETTERS
    # ============================================================

    def get_metrics(self):
        trades = self.metrics["trades"]
        winrate = (
            self.metrics["wins"] / trades
            if trades > 0 else 0.0
        )

        profit_factor = (
            self.metrics["total_profit"] /
            self.metrics["total_loss"]
            if self.metrics["total_loss"] > 0 else 0.0
        )

        return {
            "equity": self.metrics["equity"],
            "drawdown": self.metrics["max_drawdown"],
            "trades": trades,
            "winrate": winrate,
            "profit_factor": profit_factor,
            "fees": self.metrics["fees"]
        }

# instancia global institucional

performance_tracker = PerformanceTracker()