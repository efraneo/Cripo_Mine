from datetime import datetime, timedelta

# ==================================================
# EVENTOS MACRO CRÍTICOS (UTC)
# ==================================================

HIGH_IMPACT_EVENTS = [
    "CPI",
    "NFP",
    "FOMC",
    "FED",
    "INTEREST_RATE"
]

# Ejemplo base (puedes automatizar luego)
# Formato UTC
SCHEDULED_EVENTS = [
    {
        "name": "FOMC",
        "time": "2025-01-29 19:00:00"
    },
    {
        "name": "NFP",
        "time": "2025-02-07 13:30:00"
    }
]


def is_high_risk_news_window(now=None):
    """
    Devuelve (True, reason) si estamos en ventana de alto riesgo
    """
    now = now or datetime.utcnow()

    for ev in SCHEDULED_EVENTS:
        try:
            ev_time = datetime.strptime(
                ev["time"], "%Y-%m-%d %H:%M:%S"
            )

            start = ev_time - timedelta(minutes=60)
            end = ev_time + timedelta(minutes=30)

            if start <= now <= end:
                return True, f"Evento macro activo: {ev['name']}"

        except Exception:
            continue

    return False, None
