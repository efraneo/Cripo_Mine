# core/learning/regime_winrate.py

from collections import defaultdict


_REGIME_TRADES = defaultdict(list)


def record_regime_trade(regime, pnl):
    _REGIME_TRADES[regime].append(pnl)


def get_regime_winrate(regime):

    trades = _REGIME_TRADES.get(regime, [])

    if not trades:
        return 0.5

    wins = sum(1 for p in trades if p > 0)
    return wins / len(trades)
