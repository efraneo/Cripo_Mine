# core/learning/bayesian_win_rate.py

from math import isfinite

# Prior institucional (ligero)
PRIOR_WINS = 3
PRIOR_LOSSES = 3


def compute_bayesian_win_rate(stats: dict) -> float:
    """
    stats = {
        "wins": int,
        "losses": int
    }
    """

    wins = max(0, stats.get("wins", 0))
    losses = max(0, stats.get("losses", 0))

    alpha = wins + PRIOR_WINS
    beta = losses + PRIOR_LOSSES

    win_rate = alpha / (alpha + beta)

    if not isfinite(win_rate):
        return 0.5

    return max(0.01, min(0.99, win_rate))
