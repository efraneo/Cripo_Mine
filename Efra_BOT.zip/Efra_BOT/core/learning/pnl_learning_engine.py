# core/learning/pnl_learning_engine.py

import json
import os


class PnLLearningEngine:

    FILE = "data/pnl_memory.json"

    def __init__(self):
        self.data = self._load()

    # ======================================================
    # LOAD / SAVE
    # ======================================================
    def _load(self):
        if not os.path.exists(self.FILE):
            return {}
        try:
            with open(self.FILE, "r") as f:
                return json.load(f)
        except:
            return {}

    def _save(self):
        os.makedirs("data", exist_ok=True)
        with open(self.FILE, "w") as f:
            json.dump(self.data, f, indent=2)

    # ======================================================
    # UPDATE TRADE RESULT
    # ======================================================
    def update_trade(self, strategy, pnl):

        if strategy not in self.data:
            self.data[strategy] = {
                "wins": 0,
                "losses": 0,
                "pnl": 0
            }

        if pnl > 0:
            self.data[strategy]["wins"] += 1
        else:
            self.data[strategy]["losses"] += 1

        self.data[strategy]["pnl"] += pnl

        self._save()

    # ======================================================
    # GET SCORE (KEY)
    # ======================================================
    def get_strategy_score(self, strategy):

        s = self.data.get(strategy)

        if not s:
            return 1.0  # neutral

        total = s["wins"] + s["losses"]

        if total == 0:
            return 1.0

        winrate = s["wins"] / total

        # Penalización / refuerzo
        if winrate > 0.6:
            return 1.2
        elif winrate < 0.4:
            return 0.7
        else:
            return 1.0
