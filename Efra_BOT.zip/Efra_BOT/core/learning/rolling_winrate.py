# core/learning/rolling_winrate.py

from collections import deque


_ROLLING = deque(maxlen=50)


def update_rolling_trade(pnl):

    _ROLLING.append(pnl)


def get_rolling_winrate():

    if not _ROLLING:
        return 0.5

    wins = sum(1 for p in _ROLLING if p > 0)
    return wins / len(_ROLLING)
