# core/learning/alpha_decay.py

def compute_alpha_decay(pnl_series):

    if len(pnl_series) < 20:
        return {"decay": 0}

    recent = pnl_series[-10:]
    past = pnl_series[-20:-10]

    decay = (sum(recent) - sum(past))

    return {
        "decay": decay,
        "is_decaying": decay < 0
    }

