#core/ia_profiles/asset_profile.py

ASSET_PROFILES = {
    "BTC": {
        "risk_bias": "conservative",
        "min_confidence": 65,
        "max_position": 0.02,
        "session_weight": 1.2,
    },
    "ETH": {
        "risk_bias": "balanced",
        "min_confidence": 60,
        "max_position": 0.03,
        "session_weight": 1.0,
    },
    "DEFAULT": {
        "risk_bias": "aggressive",
        "min_confidence": 70,
        "max_position": 0.01,
        "session_weight": 0.8,
    }
}


def get_asset_profile(symbol: str) -> dict:
    base = symbol.replace("USDT", "")
    return ASSET_PROFILES.get(base, ASSET_PROFILES["DEFAULT"])
