# core/ia_audit_log.py
"""
IA PRO — Audit & Explainability Layer (XAI REAL)

Responsabilidad:
- Registrar TODA decisión IA
- Permitir replay, análisis y auditoría
- NO modifica decisiones
"""

import json
import uuid
import threading
from datetime import datetime
from typing import Dict, Any, Optional, List

from backend.log_manager import get_logger

log = get_logger("ia_audit")


# ==================================================
# CONFIG
# ==================================================
_AUDIT_ENABLED = True
_AUDIT_LOCK = threading.Lock()


# ==================================================
# IA AUDIT LOGGER
# ==================================================
class IAAuditLogger:
    """
    Logger canónico de decisiones IA PRO
    """

    def __init__(self):
        self.buffer: List[Dict[str, Any]] = []

    def log_decision(
        self,
        *,
        symbol: str,
        context: str,
        ia_decision: Dict[str, Any],
        data_by_tf: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Registra una decisión IA completa y explicable
        """

        if not _AUDIT_ENABLED or not ia_decision:
            return ia_decision

        event = {
            "event_id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "symbol": symbol,
            "context": context,
            "decision": {
                "direction": ia_decision.get("direction"),
                "confidence": ia_decision.get("confidence"),
                "actionable": ia_decision.get("actionable"),
            },
            "signals": ia_decision.get("signals", []),
            "timeframes": ia_decision.get("tf_scores", {}),
            "reasoning": ia_decision.get("reasons", []),
        }

        with _AUDIT_LOCK:
            self.buffer.append(event)

        log.debug(
            "IA decision audited",
            extra={
                "symbol": symbol,
                "context": context,
                "confidence": ia_decision.get("confidence"),
            },
        )

        return ia_decision

    def dump(self) -> List[Dict[str, Any]]:
        """
        Devuelve snapshot completo del audit log
        """
        with _AUDIT_LOCK:
            return list(self.buffer)

    def clear(self):
        """
        Limpia auditoría (útil para sesiones UI)
        """
        with _AUDIT_LOCK:
            self.buffer.clear()


# ==================================================
# SINGLETON
# ==================================================
_ia_audit_singleton: Optional[IAAuditLogger] = None


def get_ia_audit_logger() -> IAAuditLogger:
    global _ia_audit_singleton
    if _ia_audit_singleton is None:
        _ia_audit_singleton = IAAuditLogger()
    return _ia_audit_singleton
