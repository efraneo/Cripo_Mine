# core/allocation/strategy_buckets.py

from datetime import datetime


# ======================================================
# 🏛 ESTADO GLOBAL (MVP → luego DB / Redis)
# ======================================================
_BUCKET_STATE = {
    "TREND": {"capital": 0.30},
    "MEAN_REVERT": {"capital": 0.25},
    "BREAKOUT": {"capital": 0.25},
    "SCALP": {"capital": 0.20},
}


# ======================================================
# 📊 PERFORMANCE → CAPITAL SHIFT
# ======================================================
def _score_strategy(stats):

    win_rate = stats.get("win_rate", 0.5)
    pnl = stats.get("pnl_total", 0)
    dd = stats.get("drawdown", 0)

    score = (
        win_rate * 0.5 +
        max(-0.2, min(0.2, pnl / 1000)) +
        max(-0.3, -dd)
    )

    return score


# ======================================================
# 🔁 REBALANCE BUCKETS
# ======================================================
def rebalance_strategy_buckets(strategy_stats: dict):

    scores = {}

    for strat, stats in strategy_stats.items():
        scores[strat] = max(0.01, _score_strategy(stats))

    total_score = sum(scores.values())

    for strat in scores:
        _BUCKET_STATE.setdefault(strat, {})
        _BUCKET_STATE[strat]["capital"] = scores[strat] / total_score

    return {
        "timestamp": datetime.utcnow().isoformat(),
        "buckets": _BUCKET_STATE
    }


# ======================================================
# 📦 GET CAPITAL FRACTION
# ======================================================
def get_strategy_capital_fraction(strategy: str):

    return _BUCKET_STATE.get(strategy, {}).get("capital", 0.01)
