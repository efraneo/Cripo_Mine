# core/allocation/rl_meta_allocator.py

import numpy as np


_Q_VALUES = {}


def update_q(strategy, reward, lr=0.05):
    old_q = _Q_VALUES.get(strategy, 0)
    new_q = old_q + lr * (reward - old_q)
    _Q_VALUES[strategy] = new_q


def get_strategy_weight(strategy):

    if strategy not in _Q_VALUES:
        return 1.0

    q = _Q_VALUES[strategy]

    return max(0.5, min(1.5, 1 + q))
