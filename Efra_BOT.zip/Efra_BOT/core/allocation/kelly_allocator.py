# core/allocation/kelly_allocator.py

def compute_bayesian_kelly(win_rate, rr, confidence, drawdown):

    # Ajustes institucionales
    adj_win = win_rate * (confidence / 100)
    risk_penalty = max(0.3, 1 - drawdown * 2)

    edge = (adj_win * rr) - (1 - adj_win)

    if rr == 0:
        return 0

    kelly = edge / rr

    # Penalización por drawdown
    kelly *= risk_penalty

    # Clamp institucional
    return max(0, min(kelly, 0.25))
