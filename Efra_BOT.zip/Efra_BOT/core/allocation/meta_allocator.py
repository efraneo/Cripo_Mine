# core/allocation/meta_allocator.py

import numpy as np
from core.portfolio.strategy_nav import get_all_strategy_states
from core.session_performance.session_tracker import get_session_stats


# =========================================================
# META SCORE POR ESTRATEGIA
# =========================================================
def _compute_strategy_score(state: dict, regime: str):

    nav = state.get("nav", 1.0)
    drawdown = state.get("drawdown", 0.0)
    sharpe = state.get("sharpe", 0.0)
    win_rate = state.get("win_rate", 0.5)
    strategy = state.get("strategy")

    score = 0

    # 1️⃣ Sharpe weighting
    score += sharpe * 2.0

    # 2️⃣ Penalización por drawdown
    score -= abs(drawdown) * 1.5

    # 3️⃣ Win rate stability
    score += (win_rate - 0.5) * 3.0

    # 4️⃣ Regime alignment boost
    if regime == "TREND" and strategy == "TREND_FOLLOWING":
        score += 1.5
    elif regime == "RANGE" and strategy == "MEAN_REVERSION":
        score += 1.5
    elif regime == "VOLATILITY" and strategy == "DEFENSIVE":
        score += 1.0

    return score


# =========================================================
# SOFTMAX NORMALIZATION
# =========================================================
def _softmax(x):

    x = np.array(x)
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()


# =========================================================
# META ALLOCATION ENGINE
# =========================================================
def compute_meta_allocation(current_regime: str):

    states = get_all_strategy_states()

    if not states:
        return {}

    scores = []
    strategies = []

    for state in states:
        score = _compute_strategy_score(state, current_regime)
        scores.append(score)
        strategies.append(state["strategy"])

    weights = _softmax(scores)

    allocation = {
        strategy: float(weight)
        for strategy, weight in zip(strategies, weights)
    }

    return allocation
