# find_execution_methods.py

import os

TARGET_KEYWORDS = [
    "place_order",
    "execute_market_order"
]

EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    "venv",
    "env",
    ".venv",
    "node_modules"
}

def scan_file(filepath):
    results = []

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        for i, line in enumerate(lines):
            for keyword in TARGET_KEYWORDS:
                if keyword in line:

                    # contexto (líneas cercanas)
                    start = max(0, i - 2)
                    end = min(len(lines), i + 3)

                    snippet = "".join(lines[start:end])

                    results.append({
                        "file": filepath,
                        "line": i + 1,
                        "keyword": keyword,
                        "snippet": snippet
                    })

    except Exception as e:
        print(f"[ERROR] leyendo {filepath}: {e}")

    return results


def scan_project(root_dir):
    all_results = []

    for root, dirs, files in os.walk(root_dir):

        # excluir carpetas basura
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]

        for file in files:
            if file.endswith(".py"):
                filepath = os.path.join(root, file)
                results = scan_file(filepath)
                all_results.extend(results)

    return all_results


def main():
    print("🔍 Escaneando proyecto...\n")

    project_path = os.getcwd()  # puedes cambiar esto si quieres

    results = scan_project(project_path)

    if not results:
        print("❌ No se encontraron funciones de ejecución")
        return

    print(f"✅ Encontradas {len(results)} coincidencias:\n")

    for r in results:
        print("=" * 60)
        print(f"📂 Archivo: {r['file']}")
        print(f"📍 Línea: {r['line']}")
        print(f"🔑 Keyword: {r['keyword']}")
        print("📄 Contexto:\n")
        print(r["snippet"])
        print("=" * 60 + "\n")


if __name__ == "__main__":
    main()