# ================================================================
# streamlit_controller.py — Controlador UI PRO (2025)
# ---------------------------------------------------------------
# Actualizado y parcheado:
# - Integración con enqueue_execute(..., on_finish)
# - TelegramNotifier orientado a objetos
# - Sesión de usuario real (o fallback demo_user)
# - Router estable sin reinicios
# - Estado persistente
# - Previene recomputación de Streamlit
# ================================================================

import streamlit as st
import time

from backend.bot_manager import BotManager
from backend.model_predictor import ModelPredictor
from backend.signals_manager import SignalsManager
from backend.telegram_notifier import TelegramNotifier
from backend.environment_manager import load_env
from backend.trade_analyzer import TradeAnalyzer
from backend.auth_manager import AuthManager


# ================================================================
# INICIALIZACIÓN GLOBAL (cache real)
# ================================================================
@st.cache_resource
def _load_core():
    env = load_env()
    bot = BotManager()
    pred = ModelPredictor()
    sm = SignalsManager()
    analyzer = TradeAnalyzer()
    notifier = TelegramNotifier(env)
    auth = AuthManager()
    return env, bot, pred, sm, analyzer, notifier, auth


ENV, BOT, PREDICTOR, SIGNALS, ANALYZER, NOTIFIER, AUTH = _load_core()


# ================================================================
# SESSION STATE PRO
# ================================================================
def init_state():
    defaults = {
        "page": "Dashboard",
        "selected_asset": None,
        "last_prediction": None,
        "executing": False,
        "execution_result": None,
        "logged_user": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_state()


# ================================================================
# AUTH — Login mínimo (si no hay login real)
# ================================================================
def get_session_user():
    if st.session_state["logged_user"]:
        return st.session_state["logged_user"]

    # 🔐 Si tienes login real, conéctalo aquí
    # user = AUTH.get_logged_user()
    # if user:
    #     st.session_state["logged_user"] = user
    #     return user

    # Fallback sin login real
    st.session_state["logged_user"] = "demo_user"
    return "demo_user"


# ================================================================
# ROUTER
# ================================================================
def router():
    page = st.session_state["page"]
    if page == "Dashboard":
        render_dashboard()
    elif page == "Análisis":
        render_analisis()
    elif page == "Trading":
        render_trading()
    elif page == "Historial":
        render_history()


# ================================================================
# Sidebar PRO
# ================================================================
with st.sidebar:
    st.title("📌 Menú PRO")
    st.session_state["page"] = st.radio(
        "Navegación:",
        ("Dashboard", "Análisis", "Trading", "Historial")
    )

    st.markdown("---")
    st.write("### Seleccionar Activo")

    assets = SIGNALS.available_assets()

    selected = st.selectbox(
        "Activos Disponibles",
        assets,
        index=assets.index(st.session_state["selected_asset"])
        if st.session_state["selected_asset"] in assets else 0
    )

    if selected != st.session_state["selected_asset"]:
        st.session_state["selected_asset"] = selected
        st.session_state["last_prediction"] = None


# ================================================================
# 1 — DASHBOARD
# ================================================================
def render_dashboard():
    st.title("📊 Dashboard Trading PRO")

    metrics = SIGNALS.global_market_metrics()
    if metrics:
        st.metric("Sentimiento Global", metrics["sentiment"])
        st.metric("Volatilidad", metrics["volatility"])

    st.write("### Predicción Rápida")
    asset = st.session_state["selected_asset"]

    if st.button("Analizar Ahora"):
        pred = PREDICTOR.predict_asset(asset)
        st.session_state["last_prediction"] = pred
        NOTIFIER.send_prediction(asset, pred)

    if st.session_state["last_prediction"]:
        st.write("#### Resultado:")
        st.json(st.session_state["last_prediction"])


# ================================================================
# 2 — ANÁLISIS
# ================================================================
def render_analisis():
    st.title("📈 Análisis Técnico PRO")

    asset = st.session_state["selected_asset"]

    chart = SIGNALS.live_chart(asset)
    st.plotly_chart(chart, use_container_width=True)

    if st.button("Generar Predicción IA"):
        pred = PREDICTOR.predict_asset(asset)
        st.session_state["last_prediction"] = pred
        NOTIFIER.send_prediction(asset, pred)
        st.success("Predicción enviada a Telegram ✔")

    if st.session_state["last_prediction"]:
        st.write("### Última Predicción")
        st.json(st.session_state["last_prediction"])


# ================================================================
# 3 — TRADING
# ================================================================
def render_trading():
    st.title("💰 Trading Automático")

    user_id = get_session_user()
    asset = st.session_state["selected_asset"]
    pred = st.session_state["last_prediction"]

    if not pred:
        st.warning("Primero genera una predicción en la pestaña Análisis.")
        return

    st.write(f"### Activo Seleccionado: **{asset}**")
    st.json(pred)

    col1, col2 = st.columns(2)

    with col1:
        if st.button("⚡ Invertir Ahora", disabled=st.session_state["executing"]):
            st.session_state["executing"] = True
            st.session_state["execution_result"] = None

            # 💥 INTEGRACIÓN FINAL — NUEVO enqueue_execute()
            # Construir usuario/session: usar la sesión real si tienes SessionManager
            session_id = st.session_state.get("session_id", None)  # asume que existe
            usuario = {"usuario": st.session_state.get("username", "demo_user"), "nombre": st.session_state.get("username", "demo_user")}

            # Parámetros de inversión (puedes añadir controles UI para editarlos)
            amount = st.number_input("Monto (USDT)", min_value=1.0, value=25.0, step=1.0)
            steps = st.selectbox("Pasos DCA", [1,2,3,4], index=2)

            # Registrar callback local que actualiza session_state
            def _ui_on_finish(result):
                # Streamlit no soporta llamadas asíncronas desde threads directamente,
                # así que guardamos resultado en un lugar que Streamlit lea.
                st.session_state["execution_result"] = result
                st.session_state["executing"] = False

            # Encolar ejecución (pasa usuario/session_id correctos)
            BOT.enqueue_execute(
                symbol=asset,
                session_id=session_id or "demo_session",
                usuario=usuario,
                amount_usdt=float(amount),
                steps=int(steps),
                stop_loss_pct=0.02,
                mode="DEMO",
                metadata={"from_ui": True},
                on_finish=_ui_on_finish
            )

            NOTIFIER.send_trading_start(asset, pred)
            st.info("Ejecutando operación…")

    with col2:
        if st.button("❌ Cancelar"):
            BOT.force_stop()
            st.session_state["executing"] = False
            NOTIFIER.send_cancel(asset)
            st.warning("Operación cancelada.")

    if st.session_state["execution_result"]:
        st.success("✔ Operación finalizada")
        st.json(st.session_state["execution_result"])


# ================================================================
# CALLBACK — FINALIZACIÓN
# ================================================================
def _callback_finish(result):
    st.session_state["execution_result"] = result
    st.session_state["executing"] = False
    NOTIFIER.send_trade_confirmation(result)


# ================================================================
# 4 — HISTORIAL
# ================================================================
def render_history():
    st.title("📚 Historial Trading")

    history = ANALYZER.get_trade_history()
    if history:
        st.dataframe(history)
    else:
        st.info("Sin operaciones registradas aún.")


# ================================================================
# EJECUTAR ROUTER
# ================================================================
router()
