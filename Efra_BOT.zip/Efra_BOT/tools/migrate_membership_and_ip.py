import sqlite3
from datetime import datetime

DB_PATH = "data/usuarios.db"

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

# ---- USERS ----
try:
    cur.execute("ALTER TABLE users ADD COLUMN has_membership INTEGER DEFAULT 0")
except sqlite3.OperationalError:
    pass

try:
    cur.execute("ALTER TABLE users ADD COLUMN membership_expires_at TEXT")
except sqlite3.OperationalError:
    pass

# ---- USER IPS ----
cur.execute("""
CREATE TABLE IF NOT EXISTS user_ips (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    ip TEXT NOT NULL,
    approved INTEGER DEFAULT 0,
    expires_at TEXT,
    first_seen_at TEXT,
    last_seen_at TEXT,
    failed_attempts INTEGER DEFAULT 0,
    blocked INTEGER DEFAULT 0
)
""")

conn.commit()
conn.close()

print("✔ Migración de membresías e IPs completada.")
