import os
import ast


PROJECT_ROOT = "core"


def analyze_file(path):
    with open(path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read())

    imports = []
    assigned = []
    used = []

    for node in ast.walk(tree):

        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)

        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    assigned.append(target.id)

        if isinstance(node, ast.Name):
            used.append(node.id)

    undefined = set(used) - set(assigned)

    return {
        "file": path,
        "undefined_variables": list(undefined),
        "imports": imports
    }


def run_audit():
    for root, _, files in os.walk(PROJECT_ROOT):
        for file in files:
            if file.endswith(".py"):
                path = os.path.join(root, file)
                report = analyze_file(path)
                print(report)


if __name__ == "__main__":
    run_audit()
