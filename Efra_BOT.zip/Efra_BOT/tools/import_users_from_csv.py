# tools/import_users_from_csv.py
import sys
import os

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import csv
from backend.user_manager import UserManager

um = UserManager("data/usuarios.db")

with open("data/claves.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for r in reader:
        um.update_user_by_username(
            r["usuario"],
            {
                "email": r["correo"],
                "is_admin": r["es_admin"] == "True",
                "enabled": r["estado"] == "activo"
            }
        )
        # nombre completo
        with um._conn() as c:
            c.execute(
                "UPDATE users SET full_name=? WHERE username=?",
                (r["nombre"], r["usuario"])
            )
            c.commit()
