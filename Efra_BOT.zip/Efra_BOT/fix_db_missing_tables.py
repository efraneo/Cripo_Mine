# fix_db_missing_tables.py
import sqlite3, os

DB = os.path.join("data", "usuarios.db")

def ensure_table(c, sql):
    try:
        c.execute(sql)
    except Exception as e:
        print(f"Error creando tabla: {e}")

with sqlite3.connect(DB) as c:

    print(">>> Reparando base de datos, creando tablas faltantes...")

    ensure_table(c, """
    CREATE TABLE IF NOT EXISTS lockouts (
        username TEXT PRIMARY KEY,
        until_ts INTEGER
    );
    """)

    ensure_table(c, """
    CREATE TABLE IF NOT EXISTS failed_logins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        ip TEXT,
        ts TEXT
    );
    """)

    ensure_table(c, """
    CREATE TABLE IF NOT EXISTS twofa_tokens (
        username TEXT,
        token TEXT,
        expires_at INTEGER,
        created_at INTEGER
    );
    """)

    ensure_table(c, """
    CREATE TABLE IF NOT EXISTS reset_tokens (
        username TEXT,
        token TEXT,
        expires_at INTEGER,
        created_at INTEGER
    );
    """)

    ensure_table(c, """
    CREATE TABLE IF NOT EXISTS sessions (
        session_id TEXT PRIMARY KEY,
        username TEXT,
        created_at INTEGER,
        last_touch INTEGER,
        expires_at INTEGER
    );
    """)

    print(">>> Listo. Base de datos reparada.")
