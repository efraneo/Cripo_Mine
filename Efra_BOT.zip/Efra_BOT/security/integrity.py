"""
security/integrity.py – Sistema Profesional de Integridad y Detección de Manipulación
------------------------------------------------------------------------------------

Funciones principales:
✔ Verifica integridad de todos los módulos críticos del bot mediante SHA256 + HMAC.
✔ Detecta modificaciones no autorizadas en archivos .py.
✔ Envía alertas inmediatas al Telegram del administrador.
✔ Detiene ejecución del bot si se detecta un hack o modificación.
✔ Mantiene una base local firmada de hashes originales (hashdb.json).
✔ Protección contra inyección de código, manipulación en Streamlit o backend.

Requiere:
- security.env → con la clave HMAC_SECRET_KEY
- telegram_notifier.py → para enviar alertas

Efra_BOT versión PRO © 2025
"""

import os
import hmac
import json
import hashlib
import time
from typing import Dict, List
from pathlib import Path

from backend.telegram_notifier import TelegramNotifier

# ════════════════════════════════════════════════════════════════════════════════
#  CONFIGURACIÓN
# ════════════════════════════════════════════════════════════════════════════════

BASE_DIR = Path(__file__).resolve().parents[1]
HASH_DB_FILE = BASE_DIR / "security" / "hashdb.json"
SECURITY_ENV_FILE = BASE_DIR / "security" / "security.env"

CRITICAL_FILES = [
    "backend/binance_client.py",
    "backend/order_manager.py",
    "backend/trading_engine.py",
    "backend/monitor_ws.py",
    "backend/ia_predictor.py",
    "backend/telegram_notifier.py",
    "el_bot_de_efra.py",
]

# ════════════════════════════════════════════════════════════════════════════════
#  CARGA DE CLAVE HMAC
# ════════════════════════════════════════════════════════════════════════════════

def load_hmac_key() -> bytes:
    """
    Carga la clave HMAC desde security.env
    """
    if not SECURITY_ENV_FILE.exists():
        raise RuntimeError(
            "❌ ERROR DE SEGURIDAD: No existe security.env. "
            "Crea el archivo y coloca: HMAC_SECRET_KEY=\"tu_clave_super_secreta\""
        )

    key = None
    with open(SECURITY_ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            if "HMAC_SECRET_KEY" in line:
                key = line.split("=")[1].strip().replace('"', '').replace("'", "")
                break

    if not key:
        raise RuntimeError("❌ ERROR: No está definida la clave HMAC_SECRET_KEY en security.env")

    return key.encode("utf-8")


HMAC_SECRET_KEY = load_hmac_key()
notifier = TelegramNotifier()


# ════════════════════════════════════════════════════════════════════════════════
#  FUNCIONES DE HASHING
# ════════════════════════════════════════════════════════════════════════════════

def compute_hmac_hash(filepath: Path) -> str:
    """
    Retorna HMAC(SHA256) del contenido del archivo.
    """
    with open(filepath, "rb") as f:
        content = f.read()

    digest = hmac.new(HMAC_SECRET_KEY, content, hashlib.sha256).hexdigest()
    return digest


def load_hash_db() -> Dict[str, str]:
    """
    Carga la base de datos local de hashes.
    """
    if not HASH_DB_FILE.exists():
        return {}

    with open(HASH_DB_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def save_hash_db(db: Dict[str, str]):
    """
    Guarda los hashes firmados en hashdb.json
    """
    with open(HASH_DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, indent=4)


# ════════════════════════════════════════════════════════════════════════════════
#  VERIFICACIÓN DE INTEGRIDAD
# ════════════════════════════════════════════════════════════════════════════════

def verify_integrity():
    """
    Verifica la integridad de todos los módulos críticos.
    Si hay un archivo alterado:
    - Envía alerta a Telegram.
    - Registra el incidente.
    - **Detiene la ejecución inmediatamente.**
    """
    db = load_hash_db()
    new_db = {}

    for relative_path in CRITICAL_FILES:
        file_path = BASE_DIR / relative_path

        if not file_path.exists():
            notifier.send_alert(
                f"⚠️ ALERTA CRÍTICA: El archivo {relative_path} ha sido borrado.\n"
                f"El bot será detenido por seguridad."
            )
            raise SystemExit("❌ Integridad rota: archivo eliminado.")

        current_hash = compute_hmac_hash(file_path)
        new_db[relative_path] = current_hash

        if relative_path in db:
            if db[relative_path] != current_hash:
                # ARCHIVO MODIFICADO → ALERTA CRÍTICA
                notifier.send_alert(
                    f"🚨 ¡ALERTA DE HACKEO DETECTADA! 🚨\n\n"
                    f"El archivo:\n📄 `{relative_path}`\n\n"
                    f"Ha sido **MODIFICADO** sin autorización.\n\n"
                    f"El bot se apagará por seguridad."
                )
                raise SystemExit("❌ Integridad rota: archivo modificado.")

    # Si todo está OK, se actualiza la DB
    save_hash_db(new_db)


# ════════════════════════════════════════════════════════════════════════════════
#  REGISTRO INICIAL (se ejecuta 1 vez manualmente)
# ════════════════════════════════════════════════════════════════════════════════

def initialize_integrity_database():
    """
    Genera la base de datos inicial hashdb.json.
    Debe ejecutarse 1 vez cuando el bot esté limpio.
    """
    db = {}
    for relative_path in CRITICAL_FILES:
        file_path = BASE_DIR / relative_path
        if file_path.exists():
            db[relative_path] = compute_hmac_hash(file_path)

    save_hash_db(db)
    print("✔ Base de integridad generada correctamente.")


# ════════════════════════════════════════════════════════════════════════════════
#  USO PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════════

def enforce_integrity():
    """
    Función principal:
    Se llama al inicio del bot para validar integridad antes de ejecutar nada más.
    """
    try:
        verify_integrity()
    except Exception as e:
        print(f"❌ ERROR DE SEGURIDAD: {e}")
        raise SystemExit()
