# C:\software_phyton\Efra_BOT\buscar_config_ia.py

import os
from pathlib import Path

# ==========================================
# CONFIG
# ==========================================

ROOT = r"C:\software_phyton\Efra_BOT"

KEYWORDS = [

    "WAIT_NEXT_CLOSE",
    "allow_trade",
    "execution_policy",
    "ENTRY_TIMING",
    "entry_timing",
    "min_confidence",
    "get_best_high_confidence",
    "filter_best_assets",
    "confidence >= 95",
    "confidence>=95",
    "ui_lock",
    "show_countdown",
    "WAIT_CONFIRMATION",
    "allow_trade=False",
    "allow_trade = False",

]

IGNORE = [

    "__pycache__",
    ".git",
    ".venv",
    "venv",
    "env",
    ".idea"

]

OUTPUT = "reporte_busqueda_ia.txt"


# ==========================================
# SEARCH
# ==========================================

results = []

print("\nEscaneando proyecto...\n")

for root, dirs, files in os.walk(ROOT):

    dirs[:] = [
        d for d in dirs
        if d not in IGNORE
    ]

    for file in files:

        if not file.endswith(".py"):
            continue

        full_path = os.path.join(
            root,
            file
        )

        try:

            with open(
                full_path,
                "r",
                encoding="utf-8"
            ) as f:

                lines = f.readlines()

            for n, line in enumerate(
                lines,
                start=1
            ):

                for keyword in KEYWORDS:

                    if keyword.lower() in line.lower():

                        item = {

                            "keyword": keyword,
                            "file": full_path,
                            "line": n,
                            "content": line.strip()

                        }

                        results.append(item)

                        print(
                            f"[{keyword}] "
                            f"{file}:{n}"
                        )

        except Exception:
            pass


# ==========================================
# EXPORT TXT
# ==========================================

with open(
    OUTPUT,
    "w",
    encoding="utf-8"
) as out:

    out.write(
        "\nREPORTE IA\n"
    )

    out.write(
        "="*80
    )

    out.write("\n")

    for r in results:

        out.write("\n")

        out.write(
            f"KEYWORD : {r['keyword']}\n"
        )

        out.write(
            f"ARCHIVO : {r['file']}\n"
        )

        out.write(
            f"LINEA   : {r['line']}\n"
        )

        out.write(
            f"CODIGO  :\n"
        )

        out.write(
            f"{r['content']}\n"
        )

        out.write(
            "-"*80
        )

        out.write("\n")

print("\n")
print("="*60)
print("ESCANEO FINALIZADO")
print(f"Coincidencias: {len(results)}")
print(f"Reporte: {OUTPUT}")
print("="*60)

