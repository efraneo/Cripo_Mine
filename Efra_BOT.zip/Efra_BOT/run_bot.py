# run_bot.py
"""
Script de orquestación:
 - Start monitor (backend/monitor_ws.py)
 - Opcional: lanzar Streamlit UI (no lo hace aquí; lo haces con `streamlit run el_bot_de_Efra.py`)
 - Start scheduler simple para reentrenar IA/backtests (si lo necesitas)

Uso:
    python run_bot.py --start-monitor BTCUSDT:1m ETHUSDT:1m --mode PAPER
"""

from __future__ import annotations
import argparse
import time
import threading
from typing import List

from core.jobs.daily_close_job import is_utc_day_close, run_daily_close

from backend.monitor_ws import BinanceKlineMonitor, default_on_close_callback_factory
from backend.trading_core import SignalProcessor, TradeExecutor

def parse_symbols(specs: List[str]):
    out = []
    for s in specs:
        if ":" in s:
            sym, intr = s.split(":", 1)
        else:
            sym, intr = s, "1m"
        out.append((sym.upper(), intr))
    return out

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--start-monitor", nargs="*", default=[], help="Símbolos con intervalo (BTCUSDT:1m ETHUSDT:1m)")
    p.add_argument("--mode", default="PAPER", help="PAPER or REAL")
    args = p.parse_args()

    symbols = parse_symbols(args.start_monitor)
    if not symbols:
        print("No symbols to monitor. Use --start-monitor BTCUSDT:1m")
        return

    sp = SignalProcessor()
    te = TradeExecutor(mode=args.mode)
    monitor = BinanceKlineMonitor()

    for sym, intr in symbols:
        cb = default_on_close_callback_factory(sp, te, usuario={"usuario":"runner"}, account_balance=1000.0)
        monitor.start_listening(sym, intr, cb)
        print(f"Monitor started for {sym}@{intr}")

    try:
        while True:
            try:

                # =========================================
                # 🏛 HEDGE FUND — DAILY CLOSE JOB
                # =========================================
                if is_utc_day_close():
                    print("[DAILY CLOSE] Running institutional close process...")
                    run_daily_close()

                time.sleep(1)

            except Exception as e:
                print("Main loop error:", e)
                time.sleep(5)
    except KeyboardInterrupt:
        print("Stopping monitors...")
        monitor.stop_all()
        print("Exited.")

if __name__ == "__main__":
    main()
