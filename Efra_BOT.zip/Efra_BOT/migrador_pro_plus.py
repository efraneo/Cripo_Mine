import sqlite3
import os
import shutil
import re
from datetime import datetime

DB = os.path.join("data", "usuarios.db")
SCHEMA_FILE = os.path.join("sql", "schema_pro.sql")

# ==============================
# 🔒 Backup automático
# ==============================
def backup_database():
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"{DB}.backup_{ts}"
    shutil.copy(DB, backup_file)
    print(f"📦 Backup creado: {backup_file}")

# ==============================
# 📘 Leer schema
# ==============================
def load_schema():
    print("📌 Cargando schema:", SCHEMA_FILE)
    with open(SCHEMA_FILE, "r", encoding="utf-8") as f:
        return f.read()

# ==============================
# 🔍 Extraer definiciones de tablas del schema
# ==============================
def extract_tables(schema_sql):
    table_defs = re.findall(
        r"CREATE TABLE IF NOT EXISTS ([a-zA-Z0-9_]+)\s*\((.*?)\);",
        schema_sql,
        flags=re.DOTALL
    )
    return table_defs

# ==============================
# 🧩 Parsear columnas
# ==============================
def parse_columns(block):
    cols = []
    for line in block.split(","):
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        parts = line.split()
        name = parts[0]
        coltype = parts[1] if len(parts) > 1 else "TEXT"
        cols.append((name, coltype))
    return cols

# ==============================
# 🚀 Migración avanzada
# ==============================
def migrate():
    print("📌 Conectando a la base de datos:", DB)
    conn = sqlite3.connect(DB)
    c = conn.cursor()

    schema_sql = load_schema()
    table_defs = extract_tables(schema_sql)

    print("\n📦 Creando backup...")
    backup_database()

    print("\n🚀 Iniciando migración PLUS...\n")

    # Foreign keys ON
    c.execute("PRAGMA foreign_keys = ON;")

    report = []

    for table_name, cols_block in table_defs:
        entry = {"table": table_name, "added": [], "missing": [], "type_mismatch": [], "extra": []}

        print(f"🔍 Revisando tabla: {table_name}")

        expected_cols = parse_columns(cols_block)
        existing_cols = c.execute(f"PRAGMA table_info({table_name})").fetchall()

        # Si la tabla no existe, crearla entera
        if not existing_cols:
            print(f"  ➤ Tabla '{table_name}' NO existe. Creándola...")
            c.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({cols_block})")
            conn.commit()
            entry["created"] = True
            print("  ✔ Tabla creada\n")
            report.append(entry)
            continue

        existing_map = {col[1]: col[2] for col in existing_cols}

        # Revisar columnas faltantes
        for col_name, col_type in expected_cols:
            if col_name not in existing_map:
                print(f"  ➤ FALTA columna: {col_name} ({col_type}) → agregando...")
                try:
                    c.execute(f"ALTER TABLE {table_name} ADD COLUMN {col_name} {col_type}")
                    conn.commit()
                    entry["added"].append(col_name)
                    print("    ✔ OK")
                except Exception as e:
                    print("    ❌ Error:", e)
            else:
                # revisar tipo
                real_type = existing_map[col_name].upper()
                if real_type != col_type.upper():
                    entry["type_mismatch"].append((col_name, real_type, col_type))

        # Detectar columnas extra (sobrantes)
        expected_names = {c[0] for c in expected_cols}
        for existing_name in existing_map:
            if existing_name not in expected_names:
                entry["extra"].append(existing_name)

        report.append(entry)
        print("  ✔ Tabla revisada\n")

    # ==============================
    # 🔍 Índices recomendados (si quisieras crearlos)
    # ==============================
    print("\n🔍 Verificando índices recomendados...")
    recommended_indexes = [
        ("users", "idx_users_username", "username"),
        ("sessions", "idx_sessions_username", "username"),
        ("investments", "idx_investments_username", "username"),
        ("ip_logs", "idx_iplogs_username", "username")
    ]

    for table, index, column in recommended_indexes:
        try:
            c.execute(f"CREATE INDEX IF NOT EXISTS {index} ON {table}({column});")
            print(f"  ✔ Índice {index} activo")
        except Exception as e:
            print(f"  ❌ No se pudo crear índice {index}: {e}")

    conn.commit()

    print("\n🎉 MIGRACIÓN PLUS COMPLETADA 🎉\n")

    # ==============================
    # 📋 Reporte Final
    # ==============================
    print("📋 REPORTE DE MIGRACIÓN:\n")

    for r in report:
        print(f"🗂 Tabla: {r['table']}")
        if "created" in r:
            print("   ✔ Creada desde cero")
            continue

        if r["added"]:
            print("   ➕ Columnas agregadas:", r["added"])
        if r["type_mismatch"]:
            print("   ⚠ Tipos incorrectos detectados:")
            for name, real, expected in r["type_mismatch"]:
                print(f"      - {name}: {real} → debería ser {expected}")
        if r["extra"]:
            print("   ⚠ Columnas sobrantes detectadas:", r["extra"])
        if not (r["added"] or r["type_mismatch"] or r["extra"]):
            print("   ✔ OK — Tabla coincide con el schema")

        print("")

    conn.close()
    print("✅ Base de datos lista y migrada correctamente.")


# ==============================
# 🔧 Ejecutar
# ==============================
if __name__ == "__main__":
    migrate()
