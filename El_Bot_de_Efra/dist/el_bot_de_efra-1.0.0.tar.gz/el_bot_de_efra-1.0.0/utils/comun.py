import os
import pandas as pd
import yfinance as yf
from binance.client import Client
from config_loader import API_KEY, API_SECRET

def obtener_datos_yahoo(symbol, interval="1h", period="60d"):
    """
    Descarga datos OHLC desde Yahoo Finance.
    """
    try:
        df = yf.download(symbol, interval=interval, period=period)
        df.dropna(inplace=True)
        df.index = pd.to_datetime(df.index)
        df.rename(columns={
            'Open': 'open', 'High': 'high', 'Low': 'low',
            'Close': 'close', 'Volume': 'volume'
        }, inplace=True)
        return df
    except Exception as e:
        print(f"❌ Error descargando datos de Yahoo: {e}")
        return pd.DataFrame()


def obtener_datos_binance(symbol, interval="1h", lookback="60d"):
    """
    Descarga datos OHLC desde Binance usando la API oficial.
    """
    client = Client(API_KEY, API_SECRET)
    try:
        klines = client.get_historical_klines(symbol, interval, lookback)
        df = pd.DataFrame(klines, columns=[
            "timestamp", "open", "high", "low", "close", "volume",
            "close_time", "quote_asset_volume", "number_of_trades",
            "taker_buy_base_volume", "taker_buy_quote_volume", "ignore"
        ])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        df.set_index("timestamp", inplace=True)
        df = df[["open", "high", "low", "close", "volume"]].astype(float)
        return df
    except Exception as e:
        print(f"❌ Error obteniendo datos de Binance: {e}")
        return pd.DataFrame()


def cargar_activos(desde="csv"):
    """
    Carga lista de activos desde /csv/activos.csv o /csv/activos.txt.
    """
    try:
        path = os.path.join("csv", "activos.csv" if desde == "csv" else "activos.txt")
        if desde == "csv":
            return pd.read_csv(path)["activo"].tolist()
        else:
            with open(path, "r") as f:
                return [line.strip() for line in f.readlines()]
    except Exception as e:
        print(f"⚠️ No se pudo cargar la lista de activos: {e}")
        return []

def normalizar_columnas(df):
    """
    Asegura que las columnas OHLC estén en minúsculas.
    """
    columnas = ["open", "high", "low", "close", "volume"]
    df = df.copy()
    df.columns = [col.lower() for col in df.columns]
    return df[columnas]

