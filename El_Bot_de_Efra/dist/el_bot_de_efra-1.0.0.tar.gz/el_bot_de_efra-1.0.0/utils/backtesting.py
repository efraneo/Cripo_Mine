# backtesting.py
import os
import pandas as pd
from indicadores_tecnicos import agregar_indicadores_tecnicos
from backtesting.estrategias import (
    estrategia_cruce_medias,
    estrategia_rsi_macd,
    estrategia_volatilidad
)

ESTRATEGIAS = {
    'cruce_medias': estrategia_cruce_medias,
    'rsi_macd': estrategia_rsi_macd,
    'volatilidad': estrategia_volatilidad
}

def ejecutar_backtest(df, estrategia_func, activo, nombre_estrategia):
    df = agregar_indicadores_tecnicos(df)
    df = estrategia_func(df)

    df['retornos'] = df['close'].pct_change().fillna(0)
    df['estrategia_ret'] = df['signal'].shift(1) * df['retornos']
    df['acumulado'] = (1 + df['estrategia_ret']).cumprod()

    path = f"backtesting_resultados/{activo}_{nombre_estrategia}.csv"
    os.makedirs("backtesting_resultados", exist_ok=True)
    df.to_csv(path)

    print(f"✅ Guardado: {path}")
    return df[['close', 'signal', 'estrategia_ret', 'acumulado']]

def cargar_datos_activo(activo):
    path = f"data_historica/{activo}.csv"
    if not os.path.exists(path):
        print(f"❌ Datos no encontrados para {activo}")
        return None
    return pd.read_csv(path, parse_dates=True, index_col=0)

def main():
    activos = ["BTCUSDT", "ETHUSDT", "AAPL", "MSFT"]  # ✅ Puedes personalizar
    for activo in activos:
        df = cargar_datos_activo(activo)
        if df is None:
            continue

        for nombre_estrategia, funcion in ESTRATEGIAS.items():
            print(f"🔍 Backtesting: {activo} - {nombre_estrategia}")
            ejecutar_backtest(df.copy(), funcion, activo, nombre_estrategia)

def realizar_backtesting(df, symbol, acc):
    """
    Función adaptada para el bot. Simula compras/ventas según predicción de la IA.

    Parámetros:
        df (pd.DataFrame): Datos con predicción de IA.
        symbol (str): Activo.
        acc (float): Precisión de la IA.

    Retorna:
        df (DataFrame): Con columnas de resultados.
        ganancia_total (float): Ganancia neta.
    """
    df = df.copy()
    df['retornos'] = df['close'].pct_change().fillna(0)
    df['pred'] = df['pred'].shift(1)  # evitar lookahead bias
    df['estrategia_ret'] = df['retornos'] * df['pred'].map({"compra": 1, "venta": -1}).fillna(0)
    df['acumulado'] = (1 + df['estrategia_ret']).cumprod()

    df['signal'] = df['pred']
    df['acumulado'] *= 1000  # Capital inicial

    ganancia_total = df['acumulado'].iloc[-1] - 1000

    os.makedirs("backtesting_resultados", exist_ok=True)
    df.to_csv(f"backtesting_resultados/{symbol}_IA.csv", index=False)

    return df, ganancia_total

if __name__ == "__main__":
    main()
