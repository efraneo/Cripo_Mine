import pandas as pd
import os
import numpy as np
from sklearn.tree import DecisionTreeClassifier
import yaml
import threading
from utils.setup import crear_directorios_logs

def entrenar_y_predecir(df):
    if df is None or df.empty or len(df) < 20:
        return "esperar", 0.0

    try:
        df = df.dropna().copy()
        df['target'] = np.where(df['close'].shift(-1) > df['close'], 1, 0)

        if not all(col in df.columns for col in ['rsi', 'macd', 'macd_signal', 'ema_10', 'ema_50']):
            return "esperar", 0.0

        X = df[['rsi', 'macd', 'macd_signal', 'ema_10', 'ema_50']]
        y = df['target']

        model = DecisionTreeClassifier(max_depth=3, random_state=42)
        model.fit(X, y)
        acc = model.score(X, y)

        pred = model.predict([X.iloc[-1]])[0]
        action = 'buy' if pred == 1 else 'sell'
        return action, acc
    except Exception:
        return "esperar", 0.0

def evaluar_estrategia(rsi, macd_signal, tendencia, volumen_fuerte, precision):
    condiciones = [
        tendencia == 'alcista',
        volumen_fuerte,
        rsi < 30 or rsi > 70,
        precision >= 0.6,
        macd_signal > 0
    ]
    score = sum(condiciones)
    if score >= 4:
        return 'Compra técnica fuerte'
    elif score >= 2:
        return 'Posible oportunidad'
    return 'No operar'

def leer_activos_por_categoria(path="activos.csv"):
    """Lee el archivo CSV de activos con columna de mercado"""
    if not os.path.exists(path):
        raise FileNotFoundError("⚠️ El archivo activos.csv no fue encontrado.")

    df = pd.read_csv(path)

    # Asegurar columnas necesarias
    required = {"categoria", "simbolo", "mercado"}
    if not required.issubset(df.columns):
        raise ValueError(f"⚠️ El archivo activos.csv debe tener las columnas: {', '.join(required)}")

    activos_por_categoria = {}
    mercado_symbols = {}
    for _, row in df.iterrows():
        categoria = row["categoria"].strip()
        simbolo = row["simbolo"].strip()
        mercado = row["mercado"].strip().lower()

        if categoria not in activos_por_categoria:
            activos_por_categoria[categoria] = []
        activos_por_categoria[categoria].append(simbolo)
        mercado_symbols[simbolo] = mercado

    return activos_por_categoria, mercado_symbols

def obtener_timeframe_valido(config=None):
    if config is None:
        with open("config.yaml", 'r', encoding='utf-8') as file:
            config = yaml.safe_load(file)
    intervalo = config.get("intervalo", "1h")
    mapping = {
        "1m": ("1m", "1m", 1),
        "5m": ("5m", "5m", 5),
        "15m": ("15m", "15m", 15),
        "1h": ("1h", "60m", 60),
        "1d": ("1d", "1d", 1440),
    }
    return mapping.get(intervalo, ("1h", "60m", 60))

def validar_y_clasificar_simbolos(simbolos):
    binance = []
    yahoo = []
    commodities = []
    invalidos = []

    for s in simbolos:
        if not isinstance(s, str) or not s.strip():
            continue
        s = s.strip().upper()
        if s.endswith("USDT"):
            binance.append(s)
        elif s in ["XAUUSD", "XAGUSD", "OILUSD", "WTIUSD"]:
            commodities.append(s)
        elif "." in s or s.isupper():
            yahoo.append(s)
        else:
            invalidos.append(s)

    mercado = {s: 'binance' for s in binance} | \
              {s: 'yahoo' for s in yahoo} | \
              {s: 'yahoo' for s in commodities}

    return binance + yahoo + commodities, mercado, invalidos

def crear_directorios_logs():
    for carpeta in ["logs", "graficos", "csv"]:
        os.makedirs(carpeta, exist_ok=True)

bot_thread = None
bot_activo = False
simbolos_en_tiempo_real = []

def main_bot():
    global bot_thread, bot_activo
    if bot_thread is None or not bot_thread.is_alive():
        bot_activo = True
        bot_thread = threading.Thread(target=ejecutar_bot_con_tracking, daemon=True)
        bot_thread.start()
        return True
    return False

def detener_bot():
    global bot_activo
    bot_activo = False

def esta_corriendo():
    return bot_thread is not None and bot_thread.is_alive()

def obtener_simbolos_actuales():
    return simbolos_en_tiempo_real

def ejecutar_bot_con_tracking():
    from el_bot_de_efra import ejecutar_bot
    ejecutar_bot(symbols_override=None, stop_event=None)

def actualizar_simbolos(lista):
    global simbolos_en_tiempo_real
    simbolos_en_tiempo_real = lista

