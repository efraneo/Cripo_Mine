import pandas as pd
import os
from datetime import datetime

from logger import logger

def cargar_historial():
    """
    Carga el historial desde historial.csv
    """
    archivo = "logs/historial.csv"
    if not os.path.exists(archivo):
        logger.warning("📂 El archivo historial.csv no existe.")
        return pd.DataFrame()

    try:
        df = pd.read_csv(archivo, parse_dates=["fecha"])
        df.sort_values("fecha", ascending=False, inplace=True)
        return df
    except Exception as e:
        logger.error(f"❌ Error al leer historial: {e}")
        return pd.DataFrame()

def filtrar_historial(df, activo=None, desde=None, hasta=None, origen=None):
    """
    Filtra el historial según parámetros opcionales.
    """
    if df.empty:
        return df

    if activo:
        df = df[df["activo"] == activo]
    if origen:
        df = df[df["origen"] == origen]
    if desde:
        df = df[df["fecha"] >= pd.to_datetime(desde)]
    if hasta:
        df = df[df["fecha"] <= pd.to_datetime(hasta)]

    return df

def resumen_por_activo(df):
    """
    Devuelve una tabla con conteo de señales por activo.
    """
    if df.empty:
        return pd.DataFrame()

    return df.groupby("activo")["accion"].value_counts().unstack(fill_value=0)

def resumen_por_dia(df):
    """
    Devuelve resumen de señales por fecha.
    """
    if df.empty:
        return pd.DataFrame()

    df["fecha_dia"] = df["fecha"].dt.date
    return df.groupby("fecha_dia")["accion"].value_counts().unstack(fill_value=0)

