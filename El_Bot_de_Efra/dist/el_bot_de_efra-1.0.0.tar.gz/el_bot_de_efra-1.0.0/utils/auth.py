# 📁 utils/auth.py

import pandas as pd
import smtplib
import random
import string
from email.mime.text import MIMEText
import os
from dotenv import load_dotenv
import requests

CLAVES_PATH = "claves.csv"
ADMIN_USER = "8642239"
ADMIN_PASS = "dasb1512"

# ✅ Cargar .env con clave de correo y Telegram
load_dotenv("clave_correo.env")
SENDER_EMAIL = os.getenv("EMAIL_USER")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# 📊 Cargar o crear base de datos
def cargar_usuarios():
    if not os.path.exists(CLAVES_PATH):
        df = pd.DataFrame([{
            "cedula": ADMIN_USER,
            "clave": ADMIN_PASS,
            "correo": "efraneo@gmail.com"
        }])
        df.to_csv(CLAVES_PATH, index=False)
    else:
        df = pd.read_csv(CLAVES_PATH)
    return df

# 🔑 Clave aleatoria
def generar_clave(longitud=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=longitud))

# 📬 Enviar correo con clave
def enviar_clave(destinatario, clave):
    msg = MIMEText(f"Tu clave es: {clave}")
    msg["Subject"] = "Clave de acceso al Bot de Efra"
    msg["From"] = SENDER_EMAIL
    msg["To"] = destinatario

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(SENDER_EMAIL, EMAIL_PASSWORD)
        server.send_message(msg)

# 🔎 Verifica si cédula y clave coinciden
def verificar_usuario(cedula, clave):
    df = cargar_usuarios()
    match = df[(df["cedula"] == cedula) & (df["clave"] == clave)]
    return not match.empty

# 📧 Obtener correo desde base de datos
def obtener_correo(cedula):
    df = cargar_usuarios()
    fila = df[df["cedula"] == cedula]
    if not fila.empty:
        return fila.iloc[0]["correo"]
    return None

# ➕ Agregar nuevo usuario
def agregar_usuario(cedula, clave, correo):_
