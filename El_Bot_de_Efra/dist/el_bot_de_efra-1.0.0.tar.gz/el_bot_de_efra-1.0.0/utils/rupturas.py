# utils/rupturas.py

def detectar_rupturas(df, soporte, resistencia):
    """
    Detecta si el precio actual rompe el soporte o la resistencia.
    Retorna una tupla: (rompe_soporte, rompe_resistencia)
    """
    precio_actual = df['close'].iloc[-1]
    rompe_soporte = precio_actual < soporte
    rompe_resistencia = precio_actual > resistencia
    return rompe_soporte, rompe_resistencia
