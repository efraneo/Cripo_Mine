# 📁 Archivo: app.py

from dotenv import load_dotenv
load_dotenv("clave_correo.env")

import os
import time
import random
import string
from datetime import datetime
import threading
import pandas as pd
import streamlit as st
import yaml
import plotly.graph_objs as go

from el_bot_de_efra import ejecutar_bot, ESTADO_BOT
from admin_dashboard import mostrar_admin_panel
from utils.comun import USUARIOS_CSV, enviar_clave_por_correo
from utils.modelo import leer_activos_por_categoria, validar_y_clasificar_simbolos

# 📌 Constantes
LOG_ERRORES = "logs/errores_login.csv"
MAX_INTENTOS = 3
TIEMPO_BLOQUEO = 60
INTENTOS_FALLIDOS = {}

# ✅ Idioma por defecto
DEFAULT_LANG = "Español"

# ✅ Traducciones para la interfaz
IDIOMAS = {
    "Español": {
        "titulo": "🔐 Acceso al Bot de Efra",
        "usuario": "🪪 Cédula (usuario)",
        "clave": "🔑 Clave de acceso",
        "recuperar": "¿Olvidaste tu contraseña?",
        "ingresar": "🚪 Ingresar",
        "bienvenida": "👋 Bienvenido, ¿quieres iniciar un nuevo análisis?",
        "usuario_txt": "👤 Usuario",
        "iniciar_bot": "🚀 Iniciar Bot",
        "detener_bot": "⛔ Detener Bot",
        "selecciona_idioma": "🌍 Selecciona tu idioma",
        "estado_bot": "📈 Estado actual del bot",
        "activo": "🟢 Activo",
        "inactivo": "🔴 Inactivo",
        "ultimo_simbolo": "Último símbolo analizado",
        "precision": "🔍 Precisión estimada",
        "ultimos_simbolos": "📌 Últimos símbolos analizados:",
        "senales": "📊 Señales detectadas:",
        "compra": "🟢 Compra",
        "venta": "🔴 Venta",
        "neutral": "⚪ Neutral",
        "grafico_actualiza": "🔄 El gráfico se actualiza automáticamente cada 30 segundos.",
        "error_login": "❌ Usuario o clave incorrectos",
        "sin_historial": "Aún no hay historial disponible.",
        "no_estado": "⚠️ No se pudo obtener el estado del bot:",
        "ultima_ejecucion": "🕒 Última ejecución:",
        "panel": "📊 Panel de Usuario",
        "configuracion": "⚙️ Configuración del análisis",
        "categoria_actual": "📂 Categoría actual:",
        "seleccion_activos": "Selecciona los activos a analizar",
        "activos_seleccionados": "📈 Activos seleccionados",
        "error_activos": "❌ Error cargando activos",
        "advertencia_activos": "⚠️ Selecciona al menos un activo para iniciar el bot.",
        "grafico_error": "⚠️ No hay datos para mostrar. Asegúrate de tener el archivo csv/ultimo_df.csv.",
        "bot_iniciado": "✅ Bot iniciado con activos seleccionados.",
        "bot_detenido": "🛑 Bot detenido manualmente.",
        "redirigiendo": "✅ Acceso concedido. Redirigiendo...",
        "demasiados_intentos": "🚨 Demasiados intentos fallidos. Intenta más tarde.",
        "espera_segundos": "⏳ Espera",
        "intervalo_analisis": "⏱️ Intervalo de análisis",
        "debes_elegir_intervalo": "⚠️ Debes seleccionar un intervalo de tiempo."
    },
    "English": {
        "titulo": "🔐 Bot Access",
        "usuario": "🪪 ID (User)",
        "clave": "🔑 Password",
        "recuperar": "Forgot your password?",
        "ingresar": "🚪 Login",
        "bienvenida": "👋 Welcome, ready to start a new analysis?",
        "usuario_txt": "👤 User",
        "iniciar_bot": "🚀 Start Bot",
        "detener_bot": "⛔ Stop Bot",
        "selecciona_idioma": "🌍 Select your language",
        "estado_bot": "📈 Bot status",
        "activo": "🟢 Active",
        "inactivo": "🔴 Inactive",
        "ultimo_simbolo": "Last analyzed symbol",
        "precision": "🔍 Estimated accuracy",
        "ultimos_simbolos": "📌 Recent symbols analyzed:",
        "senales": "📊 Signals detected:",
        "compra": "🟢 Buy",
        "venta": "🔴 Sell",
        "neutral": "⚪ Neutral",
        "grafico_actualiza": "🔄 The chart updates automatically every 30 seconds.",
        "error_login": "❌ Invalid username or password",
        "sin_historial": "No history available yet.",
        "no_estado": "⚠️ Could not get bot status:",
        "ultima_ejecucion": "🕒 Last run:",
        "panel": "📊 User Panel",
        "configuracion": "⚙️ Analysis configuration",
        "categoria_actual": "📂 Current category:",
        "seleccion_activos": "Select assets to analyze",
        "activos_seleccionados": "📈 Selected assets",
        "error_activos": "❌ Error loading assets",
        "advertencia_activos": "⚠️ Select at least one asset to start the bot.",
        "grafico_error": "⚠️ No data to show. Make sure csv/ultimo_df.csv exists.",
        "bot_iniciado": "✅ Bot started with selected assets.",
        "bot_detenido": "🛑 Bot stopped manually.",
        "redirigiendo": "✅ Access granted. Redirecting...",
        "demasiados_intentos": "🚨 Too many failed attempts. Try again later.",
        "espera_segundos": "⏳ Wait",
        "intervalo_analisis": "⏱️ Analysis interval",
        "debes_elegir_intervalo": "⚠️ You must select an analysis interval."
    },
    "Deutsch": {
        "titulo": "🔐 Zugriff auf den Bot",
        "usuario": "🪪 Benutzer-ID",
        "clave": "🔑 Passwort",
        "recuperar": "Passwort vergessen?",
        "ingresar": "🚪 Einloggen",
        "bienvenida": "👋 Willkommen, möchten Sie eine neue Analyse starten?",
        "usuario_txt": "👤 Benutzer",
        "iniciar_bot": "🚀 Bot starten",
        "detener_bot": "⛔ Bot stoppen",
        "selecciona_idioma": "🌍 Sprache auswählen",
        "estado_bot": "📈 Bot-Status",
        "activo": "🟢 Aktiv",
        "inactivo": "🔴 Inaktiv",
        "ultimo_simbolo": "Letztes analysiertes Symbol",
        "precision": "🔍 Geschätzte Genauigkeit",
        "ultimos_simbolos": "📌 Zuletzt analysierte Symbole:",
        "senales": "📊 Erkannte Signale:",
        "compra": "🟢 Kauf",
        "venta": "🔴 Verkauf",
        "neutral": "⚪ Neutral",
        "grafico_actualiza": "🔄 Das Diagramm wird alle 30 Sekunden automatisch aktualisiert.",
        "error_login": "❌ Ungültiger Benutzername oder Passwort",
        "sin_historial": "Noch keine Historie verfügbar.",
        "no_estado": "⚠️ Bot-Status konnte nicht abgerufen werden:",
        "ultima_ejecucion": "🕒 Letzte Ausführung:",
        "panel": "📊 Benutzer-Panel",
        "configuracion": "⚙️ Analysekonfiguration",
        "categoria_actual": "📂 Aktuelle Kategorie:",
        "seleccion_activos": "Wählen Sie Vermögenswerte zur Analyse",
        "activos_seleccionados": "📈 Ausgewählte Vermögenswerte",
        "error_activos": "❌ Fehler beim Laden der Vermögenswerte",
        "advertencia_activos": "⚠️ Bitte wählen Sie mindestens ein Asset aus.",
        "grafico_error": "⚠️ Keine Daten verfügbar. Stellen Sie sicher, dass csv/ultimo_df.csv existiert.",
        "bot_iniciado": "✅ Bot mit ausgewählten Assets gestartet.",
        "bot_detenido": "🛑 Bot manuell gestoppt.",
        "redirigiendo": "✅ Zugriff gewährt. Weiterleitung...",
        "demasiados_intentos": "🚨 Zu viele Fehlversuche. Bitte später erneut versuchen.",
        "espera_segundos": "⏳ Warten",
        "intervalo_analisis": "⏱️ Analyseintervall",
        "debes_elegir_intervalo": "⚠️ Bitte wählen Sie ein Analyseintervall."
    },
    "中文": {
        "titulo": "🔐 访问Efra机器人",
        "usuario": "🪪 用户ID",
        "clave": "🔑 密码",
        "recuperar": "忘记密码？",
        "ingresar": "🚪 登录",
        "bienvenida": "👋 欢迎，准备开始新的分析吗？",
        "usuario_txt": "👤 用户",
        "iniciar_bot": "🚀 启动机器人",
        "detener_bot": "⛔ 停止机器人",
        "selecciona_idioma": "🌍 选择你的语言",
        "estado_bot": "📈 机器人状态",
        "activo": "🟢 活跃",
        "inactivo": "🔴 不活跃",
        "ultimo_simbolo": "最近分析的符号",
        "precision": "🔍 估算准确率",
        "ultimos_simbolos": "📌 最近分析的符号：",
        "senales": "📊 发现的信号：",
        "compra": "🟢 买入",
        "venta": "🔴 卖出",
        "neutral": "⚪ 中性",
        "grafico_actualiza": "🔄 图表每30秒自动更新。",
        "error_login": "❌ 用户名或密码无效",
        "sin_historial": "暂无历史记录。",
        "no_estado": "⚠️ 无法获取机器人状态：",
        "ultima_ejecucion": "🕒 上次执行时间：",
        "panel": "📊 用户面板",
        "configuracion": "⚙️ 分析配置",
        "categoria_actual": "📂 当前类别：",
        "seleccion_activos": "选择要分析的资产",
        "activos_seleccionados": "📈 已选择的资产",
        "error_activos": "❌ 加载资产时出错",
        "advertencia_activos": "⚠️ 至少选择一个资产以启动机器人。",
        "grafico_error": "⚠️ 没有数据可显示。确保 csv/ultimo_df.csv 存在。",
        "bot_iniciado": "✅ 已使用选定资产启动机器人。",
        "bot_detenido": "🛑 已手动停止机器人。",
        "redirigiendo": "✅ 登录成功，正在跳转…",
        "demasiados_intentos": "🚨 登录失败次数过多，请稍后再试。",
        "espera_segundos": "⏳ 等待",
        "intervalo_analisis": "⏱️ 分析时间间隔",
        "debes_elegir_intervalo": "⚠️ 请选择分析时间间隔。"
    },
    "Português": {
        "titulo": "🔐 Acesso ao Bot do Efra",
        "usuario": "🪪 CPF (usuário)",
        "clave": "🔑 Senha",
        "recuperar": "Esqueceu sua senha?",
        "ingresar": "🚪 Entrar",
        "bienvenida": "👋 Bem-vindo, pronto para iniciar uma nova análise?",
        "usuario_txt": "👤 Usuário",
        "iniciar_bot": "🚀 Iniciar Bot",
        "detener_bot": "⛔ Parar Bot",
        "selecciona_idioma": "🌍 Selecione seu idioma",
        "estado_bot": "📈 Status do Bot",
        "activo": "🟢 Ativo",
        "inactivo": "🔴 Inativo",
        "ultimo_simbolo": "Último símbolo analisado",
        "precision": "🔍 Precisão estimada",
        "ultimos_simbolos": "📌 Últimos símbolos analisados:",
        "senales": "📊 Sinais detectados:",
        "compra": "🟢 Compra",
        "venta": "🔴 Venda",
        "neutral": "⚪ Neutro",
        "grafico_actualiza": "🔄 O gráfico é atualizado automaticamente a cada 30 segundos.",
        "error_login": "❌ Usuário ou senha inválidos",
        "sin_historial": "Nenhum histórico disponível ainda.",
        "no_estado": "⚠️ Não foi possível obter o status do bot:",
        "ultima_ejecucion": "🕒 Última execução:",
        "panel": "📊 Painel do Usuário",
        "configuracion": "⚙️ Configuração da análise",
        "categoria_actual": "📂 Categoria atual:",
        "seleccion_activos": "Selecione os ativos para analisar",
        "activos_seleccionados": "📈 Ativos selecionados",
        "error_activos": "❌ Erro ao carregar os ativos",
        "advertencia_activos": "⚠️ Selecione pelo menos um ativo para iniciar o bot.",
        "grafico_error": "⚠️ Nenhum dado para exibir. Verifique se csv/ultimo_df.csv existe.",
        "bot_iniciado": "✅ Bot iniciado com ativos selecionados.",
        "bot_detenido": "🛑 Bot parado manualmente.",
        "redirigiendo": "✅ Acesso concedido. Redirecionando...",
        "demasiados_intentos": "🚨 Muitas tentativas falhas. Tente novamente mais tarde.",
        "espera_segundos": "⏳ Aguarde",
        "intervalo_analisis": "⏱️ Intervalo de análise",
        "debes_elegir_intervalo": "⚠️ Você deve selecionar um intervalo de análise."
    }
}

# Inicialización segura de session_state
for key, default in {
    "autenticado": False,
    "usuario": "",
    "nombre": "",
    "symbols_seleccionados": [],
    "intervalo_analisis": "",
    "bot_thread": None,
    "stop_event": threading.Event(),
    "idioma": DEFAULT_LANG,
    "lang": DEFAULT_LANG,
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

# Generar clave aleatoria
def generar_clave(longitud=8):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=longitud))

@st.cache_data(ttl=300)
def cargar_usuarios():
    if not os.path.exists(USUARIOS_CSV):
        df = pd.DataFrame([{
            'usuario': '8642239',
            'clave': 'dasb1512',
            'correo': 'efraneo@gmail.com',
            'nombre': 'Efraín Sarmiento Crespo',
            'es_admin': True
        }])
        df.to_csv(USUARIOS_CSV, index=False)
    else:
        df = pd.read_csv(USUARIOS_CSV)
        df.columns = df.columns.str.strip().str.lower()
    return df

def registrar_error(usuario):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    os.makedirs("logs", exist_ok=True)
    with open(LOG_ERRORES, 'a') as f:
        f.write(f"{now},{usuario}\n")

def recuperar_clave():
    st.subheader("📬 Recuperar contraseña")
    usuario = st.text_input("🪪 Ingresa tu cédula")
    correo = st.text_input("📧 Correo asociado")

    if st.button("📨 Enviar nueva clave"):
        if not usuario.strip().isdigit():
            st.error("❌ La cédula debe contener solo números.")
            return
        if "@" not in correo or "." not in correo:
            st.error("❌ Correo electrónico no válido.")
            return

        try:
            usuarios = cargar_usuarios()
            fila = usuarios[usuarios['usuario'].astype(str) == usuario]

            if not fila.empty and fila.iloc[0]['correo'].strip().lower() == correo.strip().lower():
                nueva_clave = generar_clave()
                usuarios.loc[usuarios['usuario'].astype(str) == usuario, 'clave'] = nueva_clave
                usuarios.to_csv(USUARIOS_CSV, index=False)
                if enviar_clave_por_correo(correo, nueva_clave):
                    st.success("✅ Clave enviada al correo registrado.")
                else:
                    st.error("❌ Error al enviar el correo.")
            else:
                st.error("❌ Usuario o correo no encontrados.")
        except Exception as e:
            st.error(f"❌ Ocurrió un error inesperado: {e}")

def login(T):
    st.title(T["titulo"])
    modo_recuperacion = st.checkbox(T["recuperar"])
    if modo_recuperacion:
        recuperar_clave()
        return

    usuarios = cargar_usuarios()
    usuario = st.text_input(T["usuario"])
    clave = st.text_input(T["clave"], type="password")

    if usuario in INTENTOS_FALLIDOS and INTENTOS_FALLIDOS[usuario]['bloqueado']:
        tiempo_transcurrido = time.time() - INTENTOS_FALLIDOS[usuario]['timestamp']
        if tiempo_transcurrido < TIEMPO_BLOQUEO:
            st.error(f"{T['espera_segundos']} {int(TIEMPO_BLOQUEO - tiempo_transcurrido)} segundos.")
            st.stop()
        else:
            INTENTOS_FALLIDOS[usuario] = {'intentos': 0, 'bloqueado': False}

    if st.button(T["ingresar"]):
        fila = usuarios[usuarios['usuario'].astype(str) == usuario]
        if not fila.empty and str(fila.iloc[0]['clave']) == clave:
            st.session_state["autenticado"] = True
            st.session_state["usuario"] = usuario
            st.session_state["nombre"] = fila.iloc[0]['nombre']
            st.success(T["redirigiendo"])
            st.rerun()
        else:
            st.error(T["error_login"])
            registrar_error(usuario)
            if usuario not in INTENTOS_FALLIDOS:
                INTENTOS_FALLIDOS[usuario] = {'intentos': 1, 'bloqueado': False, 'timestamp': time.time()}
            else:
                INTENTOS_FALLIDOS[usuario]['intentos'] += 1
            if INTENTOS_FALLIDOS[usuario]['intentos'] >= MAX_INTENTOS:
                INTENTOS_FALLIDOS[usuario]['bloqueado'] = True
                INTENTOS_FALLIDOS[usuario]['timestamp'] = time.time()
                st.error(T["demasiados_intentos"])
                st.stop()

def interfaz_usuario(T):
    if st.button("🔒 Cerrar sesión"):
        for key in ["autenticado", "usuario", "nombre", "symbols_seleccionados", "intervalo_analisis"]:
            if key in st.session_state:
                del st.session_state[key]
        st.rerun()

    st.title(T["panel"])

    nombre = st.session_state.get("nombre", st.session_state.get("usuario"))
    st.success(f"{T['usuario_txt']}: {nombre}")
    st.markdown(T["bienvenida"])

    # Panel de administrador si aplica
    usuarios = cargar_usuarios()
    fila = usuarios[usuarios['usuario'].astype(str) == str(st.session_state.get("usuario", ""))]
    if not fila.empty and fila.iloc[0].get("es_admin", False):
        mostrar_admin_panel()

    # Estado del bot
    try:
        st.subheader(T["estado_bot"])
        col1, col2 = st.columns(2)

        with col1:
            estado = f"🟢 {T['activo']}" if ESTADO_BOT.get("activo") else f"🔴 {T['inactivo']}"
            st.metric(label=T["estado_bot"], value=estado)
            st.metric(label=T["ultimo_simbolo"], value=ESTADO_BOT.get("ultimo_simbolo", "—"))

        with col2:
            st.metric(label=T["precision"], value=f"{ESTADO_BOT.get('precision_estimacion', 0)*100:.2f}%")

        st.markdown(f"#### {T['ultimos_simbolos']}")
        historial = list(ESTADO_BOT.get("historial", []))
        if historial:
            for i, item in enumerate(historial[::-1], 1):
                st.write(f"{i}. {item}")
        else:
            st.info(T["sin_historial"])

        st.markdown(f"#### {T['senales']}")
        señales = ESTADO_BOT.get("señales", {})
        st.write(f"🟢 {T['compra']}: {señales.get('compra', 0)}")
        st.write(f"🔴 {T['venta']}: {señales.get('venta', 0)}")
        st.write(f"⚪ {T['neutral']}: {señales.get('neutral', 0)}")
    except Exception as e:
        st.warning(f"{T['no_estado']} {e}")

    # Configuración del análisis
    with st.expander(T["configuracion"], expanded=False):
        try:
            activos_df = pd.read_csv("activos.csv")
            activos_df.columns = activos_df.columns.str.strip().str.lower()
            columna_simbolo = next((col for col in activos_df.columns if col in ["symbol", "simbolo"]), None)
            if not columna_simbolo:
                raise ValueError("No se encontró una columna válida para los símbolos.")

            lista_activos = activos_df[columna_simbolo].dropna().unique().tolist()

            seleccion_previa = st.session_state.get("symbols_seleccionados", [])
            if isinstance(seleccion_previa, str):
                seleccion_previa = [seleccion_previa]
            elif not isinstance(seleccion_previa, list):
                seleccion_previa = []

            seleccion = st.multiselect(
                T["seleccion_activos"],
                lista_activos,
                default=seleccion_previa,
                key="activos_key"
            )

            st.session_state.symbols_seleccionados = seleccion if seleccion else []

            intervalos = ['1m', '3m', '5m', '15m', '30m', '1h', '3h', '8h', '1d']
            intervalo_anterior = st.session_state.get("intervalo_analisis", "")
            try:
                selected_index = intervalos.index(intervalo_anterior) if intervalo_anterior in intervalos else 0
            except Exception:
                selected_index = 0

            intervalo = st.selectbox(
                T["intervalo_analisis"],
                intervalos,
                index=selected_index,
                key="intervalo_key"
            )
            st.session_state.intervalo_analisis = intervalo

        except Exception as e:
            st.error(f"{T['error_activos']}: {e}")

        symbols = st.session_state.get("symbols_seleccionados", [])
        if isinstance(symbols, str):
            symbols = [symbols]
        elif not isinstance(symbols, list):
            symbols = []
        st.session_state.symbols_seleccionados = symbols

        intervalo = st.session_state.get("intervalo_analisis", "")
        symbols_ok = len(symbols) > 0
        intervalo_ok = isinstance(intervalo, str) and intervalo.strip() != ""

        if not symbols_ok or not intervalo_ok:
            st.warning(T["advertencia_activos"] + " " + T["debes_elegir_intervalo"])

    # ================= BOTONES DE CONTROL ====================
    col1, col2 = st.columns(2)

    with col1:
        thread_alive = st.session_state.get("bot_thread")
        thread_running = thread_alive.is_alive() if thread_alive else False

        iniciar_disabled = not (symbols_ok and intervalo_ok) or thread_running

        iniciar = st.button(
            T["iniciar_bot"],
            type="primary",
            disabled=iniciar_disabled
        )

        if iniciar:
            st.session_state.stop_event.clear()
            st.session_state.bot_thread = threading.Thread(
                target=ejecutar_bot,
                args=(st.session_state.stop_event, st.session_state.symbols_seleccionados),
                daemon=True
            )
            st.session_state.bot_thread.start()
            st.success(T["bot_iniciado"])

    with col2:
        detener_disabled = not (
            st.session_state.get("bot_thread") and
            st.session_state["bot_thread"].is_alive()
        )

        detener = st.button(
            T["detener_bot"],
            disabled=detener_disabled
        )

        if detener:
            st.session_state.stop_event.set()
            st.session_state.bot_thread.join()
            st.session_state.bot_thread = None
            st.success(T["bot_detenido"])

            opcion = st.radio("¿Qué quieres hacer ahora?", ["🔁 Nuevo análisis", "🔒 Cerrar sesión"])
            if opcion == "🔁 Nuevo análisis":
                st.info("Puedes modificar tus activos e intervalos para iniciar nuevamente.")
            elif opcion == "🔒 Cerrar sesión":
                st.session_state.clear()
                st.success("Sesión cerrada exitosamente. Volviendo a inicio de sesión...")
                st.rerun()

    # =========== GRAFICO EN TIEMPO REAL ============
    if st.session_state.get("bot_thread") and st.session_state["bot_thread"].is_alive():
        st.subheader("📊 Gráfico en tiempo real del activo seleccionado")

        @st.cache_data(ttl=30)
        def cargar_datos_grafico():
            try:
                df = pd.read_csv("csv/ultimo_df.csv", parse_dates=["fecha"])
                return df
            except Exception:
                return pd.DataFrame()

        def graficar(df):
            fig = go.Figure()
            fig.add_trace(go.Candlestick(
                x=df["fecha"],
                open=df["open"],
                high=df["high"],
                low=df["low"],
                close=df["close"],
                name="Velas"
            ))
            df_signales = df[df["señal"].notna()]
            for _, fila in df_signales.iterrows():
                fig.add_trace(go.Scatter(
                    x=[fila["fecha"]],
                    y=[fila["close"]],
                    mode="markers+text",
                    marker=dict(color="green" if fila["señal"] == "buy" else "red", size=12),
                    text=["🔼" if fila["señal"] == "buy" else "🔽"],
                    textposition="top center"
                ))
            fig.update_layout(template="plotly_dark", height=500)
            return fig

        df_ult = cargar_datos_grafico()
        if df_ult.empty:
            st.warning(T["grafico_error"])
        else:
            st.plotly_chart(graficar(df_ult), use_container_width=True)
            st.caption(T["grafico_actualiza"])

    # Mostrar categoría y activos
    try:
        with open("config.yaml", 'r') as f:
            config = yaml.safe_load(f)
        categoria = config.get("categoria", "No definida")
        activos = leer_activos_por_categoria().get(categoria, [])
        activos_validos, _, _ = validar_y_clasificar_simbolos(activos)
        st.write(f"{T['categoria_actual']} {categoria}")
        st.code(", ".join(activos_validos))
    except Exception as e:
        st.warning(f"{T['no_estado']} {e}")


# ============================ FUNCIÓN PRINCIPAL ============================
def main():
# Protección global de valores críticos
    st.session_state.setdefault("symbols_seleccionados", [])
    st.session_state.setdefault("intervalo_analisis", "")

    idioma_actual = st.session_state.get("idioma", DEFAULT_LANG)
    T = IDIOMAS.get(idioma_actual, IDIOMAS[DEFAULT_LANG])

    st.set_page_config(page_title="El Bot de Efra", page_icon="🤖")

    # Inicializar idioma en sesión
    if "idioma" not in st.session_state:
        st.session_state["idioma"] = DEFAULT_LANG
    if "lang" not in st.session_state:
        st.session_state["lang"] = st.session_state["idioma"]

    # Inicialización segura del session_state
    if "symbols_seleccionados" not in st.session_state or not isinstance(st.session_state.symbols_seleccionados, list):
        st.session_state.symbols_seleccionados = []

    if "intervalo_analisis" not in st.session_state or not isinstance(st.session_state.intervalo_analisis, str):
        st.session_state.intervalo_analisis = ""

    # Mostrar selector de idioma y login si no está autenticado
    if not st.session_state.get("autenticado", False):
        idioma_actual = st.session_state["idioma"]
        idioma_seleccionado = st.selectbox(
            IDIOMAS[idioma_actual]["selecciona_idioma"],
            list(IDIOMAS.keys()),
            index=list(IDIOMAS.keys()).index(idioma_actual),
            key="idioma_selector_global"
        )

        if idioma_seleccionado != idioma_actual:
            st.session_state["idioma"] = idioma_seleccionado
            st.session_state["lang"] = idioma_seleccionado
            st.rerun()

        login(IDIOMAS[st.session_state["idioma"]])
        return  # <- Muy importante para que no siga con el panel

    # Si está autenticado, mostrar la interfaz principal
    interfaz_usuario(IDIOMAS[st.session_state["idioma"]])

# ============================ EJECUCIÓN ============================
if __name__ == "__main__":
    main()
