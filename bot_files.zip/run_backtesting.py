from utils.modelo import leer_activos_por_categoria, validar_y_clasificar_simbolos
from utils.backtesting import realizar_backtesting
from main import obtener_datos, agregar_indicadores_tecnicos, INTERVALO, MERCADO_SYMBOLS

def correr_backtesting_simbolos(simbolos):
    for simbolo in simbolos:
        print(f"Ejecutando backtesting para {simbolo}...")
        df = obtener_datos(simbolo, MERCADO_SYMBOLS[simbolo], intervalo=INTERVALO, periodo='30d')
        if df is not None:
            df = agregar_indicadores_tecnicos(df)
            realizar_backtesting(df, simbolo)
        else:
            print(f"No se pudieron obtener datos para {simbolo}")

if __name__ == "__main__":
    categorias = leer_activos_por_categoria()
    SYMBOLS_VALIDOS, MERCADO_SYMBOLS, _ = validar_y_clasificar_simbolos(categorias["cripto"])
    correr_backtesting_simbolos(SYMBOLS_VALIDOS)