import sqlite3

DB_NAME = "resultados_bot.db"

def crear_tabla_si_no_existe():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS historial (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        activo TEXT,
        mercado TEXT,
        precision REAL,
        ia_prediccion TEXT,
        conclusion TEXT,
        precio_actual REAL,
        soporte REAL,
        resistencia REAL,
        rsi REAL,
        macd_signal REAL,
        tendencia TEXT,
        volumen_fuerte INTEGER,
        sl REAL,
        tp1 REAL,
        tp2 REAL,
        tp3 REAL,
        tp4 REAL
    )''')
    conn.commit()
    conn.close()

def guardar_en_base_datos(data):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''INSERT INTO historial (
        fecha, activo, mercado, precision, ia_prediccion, conclusion,
        precio_actual, soporte, resistencia, rsi, macd_signal,
        tendencia, volumen_fuerte, sl, tp1, tp2, tp3, tp4
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
    (data['fecha'], data['activo'], data['mercado'], data['precision'],
     data['ia_prediccion'], data['conclusion'], data['precio_actual'],
     data['soporte'], data['resistencia'], data['rsi'], data['macd_signal'],
     data['tendencia'], int(data['volumen_fuerte']), data['sl'], data['tp1'],
     data['tp2'], data['tp3'], data['tp4']))
    conn.commit()
    conn.close()