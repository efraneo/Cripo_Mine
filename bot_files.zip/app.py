import streamlit as st
import yaml
import os

CONFIG_FILE = "config.yaml"

st.set_page_config(page_title="Bot de Trading", layout="centered")
st.title("🤖 Configuración del Bot de Trading")

# Cargar configuración
def cargar_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f)
    return {}

config = cargar_config()

categoria = st.selectbox("Selecciona categoría", ["cripto", "acciones", "forex"], index=0)
timeframe = st.selectbox("Selecciona timeframe", ["1h", "4h", "1d"], index=0)
backtesting = st.checkbox("¿Ejecutar backtesting?", value=True)
alertas = st.checkbox("¿Enviar alertas por Telegram?", value=True)
symbols = st.text_area("Símbolos personalizados (separados por coma)", value="BTCUSDT,ETHUSDT")

if st.button("Guardar configuración"):
    nueva_config = {
        "categoria": categoria,
        "timeframe": timeframe,
        "backtesting": backtesting,
        "telegram_alertas": alertas,
        "symbols_custom": [s.strip() for s in symbols.split(",") if s.strip()]
    }
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(nueva_config, f)
    st.success("✅ Configuración guardada con éxito.")