"""
Doctor Command
"""

import platform
import sys


def run():

    return {

        "python": sys.version,

        "platform": platform.platform(),

        "status": "healthy",

    }
