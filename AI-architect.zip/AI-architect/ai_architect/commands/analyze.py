"""
=========================================================
Analyze Command
=========================================================
"""

from pathlib import Path


def run(project: str) -> dict:

    project = Path(project).resolve()

    files = list(project.rglob("*.py"))

    return {

        "success": True,

        "project": str(project),

        "python_files": len(files),

        "files": [

            str(f.relative_to(project))

            for f in files

        ],

    }
