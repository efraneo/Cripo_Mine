"""
Review Command
"""

def run(project: str):

    return {

        "success": True,

        "message": "Review command coming soon.",

        "project": project,

    }
