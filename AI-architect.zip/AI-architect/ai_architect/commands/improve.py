"""
Improve Command
"""

def run(

    project: str,

    instruction: str,

    file: str | None = None,

):

    return {

        "success": True,

        "project": project,

        "file": file,

        "instruction": instruction,

    }
