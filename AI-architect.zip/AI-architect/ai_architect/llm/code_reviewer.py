"""
=========================================================
Code Reviewer
=========================================================
"""

from __future__ import annotations

from .openai_client import OpenAIClient
from .prompt_library import PromptLibrary


class CodeReviewer:

    def __init__(self):

        self.client = OpenAIClient()

        self.prompts = PromptLibrary()

    def review(

        self,

        source: str,

    ) -> str:

        return self.client.ask(

            prompt=source,

            system=self.prompts.review(),

        )
