"""
=========================================================
Repository Context

Builds the context sent to the LLM.
=========================================================
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable


class RepositoryContext:
    """
    Construye el contexto que recibirá el LLM.

    El objetivo es entregar únicamente la información
    necesaria para modificar un archivo sin enviar todo
    el repositorio.
    """

    def __init__(self) -> None:

        self.max_file_size = 20_000

    def build(
        self,
        repository: str | Path,
        files: Iterable[str],
    ) -> dict:

        root = Path(repository).resolve()

        context = {
            "repository": str(root),
            "files": [],
        }

        for relative in files:

            target = root / relative

            if not target.exists():

                continue

            context["files"].append(
                {
                    "path": relative,
                    "source": self._read_file(
                        target,
                    ),
                }
            )

        return context

    def build_prompt(
        self,
        repository: str | Path,
        files: Iterable[str],
    ) -> str:
        """
        Convierte el contexto en texto para el prompt.
        """

        context = self.build(
            repository,
            files,
        )

        sections = []

        for item in context["files"]:

            sections.append(
                "\n".join(
                    [
                        "=" * 70,
                        f"FILE: {item['path']}",
                        "=" * 70,
                        item["source"],
                    ]
                )
            )

        return "\n\n".join(sections)

    def _read_file(
        self,
        path: Path,
    ) -> str:

        source = path.read_text(
            encoding="utf-8",
            errors="ignore",
        )

        if len(source) <= self.max_file_size:

            return source

        return (
            source[: self.max_file_size]
            + "\n\n# ... FILE TRUNCATED ..."
        )
