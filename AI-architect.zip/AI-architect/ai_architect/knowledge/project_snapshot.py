ProjectSnapshot(

    total_files=318,

    total_lines=48763,

    python_files=271,

    duplicated_models=1,

    duplicated_services=0,

    oversized_files=2,

    architecture_score=97.4,

    generated_at=...
)
