"""
=========================================================
Architecture Graph
=========================================================
"""

from __future__ import annotations

from pathlib import Path


class ArchitectureGraph:

    def build(

        self,

        project: str,

    ) -> dict:

        folders = {}

        project = Path(project)

        for directory in project.rglob("*"):

            if directory.is_dir():

                folders[

                    str(directory)

                ] = len(

                    list(

                        directory.glob("*")

                    )

                )

        return folders
