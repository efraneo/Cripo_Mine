"""
=========================================================
Project Memory

Persistent Project Knowledge
=========================================================
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class ProjectMemory:
    """
    Persistent project memory.

    Stores architectural knowledge, execution history,
    metrics and learned information between executions.
    """

    def __init__(

        self,

        storage: str = ".quant",

    ) -> None:

        self.root = Path(storage)

        self.root.mkdir(

            parents=True,

            exist_ok=True,

        )

        self.memory_file = (

            self.root /

            "project_memory.json"

        )

    def load(

        self,

    ) -> dict[str, Any]:

        if not self.memory_file.exists():

            return {

                "created": datetime.utcnow().isoformat(),

                "projects": {},

            }

        try:

            return json.loads(

                self.memory_file.read_text(

                    encoding="utf-8",

                )

            )

        except Exception:

            return {

                "created": datetime.utcnow().isoformat(),

                "projects": {},

            }

    def save(

        self,

        knowledge: dict[str, Any],

    ) -> None:

        data = self.load()

        data["knowledge"] = knowledge

        data["updated"] = (

            datetime.utcnow().isoformat()

        )

        self.memory_file.write_text(

            json.dumps(

                data,

                indent=4,

                ensure_ascii=False,

            ),

            encoding="utf-8",

        )

    def update_project(

        self,

        project: str,

        information: dict[str, Any],

    ) -> None:

        data = self.load()

        projects = data.setdefault(

            "projects",

            {},

        )

        current = projects.setdefault(

            project,

            {},

        )

        current.update(

            information,

        )

        current["updated"] = (

            datetime.utcnow().isoformat()

        )

        self.memory_file.write_text(

            json.dumps(

                data,

                indent=4,

                ensure_ascii=False,

            ),

            encoding="utf-8",

        )

    def project(

        self,

        project: str,

    ) -> dict[str, Any]:

        return self.load().get(

            "projects",

            {},

        ).get(

            project,

            {},

        )

    def knowledge(

        self,

    ) -> dict[str, Any]:

        return self.load().get(

            "knowledge",

            {},

        )

    def clear(

        self,

    ) -> None:

        if self.memory_file.exists():

            self.memory_file.unlink()

    def statistics(

        self,

    ) -> dict[str, Any]:

        data = self.load()

        return {

            "projects": len(

                data.get(

                    "projects",

                    {},

                )

            ),

            "has_knowledge": (

                "knowledge" in data

            ),

            "updated": data.get(

                "updated",

            ),

        }
