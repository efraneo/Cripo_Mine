"""
=========================================================
File Graph
=========================================================
"""

from __future__ import annotations

from pathlib import Path


class FileGraph:

    def build(

        self,

        project: str,

    ) -> dict:

        graph = {}

        project = Path(project)

        for file in project.rglob("*.py"):

            graph[str(file)] = {

                "size": file.stat().st_size,

                "folder": str(

                    file.parent

                ),

            }

        return graph
