"""
=========================================================
Workspace Loader

Construye un snapshot completo del proyecto.
=========================================================
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from ai_architect.filesystem.file_hash import FileHash
from ai_architect.filesystem.project_walker import ProjectWalker

from .models import (
    WorkspaceFile,
    WorkspaceSnapshot,
)


LANGUAGE_MAP = {
    ".py": "python",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".txt": "text",
}


class WorkspaceLoader:

    def __init__(self):

        self.walker = ProjectWalker()

        self.hasher = FileHash()

    def load(
        self,
        root: str | Path,
    ) -> WorkspaceSnapshot:

        root = Path(root)

        snapshot = WorkspaceSnapshot(
            root=str(root),
            created_at=datetime.utcnow(),
        )

        for file_path in self.walker.walk(root):

            extension = file_path.suffix.lower()

            snapshot.files.append(

                WorkspaceFile(

                    path=str(file_path),

                    extension=extension,

                    language=LANGUAGE_MAP.get(
                        extension,
                        "unknown",
                    ),

                    sha256=self.hasher.sha256(
                        file_path
                    ),

                    size=file_path.stat().st_size,

                    modified=file_path.stat().st_mtime,

                )

            )

        return snapshot
