"""
=========================================================
Daily Summary
=========================================================
"""

from __future__ import annotations

from .report_formatter import ReportFormatter
from .telegram_notifier import TelegramNotifier


class DailySummary:

    def __init__(self):

        self.formatter = ReportFormatter()

        self.telegram = TelegramNotifier()

    def send(

        self,

        report: dict,

    ):

        message = self.formatter.format(

            report

        )

        return self.telegram.send(

            message

        )
