"""
=========================================================
Notifier Models
=========================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class NotificationLevel(str, Enum):

    INFO = "INFO"

    SUCCESS = "SUCCESS"

    WARNING = "WARNING"

    ERROR = "ERROR"


@dataclass(slots=True)
class Notification:

    title: str

    message: str

    level: NotificationLevel

    created_at: datetime = field(
        default_factory=datetime.utcnow
    )


@dataclass(slots=True)
class NotificationResult:

    success: bool

    provider: str

    response: str = ""
