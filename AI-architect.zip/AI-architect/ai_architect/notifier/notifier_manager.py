"""
=========================================================
Notifier Manager
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from .models import (
    Notification,
    NotificationResult,
)
from .telegram_notifier import (
    TelegramNotifier,
)


class NotifierManager:

    def __init__(
        self,
        telegram_env: str | Path,
    ) -> None:

        self.telegram = TelegramNotifier(
            telegram_env
        )

    def notify(
        self,
        title: str,
        message: str,
        level,
    ) -> NotificationResult:

        notification = Notification(

            title=title,

            message=message,

            level=level,

        )

        return self.telegram.send(
            notification
        )

    def success(
        self,
        title: str,
        message: str,
    ) -> NotificationResult:

        return self.notify(
            title,
            message,
            level="SUCCESS",
        )

    def error(
        self,
        title: str,
        message: str,
    ) -> NotificationResult:

        return self.notify(
            title,
            message,
            level="ERROR",
        )

    def info(

        self,

        title,

        message,

    ):

        return self.notify(

            title,

            message,

            NotificationLevel.INFO,

        )

    def warning(

        self,

        title,

        message,

    ):

        return self.notify(

            title,

            message,

            NotificationLevel.WARNING,

        )
