"""
=========================================================
QUANT AI ARCHITECT

Principal Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ai_architect.analyzer.project_analyzer import (
    ProjectAnalyzer,
)
from ai_architect.notifier.notifier_manager import (
    NotifierManager,
)
from ai_architect.planner.planner import (
    Planner,
)
from ai_architect.repository.repository_manager import (
    RepositoryManager,
)
from ai_architect.reviewer.code_reviewer import (
    CodeReviewer,
)
from ai_architect.test_runner.test_runner import (
    TestRunner,
)


class AIArchitect:
    """
    Core orchestration class.

    Coordina los componentes principales del AI Architect.
    """

    def __init__(
        self,
        project: str | Path,
        telegram_env: str | Path,
    ) -> None:

        self.project = Path(project).resolve()

        self.analyzer = ProjectAnalyzer()

        self.planner = Planner()

        self.reviewer = CodeReviewer()

        self.repository = RepositoryManager(
            self.project
        )

        self.tests = TestRunner()

        self.notifier = NotifierManager(
            telegram_env
        )

    def analyze(self) -> dict[str, Any]:

        return self.analyzer.analyze(
            self.project
        )

    def plan(self):

        analysis = self.analyze()

        return self.planner.build_plan(
            analysis
        )

    def run_tests(self):

        return self.tests.run(
            self.project
        )

    def review_file(
        self,
        file: str,
    ):

        target = self.project / file

        return self.reviewer.review(
            target
        )

    def repository_path(self) -> Path:

        return self.project
