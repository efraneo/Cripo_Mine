"""
=========================================================
Improvement Engine
=========================================================
"""

from __future__ import annotations

from ai_architect.analyzer.project_analyzer import (
    ProjectAnalyzer,
)


class ImprovementEngine:

    def __init__(self):

        self.analyzer = ProjectAnalyzer()

    def evaluate(
        self,
        project,
    ) -> list[dict]:

        report = self.analyzer.analyze(
            project
        )

        improvements = []

        if report["duplicate_groups"] > 0:

            improvements.append(

                {
                    "priority": "CRITICAL",
                    "title": "Remove duplicated code",
                    "module": "duplicate_detector",
                }

            )

        if report["average_complexity"] > 10:

            improvements.append(

                {
                    "priority": "HIGH",
                    "title": "Reduce complexity",
                    "module": "complexity",
                }

            )

        if report["total_files"] > 300:

            improvements.append(

                {
                    "priority": "MEDIUM",
                    "title": "Split project domains",
                    "module": "architecture",
                }

            )

        return improvements
