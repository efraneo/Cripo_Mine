"""
=========================================================
Execution Orchestrator

Execution Plan Coordinator
=========================================================
"""

from __future__ import annotations

from ai_architect.execution.execution_result import (
    ExecutionResult,
)

from ai_architect.execution.task_executor import (
    TaskExecutor,
)

from ai_architect.planner.models import (
    ExecutionPlan,
    PlannerTask,
    TaskStatus,
)


class ExecutionOrchestrator:
    """
    Executes complete execution plans.

    Responsibilities

        • Execute ExecutionPlan

        • Respect dependencies

        • Track progress

        • Aggregate results

        • Stop on critical failures

    This class coordinates TaskExecutor but
    never executes code directly.
    """

    ###############################################################

    def __init__(

        self,

        repository: str,

    ) -> None:

        self.executor = TaskExecutor(

            repository,

        )

    ###############################################################

    def execute_plan(

        self,

        plan: ExecutionPlan,

    ) -> list[ExecutionResult]:

        results: list[ExecutionResult] = []

        for task in plan.tasks:

            if not self._can_execute(

                task,

                plan,

            ):

                continue

            task.start()

            result = self.executor.execute(

                filename=task.metadata.get(

                    "file",

                    "",

                ),

                instruction=task.description,

            )

            if result.approved:

                task.complete(

                    result.decision_name,

                )

            else:

                task.fail(

                    result.decision_name,

                )

            results.append(

                result,

            )

            if (

                result.decision_name

                == "REJECT"

            ):

                break

        return results

    ###############################################################

    def _can_execute(

        self,

        task: PlannerTask,

        plan: ExecutionPlan,

    ) -> bool:

        completed = {

            item.id

            for item in plan.tasks

            if item.completed

        }

        return all(

            dependency in completed

            for dependency in task.dependencies

        )

    ###############################################################

    def summary(

        self,

        results: list[ExecutionResult],

    ) -> dict:

        return self.executor.batch_summary(

            results,

        )

    ###############################################################

    def health(

        self,

    ) -> dict:

        return self.executor.health()
