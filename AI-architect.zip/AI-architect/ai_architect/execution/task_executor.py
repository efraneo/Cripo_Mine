"""
=========================================================
Task Executor

High-Level Execution API
=========================================================
"""

from __future__ import annotations

from ai_architect.execution.execution_pipeline import (
    ExecutionPipeline,
)

from ai_architect.execution.execution_result import (
    ExecutionResult,
)


class TaskExecutor:
    """
    Public execution interface.

    Responsibilities

        • Execute one task

        • Execute multiple tasks

        • Retry failed executions

        • Generate execution summaries

    Used by

        • CLI

        • REST API

        • Multi-Agent System

        • Scheduler

        • Autonomous Planner
    """

    ##############################################################

    def __init__(

        self,

        repository: str,

    ) -> None:

        self.pipeline = ExecutionPipeline(

            repository,

        )

    ##############################################################

    def execute(

        self,

        filename: str,

        instruction: str,

    ) -> ExecutionResult:

        return self.pipeline.execute(

            filename,

            instruction,

        )

    ##############################################################

    def execute_many(

        self,

        tasks: list[dict],

    ) -> list[ExecutionResult]:

        results: list[ExecutionResult] = []

        for task in tasks:

            results.append(

                self.execute(

                    filename=task["file"],

                    instruction=task["instruction"],

                )

            )

        return results

    ##############################################################

    def execute_until_success(

        self,

        filename: str,

        instruction: str,

        retries: int = 3,

    ) -> ExecutionResult:

        result = self.execute(

            filename,

            instruction,

        )

        for _ in range(

            retries - 1,

        ):

            if result.approved:

                break

            if result.decision_name != "RETRY":

                break

            result = self.execute(

                filename,

                instruction,

            )

        return result

    ##############################################################

    def batch_summary(

        self,

        results: list[ExecutionResult],

    ) -> dict:

        summary = {

            "tasks": len(results),

            "approved": 0,

            "retry": 0,

            "manual_review": 0,

            "rejected": 0,

        }

        for result in results:

            decision = result.decision_name

            if decision == "ACCEPT":

                summary["approved"] += 1

            elif decision == "RETRY":

                summary["retry"] += 1

            elif decision == "MANUAL_REVIEW":

                summary["manual_review"] += 1

            else:

                summary["rejected"] += 1

        if results:

            summary["success_rate"] = round(

                summary["approved"]

                * 100

                / len(results),

                2,

            )

        else:

            summary["success_rate"] = 0.0

        return summary

    ##############################################################

    def health(

        self,

    ) -> dict:

        return self.pipeline.health()
