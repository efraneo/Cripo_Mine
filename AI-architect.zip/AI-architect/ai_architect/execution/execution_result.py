"""
=========================================================
Execution Result

Execution Pipeline Result Models
=========================================================
"""

from __future__ import annotations

from dataclasses import asdict
from dataclasses import dataclass
from dataclasses import field
from datetime import datetime
from typing import Any

from ai_architect.decision_engine.decision_report import (
    DecisionReport,
)

from ai_architect.execution.repository_metrics import (
    RepositoryMetrics,
)


@dataclass(slots=True)
class ExecutionResult:
    """
    Final result produced by the Execution Pipeline.

    This object is the canonical execution report
    exchanged between the Execution Pipeline,
    Memory Engine, CLI, API and future Agent System.
    """

    ##########################################################
    # Identity
    ##########################################################

    repository: str

    filename: str

    instruction: str

    ##########################################################
    # Status
    ##########################################################

    success: bool = False

    ##########################################################
    # Provider
    ##########################################################

    provider: str = ""

    ##########################################################
    # Generated Artifact
    ##########################################################

    generated_code: str = ""

    ##########################################################
    # Validation
    ##########################################################

    validation_ok: bool = False

    findings: list[str] = field(
        default_factory=list,
    )

    ##########################################################
    # Tests
    ##########################################################

    tests_ok: bool = False

    ##########################################################
    # Decision
    ##########################################################

    decision: DecisionReport | None = None

    ##########################################################
    # Repository Metrics
    ##########################################################

    metrics: RepositoryMetrics = field(
        default_factory=RepositoryMetrics,
    )

    ##########################################################
    # Metadata
    ##########################################################

    metadata: dict[str, Any] = field(
        default_factory=dict,
    )

    ##########################################################
    # Timing
    ##########################################################

    started_at: datetime = field(
        default_factory=datetime.utcnow,
    )

    finished_at: datetime | None = None

    duration: float = 0.0

    ##########################################################

    def finish(
        self,
    ) -> None:

        self.finished_at = datetime.utcnow()

        self.duration = round(

            (

                self.finished_at

                -

                self.started_at

            ).total_seconds(),

            3,

        )

    ##########################################################

    @property
    def approved(
        self,
    ) -> bool:

        if self.decision is None:

            return False

        return self.decision.approved

    ##########################################################

    @property
    def confidence(
        self,
    ) -> float:

        if self.decision is None:

            return 0.0

        return self.decision.confidence

    ##########################################################

    @property
    def decision_name(
        self,
    ) -> str:

        if self.decision is None:

            return "UNKNOWN"

        return self.decision.decision.value

    ##########################################################

    @property
    def completed(
        self,
    ) -> bool:

        return self.finished_at is not None

    ##########################################################

    @property
    def execution_time(
        self,
    ) -> float:

        return self.duration

    ##########################################################

    def add_metadata(

        self,

        key: str,

        value: Any,

    ) -> None:

        self.metadata[key] = value

    ##########################################################

    def to_dict(
        self,
    ) -> dict[str, Any]:

        data = asdict(

            self,

        )

        if self.decision is not None:

            data["decision"] = (

                self.decision.to_dict()

            )

        else:

            data["decision"] = None

        data["metrics"] = (

            self.metrics.to_dict()

        )

        data["started_at"] = (

            self.started_at.isoformat()

        )

        data["finished_at"] = (

            self.finished_at.isoformat()

            if self.finished_at

            else None

        )

        return data

    ##########################################################

    def summary(
        self,
    ) -> dict[str, Any]:

        return {

            "repository": self.repository,

            "file": self.filename,

            "success": self.success,

            "approved": self.approved,

            "decision": self.decision_name,

            "confidence": self.confidence,

            "validation": self.validation_ok,

            "tests": self.tests_ok,

            "provider": self.provider,

            "duration": self.duration,

        }

    ##########################################################

    def __bool__(
        self,
    ) -> bool:

        return self.success
