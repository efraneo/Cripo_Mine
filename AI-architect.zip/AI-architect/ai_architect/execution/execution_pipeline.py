# =========================================================
# Parte 1
# =========================================================

"""
=========================================================
Execution Pipeline

Autonomous Execution Orchestrator
=========================================================
"""

from __future__ import annotations

from uuid import uuid4

from ai_architect.decision_engine.auto_decision import (
    AutoDecision,
)

from ai_architect.execution.execution_context import (
    ExecutionContext,
)

from ai_architect.execution.execution_result import (
    ExecutionResult,
)

from ai_architect.git.git_manager import (
    GitManager,
)

from ai_architect.llm.change_validator import (
    ChangeValidator,
)

from ai_architect.llm.code_generator import (
    CodeGenerator,
)

from ai_architect.llm.repository_context import (
    RepositoryContext,
)

from ai_architect.memory.memory_engine import (
    MemoryEngine,
)

from ai_architect.memory.models import (
    Experience,
    ExperienceOutcome,
    ExperienceType,
)

from ai_architect.test_runner.test_runner import (
    TestRunner,
)


class ExecutionPipeline:
    """
    Complete autonomous execution pipeline.

    Flow

        Repository Context
                │
                ▼
          Code Generation
                │
                ▼
           Validation
                │
                ▼
             Unit Tests
                │
                ▼
          Decision Engine
                │
                ▼
            Git Commit
                │
                ▼
           Memory Engine
    """

    ##############################################################

    def __init__(

        self,

        repository: str,

    ) -> None:

        self.repository = repository

        self.context_builder = RepositoryContext()

        self.generator = CodeGenerator()

        self.validator = ChangeValidator()

        self.tests = TestRunner()

        self.git = GitManager(

            repository,

        )

        self.memory = MemoryEngine()

        self.decision = AutoDecision()

    ##############################################################

    def execute(

        self,

        filename: str,

        instruction: str,

    ) -> ExecutionResult:

        context = ExecutionContext(

            repository=self.repository,

            filename=filename,

            instruction=instruction,

        )

        result = ExecutionResult(

            success=False,

            repository=self.repository,

            filename=filename,

            instruction=instruction,

            provider=self.generator.provider_name(),

        )

        self._build_repository_context(

            context,

        )

        self._generate_code(

            context,

            result,

        )

        self._validate(

            context,

            result,

        )

        self._run_tests(

            context,

            result,

        )

        self._decision(

            context,

            result,

        )

        self._persist(

            context,

            result,

        )

        result.finish()

        return result

# =========================================================
# Parte 2
# =========================================================

    ##############################################################

    def _build_repository_context(

        self,

        context: ExecutionContext,

    ) -> None:

        repository_context = (

            self.context_builder.build(

                context.repository,

                [

                    context.filename,

                ],

            )

        )

        context.metadata[

            "repository_context"

        ] = repository_context

    ##############################################################

    def _generate_code(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        generated = self.generator.generate(

            context.instruction,

            str(

                context.metadata[

                    "repository_context"

                ]

            ),

        )

        context.generated_code = generated

        context.provider = (

            self.generator.provider_name()

        )

        result.generated_code = generated

        result.provider = context.provider

    ##############################################################

    def _validate(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        validation_ok, findings = (

            self.validator.validate(

                context.filename,

            )

        )

        context.validation_ok = validation_ok

        context.findings = findings

        result.validation_ok = validation_ok

        result.findings = list(

            findings,

        )

    ##############################################################

    def _run_tests(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        test_result = self.tests.run(

            context.repository,

        )

        context.tests_ok = (

            test_result.success

        )

        result.tests_ok = (

            test_result.success

        )

        result.metadata[

            "tests"

        ] = test_result

    ##############################################################

    def _collect_metrics(

        self,

        context: ExecutionContext,

    ) -> None:

        #
        # En futuras versiones este método obtendrá
        # información desde:
        #
        #   • Repository Analyzer
        #   • Quality Engine
        #   • Security Scanner
        #   • Coverage
        #   • Radon
        #   • Ruff
        #   • SonarQube
        #

        context.metrics = {

            "duplicates": 0,

            "oversized_files": 0,

            "complexity": 0,

            "security_findings": 0,

        }

        context.task = {

            "touches_core": False,

        }

# =========================================================
# Parte 3
# =========================================================

    ##############################################################

    def _decision(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        self._collect_metrics(

            context,

        )

        report = self.decision.evaluate(

            metrics=context.metrics,

            findings=context.findings,

            task=context.task,

            tests_ok=context.tests_ok,

        )

        context.decision = report

        result.decision = report

        result.metrics = dict(

            context.metrics,

        )

        result.success = report.get(

            "approved",

            False,

        )

    ##############################################################

    def _persist(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        self._commit_if_needed(

            result,

        )

        self._update_memory(

            context,

            result,

        )

        result.metadata[

            "repository"

        ] = self.git.summary()

    ##############################################################

    def _commit_if_needed(

        self,

        result: ExecutionResult,

    ) -> None:

        if not result.approved:

            return

        self.git.stage_all()

        self.git.commit(

            f"AI: Improve {result.filename}",

        )

    ##############################################################

    def _update_memory(

        self,

        context: ExecutionContext,

        result: ExecutionResult,

    ) -> None:

        experience = Experience(

            id=uuid4().hex,

            repository=context.repository,

            filename=context.filename,

            instruction=context.instruction,

            provider=result.provider,

            experience_type=ExperienceType.EXECUTION,

            outcome=(

                ExperienceOutcome.SUCCESS

                if result.success

                else ExperienceOutcome.FAILURE

            ),

            confidence=result.confidence,

            score=(

                1.0

                if result.success

                else 0.0

            ),

            risk=(

                0.0

                if result.success

                else 1.0

            ),

            metadata={

                "decision": result.decision,

                "metrics": result.metrics,

                "validation_ok": result.validation_ok,

                "findings": result.findings,

                "tests": result.metadata.get(

                    "tests",

                ),

                "generated_code": result.generated_code,

            },

        )

        #
        # En futuras versiones se añadirá el embedding
        # generado por EmbeddingEngine para alimentar
        # VectorMemory automáticamente.
        #

        self.memory.remember(

            experience,

        )

    ##############################################################

    def health(

        self,

    ) -> dict:

        return {

            "repository": self.repository,

            "provider": (

                self.generator.provider_name()

            ),

            "pipeline": "ready",

            "components": {

                "generator": True,

                "validator": True,

                "tests": True,

                "decision": True,

                "git": True,

                "memory": True,

            },

        }
