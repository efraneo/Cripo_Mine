"""
=========================================================
Memory Store
=========================================================
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from .models import (
    MemoryEntry,
    MemoryType,
)


class MemoryStore:

    def __init__(
        self,
        database: str | Path,
    ) -> None:

        self.database = Path(
            database
        )

        self.database.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        if not self.database.exists():

            self.database.write_text(
                "[]",
                encoding="utf-8",
            )

    def _load(self):

        data = json.loads(

            self.database.read_text(
                encoding="utf-8"
            )

        )

        return [

            MemoryEntry(

                **item

            )

            for item in data

        ]

    def _save(
        self,
        memories,
    ):

        self.database.write_text(

            json.dumps(

                [

                    memory.__dict__

                    for memory in memories

                ],

                indent=4,

                default=str,

            ),

            encoding="utf-8",

        )

    def add(

        self,

        category: MemoryType,

        title: str,

        content: str,

        source: str = "",

        tags: list[str] | None = None,

    ) -> MemoryEntry:

        memories = self._load()

        memory = MemoryEntry(

            id=uuid.uuid4().hex,

            category=category,

            title=title,

            content=content,

            source=source,

            tags=tags or [],

        )

        memories.append(
            memory
        )

        self._save(
            memories
        )

        return memory

    def all(self):

        return self._load()

    def clear(self):

        self.database.write_text(
            "[]",
            encoding="utf-8",
        )
