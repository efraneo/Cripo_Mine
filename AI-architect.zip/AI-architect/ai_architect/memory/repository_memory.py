"""
=========================================================
Repository Memory

Persistent Repository State
=========================================================
"""

from __future__ import annotations

import json

from datetime import datetime
from pathlib import Path
from typing import Any


class RepositoryMemory:
    """
    Stores persistent information about one repository.

    This is NOT execution history.

    This is NOT knowledge.

    It stores repository metadata and long-term state.
    """

    FILE_NAME = ".quant_repository.json"

    def __init__(
        self,
        repository: str,
    ) -> None:

        self.repository = Path(repository)

        self.file = self.repository / self.FILE_NAME

        self.data = self._load()

    # -----------------------------------------------------

    def _default(self) -> dict:

        return {

            "created": datetime.utcnow().isoformat(),

            "last_updated": datetime.utcnow().isoformat(),

            "repository": self.repository.name,

            "settings": {},

            "metadata": {},

            "metrics": {},

            "preferences": {},

            "custom": {},

        }

    # -----------------------------------------------------

    def _load(
        self,
    ) -> dict:

        if self.file.exists():

            try:

                with self.file.open(
                    "r",
                    encoding="utf-8",
                ) as f:

                    return json.load(f)

            except Exception:

                pass

        return self._default()

    # -----------------------------------------------------

    def save(
        self,
    ) -> None:

        self.data["last_updated"] = (

            datetime.utcnow().isoformat()

        )

        with self.file.open(
            "w",
            encoding="utf-8",
        ) as f:

            json.dump(

                self.data,

                f,

                indent=4,

                ensure_ascii=False,

            )

    # -----------------------------------------------------

    def get(
        self,
        key: str,
        default: Any = None,
    ) -> Any:

        return self.data.get(

            key,

            default,

        )

    # -----------------------------------------------------

    def set(
        self,
        key: str,
        value: Any,
    ) -> None:

        self.data[key] = value

        self.save()

    # -----------------------------------------------------

    def update_section(
        self,
        section: str,
        values: dict,
    ) -> None:

        if section not in self.data:

            self.data[section] = {}

        self.data[section].update(values)

        self.save()

    # -----------------------------------------------------

    def get_section(
        self,
        section: str,
    ) -> dict:

        return dict(

            self.data.get(

                section,

                {},

            )

        )

    # -----------------------------------------------------

    def remove(
        self,
        key: str,
    ) -> bool:

        if key not in self.data:

            return False

        del self.data[key]

        self.save()

        return True

    # -----------------------------------------------------

    def reset(
        self,
    ) -> None:

        self.data = self._default()

        self.save()

    # -----------------------------------------------------

    def summary(
        self,
    ) -> dict:

        return {

            "repository": self.repository.name,

            "created": self.data["created"],

            "last_updated": self.data["last_updated"],

            "sections": sorted(

                self.data.keys(),

            ),

        }
