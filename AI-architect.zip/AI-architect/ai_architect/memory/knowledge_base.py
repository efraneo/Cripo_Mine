"""
=========================================================
Knowledge Base

Persistent Knowledge Repository
=========================================================
"""

from __future__ import annotations

import json

from datetime import datetime

from pathlib import Path


class KnowledgeBase:
    """
    Stores reusable engineering knowledge.

    Unlike ExperienceMemory, this repository stores
    permanent knowledge instead of execution history.

    Examples:

    - SOLID principles
    - Design patterns
    - Anti-patterns
    - Refactoring strategies
    - Coding standards
    - Architecture rules
    """

    FILE_NAME = ".quant_knowledge.json"

    def __init__(
        self,
        repository: str,
    ) -> None:

        self.repository = Path(repository)

        self.file = self.repository / self.FILE_NAME

        self.knowledge = self._load()

    # -----------------------------------------------------

    def _load(
        self,
    ) -> dict:

        if self.file.exists():

            try:

                with self.file.open(
                    "r",
                    encoding="utf-8",
                ) as f:

                    return json.load(f)

            except Exception:

                pass

        return {

            "created": datetime.utcnow().isoformat(),

            "items": [],

        }

    # -----------------------------------------------------

    def save(
        self,
    ) -> None:

        with self.file.open(
            "w",
            encoding="utf-8",
        ) as f:

            json.dump(

                self.knowledge,

                f,

                indent=4,

                ensure_ascii=False,

            )

    # -----------------------------------------------------

    def add(
        self,
        *,
        category: str,
        title: str,
        description: str,
        tags: list[str] | None = None,
        source: str = "manual",
        confidence: float = 1.0,
    ) -> None:

        self.knowledge["items"].append(

            {

                "timestamp": datetime.utcnow().isoformat(),

                "category": category,

                "title": title,

                "description": description,

                "tags": tags or [],

                "source": source,

                "confidence": confidence,

            }

        )

        self.save()

    # -----------------------------------------------------

    def all(
        self,
    ) -> list[dict]:

        return list(

            self.knowledge["items"],

        )

    # -----------------------------------------------------

    def search(
        self,
        keyword: str,
    ) -> list[dict]:

        keyword = keyword.lower()

        return [

            item

            for item in self.knowledge["items"]

            if keyword in item["title"].lower()

            or keyword in item["description"].lower()

            or any(

                keyword in tag.lower()

                for tag in item["tags"]

            )

        ]

    # -----------------------------------------------------

    def by_category(
        self,
        category: str,
    ) -> list[dict]:

        return [

            item

            for item in self.knowledge["items"]

            if item["category"] == category

        ]

    # -----------------------------------------------------

    def remove(
        self,
        title: str,
    ) -> bool:

        before = len(

            self.knowledge["items"]

        )

        self.knowledge["items"] = [

            item

            for item in self.knowledge["items"]

            if item["title"] != title

        ]

        changed = len(

            self.knowledge["items"]

        ) != before

        if changed:

            self.save()

        return changed

    # -----------------------------------------------------

    def statistics(
        self,
    ) -> dict:

        items = self.knowledge["items"]

        categories = {}

        for item in items:

            category = item["category"]

            categories[category] = (

                categories.get(

                    category,

                    0,

                )

                + 1

            )

        return {

            "entries": len(items),

            "categories": categories,

        }

    # -----------------------------------------------------

    def clear(
        self,
    ) -> None:

        self.knowledge = {

            "created": datetime.utcnow().isoformat(),

            "items": [],

        }

        self.save()

    # -----------------------------------------------------

    def summary(
        self,
    ) -> dict:

        return {

            "repository": str(

                self.repository,

            ),

            "statistics": self.statistics(),

        }
