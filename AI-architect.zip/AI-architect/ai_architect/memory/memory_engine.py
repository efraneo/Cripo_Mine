"""
=========================================================
Memory Engine

Central Memory Coordinator
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from ai_architect.memory.backends.json_backend import (
    JsonMemoryBackend,
)

from ai_architect.memory.experience_store import (
    ExperienceStore,
)

from ai_architect.memory.knowledge_graph import (
    KnowledgeGraph,
)

from ai_architect.memory.learning_engine import (
    LearningEngine,
)

from ai_architect.memory.models import (
    Experience,
    LearningPattern,
    MemorySnapshot,
)

from ai_architect.memory.pattern_miner import (
    PatternMiner,
)

from ai_architect.memory.vector_memory import (
    VectorMemory,
)


class MemoryEngine:
    """
    Central facade for the Memory subsystem.

    Coordinates

        • Experience Store

        • Learning Engine

        • Pattern Miner

        • Vector Memory

        • Knowledge Graph
    """

    ###############################################################

    def __init__(

        self,

        storage: str | Path = ".ai_architect/memory.json",

    ) -> None:

        backend = JsonMemoryBackend(

            storage,

        )

        self.store = ExperienceStore(

            backend,

        )

        self.learning = LearningEngine()

        self.patterns = PatternMiner()

        self.vector = VectorMemory()

        self.graph = KnowledgeGraph()

    ###############################################################

    def snapshot(

        self,

    ) -> MemorySnapshot:

        return self.store.load()

    ###############################################################

    def remember(

        self,

        experience: Experience,

        embedding: list[float] | None = None,

    ) -> None:

        #
        # Persistent storage
        #

        self.store.append(

            experience,

        )

        #
        # Vector memory
        #

        if embedding is not None:

            self.vector.add(

                experience,

                embedding,

            )

        #
        # Refresh learning
        #

        self.refresh()

    ###############################################################

    def refresh(

        self,

    ) -> list[LearningPattern]:

        snapshot = self.store.load()

        patterns = self.learning.learn(

            snapshot,

        )

        snapshot.patterns = patterns

        self.store.save(

            snapshot,

        )

        return patterns

    ###############################################################

    def patterns_summary(

        self,

    ) -> list[LearningPattern]:

        return self.snapshot().patterns

    ###############################################################

    def recommendations(

        self,

    ) -> list[str]:

        return self.learning.recommendations(

            self.snapshot(),

        )

    ###############################################################

    def similar(

        self,

        embedding: list[float],

        limit: int = 5,

    ):

        return self.vector.search(

            embedding,

            limit,

        )

    ###############################################################

    def clear(

        self,

    ) -> None:

        self.store.clear()

        self.vector.clear()

        self.graph.clear()

    ###############################################################

    def statistics(

        self,

    ) -> dict:

        snapshot = self.snapshot()

        return {

            "experiences": len(

                snapshot.experiences,

            ),

            "patterns": len(

                snapshot.patterns,

            ),

            "graph_nodes": (

                self.graph.node_count()

            ),

            "graph_edges": (

                self.graph.edge_count()

            ),

            "vectors": (

                self.vector.count()

            ),

        }
