"""
=========================================================
Project History

Persistent Execution History
=========================================================
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any


class ProjectHistory:
    """
    Stores every execution performed by
    QUANT AI Architect.

    This history is later consumed by the
    Learning Engine, Decision Engine and
    Knowledge Engine.
    """

    def __init__(
        self,
        storage: str = ".quant",
    ) -> None:

        self.root = Path(storage)

        self.root.mkdir(

            parents=True,

            exist_ok=True,

        )

        self.history_file = (

            self.root /

            "history.json"

        )

    def append(
        self,
        execution: dict[str, Any],
    ) -> None:

        history = self.load()

        execution = dict(execution)

        execution["timestamp"] = (

            datetime.utcnow().isoformat()

        )

        history.append(execution)

        self.history_file.write_text(

            json.dumps(

                history,

                indent=4,

                ensure_ascii=False,

            ),

            encoding="utf-8",

        )

    def load(
        self,
    ) -> list[dict]:

        if not self.history_file.exists():

            return []

        try:

            return json.loads(

                self.history_file.read_text(

                    encoding="utf-8",

                )

            )

        except Exception:

            return []

    def last(
        self,
        count: int = 10,
    ) -> list[dict]:

        return self.load()[-count:]

    def successful(
        self,
    ) -> list[dict]:

        return [

            item

            for item in self.load()

            if item.get(

                "success",

                False,

            )

        ]

    def failed(
        self,
    ) -> list[dict]:

        return [

            item

            for item in self.load()

            if not item.get(

                "success",

                False,

            )

        ]

    def clear(
        self,
    ) -> None:

        if self.history_file.exists():

            self.history_file.unlink()

    def statistics(
        self,
    ) -> dict:

        history = self.load()

        total = len(history)

        successful = len(

            self.successful()

        )

        failed = total - successful

        average_confidence = 0.0

        if total:

            average_confidence = (

                sum(

                    item.get(

                        "confidence",

                        0.0,

                    )

                    for item in history

                )

                / total

            )

        return {

            "executions": total,

            "successful": successful,

            "failed": failed,

            "success_rate": round(

                (

                    successful / total

                    if total

                    else 0

                )

                * 100,

                2,

            ),

            "average_confidence": round(

                average_confidence,

                3,

            ),

            "last_execution": (

                history[-1]

                if history

                else None

            ),

        }

    def providers(
        self,
    ) -> dict[str, int]:

        result: dict[str, int] = {}

        for item in self.load():

            provider = item.get(

                "provider",

                "unknown",

            )

            result[provider] = (

                result.get(

                    provider,

                    0,

                )

                + 1

            )

        return result

    def files(
        self,
    ) -> dict[str, int]:

        result: dict[str, int] = {}

        for item in self.load():

            filename = item.get(

                "file",

                "unknown",

            )

            result[filename] = (

                result.get(

                    filename,

                    0,

                )

                + 1

            )

        return result
