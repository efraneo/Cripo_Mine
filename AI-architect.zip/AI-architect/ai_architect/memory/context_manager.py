"""
=========================================================
Context Manager
=========================================================
"""

from __future__ import annotations

from .memory_store import (
    MemoryStore,
)


class ContextManager:

    def __init__(
        self,
        store: MemoryStore,
    ) -> None:

        self.store = store

    def search(
        self,
        text: str,
    ):

        text = text.lower()

        result = []

        for memory in self.store.all():

            score = 0

            if text in memory.title.lower():

                score += 2

            if text in memory.content.lower():

                score += 3

            for tag in memory.tags:

                if text in tag.lower():

                    score += 5

            if score:

                result.append(

                    (

                        score,

                        memory,

                    )

                )

        result.sort(

            key=lambda item: item[0],

            reverse=True,

        )

        return [

            memory

            for _, memory

            in result

        ]

    def latest(
        self,
        limit: int = 20,
    ):

        memories = sorted(

            self.store.all(),

            key=lambda item: item.created_at,

            reverse=True,

        )

        return memories[:limit]
