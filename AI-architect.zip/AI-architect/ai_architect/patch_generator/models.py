"""
=========================================================
Patch Generator Models
=========================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(slots=True)
class PatchFile:

    path: str

    action: str

    additions: int = 0

    deletions: int = 0


@dataclass(slots=True)
class Patch:

    id: str

    title: str

    description: str

    created_at: datetime

    files: list[PatchFile] = field(
        default_factory=list
    )

    diff: str = ""

    approved: bool = False

    def add_file(
        self,
        file: PatchFile,
    ) -> None:

        self.files.append(file)

    @property
    def total_files(
        self,
    ) -> int:

        return len(self.files)
