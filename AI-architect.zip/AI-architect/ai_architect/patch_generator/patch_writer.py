"""
=========================================================
Patch Writer
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from .models import Patch


class PatchWriter:

    def save(
        self,
        patch: Patch,
        folder: str | Path,
    ) -> Path:

        folder = Path(folder)

        folder.mkdir(
            parents=True,
            exist_ok=True,
        )

        file = folder / f"{patch.id}.patch"

        lines = [

            "=" * 70,

            "QUANT AI ARCHITECT PATCH",

            "=" * 70,

            "",

            f"ID          : {patch.id}",

            f"TITLE       : {patch.title}",

            f"DESCRIPTION : {patch.description}",

            f"CREATED     : {patch.created_at}",

            "",

            "FILES",

            "-" * 70,

        ]

        for item in patch.files:

            lines.append(

                f"{item.action:8}"

                f"{item.path}"

            )

        lines.extend(

            [

                "",

                "-" * 70,

                "",

                patch.diff,

            ]

        )

        file.write_text(

            "\n".join(lines),

            encoding="utf-8",

        )

        return file
