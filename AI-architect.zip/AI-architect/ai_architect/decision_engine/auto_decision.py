"""
=========================================================
Auto Decision

Institutional Autonomous Decision Coordinator
=========================================================
"""

from __future__ import annotations

from ai_architect.core.context import AIContext

from .confidence_engine import ConfidenceEngine
from .execution_policy import ExecutionPolicy
from .quality_score import QualityScore
from .risk_engine import RiskEngine
from .scoring_engine import ScoringEngine


class AutoDecision:
    """
    Institutional autonomous decision system.

    Pipeline

        AIContext
             │
             ▼
      Quality Engine
             │
             ▼
       Risk Engine
             │
             ▼
    Confidence Engine
             │
             ▼
      Scoring Engine
             │
             ▼
     Execution Policy
             │
             ▼
      Final Decision
    """

    def __init__(
        self,
    ) -> None:

        self.quality = QualityScore()

        self.risk = RiskEngine()

        self.confidence = ConfidenceEngine()

        self.scoring = ScoringEngine()

        self.policy = ExecutionPolicy()

    ##################################################################

    def evaluate(
        self,
        context: AIContext,
    ) -> dict:

        quality = self.quality.evaluate(
            context,
        )

        risk = self.risk.evaluate(
            context,
        )

        confidence = self.confidence.evaluate(
            context,
            quality,
            risk,
        )

        score = self.scoring.evaluate(
            quality,
            confidence,
            risk,
        )

        report = self.policy.evaluate(

            score=score,

            confidence=confidence,

            risk=risk,

            tests_ok=context.tests.get(
                "success",
                False,
            ),

        )

        report.update(

            {

                "quality": quality,

                "risk_report": risk,

                "confidence_report": confidence,

                "score_report": score,

            }

        )

        return report

    ##################################################################

    def should_commit(
        self,
        report: dict,
    ) -> bool:

        return self.policy.should_commit(
            report,
        )

    ##################################################################

    def should_retry(
        self,
        report: dict,
    ) -> bool:

        return self.policy.should_retry(
            report,
        )

    ##################################################################

    def requires_review(
        self,
        report: dict,
    ) -> bool:

        return self.policy.requires_review(
            report,
        )

    ##################################################################

    def rejected(
        self,
        report: dict,
    ) -> bool:

        return self.policy.rejected(
            report,
        )

    ##################################################################

    def summary(
        self,
        report: dict,
    ) -> str:

        score = report["score_report"]

        confidence = report[
            "confidence_report"
        ]

        risk = report["risk_report"]

        return (

            f"{report['decision']} | "

            f"Grade={score.grade} | "

            f"Score={score.score:.2f} | "

            f"Risk={risk.level.value} | "

            f"Confidence={confidence.value:.3f}"

        )

    ##################################################################

    def diagnostics(
        self,
        report: dict,
    ) -> dict:

        return {

            "decision": report["decision"],

            "approved": report["approved"],

            "reason": report["reason"],

            "quality": report[
                "quality"
            ].to_dict(),

            "risk": report[
                "risk_report"
            ].to_dict(),

            "confidence": report[
                "confidence_report"
            ].to_dict(),

            "score": report[
                "score_report"
            ].to_dict(),

        }
