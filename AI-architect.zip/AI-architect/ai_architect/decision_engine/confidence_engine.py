"""
=========================================================
Confidence Engine

Institutional Decision Confidence Engine
=========================================================
"""

from __future__ import annotations

from dataclasses import field
from dataclasses import dataclass
from typing import Any

from ai_architect.core.context import AIContext
from ai_architect.core.enums import Confidence

from .models import (
    QualityAssessment,
    RiskAssessment,
)


@dataclass(slots=True)
class ConfidenceReport:
    """
    Final confidence evaluation.

    Confidence is a normalized value between:

        0.0
            ↓
        1.0
    """

    value: float

    level: Confidence

    reasons: list[str] = field(
        default_factory=list,
    )

    def to_dict(
        self,
    ) -> dict[str, Any]:

        return {

            "value": self.value,

            "level": self.level.value,

            "reasons": self.reasons,

        }


class ConfidenceEngine:
    """
    Calculates execution confidence.

    Inputs

        • Repository Quality

        • Repository Risk

        • Validation

        • Tests

        • Learning

    Output

        ConfidenceReport
    """

    #
    # Weights
    #

    TEST_FAILURE = 0.20

    VALIDATION_WEIGHT = 0.03

    MAX_VALIDATION = 0.20

    HIGH_LEARNING_BONUS = 0.05

    LOW_LEARNING_PENALTY = 0.05

    def evaluate(
        self,
        context: AIContext,
        quality: QualityAssessment,
        risk: RiskAssessment,
    ) -> ConfidenceReport:

        confidence = quality.score / 100.0

        reasons: list[str] = []

        #
        # Risk
        #

        confidence -= risk.score / 200.0

        reasons.extend(
            risk.reasons,
        )

        #
        # Tests
        #

        confidence += self._tests(
            context,
            reasons,
        )

        #
        # Validation
        #

        confidence += self._validation(
            context,
            reasons,
        )

        #
        # Learning
        #

        confidence += self._learning(
            context,
            reasons,
        )

        confidence = max(

            0.0,

            min(

                1.0,

                round(
                    confidence,
                    3,
                ),

            ),

        )

        return ConfidenceReport(

            value=confidence,

            level=self._level(
                confidence,
            ),

            reasons=reasons,

        )

    ###############################################################

    def _tests(
        self,
        context: AIContext,
        reasons: list[str],
    ) -> float:

        tests = context.tests

        if tests.get(
            "success",
            False,
        ):

            return 0.0

        reasons.append(
            "Tests failed."
        )

        return -self.TEST_FAILURE

    ###############################################################

    def _validation(
        self,
        context: AIContext,
        reasons: list[str],
    ) -> float:

        findings = context.validation.get(
            "findings",
            [],
        )

        if not findings:

            return 0.0

        penalty = min(

            len(findings)
            * self.VALIDATION_WEIGHT,

            self.MAX_VALIDATION,

        )

        reasons.append(

            f"{len(findings)} validation findings."

        )

        return -penalty

    ###############################################################

    def _learning(
        self,
        context: AIContext,
        reasons: list[str],
    ) -> float:

        learning = context.learning

        if not learning:

            return 0.0

        success_rate = learning.get(
            "success_rate",
        )

        if success_rate is None:

            return 0.0

        if success_rate >= 90:

            reasons.append(
                "Excellent historical performance."
            )

            return self.HIGH_LEARNING_BONUS

        if success_rate < 50:

            reasons.append(
                "Low historical performance."
            )

            return -self.LOW_LEARNING_PENALTY

        return 0.0

    ###############################################################

    @staticmethod
    def _level(
        value: float,
    ) -> Confidence:

        if value >= 0.95:

            return Confidence.VERY_HIGH

        if value >= 0.80:

            return Confidence.HIGH

        if value >= 0.60:

            return Confidence.MEDIUM

        if value >= 0.40:

            return Confidence.LOW

        return Confidence.VERY_LOW

    ###############################################################

    @staticmethod
    def acceptable(
        report: ConfidenceReport,
        minimum: float = 0.70,
    ) -> bool:

        return report.value >= minimum

    ###############################################################

    @staticmethod
    def summary(
        report: ConfidenceReport,
    ) -> str:

        return (

            f"Confidence={report.level.value} "

            f"({report.value:.3f})"

        )
