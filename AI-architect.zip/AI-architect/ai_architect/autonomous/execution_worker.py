"""
=========================================================
Execution Worker
=========================================================
"""

from __future__ import annotations

import traceback


class ExecutionWorker:

    def execute(

        self,

        task: dict,

    ) -> dict:

        try:

            callback = task["callback"]

            result = callback()

            return {

                "success": True,

                "result": result,

            }

        except Exception:

            return {

                "success": False,

                "traceback":

                traceback.format_exc(),

            }
