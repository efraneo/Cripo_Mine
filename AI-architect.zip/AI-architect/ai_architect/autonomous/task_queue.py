"""
=========================================================
Task Queue
=========================================================
"""

from __future__ import annotations

from queue import Queue


class TaskQueue:

    def __init__(self):

        self._queue = Queue()

    def push(

        self,

        task: dict,

    ):

        self._queue.put(task)

    def pop(self):

        if self._queue.empty():

            return None

        return self._queue.get()

    def empty(self):

        return self._queue.empty()

    def size(self):

        return self._queue.qsize()
