"""
=========================================================
Autonomous Engine
=========================================================
"""

from __future__ import annotations

from .approval_engine import ApprovalEngine
from .branch_manager import BranchManager
from .execution_monitor import ExecutionMonitor
from .execution_worker import ExecutionWorker
from .merge_manager import MergeManager
from .rollback_manager import RollbackManager
from .task_queue import TaskQueue
from .task_scheduler import TaskScheduler


class AutonomousEngine:

    def __init__(self):

        self.queue = TaskQueue()

        self.scheduler = TaskScheduler()

        self.worker = ExecutionWorker()

        self.branch = BranchManager()

        self.merge = MergeManager()

        self.rollback = RollbackManager()

        self.approval = ApprovalEngine()

        self.monitor = ExecutionMonitor()

    def execute(

        self,

        tasks: list[dict],

    ):

        ordered = self.scheduler.schedule(

            tasks

        )

        for task in ordered:

            self.queue.push(task)

        results = []

        while not self.queue.empty():

            task = self.queue.pop()

            result = self.worker.execute(

                task

            )

            self.monitor.register(

                result

            )

            results.append(

                result

            )

        return {

            "results": results,

            "monitor":

            self.monitor.report(),

        }
