"""
=========================================================
Execution Monitor
=========================================================
"""

from __future__ import annotations

from datetime import datetime


class ExecutionMonitor:

    def __init__(self):

        self.history = []

    def register(

        self,

        event: dict,

    ):

        event["timestamp"] = (

            datetime.utcnow()

            .isoformat()

        )

        self.history.append(

            event

        )

    def report(self):

        return {

            "executions":

            len(

                self.history

            ),

            "events":

            self.history,

        }
