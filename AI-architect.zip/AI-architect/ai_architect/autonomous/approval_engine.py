"""
=========================================================
Approval Engine
=========================================================
"""

from __future__ import annotations


class ApprovalEngine:

    def approve(

        self,

        execution: dict,

    ) -> bool:

        if not execution.get(

            "tests_ok",

            False,

        ):

            return False

        if execution.get(

            "risk",

            "LOW",

        ) == "CRITICAL":

            return False

        return execution.get(

            "confidence",

            0,

        ) >= 90
