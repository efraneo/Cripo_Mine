"""
=========================================================
Backend Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path


class BackendAgent:

    def review(
        self,
        project: str,
    ):

        project = Path(project)

        modules = len(

            list(

                project.rglob("*.py")

            )

        )

        return {

            "python_modules": modules,

            "status": "OK",

            "recommendation":

            "Keep modules under 600 lines."

        }
