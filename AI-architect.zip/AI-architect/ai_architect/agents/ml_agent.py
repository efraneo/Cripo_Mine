"""
=========================================================
Machine Learning Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from .base_agent import BaseAgent


class MLAgent(BaseAgent):

    name = "Machine Learning Agent"

    def review(
        self,
        project: str,
    ) -> dict:

        project = Path(project)

        models = []

        for file in project.rglob("*.py"):

            source = file.read_text(

                encoding="utf-8",

                errors="ignore",

            )

            if (

                "lightgbm" in source.lower()

                or

                "xgboost" in source.lower()

                or

                "catboost" in source.lower()

                or

                "sklearn" in source.lower()

            ):

                models.append(

                    str(file)

                )

        return {

            "ml_modules": len(
                models
            ),

            "files": models,

        }
