"""
=========================================================
Testing Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from .base_agent import BaseAgent


class TestingAgent(BaseAgent):

    name = "Testing Agent"

    def review(

        self,

        project: str,

    ) -> dict:

        project = Path(project)

        test_files = list(

            project.rglob(

                "test_*.py",

            )

        )

        pytest_files = list(

            project.rglob(

                "*pytest*.py",

            )

        )

        unittest_files = list(

            project.rglob(

                "*unittest*.py",

            )

        )

        source_files = list(

            project.rglob(

                "*.py",

            )

        )

        production = [

            f

            for f in source_files

            if "test" not in f.name.lower()

        ]

        coverage = min(

            len(test_files) * 5,

            100,

        )

        missing = max(

            0,

            len(production) - len(test_files),

        )

        return {

            "python_files": len(

                source_files,

            ),

            "production_files": len(

                production,

            ),

            "tests": len(

                test_files,

            ),

            "pytest_files": len(

                pytest_files,

            ),

            "unittest_files": len(

                unittest_files,

            ),

            "coverage_estimate": coverage,

            "missing_tests": missing,

            "status": "OK",

        }
