"""
=========================================================
Release Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from .base_agent import BaseAgent


class ReleaseAgent(BaseAgent):

    name = "Release Agent"

    def review(
        self,
        project: str,
    ) -> dict:

        project = Path(project)

        return {

            "version_file": (

                project / "VERSION"

            ).exists(),

            "changelog": (

                project / "CHANGELOG.md"

            ).exists(),

            "license": (

                project / "LICENSE"

            ).exists(),

            "release_ready": False,

            "next_step":

            "Execute all tests before release.",

        }
