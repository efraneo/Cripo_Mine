"""
=========================================================
Project Manager Agent
=========================================================
"""

from __future__ import annotations

from ai_architect.analyzer.project_analyzer import ProjectAnalyzer


class ProjectManagerAgent:

    def __init__(self):

        self.analyzer = ProjectAnalyzer()

    def plan(
        self,
        project: str,
    ):

        analysis = self.analyzer.analyze(project)

        priorities = []

        if analysis["duplicate_groups"]:

            priorities.append(
                "Remove duplicated modules"
            )

        if analysis["average_complexity"] > 10:

            priorities.append(
                "Reduce complexity"
            )

        priorities.append(
            "Execute tests"
        )

        priorities.append(
            "Generate documentation"
        )

        priorities.append(
            "Commit approved changes"
        )

        return {

            "analysis": analysis,

            "priorities": priorities,

        }
