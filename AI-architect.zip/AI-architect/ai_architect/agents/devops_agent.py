"""
=========================================================
DevOps Agent
=========================================================
"""

from __future__ import annotations

from pathlib import Path


class DevOpsAgent:

    def review(
        self,
        project: str,
    ):

        project = Path(project)

        return {

            "docker":

            (

                project / "Dockerfile"

            ).exists(),

            "github_actions":

            (

                project

                / ".github"

            ).exists(),

            "pyproject":

            (

                project

                / "pyproject.toml"

            ).exists(),

        }
