"""
=========================================================
Analyzer Models
=========================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ImportInfo:

    module: str

    imported: list[str] = field(
        default_factory=list
    )


@dataclass(slots=True)
class FunctionInfo:

    name: str

    line: int

    arguments: int

    decorators: list[str] = field(
        default_factory=list
    )


@dataclass(slots=True)
class ClassInfo:

    name: str

    line: int

    methods: list[str] = field(
        default_factory=list
    )

    bases: list[str] = field(
        default_factory=list
    )


@dataclass(slots=True)
class PythonAnalysis:

    imports: list[ImportInfo] = field(
        default_factory=list
    )

    classes: list[ClassInfo] = field(
        default_factory=list
    )

    functions: list[
        FunctionInfo
    ] = field(
        default_factory=list
    )

    total_lines: int = 0

    complexity: int = 0
