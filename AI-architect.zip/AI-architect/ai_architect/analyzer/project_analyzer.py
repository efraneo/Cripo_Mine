"""
=========================================================
Project Analyzer

Analizador principal del proyecto.
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from ai_architect.workspace.workspace_loader import (
    WorkspaceLoader,
)

from .class_analyzer import (
    ClassAnalyzer,
)

from .complexity_analyzer import (
    ComplexityAnalyzer,
)

from .dependency_analyzer import (
    DependencyAnalyzer,
)

from .duplicate_detector import (
    DuplicateDetector,
)

from .function_analyzer import (
    FunctionAnalyzer,
)


class ProjectAnalyzer:

    def __init__(self):

        self.loader = WorkspaceLoader()

        self.classes = ClassAnalyzer()

        self.functions = FunctionAnalyzer()

        self.complexity = (
            ComplexityAnalyzer()
        )

        self.dependencies = (
            DependencyAnalyzer()
        )

        self.duplicates = (
            DuplicateDetector()
        )

    def analyze(
        self,
        root: str | Path,
    ) -> dict:

        snapshot = self.loader.load(
            root
        )

        files = [

            file.path

            for file in snapshot.files

            if file.extension == ".py"

        ]

        dependency_index = (

            self.dependencies.analyze_project(
                files
            )

        )

        return {

            "total_files": len(
                snapshot.files
            ),

            "python_files": len(
                files
            ),

            "duplicate_groups": (

                self.duplicates.total_duplicates(
                    root
                )

            ),

            "dependency_modules": (

                dependency_index.total_modules

            ),

            "total_classes": sum(

                len(
                    self.classes.classes(
                        file
                    )
                )

                for file in files

            ),

            "total_functions": sum(

                len(
                    self.functions.functions(
                        file
                    )
                )

                for file in files

            ),

            "average_complexity": (

                round(

                    sum(

                        self.complexity.score(
                            file
                        )

                        for file in files

                    )

                    / max(
                        len(files),
                        1,
                    ),

                    2,

                )

            ),

        }
