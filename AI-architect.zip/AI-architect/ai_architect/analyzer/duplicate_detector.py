"""
=========================================================
Duplicate Detector
=========================================================
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

from ai_architect.filesystem.file_hash import FileHash
from ai_architect.filesystem.project_walker import ProjectWalker


class DuplicateDetector:

    def __init__(self) -> None:

        self.walker = ProjectWalker()
        self.hasher = FileHash()

    def duplicates(
        self,
        root: str | Path,
    ) -> dict[str, list[str]]:

        hashes = defaultdict(list)

        for file in self.walker.walk(root):

            digest = self.hasher.sha256(file)

            hashes[digest].append(
                str(file)
            )

        return {

            digest: files

            for digest, files in hashes.items()

            if len(files) > 1

        }

    def total_duplicates(
        self,
        root: str | Path,
    ) -> int:

        return len(
            self.duplicates(root)
        )
