"""
=========================================================
Task Generator
=========================================================
"""

from __future__ import annotations


class TaskGenerator:

    def build(

        self,

        reports: dict,

    ) -> list:

        tasks = []

        for agent, report in reports.items():

            tasks.append(

                {

                    "agent": agent,

                    "priority": 1,

                    "callback":

                    lambda: report,

                }

            )

        return tasks
