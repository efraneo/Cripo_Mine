"""
=========================================================
Global Enums

Shared Enumerations
=========================================================
"""

from __future__ import annotations

from enum import Enum


class Status(str, Enum):

    PENDING = "PENDING"

    RUNNING = "RUNNING"

    COMPLETED = "COMPLETED"

    FAILED = "FAILED"

    CANCELLED = "CANCELLED"

    SKIPPED = "SKIPPED"


class Priority(str, Enum):

    LOW = "LOW"

    MEDIUM = "MEDIUM"

    HIGH = "HIGH"

    CRITICAL = "CRITICAL"


class Decision(str, Enum):

    ACCEPT = "ACCEPT"

    RETRY = "RETRY"

    REJECT = "REJECT"

    MANUAL_REVIEW = "MANUAL_REVIEW"


class RiskLevel(str, Enum):

    LOW = "LOW"

    MEDIUM = "MEDIUM"

    HIGH = "HIGH"

    CRITICAL = "CRITICAL"


class Confidence(str, Enum):

    VERY_LOW = "VERY_LOW"

    LOW = "LOW"

    MEDIUM = "MEDIUM"

    HIGH = "HIGH"

    VERY_HIGH = "VERY_HIGH"


class AgentState(str, Enum):

    IDLE = "IDLE"

    RUNNING = "RUNNING"

    WAITING = "WAITING"

    FAILED = "FAILED"


class ProviderStatus(str, Enum):

    AVAILABLE = "AVAILABLE"

    UNAVAILABLE = "UNAVAILABLE"

    RATE_LIMITED = "RATE_LIMITED"

    ERROR = "ERROR"
