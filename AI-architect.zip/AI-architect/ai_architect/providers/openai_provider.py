"""
=========================================================
OpenAI Provider
=========================================================
"""

from __future__ import annotations

import os
from typing import Any

from openai import OpenAI

from ai_architect.providers.base_provider import (
    BaseProvider,
)


class OpenAIProvider(BaseProvider):
    """
    OpenAI Provider implementation.
    """

    def __init__(self) -> None:

        super().__init__()

        self.api_key = os.getenv(

            "OPENAI_API_KEY",

            "",

        )

        self.client = (

            OpenAI(

                api_key=self.api_key,

            )

            if self.api_key

            else None

        )

    def default_model(self) -> str:

        return os.getenv(

            "OPENAI_MODEL",

            "gpt-5.5",

        )

    def available(self) -> bool:

        return (

            self.client is not None

        )

    def generate(

        self,

        prompt: str,

        *,

        temperature: float = 0.2,

        **kwargs: Any,

    ) -> str:

        if not self.available():

            raise RuntimeError(

                "OPENAI_API_KEY is not configured."

            )

        response = (

            self.client.chat.completions.create(

                model=self.model,

                messages=[

                    {

                        "role": "system",

                        "content": (

                            "You are QUANT AI Architect, "

                            "an autonomous senior software engineer."

                        ),

                    },

                    {

                        "role": "user",

                        "content": prompt,

                    },

                ],

                temperature=temperature,

                **kwargs,

            )

        )

        return (

            response

            .choices[0]

            .message

            .content

            or ""

        ).strip()

    def list_models(

        self,

    ) -> list[str]:

        if not self.available():

            return []

        models = self.client.models.list()

        return sorted(

            model.id

            for model in models.data

        )

    def embedding(

        self,

        text: str,

        model: str = "text-embedding-3-small",

    ) -> list[float]:

        if not self.available():

            raise RuntimeError(

                "OPENAI_API_KEY is not configured."

            )

        response = (

            self.client.embeddings.create(

                model=model,

                input=text,

            )

        )

        return (

            response

            .data[0]

            .embedding

        )
