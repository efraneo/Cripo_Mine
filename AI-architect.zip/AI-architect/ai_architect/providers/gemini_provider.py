"""
=========================================================
Gemini Provider
=========================================================
"""

from __future__ import annotations

import os
from typing import Any

import google.generativeai as genai

from ai_architect.providers.base_provider import (
    BaseProvider,
)


class GeminiProvider(BaseProvider):
    """
    Google Gemini Provider.
    """

    def __init__(self) -> None:

        super().__init__()

        self.api_key = os.getenv(

            "GOOGLE_API_KEY",

            "",

        )

        if self.api_key:

            genai.configure(

                api_key=self.api_key,

            )

            self.client = genai.GenerativeModel(

                self.model,

            )

        else:

            self.client = None

    def default_model(self) -> str:

        return os.getenv(

            "GEMINI_MODEL",

            "gemini-2.5-pro",

        )

    def available(self) -> bool:

        return self.client is not None

    def generate(

        self,

        prompt: str,

        *,

        temperature: float = 0.2,

        **kwargs: Any,

    ) -> str:

        if not self.available():

            raise RuntimeError(

                "GOOGLE_API_KEY is not configured."

            )

        response = self.client.generate_content(

            prompt,

            generation_config={

                "temperature": temperature,

            },

            **kwargs,

        )

        if not response.text:

            return ""

        return response.text.strip()

    def count_tokens(

        self,

        text: str,

    ) -> int:

        if not self.available():

            return 0

        try:

            result = self.client.count_tokens(

                text,

            )

            return result.total_tokens

        except Exception:

            return 0

    def models(self) -> list[str]:

        if not self.available():

            return []

        return [

            model.name

            for model in genai.list_models()

        ]
