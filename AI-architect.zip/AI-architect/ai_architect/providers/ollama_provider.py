"""
=========================================================
Ollama Provider
=========================================================
"""

from __future__ import annotations

import os
from typing import Any

import requests

from ai_architect.providers.base_provider import (
    BaseProvider,
)


class OllamaProvider(BaseProvider):
    """
    Ollama Local Provider.

    Uses the Ollama REST API.

    Default endpoint:

        http://localhost:11434
    """

    def __init__(self) -> None:

        super().__init__()

        self.base_url = os.getenv(

            "OLLAMA_URL",

            "http://localhost:11434",

        ).rstrip("/")

    def default_model(self) -> str:

        return os.getenv(

            "OLLAMA_MODEL",

            "qwen2.5-coder:32b",

        )

    def available(self) -> bool:

        try:

            response = requests.get(

                f"{self.base_url}/api/tags",

                timeout=3,

            )

            return response.status_code == 200

        except Exception:

            return False

    def generate(

        self,

        prompt: str,

        *,

        temperature: float = 0.2,

        **kwargs: Any,

    ) -> str:

        if not self.available():

            raise RuntimeError(

                "Ollama server is not available."

            )

        payload = {

            "model": self.model,

            "prompt": prompt,

            "stream": False,

            "options": {

                "temperature": temperature,

            },

        }

        payload.update(kwargs)

        response = requests.post(

            f"{self.base_url}/api/generate",

            json=payload,

            timeout=600,

        )

        response.raise_for_status()

        data = response.json()

        return data.get(

            "response",

            "",

        ).strip()

    def list_models(

        self,

    ) -> list[str]:

        if not self.available():

            return []

        response = requests.get(

            f"{self.base_url}/api/tags",

            timeout=10,

        )

        response.raise_for_status()

        models = response.json().get(

            "models",

            [],

        )

        return sorted(

            model["name"]

            for model in models

        )

    def pull(

        self,

        model: str,

    ) -> bool:

        response = requests.post(

            f"{self.base_url}/api/pull",

            json={

                "name": model,

            },

            timeout=None,

        )

        return response.status_code == 200

    def embeddings(

        self,

        text: str,

    ) -> list[float]:

        response = requests.post(

            f"{self.base_url}/api/embeddings",

            json={

                "model": self.model,

                "prompt": text,

            },

            timeout=300,

        )

        response.raise_for_status()

        data = response.json()

        return data.get(

            "embedding",

            [],

        )
