"""
=========================================================
OpenRouter Provider
=========================================================
"""

from __future__ import annotations

import os
from typing import Any

import requests

from ai_architect.providers.base_provider import (
    BaseProvider,
)


class OpenRouterProvider(BaseProvider):
    """
    OpenRouter Provider.

    Compatible with every model exposed by OpenRouter.

    https://openrouter.ai
    """

    API_URL = "https://openrouter.ai/api/v1/chat/completions"

    def __init__(self) -> None:

        super().__init__()

        self.api_key = os.getenv(

            "OPENROUTER_API_KEY",

            "",

        )

        self.site = os.getenv(

            "OPENROUTER_SITE",

            "https://github.com/efraneo/ia_architect",

        )

        self.app_name = os.getenv(

            "OPENROUTER_APP",

            "QUANT AI Architect",

        )

    def default_model(self) -> str:

        return os.getenv(

            "OPENROUTER_MODEL",

            "anthropic/claude-sonnet-4",

        )

    def available(self) -> bool:

        return bool(

            self.api_key

        )

    def generate(

        self,

        prompt: str,

        *,

        temperature: float = 0.2,

        **kwargs: Any,

    ) -> str:

        if not self.available():

            raise RuntimeError(

                "OPENROUTER_API_KEY is not configured."

            )

        headers = {

            "Authorization": (

                f"Bearer {self.api_key}"

            ),

            "HTTP-Referer": self.site,

            "X-Title": self.app_name,

            "Content-Type": "application/json",

        }

        payload = {

            "model": self.model,

            "messages": [

                {

                    "role": "system",

                    "content": (

                        "You are QUANT AI Architect, "

                        "an autonomous senior software architect."

                    ),

                },

                {

                    "role": "user",

                    "content": prompt,

                },

            ],

            "temperature": temperature,

        }

        payload.update(kwargs)

        response = requests.post(

            self.API_URL,

            headers=headers,

            json=payload,

            timeout=600,

        )

        response.raise_for_status()

        data = response.json()

        return (

            data["choices"][0]

            ["message"]

            ["content"]

            .strip()

        )

    def models(

        self,

    ) -> list[str]:

        response = requests.get(

            "https://openrouter.ai/api/v1/models",

            timeout=30,

        )

        response.raise_for_status()

        models = response.json().get(

            "data",

            [],

        )

        return sorted(

            model["id"]

            for model in models

        )

    def headers(

        self,

    ) -> dict[str, str]:

        return {

            "Authorization": (

                f"Bearer {self.api_key}"

            ),

            "HTTP-Referer": self.site,

            "X-Title": self.app_name,

        }

    def configuration(

        self,

    ) -> dict:

        return {

            "provider": "OpenRouter",

            "model": self.model,

            "site": self.site,

            "application": self.app_name,

            "available": self.available(),

        }
