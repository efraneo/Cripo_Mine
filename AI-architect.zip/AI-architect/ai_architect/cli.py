"""
=========================================================
QUANT AI Architect CLI
=========================================================
"""

from __future__ import annotations

import argparse
import json
import sys

from ai_architect.commands import (
    analyze,
    doctor,
    improve,
    review,
)


def build_parser() -> argparse.ArgumentParser:

    parser = argparse.ArgumentParser(
        prog="ai-architect",
        description="QUANT AI Architect",
    )

    parser.add_argument(
        "command",
        choices=[
            "analyze",
            "review",
            "improve",
            "doctor",
        ],
    )

    parser.add_argument(
        "project",
        nargs="?",
        default=".",
        help="Project directory",
    )

    parser.add_argument(
        "--file",
        default=None,
    )

    parser.add_argument(
        "--instruction",
        default="Improve code quality",
    )

    parser.add_argument(
        "--json",
        action="store_true",
    )

    return parser


def print_result(
    result,
    as_json: bool,
):

    if as_json:

        print(
            json.dumps(
                result,
                indent=4,
                default=str,
            )
        )

        return

    if isinstance(result, dict):

        for key, value in result.items():

            print(f"{key}: {value}")

        return

    print(result)


def main():

    parser = build_parser()

    args = parser.parse_args()

    if args.command == "doctor":

        result = doctor.run()

    elif args.command == "analyze":

        result = analyze.run(
            args.project,
        )

    elif args.command == "review":

        result = review.run(
            args.project,
        )

    elif args.command == "improve":

        result = improve.run(
            args.project,
            instruction=args.instruction,
            file=args.file,
        )

    else:

        parser.error("Unknown command.")

    print_result(
        result,
        args.json,
    )


if __name__ == "__main__":

    sys.exit(main())
