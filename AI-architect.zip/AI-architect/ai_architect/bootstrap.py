"""
=========================================================
Bootstrap
=========================================================
"""

from __future__ import annotations

from pathlib import Path

from ai_architect.logger.logger import Logger
from ai_architect.config.settings import Settings


class Bootstrap:

    def __init__(

        self,

        env_file: str | Path,

    ):

        self.settings = Settings(

            env_file

        )

        self.logger = Logger()

    def initialize(self):

        self.logger.info(

            "Initializing AI Architect"

        )

        self.logger.info(

            f"Project: "

            f"{self.settings.project_root}"

        )

        return self.settings
